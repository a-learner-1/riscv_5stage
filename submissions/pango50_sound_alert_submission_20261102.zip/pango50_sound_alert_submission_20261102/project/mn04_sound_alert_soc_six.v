`timescale 1ns/1ps
// Pango 50 sound-alert board top: ES8311 I2S -> 32 kHz -> MN04 features ->
// short/long snapshots -> one MN04 core plus template matcher -> motor and TFT.
// User-clock logic runs on the DDR controller's 100 MHz core clock; the 50 MHz
// board oscillator supplies the DDR reference and ES8311 MCLK/I2C setup.
module mn04_sound_alert_soc #(
    parameter integer CAPTURE_DIAGNOSTICS=0,
    parameter OP_FILE="C:/Studying_file/pango50_sound_alert_v1/training/output/dual_window_integer_full/op_desc_five_class.mem",
    parameter SOFTMAX_LUT_FILE="C:/Studying_file/pango50_sound_alert_v1/training/output/dual_window_integer_full/softmax_exp_q24_five_class.mem",
    parameter EIGHT_CLASS_MODE=0,
    parameter SIX_CLASS_MODE=1,
    parameter integer CURRENT_FIVE_CLASS_MODE=1,
    parameter integer ENABLE_CPU_CONTROL=1,
    parameter integer ENABLE_CPU_TASK_CONTROL=1,
    parameter CPU_FIRMWARE_FILE="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/control_cpu5.mem",
    parameter [23:0] LUTS_BASE_FIVE=24'd799858,
    parameter [23:0] LUTS_BASE_EIGHT=24'd799858,
    parameter [23:0] IMAGE_BYTES_FIVE=24'd811890,
    parameter [31:0] IMAGE_CHECKSUM_FIVE=32'h053e2a11,
    parameter [23:0] IMAGE_BYTES_EIGHT=24'd812685,
    parameter [31:0] IMAGE_CHECKSUM_EIGHT=32'h053E4CB2,
    parameter [23:0] LUTS_BASE_SIX=24'd799858,
    parameter [23:0] IMAGE_BYTES_SIX=24'd811890,
    parameter [31:0] IMAGE_CHECKSUM_SIX=32'h053dce80,
    parameter OP_FILE_EIGHT="C:/Studying_file/pango50_sound_alert_v1/training/output/pc_8class_export_hwref_20261022_final_mode_masked_fa20/op_desc_100f_eight_class.mem",
    parameter SOFTMAX_LUT_FILE_EIGHT="C:/Studying_file/pango50_sound_alert_v1/training/output/pc_8class_export_hwref_20261022_final_mode_masked_fa20/softmax_exp_q24_eight_class.mem",
    parameter OP_FILE_SIX="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_five_cpu_acceptance_final_20261027/op_desc_120f_six_class.mem",
    parameter SOFTMAX_LUT_FILE_SIX="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_five_cpu_acceptance_final_20261027/softmax_exp_q24_six_class.mem",
    parameter integer CLASS_WINDOW_MODE=1,
    parameter integer UNIFORM_120_WINDOW_MODE=1,
    // 1 = template-only board test: the CNN core is never started and softmax
    // results never reach the alert path, so only matcher hits can alert.
    parameter integer TEMPLATE_ONLY_MODE=0,
    parameter [15:0] BABY_THRESHOLD_Q16=16'd29491,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hb333,
    parameter [15:0] SIREN_THRESHOLD_Q16=16'd61298,
    parameter [15:0] FIRE_TRUCK_THRESHOLD_Q16=16'd23360,
    parameter [15:0] AMBULANCE_THRESHOLD_Q16=16'd16262,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'h170a,
    parameter [15:0] EMERGENCY_VEHICLE_THRESHOLD_Q16=16'h4ccd,
    parameter CNN_TEMPLATE_FILE="",
    parameter [23:0] CNN_TEMPLATE_VALID_MASK=24'h000000,
    parameter integer CNN_TEMPLATE_WEIGHT_Q2=1,
    parameter TEMPLATE_FILE="",
    parameter integer TEMPLATE_DOORBELL_MAPS=5,
    parameter integer TEMPLATE_SMOKE_ALARM_MAPS=5,
    parameter integer TEMPLATE_GAS_CO_ALARM_MAPS=5,
    parameter integer ENABLE_TEMPLATE_CAPTURE=1,
    parameter integer ENABLE_LOCAL_TEMPLATE_ENROLLMENT=1,
    parameter integer ENABLE_SD_TEMPLATE_STORAGE=1,
    parameter integer TEMPLATE_MAPS_PER_CLASS=5,
    parameter integer TEMPLATE_DDR_STORAGE=1,
    parameter [3*TEMPLATE_MAPS_PER_CLASS-1:0] TEMPLATE_INITIAL_VALID_MASK=15'd0,
    parameter [15:0] TEMPLATE_THRESHOLD_Q15=16'd18022,
    parameter integer TEMPLATE_CENTER_ALPHA_Q4=8,
    parameter integer TEMPLATE_FLASH_LOAD=0,
    parameter [23:0] TEMPLATE_FLASH_BASE=24'h610080,
    parameter [23:0] TEMPLATE_CONTAINER_BYTES=24'd104961
)(
    input wire clk,rst_n,
    input wire es8311_bclk_i,es8311_lrck_i,es8311_dout_i,
    output wire es8311_mclk_o,es8311_scl_o,
    inout wire es8311_sda_io,
    input wire gpio_mode_btn_n_i,gpio_history_next_btn_n_i,
    input wire gpio_template_next_btn_n_i,gpio_template_capture_btn_n_i,
    input wire gpio_capture_stop_btn_n_i,gpio_capture_mode_btn_n_i,
    input wire uart_rx_i,
    output wire uart_tx_o,
    output wire motor_in_o,
    output wire tft_nrst_o,tft_backlight_o,tft_sclk_o,
    output wire tft_mosi_o,tft_dc_o,tft_cs_n_o,
    output wire qspi_cs_o,qspi_sck_o,qspi_mosi_o,
    input wire qspi_miso_i,
    input wire sd_card_detect_n_i,sd_miso_i,
    output wire sd_clk_o,sd_cs_n_o,sd_mosi_o,
    output wire ddr_rst_n,ddr_ck,ddr_ck_n,ddr_cke,ddr_cs_n,
    output wire ddr_ras_n,ddr_cas_n,ddr_we_n,ddr_odt,
    output wire [14:0] ddr_a,
    output wire [2:0] ddr_ba,
    inout wire [3:0] ddr_dqs,ddr_dqs_n,
    inout wire [31:0] ddr_dq,
    output wire [3:0] ddr_dm
);
    localparam integer ACTIVE_CLASSES = CURRENT_FIVE_CLASS_MODE ? 5 : (SIX_CLASS_MODE ? 6 : (EIGHT_CLASS_MODE ? 8 : 5));
    localparam ACTIVE_OP_FILE = SIX_CLASS_MODE ? OP_FILE_SIX : (EIGHT_CLASS_MODE ? OP_FILE_EIGHT : OP_FILE);
    localparam ACTIVE_SOFTMAX_FILE = SIX_CLASS_MODE ? SOFTMAX_LUT_FILE_SIX : (EIGHT_CLASS_MODE ? SOFTMAX_LUT_FILE_EIGHT : SOFTMAX_LUT_FILE);
    localparam [23:0] ACTIVE_LUTS_BASE = SIX_CLASS_MODE ? LUTS_BASE_SIX : (EIGHT_CLASS_MODE ? LUTS_BASE_EIGHT : LUTS_BASE_FIVE);
    localparam [23:0] ACTIVE_IMAGE_BYTES = SIX_CLASS_MODE ? IMAGE_BYTES_SIX : (EIGHT_CLASS_MODE ? IMAGE_BYTES_EIGHT : IMAGE_BYTES_FIVE);
    localparam [31:0] ACTIVE_IMAGE_CHECKSUM = SIX_CLASS_MODE ? IMAGE_CHECKSUM_SIX : (EIGHT_CLASS_MODE ? IMAGE_CHECKSUM_EIGHT : IMAGE_CHECKSUM_FIVE);
    wire ddr_clk,ddr_init_done,ddr_pll_lock;
    // full AXI4 fabric side (byte addresses, five channels)
    wire [27:0] ddr_awaddr,ddr_araddr;
    wire [3:0] ddr_awlen,ddr_arlen;
    wire ddr_awvalid,ddr_arvalid,ddr_awready,ddr_arready;
    wire [255:0] ddr_wdata,ddr_rdata;
    wire [31:0] ddr_wstrb;
    wire ddr_wvalid,ddr_wlast,ddr_wready;
    wire [1:0] ddr_bresp,ddr_rresp;
    wire ddr_bvalid,ddr_bready;
    wire ddr_rlast,ddr_rvalid,ddr_rready;
    // stripped Pango DDR user port (bridge -> ddr3_host_top)
    wire [27:0] host_awaddr,host_araddr;
    wire [3:0] host_awlen,host_arlen;
    wire host_awvalid,host_arvalid,host_awready,host_arready;
    wire [255:0] host_wdata,host_rdata;
    wire [31:0] host_wstrb;
    wire host_wready,host_rlast,host_rvalid;
    ddr3_host_top ddr_host (
        .ref_clk(clk),.resetn(rst_n),
        .core_clk_o(ddr_clk),.init_done_o(ddr_init_done),
        .pll_lock_o(ddr_pll_lock),
        .awaddr_i(host_awaddr),.awlen_i(host_awlen),
        .awvalid_i(host_awvalid),.awready_o(host_awready),
        .wdata_i(host_wdata),.wstrb_i(host_wstrb),.wready_o(host_wready),
        .araddr_i(host_araddr),.arlen_i(host_arlen),
        .arvalid_i(host_arvalid),.arready_o(host_arready),
        .rdata_o(host_rdata),.rlast_o(host_rlast),.rvalid_o(host_rvalid),
        .mem_rst_n(ddr_rst_n),.mem_ck(ddr_ck),.mem_ck_n(ddr_ck_n),
        .mem_cke(ddr_cke),.mem_cs_n(ddr_cs_n),
        .mem_ras_n(ddr_ras_n),.mem_cas_n(ddr_cas_n),
        .mem_we_n(ddr_we_n),.mem_odt(ddr_odt),
        .mem_a(ddr_a),.mem_ba(ddr_ba),
        .mem_dqs(ddr_dqs),.mem_dqs_n(ddr_dqs_n),
        .mem_dq(ddr_dq),.mem_dm(ddr_dm));

    reg [1:0] ddr_reset_sync;
    always @(posedge ddr_clk or negedge rst_n) begin
        if(!rst_n) ddr_reset_sync<=2'b00;
        else ddr_reset_sync<={ddr_reset_sync[0],ddr_init_done && ddr_pll_lock};
    end
    wire core_rst_n=ddr_reset_sync[1];

    mn04_axi4_ddr_bridge u_ddr_bridge (
        .clk(ddr_clk),.rst_n(core_rst_n),
        .s_awaddr(ddr_awaddr),.s_awlen(ddr_awlen),
        .s_awvalid(ddr_awvalid),.s_awready(ddr_awready),
        .s_wdata(ddr_wdata),.s_wstrb(ddr_wstrb),
        .s_wvalid(ddr_wvalid),.s_wlast(ddr_wlast),.s_wready(ddr_wready),
        .s_bresp(ddr_bresp),.s_bvalid(ddr_bvalid),.s_bready(ddr_bready),
        .s_araddr(ddr_araddr),.s_arlen(ddr_arlen),
        .s_arvalid(ddr_arvalid),.s_arready(ddr_arready),
        .s_rdata(ddr_rdata),.s_rresp(ddr_rresp),
        .s_rlast(ddr_rlast),.s_rvalid(ddr_rvalid),.s_rready(ddr_rready),
        .d_awaddr(host_awaddr),.d_awlen(host_awlen),
        .d_awvalid(host_awvalid),.d_awready(host_awready),
        .d_wdata(host_wdata),.d_wstrb(host_wstrb),.d_wready(host_wready),
        .d_araddr(host_araddr),.d_arlen(host_arlen),
        .d_arvalid(host_arvalid),.d_arready(host_arready),
        .d_rdata(host_rdata),.d_rlast(host_rlast),.d_rvalid(host_rvalid));
    reg boot_start_r,boot_started_r;
    always @(posedge ddr_clk or negedge core_rst_n) begin
        if(!core_rst_n) begin boot_start_r<=0;boot_started_r<=0;end
        else begin
            boot_start_r<=!boot_started_r;
            boot_started_r<=1;
        end
    end

    wire mclk_unused_25m,mclk_locked,codec_init_done,codec_error;
    es8311_mclk_pll u_mclk (
        .clkin1(clk),.clkout0(es8311_mclk_o),
        .sysclk_out(mclk_unused_25m),.pll_lock(mclk_locked));
    es8311_i2c_init #(.CLOCK_HZ(50000000)) u_codec_init (
        .clk(clk),.scl_o(es8311_scl_o),.sda_io(es8311_sda_io),
        .done_o(codec_init_done),.error_o(codec_error));
    // DIAG: fallback-gated codec ready.  ES8311 init has only a soft retry
    // loop and no hard timeout, so if it stalls, audio would stay frozen and
    // both CNN and template recognition would silently fail while the display
    // works.  Force ready after 800 ms so we can observe the audio link.
    wire codec_ready_ret;
    mn04_codec_ready_tmo #(.CLOCK_HZ(100000000),.FORCE_MS(800))
        u_codec_tmo (.clk(ddr_clk),.rst_n(core_rst_n),
        .codec_init_done_i(codec_init_done),.mclk_locked_i(mclk_locked),
        .codec_error_i(codec_error),.codec_ready_sync_o(codec_ready_ret));
    reg [1:0] codec_ready_sync;
    always @(posedge ddr_clk or negedge core_rst_n) begin
        if(!core_rst_n) codec_ready_sync<=2'b00;
        else codec_ready_sync<={codec_ready_sync[0],codec_ready_ret};
    end

    wire [3:0] capture_selected_class;
    wire short_ready,long_ready,short_accept,long_accept;
    wire template_result_valid;
    wire [1:0] template_result_class;
    wire [15:0] template_result_score_q15;
    wire [95:0] template_diag;
    wire boot_init_done,x0_overflow,pcm_overflow;
    wire capture_task_busy,capture_recording;
    wire recognition_enable,work_mode,panel_ready,panel_busy;
    wire [5:0] physical_key_n={gpio_capture_mode_btn_n_i,gpio_capture_stop_btn_n_i,
        gpio_template_capture_btn_n_i,gpio_template_next_btn_n_i,
        gpio_history_next_btn_n_i,gpio_mode_btn_n_i};
    wire [5:0] control_key_n;
    wire cpu_job_authorized,cpu_event_valid,cpu_probs_valid,cpu_job_done;
    wire [3:0] cpu_event_class,cpu_template_slot;
    wire [95:0] cpu_probs;
    wire fabric_uart_tx,prob_dump_tx,prob_dump_busy;
    wire banner_tx,banner_busy;
    wire banner_valid,banner_ready;
    wire [7:0] banner_data;
    wire [14:0] cpu_template_slot_mask;
    wire cpu_template_commit;
    wire control_uart_rx=ENABLE_CPU_CONTROL ? 1'b1 : uart_rx_i;
    // Declared early so the boot-banner state word can sample them before the
    // audio frontend instantiation that normally declares them.
    wire signed [7:0] x0;
    wire x0_valid;

    // DIAG: boot banner printed as soon as the core clock is up, so the serial
    // link health is visible without needing the codec/audio path to work.  It
    // also appends one state word reporting where the live audio/recognition
    // pipeline stands, using hard-wired nets (no dependence on the paths it
    // probes).  banner_busy drops after this single line, so P= still prints.
    mn04_boot_banner #(.CLOCK_HZ(100000000)) u_boot_banner (
        .clk(ddr_clk),.rst_n(core_rst_n),
        .core_rst_n_i(core_rst_n),.boot_init_done_i(boot_init_done),
        .codec_ready_i(codec_ready_sync[1]),
        .recognition_enable_i(recognition_enable),
        .pcm_overflow_i(pcm_overflow),.x0_overflow_i(x0_overflow),
        .x0_valid_i(x0_valid),.template_diag_i(template_diag),
        .valid_o(banner_valid),.data_o(banner_data),.ready_i(banner_ready));
    uart_tx_8n1 #(.CLOCK_HZ(100000000),.BAUD(115200)) u_banner_tx (
        .clk(ddr_clk),.rst_n(core_rst_n),.data_i(banner_data),
        .valid_i(banner_valid),.ready_o(banner_ready),.tx_o(banner_tx));
    assign banner_busy = banner_valid;

    // Diagnostic tap: every CNN result is printed as one ASCII line so the
    // host can read the probabilities the decision actually used.
    mn04_prob_uart_dump #(.CLOCK_HZ(100000000),.BAUD(115200)) u_prob_dump (
        .clk(ddr_clk),.rst_n(core_rst_n),
        .valid_i(cpu_probs_valid),.probs_q16_i(cpu_probs),
        .busy_o(prob_dump_busy),.tx_o(prob_dump_tx));
    assign uart_tx_o = banner_busy ? banner_tx :
                       (prob_dump_busy ? prob_dump_tx : fabric_uart_tx);
    generate if(ENABLE_CPU_TASK_CONTROL) begin:g_cpu_tasks
        mn04_cpu5_control_cdc #(.CLOCK_HZ(50000000),.FIRMWARE_FILE(CPU_FIRMWARE_FILE),
            .BABY_THRESHOLD(BABY_THRESHOLD_Q16),.KNOCK_THRESHOLD(KNOCK_THRESHOLD_Q16),
            .SIREN_THRESHOLD(EMERGENCY_VEHICLE_THRESHOLD_Q16),.CAR_THRESHOLD(CAR_HORN_THRESHOLD_Q16),
            .TEMPLATE_THRESHOLD(TEMPLATE_THRESHOLD_Q15)) supervisor(
            .src_clk_i(ddr_clk),.cpu_clk_i(clk),.rst_n(rst_n),.core_rst_n_i(core_rst_n),.key_n_i(physical_key_n),
            .boot_ready_i(boot_init_done),.codec_ready_i(codec_ready_sync[1]),
            .recognition_i(recognition_enable),.capture_busy_i(capture_task_busy),
            .recording_i(capture_recording),.alert_i(motor_in_o),
            .snapshot_ready_i(short_ready),.job_done_i(cpu_job_done),
            .cnn_valid_i(cpu_probs_valid),.cnn_probabilities_i(cpu_probs),
            .template_valid_i(template_result_valid),.template_class_i(template_result_class),
            .template_score_i(template_result_score_q15),.capture_category_i(capture_selected_class),
            .template_slot_mask_i(cpu_template_slot_mask),.template_commit_i(cpu_template_commit),
            .command_key_n_o(control_key_n),.job_authorized_o(cpu_job_authorized),
            .template_slot_o(cpu_template_slot),.event_valid_o(cpu_event_valid),.event_class_o(cpu_event_class),
            .firmware_signature_o(),.command_count_o(),.irq_count_o(),.isa_selftest_o());
    end else if(ENABLE_CPU_CONTROL) begin:g_cpu_supervisor
        mn04_vexriscv_supervisor #(.FIRMWARE_FILE(CPU_FIRMWARE_FILE)) supervisor(
            .clk(ddr_clk),.rst_n(core_rst_n),.key_n_i(physical_key_n),
            .boot_ready_i(boot_init_done),.codec_ready_i(codec_ready_sync[1]),
            .recognition_i(recognition_enable),.capture_busy_i(capture_task_busy),
            .recording_i(capture_recording),.alert_i(motor_in_o),
            .command_key_n_o(control_key_n),.firmware_signature_o(),.command_count_o());
    end else begin:g_direct_keys
        assign control_key_n=physical_key_n;
    end endgenerate
    generate if(!ENABLE_CPU_TASK_CONTROL) begin:g_no_cpu_tasks
        assign cpu_job_authorized=1'b1;
        assign cpu_event_valid=1'b0;
        assign cpu_event_class=4'd0;
        assign cpu_template_slot=4'd0;
    end endgenerate
    wire [23:0] capture_ring_base;
    wire template_preview_enable,template_category_advance,template_capture_mode;
    // Only show the armed capture class while the template-capture switch is on.
    // An always-on preview used the alarm renderer, so an idle board looked like
    // a permanently detected class.
    wire preview_visible = template_preview_enable;
    wire template_capture_start,template_capture_stop;
    // Capture protocol IDs are dense (CNN classes first, then three template
    // classes). The screen keeps the existing asset IDs 8/9/10 for the three
    // preset template previews; CNN background remains display ID 11.
    wire [3:0] selected_preview_class =
        (capture_selected_class < ACTIVE_CLASSES) ?
            ((capture_selected_class==4'd0) ? 4'd11 :
             ((CURRENT_FIVE_CLASS_MODE && capture_selected_class==4'd4) ? 4'd5 : capture_selected_class)) :
            (capture_selected_class - ACTIVE_CLASSES + 4'd8);
    // The codec keeps its external clocks running, but the FPGA audio receive,
    // resample, PCM FIFO and Mel/FFT frontend are active only during a user
    // recognition session or a UART capture task. This lets the complete
    // internal audio path stop after one-shot recognition/capture completion.
    // Pause the microphone/Mel frontend while the frozen class batch is sent;
    // the selected CNN category is latched before recording begins.
    wire audio_task_active = recognition_enable || capture_recording;
    wire audio_rst_n=core_rst_n && boot_init_done && codec_ready_sync[1] &&
                     audio_task_active;
    wire signed [15:0] capture_pcm_debug;
    wire capture_pcm_debug_valid;
    mn04_audio_capture_frontend u_audio (
        .clk(ddr_clk),.rst_n(audio_rst_n),
        .es8311_bclk_i(es8311_bclk_i),
        .es8311_lrck_i(es8311_lrck_i),
        .es8311_dout_i(es8311_dout_i),
        .x0_o(x0),.x0_valid_o(x0_valid),
        .pcm_overflow_o(pcm_overflow),
        .pcm_debug_o(capture_pcm_debug),.pcm_debug_valid_o(capture_pcm_debug_valid));

    wire [1:0] short_mode,core_class_window_mode;
    wire core_start,core_short,core_context_short,core_busy,core_done;
    wire [8:0] core_start_op,core_end_op;
    wire core_logits_valid;
    wire [8*ACTIVE_CLASSES-1:0] core_logits;
    wire window_quiet;
    wire display_asset_we;
    wire [14:0] display_asset_addr;
    wire [7:0] display_asset_data;
    mn04_board_capture_keys #(.CLOCK_HZ(100000000)) u_template_keys (
        .clk(ddr_clk),.rst_n(core_rst_n),
        .category_key_n_i(control_key_n[2]),
        .start_key_n_i(control_key_n[3]),
        .stop_key_n_i(control_key_n[4]),
        .mode_key_n_i(control_key_n[5]),
        .recognition_enable_i(recognition_enable),
        .capture_busy_i(capture_task_busy),
        .capture_recording_i(capture_recording),
        .category_advance_o(template_category_advance),
        .template_mode_o(template_capture_mode),
        .preview_enable_o(template_preview_enable),
        .capture_start_o(template_capture_start),
        .capture_stop_o(template_capture_stop));
    generate if (SIX_CLASS_MODE) begin : g_six_class_control
        mn04_six_class_realtime_control #(
            .CURRENT_FIVE_CLASS_MODE(CURRENT_FIVE_CLASS_MODE),
            .CPU_TASK_CONTROL(ENABLE_CPU_TASK_CONTROL),
            .SOFTMAX_LUT_FILE(ACTIVE_SOFTMAX_FILE),
            .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
            .UNIFORM_120_WINDOW_MODE(UNIFORM_120_WINDOW_MODE),
            .TEMPLATE_ONLY_MODE(TEMPLATE_ONLY_MODE),
            .CNN_TEMPLATE_FILE(CNN_TEMPLATE_FILE),
            .CNN_TEMPLATE_VALID_MASK(CNN_TEMPLATE_VALID_MASK),
            .CNN_TEMPLATE_WEIGHT_Q2(CNN_TEMPLATE_WEIGHT_Q2),
            .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
            .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
            .EMERGENCY_VEHICLE_THRESHOLD_Q16(EMERGENCY_VEHICLE_THRESHOLD_Q16),
            .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
            .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16),
            .CLOCK_HZ(100000000),.SPI_HZ(5000000)) u_control (
            .clk(ddr_clk),.rst_n(core_rst_n),.short_snapshot_ready_i(short_ready),
            .short_snapshot_mode_i(short_mode),.core_busy_i(core_busy),
            .core_done_i(core_done),.core_logits_valid_i(core_logits_valid),
            .core_logits_i({{(48-8*ACTIVE_CLASSES){1'b0}},core_logits}),
            .window_quiet_i(window_quiet),
            .template_result_valid_i(template_result_valid),
            .template_result_class_i(template_result_class),
            .cpu_job_authorized_i(cpu_job_authorized),.cpu_event_valid_i(cpu_event_valid),
            .cpu_event_class_i(cpu_event_class),.cpu_probs_valid_o(cpu_probs_valid),
            .cpu_probs_o(cpu_probs),.cpu_job_done_o(cpu_job_done),
            .display_asset_we_i(display_asset_we),
            .display_asset_addr_i(display_asset_addr),.display_asset_data_i(display_asset_data),
            .work_key_n_i(control_key_n[0]),.confirm_key_n_i(control_key_n[1]),
            .template_preview_i(preview_visible),
            .template_preview_class_i(selected_preview_class),
            .uart_rx_i(control_uart_rx),.external_task_busy_i(capture_task_busy),
            .set_time_i(1'b0),.set_hour_i(8'd0),.set_minute_i(8'd0),.set_second_i(8'd0),
            .core_start_o(core_start),.core_start_op_o(core_start_op),
            .core_end_op_o(core_end_op),.core_short_window_o(core_short),
            .core_context_short_o(core_context_short),
            .core_class_window_mode_o(core_class_window_mode),
            .short_snapshot_accept_o(short_accept),.short_result_valid_o(),
            .motor_o(motor_in_o),.recognition_enable_o(recognition_enable),
            .work_mode_o(work_mode),.panel_ready_o(panel_ready),.panel_busy_o(panel_busy),
            .tft_nrst_o(tft_nrst_o),.tft_backlight_o(tft_backlight_o),
            .tft_sclk_o(tft_sclk_o),.tft_mosi_o(tft_mosi_o),
            .tft_dc_o(tft_dc_o),.tft_cs_n_o(tft_cs_n_o));
        assign long_accept=1'b0;
    end else if (EIGHT_CLASS_MODE) begin : g_eight_class_control
        mn04_eight_class_realtime_control #(
            .SOFTMAX_LUT_FILE(ACTIVE_SOFTMAX_FILE),
            .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
            .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
            .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
            .SIREN_THRESHOLD_Q16(SIREN_THRESHOLD_Q16),
            .FIRE_TRUCK_THRESHOLD_Q16(FIRE_TRUCK_THRESHOLD_Q16),
            .AMBULANCE_THRESHOLD_Q16(AMBULANCE_THRESHOLD_Q16),
            .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
            .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16),
            .CLOCK_HZ(100000000),.SPI_HZ(5000000)) u_control (
            .clk(ddr_clk),.rst_n(core_rst_n),.short_snapshot_ready_i(short_ready),
            .short_snapshot_mode_i(short_mode),
            .core_busy_i(core_busy),.core_done_i(core_done),
            .core_logits_valid_i(core_logits_valid),.core_logits_i(core_logits),
            .window_quiet_i(window_quiet),
            .template_result_valid_i(template_result_valid),
            .template_result_class_i(template_result_class),
            .display_asset_we_i(display_asset_we),
            .display_asset_addr_i(display_asset_addr),
            .display_asset_data_i(display_asset_data),
            .work_key_n_i(control_key_n[0]),.confirm_key_n_i(control_key_n[1]),
            .template_preview_i(preview_visible),
            .template_preview_class_i(selected_preview_class),
            .uart_rx_i(control_uart_rx),.external_task_busy_i(capture_task_busy),
            .set_time_i(1'b0),.set_hour_i(8'd0),
            .set_minute_i(8'd0),.set_second_i(8'd0),.core_start_o(core_start),
            .core_start_op_o(core_start_op),.core_end_op_o(core_end_op),
            .core_short_window_o(core_short),.core_context_short_o(core_context_short),
            .core_class_window_mode_o(core_class_window_mode),
            .short_snapshot_accept_o(short_accept),.short_result_valid_o(),
            .motor_o(motor_in_o),.recognition_enable_o(recognition_enable),
            .work_mode_o(work_mode),.panel_ready_o(panel_ready),.panel_busy_o(panel_busy),
            .tft_nrst_o(tft_nrst_o),.tft_backlight_o(tft_backlight_o),
            .tft_sclk_o(tft_sclk_o),.tft_mosi_o(tft_mosi_o),
            .tft_dc_o(tft_dc_o),.tft_cs_n_o(tft_cs_n_o));
        assign long_accept=1'b0;
    end else begin : g_five_class_control
    assign core_class_window_mode=2'd0;
    mn04_five_class_realtime_control #(
        .SOFTMAX_LUT_FILE(ACTIVE_SOFTMAX_FILE),
        .CLOCK_HZ(100000000),.SPI_HZ(5000000)) u_control (
        .clk(ddr_clk),.rst_n(core_rst_n),
        .short_snapshot_ready_i(short_ready),
        .long_snapshot_ready_i(long_ready),
        .core_busy_i(core_busy),.core_done_i(core_done),
        .core_logits_valid_i(core_logits_valid),
        .core_logits_i(core_logits),
        .template_result_valid_i(template_result_valid),
        .template_result_class_i(template_result_class),
        .display_asset_we_i(display_asset_we),
        .display_asset_addr_i(display_asset_addr),
        .display_asset_data_i(display_asset_data),
        .work_key_n_i(control_key_n[0]),
        .confirm_key_n_i(control_key_n[1]),
        .template_preview_i(preview_visible),
        .template_preview_class_i(selected_preview_class),
        .uart_rx_i(control_uart_rx),
        .external_task_busy_i(capture_task_busy),
        .set_time_i(1'b0),.set_hour_i(8'd0),
        .set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(core_start),
        .core_start_op_o(core_start_op),
        .core_end_op_o(core_end_op),
        .core_short_window_o(core_short),
        .core_context_short_o(core_context_short),
        .short_snapshot_accept_o(short_accept),
        .long_snapshot_accept_o(long_accept),
        .short_result_valid_o(),.long_result_valid_o(),
        .motor_o(motor_in_o),
        .recognition_enable_o(recognition_enable),
        .work_mode_o(work_mode),
        .panel_ready_o(panel_ready),.panel_busy_o(panel_busy),
        .tft_nrst_o(tft_nrst_o),
        .tft_backlight_o(tft_backlight_o),
        .tft_sclk_o(tft_sclk_o),.tft_mosi_o(tft_mosi_o),
        .tft_dc_o(tft_dc_o),.tft_cs_n_o(tft_cs_n_o));
    end endgenerate

    mn04_runtime_fabric #(.OP_FILE(ACTIVE_OP_FILE),.FAST_BYTES(0),
        .CAPTURE_DIAGNOSTICS(CAPTURE_DIAGNOSTICS),
        .CLASS_WINDOW_MODE((EIGHT_CLASS_MODE || SIX_CLASS_MODE) && CLASS_WINDOW_MODE),
        .UNIFORM_120_WINDOW(UNIFORM_120_WINDOW_MODE),
        .LUTS_BASE(ACTIVE_LUTS_BASE),
        .ENABLE_TEMPLATE_CAPTURE(ENABLE_TEMPLATE_CAPTURE),
        .ENABLE_LOCAL_TEMPLATE_ENROLLMENT(ENABLE_LOCAL_TEMPLATE_ENROLLMENT),
        .ENABLE_SD_TEMPLATE_STORAGE(ENABLE_SD_TEMPLATE_STORAGE),
        .TEMPLATE_MAPS_PER_CLASS(TEMPLATE_MAPS_PER_CLASS),.TEMPLATE_DDR_STORAGE(TEMPLATE_DDR_STORAGE),
        .CPU_TEMPLATE_SLOT_SELECT(ENABLE_CPU_TASK_CONTROL),
        .IMAGE_BYTES(ACTIVE_IMAGE_BYTES),
        .IMAGE_CHECKSUM_EXPECTED(ACTIVE_IMAGE_CHECKSUM),
        .FLASH_IMAGE_BASE(24'h400000),.CACHE_LINE_BITS(8),
        .CNN_CLASS_COUNT(ACTIVE_CLASSES),
        .SHORT_HOP_FRAMES((EIGHT_CLASS_MODE || SIX_CLASS_MODE) ? 50 : 75),
        .ENABLE_LONG_WINDOW((EIGHT_CLASS_MODE || SIX_CLASS_MODE) ? 0 : 1),
        .N_CLASSES(ACTIVE_CLASSES),
        .TEMPLATE_FILE(TEMPLATE_FILE),
        .TEMPLATE_DOORBELL_MAPS(TEMPLATE_DOORBELL_MAPS),
        .TEMPLATE_SMOKE_ALARM_MAPS(TEMPLATE_SMOKE_ALARM_MAPS),
        .TEMPLATE_GAS_CO_ALARM_MAPS(TEMPLATE_GAS_CO_ALARM_MAPS),
        .TEMPLATE_INITIAL_VALID_MASK(TEMPLATE_INITIAL_VALID_MASK),
        .TEMPLATE_THRESHOLD_Q15(TEMPLATE_THRESHOLD_Q15),
        .TEMPLATE_CENTER_ALPHA_Q4(TEMPLATE_CENTER_ALPHA_Q4),
        .TEMPLATE_FLASH_LOAD(TEMPLATE_FLASH_LOAD),
        .TEMPLATE_FLASH_BASE(TEMPLATE_FLASH_BASE),
        .TEMPLATE_CONTAINER_BYTES(TEMPLATE_CONTAINER_BYTES)) u_fabric (
        .clk(ddr_clk),.rst_n(core_rst_n),.boot_start_i(boot_start_r),
        // Keep the raw frontend valid clocking the DDR-side frame phase tracker;
        // runtime_fabric gates writes on task state at frame boundaries.
        .x0_i(x0),.x0_valid_i(x0_valid && audio_rst_n),
        .pcm_overflow_i(pcm_overflow),
        .capture_pcm_debug_i(capture_pcm_debug),.capture_pcm_debug_valid_i(capture_pcm_debug_valid),
        .recognition_enable_i(recognition_enable && !pcm_overflow),
        .short_snapshot_accept_i(short_accept),
        .long_snapshot_accept_i(long_accept),
        .short_snapshot_ready_o(short_ready),
        .short_snapshot_mode_o(short_mode),
        .long_snapshot_ready_o(long_ready),
        .x0_overflow_o(x0_overflow),.boot_init_done_o(boot_init_done),
        .core_start_i(core_start && !pcm_overflow && !x0_overflow),
        .core_start_op_i(core_start_op),.core_end_op_i(core_end_op),
        .core_short_window_i(core_short),
        .core_context_short_i(core_context_short),
        .core_class_window_mode_i(core_class_window_mode),
        .core_busy_o(core_busy),.core_done_o(core_done),
        .core_logits_valid_o(core_logits_valid),
        .core_logits_o(core_logits),
        .window_quiet_o(window_quiet),.template_result_valid_o(template_result_valid),
        .template_result_class_o(template_result_class),
        .template_result_score_q15_o(template_result_score_q15),
        .display_asset_we_o(display_asset_we),
        .display_asset_addr_o(display_asset_addr),
        .display_asset_data_o(display_asset_data),
        .boot_flash_rd_addr_o(),.core_flash_rd_addr_o(),
        .boot_flash_rd_data_i(8'd0),.core_flash_rd_data_i(8'd0),
        .qspi_cs_o(qspi_cs_o),.qspi_sck_o(qspi_sck_o),
        .qspi_mosi_o(qspi_mosi_o),.qspi_miso_i(qspi_miso_i),
        .sd_card_detect_n_i(sd_card_detect_n_i),.sd_miso_i(sd_miso_i),
        .sd_clk_o(sd_clk_o),.sd_cs_n_o(sd_cs_n_o),.sd_mosi_o(sd_mosi_o),
        .uart_rx_i(control_uart_rx),.uart_tx_o(fabric_uart_tx),
        .template_capture_category_advance_i(template_category_advance),
        .template_capture_start_i(template_capture_start),
        .template_capture_stop_i(template_capture_stop),
        .template_capture_mode_i(template_capture_mode),
        .capture_task_busy_o(capture_task_busy),
        .template_diag_o(template_diag),.capture_recording_o(capture_recording),
        .capture_selected_category_o(capture_selected_class),
        .cpu_template_slot_i(cpu_template_slot),
        .cpu_template_slot_mask_o(cpu_template_slot_mask),
        .cpu_template_commit_o(cpu_template_commit),
        .capture_ring_base_o(capture_ring_base),
        .ddr_awaddr_o(ddr_awaddr),.ddr_araddr_o(ddr_araddr),
        .ddr_awlen_o(ddr_awlen),.ddr_arlen_o(ddr_arlen),
        .ddr_awvalid_o(ddr_awvalid),.ddr_arvalid_o(ddr_arvalid),
        .ddr_awready_i(ddr_awready),.ddr_arready_i(ddr_arready),
        .ddr_wdata_o(ddr_wdata),.ddr_wstrb_o(ddr_wstrb),
        .ddr_wvalid_o(ddr_wvalid),.ddr_wlast_o(ddr_wlast),
        .ddr_wready_i(ddr_wready),
        .ddr_bresp_i(ddr_bresp),.ddr_bvalid_i(ddr_bvalid),
        .ddr_bready_o(ddr_bready),
        .ddr_rdata_i(ddr_rdata),.ddr_rresp_i(ddr_rresp),
        .ddr_rlast_i(ddr_rlast),.ddr_rvalid_i(ddr_rvalid),
        .ddr_rready_o(ddr_rready));
endmodule
