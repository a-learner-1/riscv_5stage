`timescale 1ns/1ps
// DIAG fallback: if the ES8311 I2C init (which has only a soft retry loop,
// never a hard timeout) never asserts done_o, force codec_ready high after
// ~800 ms so the audio capture path is not permanently reset.  This lets us
// tell a codec-lockup apart from everything else: the banner prints either
// way, and a P= line with the forced gate proves audio is really arriving.
// only ties into codec_ready_sync as a timeout override; it does not change
// the ES8311 init itself.
module mn04_codec_ready_tmo #(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer FORCE_MS = 800
)(
    input wire clk,
    input wire rst_n,
    input wire codec_init_done_i,
    input wire mclk_locked_i,
    input wire codec_error_i,
    output reg codec_ready_sync_o = 1'b0
);
    // count MS using a simple free-running tick.  FORCE_MS up to ~65535.
    localparam [31:0] TICKS_MS = CLOCK_HZ/1000;      // per ms tick count
    localparam [31:0] TICK_MS = TICKS_MS - 1;        // ms counter period
    localparam [31:0] FORCE_TICKS = ((FORCE_MS-1)*TICK_MS) + (TICKS_MS-1);
    reg [31:0] count = 0;
    reg forced = 0;
    reg armed = 0;

    // propagate the real ready plus the timeout override
    reg [1:0] sync;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            sync<=2'b00; forced<=1'b0; count<=32'd0; armed<=1'b1;
            codec_ready_sync_o<=1'b0;
        end else begin
            // normal ready: done && mclk locked, double-sync
            sync<={sync[0],codec_init_done_i && mclk_locked_i};
            // start the timeout only once armed (after reset) and not yet forced
            if(armed && !forced) begin
                if(count==FORCE_TICKS) begin
                    forced<=1'b1;
                end else count<=count+1'b1;
            end
            // if real init completes before the timeout, we don't need the fallback
            if(sync[1] && !forced) forced<=1'b1;   // latch done; prevents later force if already ok
            // output: prefer real ready; else timeout-forced ready
            codec_ready_sync_o <= (sync[1] || forced);
        end
    end
endmodule