module cpu_top #(
    parameter PROGRAM_FILE = "programs/rv32i_regression.hex",
    parameter DATA_FILE = "",
    parameter integer IMEM_WORDS = 8192,
    parameter integer DMEM_WORDS = 4096,
    parameter [31:0] DMEM_BASE_ADDR = 32'h00000000,
    parameter integer UART_CLOCK_HZ = 100000000,
    parameter integer UART_BAUD = 115200,
    parameter integer UART_RX_FIFO_DEPTH = 16,
    parameter integer SIM_CONSOLE_ECHO = 1,
    parameter integer EXTERNAL_DMEM = 0,
    parameter integer DMEM_REQ_WAIT_CYCLES = 0,
    parameter integer DMEM_RSP_WAIT_CYCLES = 0,
    parameter integer EXTERNAL_IMEM = 0,
    parameter integer IMEM_REQ_WAIT_CYCLES = 0,
    parameter integer IMEM_RSP_WAIT_CYCLES = 0,
    // Opt in explicitly. Existing boards retain their fault-stop behavior.
    parameter integer ENABLE_TRAPS = 0,
    // Timer interrupts require the M-mode exception environment above.
    parameter integer ENABLE_TIMER_IRQ = 0,
    // Direct-mapped BTB and conditional 2-bit predictor; opt in explicitly.
    parameter integer ENABLE_BRANCH_PRED = 0,
    parameter integer BTB_ENTRIES = 64,
    // Independent machine interrupt sources; existing targets leave both off.
    parameter integer ENABLE_EXTERNAL_IRQ = 0,
    parameter integer ENABLE_SOFTWARE_IRQ = 0,
    // Full RV32M is opt-in; legacy RV32I targets retain identical behavior.
    parameter integer ENABLE_M = 0
) (
    input wire clk,
    input wire rst_n,

    output wire [31:0] pc_x,
    output wire [31:0] instr_x,
    output wire        valid_x,

    output reg [31:0] wb_pc,
    output reg [4:0]  wb_rd,
    output reg [31:0] wb_data,
    output reg        wb_we,

    output reg        retire_valid,
    output reg [63:0] cycle_count,
    output reg [63:0] instret_count,
    output wire       uart_tx,
    input  wire       uart_rx,
    input  wire [7:0] gpio_in,
    output wire [7:0] gpio_out,
    output wire [7:0] gpio_oe,

    // External data RAM bus; ignored completely when EXTERNAL_DMEM=0.
    // MMIO always stays local. Only one transaction may be outstanding.
    output wire        dmem_req_valid,
    input  wire        dmem_req_ready,
    output wire        dmem_req_write,
    output wire [31:0] dmem_req_addr,
    output wire [1:0]  dmem_req_size,
    output wire [31:0] dmem_req_wdata,
    output wire [3:0]  dmem_req_wstrb,
    input  wire        dmem_rsp_valid,
    output wire        dmem_rsp_ready,
    input  wire [31:0] dmem_rsp_rdata,
    input  wire        dmem_rsp_error,
    output reg         dmem_fault,

    // External instruction bus; ignored when EXTERNAL_IMEM=0.
    // In-order, one outstanding request; endpoint shares CPU reset.
    output wire        imem_req_valid,
    input  wire        imem_req_ready,
    output wire [31:0] imem_req_addr,
    input  wire        imem_rsp_valid,
    output wire        imem_rsp_ready,
    input  wire [31:0] imem_rsp_rdata,
    input  wire        imem_rsp_error,
    output wire        imem_fault,
    output wire [31:0] imem_fault_pc,
    // One-cycle trap-entry pulse and the most recent trap descriptor
    // (synchronous exception or an enabled machine interrupt source).
    output reg         trap_valid,
    output reg  [31:0] trap_pc,
    output reg  [31:0] trap_cause,
    output reg  [31:0] trap_tval,
    // Predictor observations retain their existing internal counter semantics.
    output wire [31:0] bp_lookup_count, bp_hit_count, bp_taken_count,
    output reg  [31:0] bp_resolved_count, bp_mispredict_count,
    output reg  [31:0] bp_direction_error_count, bp_target_error_count,
    // Asynchronous level request; ignored when the external source is disabled.
    input wire irq_external,
    // Registered, mutually exclusive primary cycle classification. Bit order:
    // work/other, instruction wait, data read wait, data write wait,
    // local MMIO wait, normal redirect recovery wait. Not retirement events.
    output reg [5:0] perf_cycle_events
);

    localparam [31:0] MMIO_CYCLE_ADDR   = 32'h2000_0000;
    localparam [31:0] MMIO_INSTRET_ADDR = 32'h2000_0004;
    localparam [31:0] MMIO_PUTCHAR_ADDR = 32'h2000_0010;
    localparam [31:0] MMIO_UART_STATUS_ADDR = 32'h2000_0014;
    localparam [31:0] MMIO_MSIP_ADDR = 32'h2000_0050;
    localparam integer TIMER_IRQ_ENABLED =
        (ENABLE_TRAPS != 0) && (ENABLE_TIMER_IRQ != 0);
    localparam integer EXTERNAL_IRQ_ENABLED =
        (ENABLE_TRAPS != 0) && (ENABLE_EXTERNAL_IRQ != 0);
    localparam integer SOFTWARE_IRQ_ENABLED =
        (ENABLE_TRAPS != 0) && (ENABLE_SOFTWARE_IRQ != 0);
    localparam integer MACHINE_IRQ_ENABLED =
        TIMER_IRQ_ENABLED || EXTERNAL_IRQ_ENABLED || SOFTWARE_IRQ_ENABLED;
    localparam [31:0] MIE_WRITABLE_MASK =
        (TIMER_IRQ_ENABLED != 0 ? 32'h00000080 : 32'd0) |
        (EXTERNAL_IRQ_ENABLED != 0 ? 32'h00000800 : 32'd0) |
        (SOFTWARE_IRQ_ENABLED != 0 ? 32'h00000008 : 32'd0);

    localparam [3:0] ALU_ADD  = 4'b0000;
    localparam [3:0] ALU_SUB  = 4'b0001;
    localparam [3:0] ALU_AND  = 4'b0010;
    localparam [3:0] ALU_OR   = 4'b0011;
    localparam [3:0] ALU_XOR  = 4'b0100;
    localparam [3:0] ALU_SLL  = 4'b0101;
    localparam [3:0] ALU_SRL  = 4'b0110;
    localparam [3:0] ALU_SRA  = 4'b0111;
    localparam [3:0] ALU_SLT  = 4'b1000;
    localparam [3:0] ALU_SLTU = 4'b1001;

    wire [31:0] pc_f;

    wire [4:0] rs1_addr_x;
    wire [4:0] rs2_addr_x;
    wire [4:0] rd_addr_x;

    wire [31:0] imm_x;
    wire [31:0] imm_u_x;
    wire [31:0] imm_b_x;
    wire [31:0] imm_j_x;
    wire [31:0] imm_s_x;

    wire is_lw_x;
    wire is_sw_x;
    wire is_lb_x;
    wire is_lbu_x;
    wire is_lh_x;
    wire is_lhu_x;
    wire is_sb_x;
    wire is_sh_x;

    wire is_load_x;
    wire is_store_x;

    wire        mem_re_x;
    wire        mem_we_x;
    wire        mem_access_ok_x;
    wire [1:0]  mem_size_x;
    wire [3:0]  mem_wstrb_x;
    wire [31:0] mem_rdata_x;
    wire [31:0] mem_addr_x;
    wire [31:0] mem_wdata_x;

    wire        mmio_region_x;
    wire        mmio_cycle_addr_x;
    wire        mmio_instret_addr_x;
    wire        mmio_counter_addr_x;
    wire        mmio_load_ok_x;
    wire        mmio_putchar_write_x;
    wire        mmio_uart_status_addr_x;
    wire        uart_busy;
    wire        uart_write_accept_x;
    wire        uart_rx_read_hit_x;
    wire        uart_rx_write_hit_x;
    wire        uart_rx_read_hit_raw;
    wire        uart_rx_write_hit_raw;
    wire        mmio_uart_rx_write_x;
    wire [31:0] uart_rx_read_data_x;
    wire        gpio_read_hit_x;
    wire        gpio_write_hit_x;
    wire        gpio_read_hit_raw;
    wire        gpio_write_hit_raw;
    wire        mmio_gpio_write_x;
    wire [31:0] gpio_read_data_x;
    wire        timer_read_hit_x;
    wire        timer_write_hit_x;
    wire        timer_read_hit_raw;
    wire        timer_write_hit_raw;
    wire        mmio_timer_store_ok_x;
    wire        mmio_timer_write_x;
    wire [31:0] timer_read_data_x;
    wire [63:0] timer_mtime;
    wire [63:0] timer_mtimecmp;
    wire        timer_mtip;
    wire        mmio_msip_read_hit_x;
    wire        mmio_msip_store_ok_x;
    wire        mmio_msip_write_x;
    wire [31:0] mmio_read_data_x;
    wire [31:0] load_raw_data_x;

    // Accepted UART character event retained for the existing MMIO monitors.
    reg         mmio_putchar_valid;
    reg [7:0]   mmio_putchar_data;

    wire [31:0] load_shifted_x;
    wire [31:0] load_data_x;

    wire load_issue_x;
    wire stall_x;
    wire is_m_encoded_x;
    wire is_m_x = (ENABLE_M != 0) && is_m_encoded_x;
    reg m_active;
    reg [31:0] m_pc_q;
    reg [4:0] m_rd_q;
    wire m_start_x, m_complete_x, m_wait_x;
    wire m_busy, m_done;
    wire [31:0] m_result;

    // A memory descriptor is captured on its FIRST EX edge, including
    // operands forwarded from WB. It must not change while ready is low.
    reg        mem_active;
    reg        req_sent;
    reg        mem_write_q;
    reg        mem_mmio_q;
    reg [31:0] mem_pc_q;
    reg [4:0]  mem_rd_q;
    reg [2:0]  mem_funct3_q;
    reg [31:0] mem_addr_q;
    reg [1:0]  mem_size_q;
    reg [3:0]  mem_wstrb_q;
    reg [31:0] mem_wdata_q;
    reg [31:0] mem_rs2_q;

    wire        mem_start_x;
    wire        mem_req_valid;
    wire        mem_req_ready;
    wire        mem_req_fire;
    wire        mem_req_write;
    wire        mem_req_mmio;
    wire        mem_req_access_ok;
    wire [31:0] mem_store_raw_x;
    // MMIO alone has a descriptor stage before the local endpoint accepts.
    // RAM and external D-cache requests retain their original direct path.
    reg         mmio_endpoint_pending;
    reg [31:0]  mmio_endpoint_addr_q;
    reg [31:0]  mmio_endpoint_wdata_q;
    reg [3:0]   mmio_endpoint_wstrb_q;
    reg [1:0]   mmio_endpoint_size_q;
    reg         mmio_endpoint_write_q;
    reg         mmio_endpoint_is_mmio_q;
    wire        mmio_endpoint_fire;
    wire        mmio_endpoint_decode_valid;
    wire        mmio_endpoint_store_strobe_ok;
    wire        local_endpoint_req_valid;
    wire        local_endpoint_req_write;
    wire        local_endpoint_req_mmio;
    wire        mmio_store_ok_x;
    wire        mmio_putchar_addr_ok_x;
    wire        mmio_gpio_store_ok_x;
    wire        mmio_uart_rx_store_ok_x;
    wire        mem_external_x;
    wire        mem_rsp_external;
    wire        local_req_ready;
    wire        local_rsp_valid;
    wire [31:0] local_rsp_rdata;
    wire        local_rsp_error;
    wire        mem_rsp_valid;
    wire        mem_rsp_ready;
    wire        mem_rsp_fire;
    wire [31:0] mem_rsp_rdata;
    wire        mem_rsp_error;
    wire        mem_rsp_success;
    wire        retire_to_wb;

    // Compatibility monitors: accepted load and accepted-load response wait.
    reg        load_pending;
    reg [31:0] load_pc_q;
    reg [4:0]  load_rd_q;
    reg [1:0]  load_addr_lsb_q;
    reg [2:0]  load_funct3_q;
    reg        load_mmio_q;
    reg [31:0] load_mmio_data_q;

    wire is_addi_x;
    wire is_add_x;
    wire is_sub_x;
    wire is_and_x;
    wire is_or_x;
    wire is_xor_x;

    wire is_andi_x;
    wire is_ori_x;
    wire is_xori_x;

    wire is_sll_x;
    wire is_srl_x;
    wire is_sra_x;

    wire is_slli_x;
    wire is_srli_x;
    wire is_srai_x;

    wire is_slt_x;
    wire is_sltu_x;
    wire is_slti_x;
    wire is_sltiu_x;

    wire is_lui_x;
    wire is_auipc_x;

    wire is_beq_x;
    wire is_bne_x;
    wire is_blt_x;
    wire is_bge_x;
    wire is_bltu_x;
    wire is_bgeu_x;

    wire is_jal_x;
    wire is_jalr_x;
    wire is_jump_x;

    wire        is_branch_x;
    wire        branch_taken_x;
    wire [31:0] branch_target_x;

    wire        jump_taken_x;
    wire [31:0] jump_target_x;

    wire        redirect_x;
    wire [31:0] redirect_pc_x;

    wire        use_upper_imm_x;
    wire        use_shift_imm_x;
    wire [31:0] shamt_imm_x;

    wire use_imm_x;
    wire uses_rs1_x;
    wire uses_rs2_x;
    wire writes_rd_x;
    wire instr_supported_x;

    wire is_fence_x;
    wire is_ecall_x;
    wire is_ebreak_x;
    wire is_mret_x;
    wire is_csr_x;
    wire system_enabled_x;
    wire csr_write_intent_x;
    wire csr_commit_x;
    wire mret_commit_x;
    wire [11:0] csr_addr_x;
    wire [31:0] csr_operand_x;
    reg  [31:0] csr_read_data_x;
    wire [31:0] csr_write_data_x;
    reg         csr_known_x;
    reg         csr_read_only_x;
    wire        csr_legal_x;

    // Minimal M-mode trap CSRs, with independently optional timer, software
    // and one synchronized machine external interrupt source. No delegation,
    // U/S mode, PLIC, PMP or counter CSR implementation is provided here.
    // MPP is WARL M (3); mstatus implements only MIE and MPIE besides MPP.
    reg [31:0] csr_mstatus;
    reg [31:0] csr_mtvec;
    reg [31:0] csr_mscratch;
    reg [31:0] csr_mepc;
    reg [31:0] csr_mcause;
    reg [31:0] csr_mtval;
    reg [31:0] csr_mie;
    reg        external_irq_meta;
    reg        external_irq_sync;
    reg        software_msip;
    wire [31:0] csr_mip_value;
    wire [31:0] irq_enabled_pending;
    wire [31:0] irq_selected_cause;

    // The source must hold its request until its peripheral is serviced.
    // Clearing CPU trap state or writing mip does not acknowledge that source.
    // Constant disabled gating keeps an omitted legacy input (Z) out of the
    // CSR/IRQ logic and allows these synchronizer registers to be removed.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            external_irq_meta <= 1'b0;
            external_irq_sync <= 1'b0;
        end else if (EXTERNAL_IRQ_ENABLED != 0) begin
            external_irq_meta <= irq_external;
            external_irq_sync <= external_irq_meta;
        end else begin
            external_irq_meta <= 1'b0;
            external_irq_sync <= 1'b0;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            software_msip <= 1'b0;
        else if (SOFTWARE_IRQ_ENABLED == 0)
            software_msip <= 1'b0;
        else if (mmio_msip_write_x)
            software_msip <= mmio_endpoint_wdata_q[0];
    end

    assign csr_mip_value =
        ((EXTERNAL_IRQ_ENABLED != 0 && external_irq_sync) ? 32'h00000800 : 32'd0) |
        ((SOFTWARE_IRQ_ENABLED != 0 && software_msip) ? 32'h00000008 : 32'd0) |
        ((TIMER_IRQ_ENABLED != 0 && timer_mtip) ? 32'h00000080 : 32'd0);
    assign irq_enabled_pending = csr_mip_value & csr_mie & MIE_WRITABLE_MASK;
    // Standard machine-source priority considers only implemented, enabled
    // requests: external before software before timer. Global MIE gates entry.
    assign irq_selected_cause = irq_enabled_pending[11] ? 32'h8000000b :
                                irq_enabled_pending[3] ? 32'h80000003 :
                                irq_enabled_pending[7] ? 32'h80000007 : 32'd0;

    wire        control_misaligned_x;
    wire        data_misaligned_x;
    wire        illegal_instruction_x;
    wire        ex_exception_x;
    wire [31:0] ex_exception_cause_x;
    wire [31:0] ex_exception_tval_x;
    wire        data_exception;
    wire        fetch_exception;
    wire        sync_trap_event;
    wire        irq_pending;
    wire        irq_event;
    // Architectural boundary after all previously completed instructions;
    // unlike pc_f, this never tracks a speculative fetch or held request.
    reg  [31:0] arch_next_pc;
    wire        trap_event;
    wire [31:0] trap_event_pc;
    wire [31:0] trap_event_cause;
    wire [31:0] trap_event_tval;
    wire        normal_redirect_x;
    wire [31:0] predicted_next_pc_x;
    wire        prediction_taken_x, prediction_hit_x;
    wire [31:0] actual_next_pc_x;
    wire        bp_resolve_valid, bp_predictable_x, bp_actual_taken_x;
    wire        bp_next_mismatch_x, bp_direction_error_x, bp_target_error_x;
    wire        bp_mmio_read_hit_x;
    reg [31:0]  bp_mmio_read_data_x;

    wire [31:0] rs1_data_x;
    wire [31:0] rs2_data_x;

    wire        forward_rs1_x;
    wire        forward_rs2_x;
    wire [31:0] rs1_value_x;
    wire [31:0] rs2_value_x;

    wire [31:0] alu_a_x;
    wire [31:0] alu_b_x;
    wire [3:0]  alu_op_x;
    wire [31:0] alu_result_x;

    /*
     * IF?
     */
    if_stage #(
        .PROGRAM_FILE(PROGRAM_FILE),
        .IMEM_WORDS(IMEM_WORDS),
        .EXTERNAL_IMEM(EXTERNAL_IMEM),
        .IMEM_REQ_WAIT_CYCLES(IMEM_REQ_WAIT_CYCLES),
        .IMEM_RSP_WAIT_CYCLES(IMEM_RSP_WAIT_CYCLES),
        .ENABLE_TRAPS(ENABLE_TRAPS),
        .ENABLE_BRANCH_PRED(ENABLE_BRANCH_PRED), .BTB_ENTRIES(BTB_ENTRIES)
    ) u_if_stage (
        .clk           (clk),
        .rst_n         (rst_n),
        .redirect_x    (redirect_x),
        .redirect_pc_x (redirect_pc_x),
        .stall_x       (stall_x),
        .pc_f          (pc_f),
        .pc_x          (pc_x),
        .instr_x       (instr_x),
        .valid_x       (valid_x),
        .imem_req_valid(imem_req_valid), .imem_req_ready(imem_req_ready),
        .imem_req_addr(imem_req_addr), .imem_rsp_valid(imem_rsp_valid),
        .imem_rsp_ready(imem_rsp_ready), .imem_rsp_rdata(imem_rsp_rdata),
        .imem_rsp_error(imem_rsp_error),
        .imem_fault(imem_fault), .imem_fault_pc(imem_fault_pc),
        .bp_update_valid((ENABLE_BRANCH_PRED != 0) && bp_resolve_valid),
        .bp_update_pc(pc_x),
        .bp_update_target(is_jal_x ? jump_target_x : branch_target_x),
        .bp_update_taken(bp_actual_taken_x),
        .bp_update_is_branch(is_branch_x), .bp_update_is_jal(is_jal_x),
        .predicted_next_pc_x(predicted_next_pc_x),
        .prediction_taken_x(prediction_taken_x), .prediction_hit_x(prediction_hit_x),
        .bp_lookup_count(bp_lookup_count), .bp_hit_count(bp_hit_count),
        .bp_taken_count(bp_taken_count)
    );

    /*
     * ????
     */
    decoder u_decoder (
        .instr    (instr_x),

        .rs1_addr (rs1_addr_x),
        .rs2_addr (rs2_addr_x),
        .rd_addr  (rd_addr_x),

        .imm_i    (imm_x),
        .imm_u    (imm_u_x),
        .imm_b    (imm_b_x),
        .imm_j    (imm_j_x),
        .imm_s    (imm_s_x),

        .is_addi  (is_addi_x),
        .is_add   (is_add_x),
        .is_sub   (is_sub_x),

        .is_and   (is_and_x),
        .is_or    (is_or_x),
        .is_xor   (is_xor_x),

        .is_andi  (is_andi_x),
        .is_ori   (is_ori_x),
        .is_xori  (is_xori_x),

        .is_sll   (is_sll_x),
        .is_srl   (is_srl_x),
        .is_sra   (is_sra_x),

        .is_slli  (is_slli_x),
        .is_srli  (is_srli_x),
        .is_srai  (is_srai_x),

        .is_slt   (is_slt_x),
        .is_sltu  (is_sltu_x),
        .is_slti  (is_slti_x),
        .is_sltiu (is_sltiu_x),

        .is_lui   (is_lui_x),
        .is_auipc (is_auipc_x),

        .is_beq   (is_beq_x),
        .is_bne   (is_bne_x),
        .is_blt   (is_blt_x),
        .is_bge   (is_bge_x),
        .is_bltu  (is_bltu_x),
        .is_bgeu  (is_bgeu_x),

        .is_jal   (is_jal_x),
        .is_jalr  (is_jalr_x),

        .is_lw    (is_lw_x),
        .is_sw    (is_sw_x),
        .is_lb    (is_lb_x),
        .is_lbu   (is_lbu_x),
        .is_lh    (is_lh_x),
        .is_lhu   (is_lhu_x),
        .is_sb    (is_sb_x),
        .is_sh    (is_sh_x),
        .is_fence (is_fence_x),
        .is_ecall (is_ecall_x),
        .is_ebreak(is_ebreak_x),
        .is_mret  (is_mret_x),
        .is_csr   (is_csr_x),
        .is_m     (is_m_encoded_x)
    );

    /*
     * ??????
     */
    regfile u_regfile (
        .clk      (clk),
        .we       (wb_we),

        .rs1_addr (rs1_addr_x),
        .rs2_addr (rs2_addr_x),

        .rd_addr  (wb_rd),
        .rd_data  (wb_data),

        .rs1_data (rs1_data_x),
        .rs2_data (rs2_data_x)
    );

    /*
     * ????????
     */
    assign use_shift_imm_x =
        is_slli_x |
        is_srli_x |
        is_srai_x;

    assign shamt_imm_x =
        {27'd0, instr_x[24:20]};

    assign use_upper_imm_x =
        is_lui_x |
        is_auipc_x;

    assign is_load_x =
        is_lb_x  |
        is_lbu_x |
        is_lh_x  |
        is_lhu_x |
        is_lw_x;

    assign is_store_x =
        is_sb_x |
        is_sh_x |
        is_sw_x;

    assign is_branch_x =
        is_beq_x  |
        is_bne_x  |
        is_blt_x  |
        is_bge_x  |
        is_bltu_x |
        is_bgeu_x;

    assign is_jump_x =
        is_jal_x |
        is_jalr_x;

    assign use_imm_x =
        is_addi_x |
        is_andi_x |
        is_ori_x  |
        is_xori_x |
        use_shift_imm_x |
        is_slti_x |
        is_sltiu_x |
        use_upper_imm_x |
        is_load_x |
        is_store_x;

    assign uses_rs2_x =
        is_add_x |
        is_sub_x |
        is_and_x |
        is_or_x  |
        is_xor_x |
        is_sll_x |
        is_srl_x |
        is_sra_x |
        is_slt_x |
        is_sltu_x |
        is_m_x |
        is_branch_x |
        is_store_x;

    assign uses_rs1_x =
        (((use_imm_x | uses_rs2_x) && !use_upper_imm_x) |
         is_jalr_x |
         ((ENABLE_TRAPS != 0) && is_csr_x && !instr_x[14]));

    assign writes_rd_x =
        (((use_imm_x | uses_rs2_x) &&
          !is_branch_x &&
          !is_store_x) |
         is_jump_x |
         ((ENABLE_TRAPS != 0) && is_csr_x));

    assign instr_supported_x =
        is_addi_x |
        is_add_x |
        is_sub_x |

        is_and_x |
        is_or_x |
        is_xor_x |

        is_andi_x |
        is_ori_x |
        is_xori_x |

        is_sll_x |
        is_srl_x |
        is_sra_x |

        is_slli_x |
        is_srli_x |
        is_srai_x |

        is_slt_x |
        is_sltu_x |
        is_slti_x |
        is_sltiu_x |

        is_lui_x |
        is_auipc_x |

        is_branch_x |
        is_jump_x |
        is_load_x |
        is_store_x |
        is_m_x |
        system_enabled_x;

    assign system_enabled_x = (ENABLE_TRAPS != 0) &&
        (is_fence_x || is_ecall_x || is_ebreak_x || is_mret_x || is_csr_x);

    assign csr_addr_x = instr_x[31:20];
    assign csr_operand_x = instr_x[14] ? {27'd0, instr_x[19:15]} : rs1_value_x;
    // CSRRS/CSRRC suppress the write only for the encoded x0/zimm=0, even
    // when a nonzero source register happens to contain zero. CSRRW always
    // writes; rd=x0 suppresses the architectural read/result (no CSR here
    // has a read side effect, and normal WB masks x0).
    assign csr_write_intent_x = is_csr_x &&
        ((instr_x[13:12] == 2'b01) || (instr_x[19:15] != 5'd0));
    assign csr_write_data_x = (instr_x[13:12] == 2'b01) ? csr_operand_x :
                             (instr_x[13:12] == 2'b10) ?
                                 (csr_read_data_x | csr_operand_x) :
                                 (csr_read_data_x & ~csr_operand_x);
    assign csr_legal_x = csr_known_x &&
                         !(csr_read_only_x && csr_write_intent_x);

    always @* begin
        csr_known_x = 1'b1;
        csr_read_only_x = 1'b0;
        csr_read_data_x = 32'd0;
        case (csr_addr_x)
            12'h300: csr_read_data_x = csr_mstatus;
            12'h301: begin
                // Fixed RV32I/RV32IM WARL value. Writes are legal and ignored;
                // Zicsr and M privilege are not ISA extension letter bits.
                csr_read_data_x = (ENABLE_M != 0) ? 32'h40001100 : 32'h40000100;
            end
            12'h304: begin
                csr_known_x = (MACHINE_IRQ_ENABLED != 0);
                csr_read_data_x = csr_mie;
            end
            12'h305: csr_read_data_x = csr_mtvec;
            12'h340: csr_read_data_x = csr_mscratch;
            12'h341: csr_read_data_x = csr_mepc;
            12'h342: csr_read_data_x = csr_mcause;
            12'h343: csr_read_data_x = csr_mtval;
            12'h344: begin
                csr_known_x = (MACHINE_IRQ_ENABLED != 0);
                csr_read_data_x = csr_mip_value;
                // MEIP/MSIP/MTIP are owned by their source devices. CSR writes
                // remain legal and ignored; MSIP changes through its MMIO word.
            end
            12'hf11, 12'hf12, 12'hf13, 12'hf14, 12'hf15: begin
                csr_read_data_x = 32'd0;
                csr_read_only_x = 1'b1;
            end
            default: csr_known_x = 1'b0;
        endcase
    end

    /*
     * WB -> EX ????
     */
    assign forward_rs1_x =
        uses_rs1_x &&
        wb_we &&
        (wb_rd != 5'd0) &&
        (wb_rd == rs1_addr_x);

    assign rs1_value_x =
        forward_rs1_x ?
        wb_data :
        rs1_data_x;

    assign forward_rs2_x =
        uses_rs2_x &&
        wb_we &&
        (wb_rd != 5'd0) &&
        (wb_rd == rs2_addr_x);

    assign rs2_value_x =
        forward_rs2_x ?
        wb_data :
        rs2_data_x;

    /*
     * ?????
     */
    assign branch_taken_x =
        valid_x &&
        (
            (is_beq_x  && (rs1_value_x == rs2_value_x)) ||
            (is_bne_x  && (rs1_value_x != rs2_value_x)) ||
            (is_blt_x  && ($signed(rs1_value_x) <
                           $signed(rs2_value_x))) ||
            (is_bge_x  && ($signed(rs1_value_x) >=
                           $signed(rs2_value_x))) ||
            (is_bltu_x && (rs1_value_x < rs2_value_x)) ||
            (is_bgeu_x && (rs1_value_x >= rs2_value_x))
        );

    assign branch_target_x =
        pc_x + imm_b_x;

    assign jump_taken_x =
        valid_x && is_jump_x;

    assign jump_target_x =
        is_jal_x ?
        (pc_x + imm_j_x) :
        ((rs1_value_x + imm_x) & 32'hffff_fffe);

    assign actual_next_pc_x = jump_taken_x ? jump_target_x :
                              branch_taken_x ? branch_target_x : pc_x + 32'd4;
    // Resolve only a completed architectural instruction. A stalled memory
    // instruction retains its prediction until its successful response. IRQ,
    // synchronous exception and MRET use their existing priority path instead.
    assign bp_resolve_valid = rst_n && !dmem_fault && valid_x &&
        !trap_event && !mret_commit_x &&
        (mem_rsp_success || m_complete_x ||
         (!mem_active && !m_active && !is_m_x &&
          !is_load_x && !is_store_x && instr_supported_x));
    assign bp_predictable_x = is_branch_x || is_jal_x;
    assign bp_actual_taken_x = branch_taken_x || is_jal_x;
    assign bp_next_mismatch_x = (predicted_next_pc_x != actual_next_pc_x);
    assign bp_direction_error_x = bp_predictable_x &&
                                 (prediction_taken_x != bp_actual_taken_x);
    assign bp_target_error_x = bp_predictable_x && prediction_taken_x &&
                              bp_actual_taken_x && bp_next_mismatch_x;
    assign normal_redirect_x = (ENABLE_BRANCH_PRED != 0) ?
        (bp_resolve_valid && bp_next_mismatch_x) :
        (!dmem_fault && !mem_active && (branch_taken_x | jump_taken_x));

    // IALIGN=32: only a taken branch/jump checks its destination. JALR
    // clears bit 0 first. The exception belongs to the control instruction,
    // so its link register must not be written on a misaligned target.
    assign control_misaligned_x =
        (jump_taken_x && (jump_target_x[1:0] != 2'b00)) ||
        (branch_taken_x && (branch_target_x[1:0] != 2'b00));
    assign data_misaligned_x = (is_load_x || is_store_x) &&
        (((mem_size_x == 2'd1) && mem_addr_x[0]) ||
         ((mem_size_x == 2'd2) && (mem_addr_x[1:0] != 2'b00)));
    assign illegal_instruction_x = !instr_supported_x ||
                                    (is_csr_x && !csr_legal_x);
    assign ex_exception_x = (ENABLE_TRAPS != 0) && rst_n &&
        !dmem_fault && !mem_active && valid_x &&
        (illegal_instruction_x || is_ecall_x || is_ebreak_x ||
         control_misaligned_x || data_misaligned_x);
    assign ex_exception_cause_x = illegal_instruction_x ? 32'd2 :
                                 is_ecall_x ? 32'd11 :
                                 is_ebreak_x ? 32'd3 :
                                 control_misaligned_x ? 32'd0 :
                                 is_store_x ? 32'd6 : 32'd4;
    assign ex_exception_tval_x = illegal_instruction_x ? instr_x :
                                is_ecall_x ? 32'd0 :
                                is_ebreak_x ? pc_x :
                                control_misaligned_x ?
                                    (jump_taken_x ? jump_target_x : branch_target_x) :
                                mem_addr_x;

    // A data response is for the older captured instruction. A frontend
    // error is acknowledged only after the older EX slot has drained. This
    // extra edge also makes an older mtvec write visible to the fetch trap.
    assign data_exception = (ENABLE_TRAPS != 0) && mem_rsp_fire && mem_rsp_error;
    assign fetch_exception = (ENABLE_TRAPS != 0) && rst_n && imem_fault &&
                              !dmem_fault && !mem_active && !valid_x;
    assign sync_trap_event = data_exception || ex_exception_x || fetch_exception;
    assign irq_pending = (MACHINE_IRQ_ENABLED != 0) &&
                         (|irq_enabled_pending) && csr_mstatus[3];
    // Once a memory descriptor has started, even an unaccepted request or
    // held response must drain. Its STORE/MMIO effect is never replayed.
    // Only recognized synchronous exceptions outrank this interrupt. A raw
    // younger IF response not yet in EX can be discarded as stale by redirect;
    // MRET refetches the architectural next PC and redetects any access fault.
    assign irq_event = rst_n && irq_pending && !dmem_fault && !mem_active && !m_active &&
                       !sync_trap_event;
    assign trap_event = sync_trap_event || irq_event;
    assign trap_event_pc = data_exception ? mem_pc_q :
                           ex_exception_x ? pc_x :
                           fetch_exception ? imem_fault_pc :
                           valid_x ? pc_x : arch_next_pc;
    assign trap_event_cause = data_exception ? (mem_write_q ? 32'd7 : 32'd5) :
                              ex_exception_x ? ex_exception_cause_x :
                              fetch_exception ?
                                  ((imem_fault_pc[1:0] != 2'b00) ? 32'd0 : 32'd1) :
                              irq_selected_cause;
    assign trap_event_tval = data_exception ? mem_addr_q :
                             ex_exception_x ? ex_exception_tval_x :
                             fetch_exception ? imem_fault_pc : 32'd0;
    assign mret_commit_x = (ENABLE_TRAPS != 0) && rst_n && valid_x &&
                           !dmem_fault && !mem_active && is_mret_x && !trap_event;
    assign csr_commit_x = (ENABLE_TRAPS != 0) && rst_n && valid_x &&
                          !dmem_fault && !mem_active && is_csr_x &&
                          csr_legal_x && csr_write_intent_x && !trap_event;

    assign redirect_x = trap_event || mret_commit_x ||
                         (normal_redirect_x && !ex_exception_x);
    assign redirect_pc_x = trap_event ? csr_mtvec :
                           mret_commit_x ? csr_mepc :
                           actual_next_pc_x;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bp_resolved_count <= 0;
            bp_mispredict_count <= 0;
            bp_direction_error_count <= 0;
            bp_target_error_count <= 0;
        end else if ((ENABLE_BRANCH_PRED != 0) && bp_resolve_valid) begin
            if (bp_predictable_x) bp_resolved_count <= bp_resolved_count + 1;
            if (bp_next_mismatch_x) bp_mispredict_count <= bp_mispredict_count + 1;
            if (bp_direction_error_x) bp_direction_error_count <= bp_direction_error_count + 1;
            if (bp_target_error_x) bp_target_error_count <= bp_target_error_count + 1;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            csr_mstatus <= 32'h00001800;
            csr_mtvec <= 32'd0;
            csr_mscratch <= 32'd0;
            csr_mepc <= 32'd0;
            csr_mcause <= 32'd0;
            csr_mtval <= 32'd0;
            csr_mie <= 32'd0;
            trap_valid <= 1'b0;
            trap_pc <= 32'd0;
            trap_cause <= 32'd0;
            trap_tval <= 32'd0;
        end else begin
            trap_valid <= trap_event;
            if (trap_event) begin
                trap_pc <= trap_event_pc;
                trap_cause <= trap_event_cause;
                trap_tval <= trap_event_tval;
                csr_mepc <= {trap_event_pc[31:2], 2'b00};
                csr_mcause <= trap_event_cause;
                csr_mtval <= trap_event_tval;
                csr_mstatus <= 32'h00001800 |
                               (csr_mstatus[3] ? 32'h00000080 : 32'd0);
            end else if (mret_commit_x) begin
                csr_mstatus <= 32'h00001880 |
                               (csr_mstatus[7] ? 32'h00000008 : 32'd0);
            end else if (csr_commit_x) begin
                case (csr_addr_x)
                    12'h300: csr_mstatus <= 32'h00001800 |
                                           (csr_write_data_x & 32'h00000088);
                    12'h304: csr_mie <= csr_write_data_x & MIE_WRITABLE_MASK;
                    // Only direct mtvec and IALIGN=32 addresses are WARL.
                    12'h305: csr_mtvec <= {csr_write_data_x[31:2], 2'b00};
                    12'h340: csr_mscratch <= csr_write_data_x;
                    12'h341: csr_mepc <= {csr_write_data_x[31:2], 2'b00};
                    12'h342: csr_mcause <= csr_write_data_x;
                    12'h343: csr_mtval <= csr_write_data_x;
                    // Fixed misa and hardware-owned mip writes have no effect.
                    default: begin end
                endcase
            end
        end
    end

    // This tracker advances only at architectural completion, including a
    // successfully drained memory response. It is valid even when IF waits
    // for request acceptance/response and no EX instruction is available.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            arch_next_pc <= 32'd0;
        else if (trap_event)
            arch_next_pc <= csr_mtvec;
        else if (mem_rsp_success)
            arch_next_pc <= mem_pc_q + 32'd4;
        else if (retire_to_wb) begin
            if (mret_commit_x)
                arch_next_pc <= csr_mepc;
            else if (jump_taken_x)
                arch_next_pc <= jump_target_x;
            else if (branch_taken_x)
                arch_next_pc <= branch_target_x;
            else
                arch_next_pc <= pc_x + 32'd4;
        end
    end

    /*
     * ALU????
     */
    assign alu_a_x =
        is_lui_x   ? 32'd0 :
        is_auipc_x ? pc_x :
                     rs1_value_x;

    assign alu_b_x =
        is_store_x      ? imm_s_x :
        use_upper_imm_x ? imm_u_x :
        use_shift_imm_x ? shamt_imm_x :
        use_imm_x       ? imm_x :
                          rs2_value_x;

    assign alu_op_x =
        (is_slt_x  | is_slti_x)  ? ALU_SLT :
        (is_sltu_x | is_sltiu_x) ? ALU_SLTU :
        (is_sll_x  | is_slli_x)  ? ALU_SLL :
        (is_srl_x  | is_srli_x)  ? ALU_SRL :
        (is_sra_x  | is_srai_x)  ? ALU_SRA :
        is_sub_x                  ? ALU_SUB :
        (is_and_x  | is_andi_x)  ? ALU_AND :
        (is_or_x   | is_ori_x)   ? ALU_OR :
        (is_xor_x  | is_xori_x)  ? ALU_XOR :
                                    ALU_ADD;

    alu u_alu (
        .a      (alu_a_x),
        .b      (alu_b_x),
        .alu_op (alu_op_x),
        .result (alu_result_x)
    );

    // Snapshot forwarded operands on the first EX edge. A completed result
    // stays owned through its retirement edge; interrupts wait until the next
    // architectural boundary, and cannot cancel or replay an accepted M op.
    assign m_start_x = rst_n && !dmem_fault && !mem_active && !m_active &&
        valid_x && is_m_x && !trap_event;
    assign m_complete_x = rst_n && !dmem_fault && m_active && m_done;
    assign m_wait_x = (m_active || (valid_x && is_m_x)) && !m_complete_x;
    generate if(ENABLE_M != 0) begin: g_m
        rv32m_unit u_muldiv (
            .clk(clk),.rst_n(rst_n),.start(m_start_x),.op(instr_x[14:12]),
            .lhs(rs1_value_x),.rhs(rs2_value_x),
            .busy(m_busy),.done(m_done),.result(m_result)
        );
    end else begin: g_no_m
        assign m_busy=1'b0;
        assign m_done=1'b0;
        assign m_result=32'd0;
    end endgenerate

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin m_active<=0;m_pc_q<=0;m_rd_q<=0;end
        else if(m_complete_x) m_active<=0;
        else if(m_start_x) begin
            m_active<=1;m_pc_q<=pc_x;m_rd_q<=rd_addr_x;
        end
    end

    /*
     * ???????
     */
    assign mem_addr_x = mem_active ? mem_addr_q : alu_result_x;

    assign mem_size_x =
        mem_active ? mem_size_q :
        (is_lb_x | is_lbu_x | is_sb_x) ? 2'd0 :
        (is_lh_x | is_lhu_x | is_sh_x) ? 2'd1 :
                                         2'd2;

    assign mem_wstrb_x =
        mem_active ? mem_wstrb_q :
        is_sb_x ? (4'b0001 << mem_addr_x[1:0]) :
        is_sh_x ? (4'b0011 << mem_addr_x[1:0]) :
        is_sw_x ? 4'b1111 :
                  4'b0000;

    assign mem_wdata_x =
        mem_active ? mem_wdata_q :
        (rs2_value_x << {mem_addr_x[1:0], 3'b000});

    assign mem_store_raw_x = mem_active ? mem_rs2_q : rs2_value_x;

    /*
     * Memory-mapped I/O region used by bare-metal software.
     *
     *   0x2000_0000: cycle counter, low 32 bits, read-only
     *   0x2000_0004: retired-instruction counter, low 32 bits, read-only
     *   0x2000_0010: UART data, write-only (low byte)
     *   0x2000_0014: UART status, read-only (bit 0: busy)
     *   0x2000_0018: UART RX data, aligned LW pops one byte (empty -> 0)
     *   0x2000_001c: UART RX status, aligned LW; SW W1C error bits 2/3
     *   0x2000_0020: GPIO output latch, read/write
     *   0x2000_0024: synchronized GPIO input, read-only
     *   0x2000_0028: GPIO output-enable mask, read/write
     *   0x2000_002c/0030/0034: output SET/CLEAR/TOGGLE, write-only
     *   0x2000_0040/0044: optional mtime low/high, read/write
     *   0x2000_0048/004c: optional mtimecmp low/high, read/write
     *   0x2000_0050: optional machine software interrupt word; bit 0 is MSIP
     * GPIO registers accept aligned LW/SW only.
     * Timer registers accept aligned LW/SW only when TIMER_IRQ_ENABLED.
     * MSIP accepts aligned LW/SW only when SOFTWARE_IRQ_ENABLED; bits 31:1
     * always read zero and ignore written data. Subword accesses have no effect.
     */
    assign mmio_region_x =
        (mem_addr_x[31:16] == 16'h2000);

    assign mmio_cycle_addr_x =
        mmio_endpoint_decode_valid && (mmio_endpoint_addr_q == MMIO_CYCLE_ADDR);

    assign mmio_instret_addr_x =
        mmio_endpoint_decode_valid && (mmio_endpoint_addr_q == MMIO_INSTRET_ADDR);

    assign mmio_counter_addr_x =
        mmio_cycle_addr_x |
        mmio_instret_addr_x;

    assign mmio_uart_status_addr_x =
        mmio_endpoint_decode_valid && (mmio_endpoint_addr_q == MMIO_UART_STATUS_ADDR);

    // Counters are exposed as aligned 32-bit registers.  CoreMark only
    // needs the low word because elapsed time is computed by subtraction.
    assign mmio_load_ok_x =
        (mmio_counter_addr_x || mmio_uart_status_addr_x ||
         uart_rx_read_hit_x || gpio_read_hit_x || timer_read_hit_x ||
         mmio_msip_read_hit_x || bp_mmio_read_hit_x) &&
        (mmio_endpoint_size_q == 2'd2) &&
        (mmio_endpoint_addr_q[1:0] == 2'b00);

    // These register address sets are disjoint. Use parallel masked data
    // rather than a priority chain after the late effective-address decode.
    assign mmio_read_data_x =
        ({32{mmio_cycle_addr_x}} & cycle_count[31:0]) |
        ({32{mmio_instret_addr_x}} & instret_count[31:0]) |
        ({32{mmio_uart_status_addr_x}} & {31'd0, uart_busy}) |
        ({32{uart_rx_read_hit_x}} & uart_rx_read_data_x) |
        ({32{gpio_read_hit_x}} & gpio_read_data_x) |
        ({32{timer_read_hit_x}} & timer_read_data_x) |
        ({32{mmio_msip_read_hit_x}} & {31'd0, software_msip}) |
        ({32{bp_mmio_read_hit_x}} & bp_mmio_read_data_x);

    assign mmio_msip_read_hit_x = mmio_endpoint_decode_valid && (SOFTWARE_IRQ_ENABLED != 0) &&
        (mmio_endpoint_addr_q == MMIO_MSIP_ADDR);

    // Opt-in, aligned LW-only diagnostic registers. Stores are rejected by
    // the existing MMIO legality path; the disabled core keeps them unmapped.
    assign bp_mmio_read_hit_x = mmio_endpoint_decode_valid && (ENABLE_BRANCH_PRED != 0) &&
        (mmio_endpoint_addr_q >= 32'h20000070) &&
        (mmio_endpoint_addr_q <= 32'h2000008c) &&
        (mmio_endpoint_addr_q[1:0] == 2'b00);
    always @(*) begin
        case (mmio_endpoint_addr_q)
            32'h20000070: bp_mmio_read_data_x = (BTB_ENTRIES << 16) | 32'd1;
            32'h20000074: bp_mmio_read_data_x = bp_lookup_count;
            32'h20000078: bp_mmio_read_data_x = bp_hit_count;
            32'h2000007c: bp_mmio_read_data_x = bp_taken_count;
            32'h20000080: bp_mmio_read_data_x = bp_resolved_count;
            32'h20000084: bp_mmio_read_data_x = bp_mispredict_count;
            32'h20000088: bp_mmio_read_data_x = bp_direction_error_count;
            32'h2000008c: bp_mmio_read_data_x = bp_target_error_count;
            default: bp_mmio_read_data_x = 32'd0;
        endcase
    end

    // Accept SB, SH and SW at the character register and use the low byte.
    assign mmio_putchar_addr_ok_x =
        mmio_endpoint_decode_valid && (mmio_endpoint_addr_q == MMIO_PUTCHAR_ADDR) &&
        (mmio_endpoint_size_q != 2'd3);

    assign mmio_gpio_store_ok_x = gpio_write_hit_x &&
        (mmio_endpoint_size_q == 2'd2) && (mmio_endpoint_addr_q[1:0] == 2'b00);

    assign mmio_uart_rx_store_ok_x = uart_rx_write_hit_x &&
        (mmio_endpoint_size_q == 2'd2) && (mmio_endpoint_addr_q[1:0] == 2'b00);

    assign mmio_timer_store_ok_x = timer_write_hit_x &&
        (mmio_endpoint_size_q == 2'd2) && (mmio_endpoint_addr_q[1:0] == 2'b00);

    assign mmio_msip_store_ok_x = mmio_msip_read_hit_x &&
        (mmio_endpoint_size_q == 2'd2) && (mmio_endpoint_addr_q[1:0] == 2'b00);

    assign mmio_endpoint_store_strobe_ok = mmio_endpoint_wstrb_q ==
        (mmio_endpoint_size_q == 2'd0 ? (4'b0001 << mmio_endpoint_addr_q[1:0]) :
         mmio_endpoint_size_q == 2'd1 ? (4'b0011 << mmio_endpoint_addr_q[1:0]) :
         mmio_endpoint_size_q == 2'd2 ? 4'b1111 : 4'b0000);
    assign mmio_store_ok_x = mmio_endpoint_store_strobe_ok &&
        (mmio_putchar_addr_ok_x ||
        mmio_gpio_store_ok_x || mmio_uart_rx_store_ok_x || mmio_timer_store_ok_x ||
        mmio_msip_store_ok_x);

    // Every MMIO side effect uses the same staged descriptor and endpoint
    // acceptance edge. Response backpressure cannot repeat this edge.
    assign mmio_putchar_write_x = mmio_endpoint_fire && mmio_endpoint_write_q &&
        mmio_endpoint_store_strobe_ok &&
        mmio_putchar_addr_ok_x;

    assign uart_write_accept_x = mmio_putchar_write_x && !uart_busy;

    assign mmio_gpio_write_x = mmio_endpoint_fire && mmio_endpoint_write_q &&
        mmio_endpoint_store_strobe_ok &&
        mmio_gpio_store_ok_x;

    assign mmio_uart_rx_write_x = mmio_endpoint_fire && mmio_endpoint_write_q &&
        mmio_endpoint_store_strobe_ok &&
        mmio_uart_rx_store_ok_x;

    assign mmio_timer_write_x = mmio_endpoint_fire && mmio_endpoint_write_q &&
        mmio_endpoint_store_strobe_ok &&
        mmio_timer_store_ok_x;

    assign mmio_msip_write_x = mmio_endpoint_fire && mmio_endpoint_write_q &&
        mmio_endpoint_store_strobe_ok &&
        mmio_msip_store_ok_x;

    // Capture the pre-pop head in load_mmio_data_q and the adapter on the
    // staged endpoint issue edge. A held response cannot pop the FIFO again.
    // The stage keeps its last address after acceptance. Scope the public
    // hit predicates to its valid lifetime so later RAM loads cannot appear
    // to access the previous peripheral in existing transaction monitors.
    assign uart_rx_read_hit_x = mmio_endpoint_decode_valid && uart_rx_read_hit_raw;
    assign uart_rx_write_hit_x = mmio_endpoint_decode_valid && uart_rx_write_hit_raw;
    assign gpio_read_hit_x = mmio_endpoint_decode_valid && gpio_read_hit_raw;
    assign gpio_write_hit_x = mmio_endpoint_decode_valid && gpio_write_hit_raw;
    assign timer_read_hit_x = mmio_endpoint_decode_valid && timer_read_hit_raw;
    assign timer_write_hit_x = mmio_endpoint_decode_valid && timer_write_hit_raw;

    uart_rx_mmio #(
        .CLOCK_HZ(UART_CLOCK_HZ), .BAUD(UART_BAUD),
        .FIFO_DEPTH(UART_RX_FIFO_DEPTH)
    ) u_uart_rx_mmio (
        .clk(clk), .rst_n(rst_n), .rx(uart_rx), .addr(mmio_endpoint_addr_q),
        .read_enable(mmio_endpoint_fire && !mmio_endpoint_write_q && mmio_load_ok_x),
        .write_enable(mmio_uart_rx_write_x), .write_data(mmio_endpoint_wdata_q),
        .read_data(uart_rx_read_data_x),
        .read_hit(uart_rx_read_hit_raw), .write_hit(uart_rx_write_hit_raw)
    );

    // Keep the peripheral independent of the pipeline implementation.
    // Output enable is exposed separately; a board wrapper implements IOB
    // tristates or uses the mask to gate dedicated LED output pins.
    gpio_mmio u_gpio (
        .clk(clk), .rst_n(rst_n),
        .addr(mmio_endpoint_addr_q), .write_enable(mmio_gpio_write_x),
        .write_data(mmio_endpoint_wdata_q), .read_data(gpio_read_data_x),
        .read_hit(gpio_read_hit_raw), .write_hit(gpio_write_hit_raw),
        .gpio_in(gpio_in), .gpio_out(gpio_out), .gpio_oe(gpio_oe)
    );

    generate
        if (TIMER_IRQ_ENABLED != 0) begin : g_machine_timer
            machine_timer u_timer (
                .clk(clk), .rst_n(rst_n), .addr(mmio_endpoint_addr_q),
                .write_enable(mmio_timer_write_x), .write_data(mmio_endpoint_wdata_q),
                .read_data(timer_read_data_x), .read_hit(timer_read_hit_raw),
                .write_hit(timer_write_hit_raw), .mtime(timer_mtime),
                .mtimecmp(timer_mtimecmp), .mtip(timer_mtip)
            );
        end else begin : g_no_machine_timer
            // A disabled generate branch has no timer module dependency;
            // existing standalone compile scripts remain compatible.
            assign timer_read_data_x = 32'd0;
            assign timer_read_hit_raw = 1'b0;
            assign timer_write_hit_raw = 1'b0;
            assign timer_mtime = 64'd0;
            assign timer_mtimecmp = 64'hffffffffffffffff;
            assign timer_mtip = 1'b0;
        end
    endgenerate

    // Request and byte reach the UART in the same cycle as the MMIO store.
    // There is no delayed request whose pending state could be missed by
    // a following status read.
    uart_tx #(
        .CLOCK_HZ(UART_CLOCK_HZ),
        .BAUD(UART_BAUD)
    ) u_uart_tx (
        .clk(clk),
        .rst_n(rst_n),
        .valid(mmio_putchar_write_x),
        .data(mmio_endpoint_wdata_q[7:0]),
        .tx(uart_tx),
        .busy(uart_busy),
        .done()
    );

    // Unified request/response handshake. A new memory instruction can
    // present its request in its first EX cycle. The first edge captures
    // the descriptor whether or not the endpoint is ready on that edge.
    assign mem_start_x = rst_n && !dmem_fault && !mem_active && valid_x &&
                         (is_load_x || is_store_x) && !ex_exception_x && !irq_event;
    assign mem_req_valid = rst_n && !dmem_fault && !req_sent &&
                           (mem_active || mem_start_x);
    assign mem_req_write = mem_active ? mem_write_q : is_store_x;
    assign mem_req_mmio = mem_active ? mem_mmio_q : mmio_region_x;
    assign mem_external_x = (EXTERNAL_DMEM != 0) && !mem_req_mmio;
    assign mem_req_ready = mem_external_x ? dmem_req_ready :
                           mem_req_mmio ? (mmio_endpoint_pending && local_req_ready) :
                           local_req_ready;
    assign mem_req_fire = mem_req_valid && mem_req_ready;

    // Accept MMIO only after the complete descriptor has crossed a clock
    // edge. The original request/response wait parameters remain in the
    // adapter. In particular, RAM never enters this MMIO-only stage.
    assign local_endpoint_req_valid = mmio_endpoint_pending ||
        (mem_req_valid && !mem_external_x && !mem_req_mmio);
    assign local_endpoint_req_write = mmio_endpoint_pending ?
        mmio_endpoint_write_q : mem_req_write;
    assign local_endpoint_req_mmio = mmio_endpoint_pending ?
        mmio_endpoint_is_mmio_q : mem_req_mmio;
    // No EX-valid/decode signal feeds peripheral write enables. The staged
    // request is independently owned until this local acceptance edge.
    assign mmio_endpoint_decode_valid = mmio_endpoint_pending && mmio_endpoint_is_mmio_q;
    assign mmio_endpoint_fire = rst_n && local_req_ready && mmio_endpoint_pending &&
        mmio_endpoint_is_mmio_q;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mmio_endpoint_pending <= 1'b0;
            mmio_endpoint_addr_q <= 32'd0;
            mmio_endpoint_wdata_q <= 32'd0;
            mmio_endpoint_wstrb_q <= 4'd0;
            mmio_endpoint_size_q <= 2'd0;
            mmio_endpoint_write_q <= 1'b0;
            mmio_endpoint_is_mmio_q <= 1'b0;
        end else if (mmio_endpoint_fire) begin
            mmio_endpoint_pending <= 1'b0;
        end else if (mem_req_valid && mem_req_mmio && !mmio_endpoint_pending) begin
            mmio_endpoint_pending <= 1'b1;
            mmio_endpoint_addr_q <= mem_addr_x;
            mmio_endpoint_wdata_q <= mem_wdata_x;
            mmio_endpoint_wstrb_q <= mem_wstrb_x;
            mmio_endpoint_size_q <= mem_size_x;
            mmio_endpoint_write_q <= mem_req_write;
            mmio_endpoint_is_mmio_q <= mem_req_mmio;
        end
    end

    // These are pure address/size predicates, not side-effect pulses.
    // External RAM legality is decided by its error response, not by the
    // internal teaching RAM's address range.
    assign mem_req_access_ok = mem_req_mmio ?
        (mmio_endpoint_write_q ? (mmio_store_ok_x &&
            (!mmio_putchar_addr_ok_x || !uart_busy)) : mmio_load_ok_x) :
        mem_access_ok_x;

    assign dmem_req_valid = (EXTERNAL_DMEM != 0) && mem_req_valid &&
                            !mem_req_mmio;
    assign dmem_req_write = mem_req_write;
    assign dmem_req_addr = mem_addr_x;
    assign dmem_req_size = mem_size_x;
    assign dmem_req_wdata = mem_wdata_x;
    assign dmem_req_wstrb = mem_wstrb_x;

    // req_sent is updated only at an acceptance edge; it prevents consuming
    // an unsolicited or combinational same-edge external response.
    assign mem_rsp_ready = rst_n && !dmem_fault && mem_active && req_sent;
    // Only the captured transaction can own a response. Using its saved
    // route keeps live EX address/decode logic off response error/redirect
    // paths. mem_rsp_ready stays low until that descriptor is captured
    // and the request accepted; this adds neither a cycle nor a register.
    assign mem_rsp_external = (EXTERNAL_DMEM != 0) && !mem_mmio_q;
    assign mem_rsp_valid = mem_rsp_external ? dmem_rsp_valid : local_rsp_valid;
    assign mem_rsp_rdata = mem_rsp_external ? dmem_rsp_rdata : local_rsp_rdata;
    assign mem_rsp_error = mem_rsp_external ? dmem_rsp_error : local_rsp_error;
    assign mem_rsp_fire = mem_rsp_valid && mem_rsp_ready;
    assign mem_rsp_success = mem_rsp_fire && !mem_rsp_error;
    assign dmem_rsp_ready = mem_rsp_external && mem_rsp_ready;

    assign load_issue_x = mem_req_fire && !mem_req_write;
    // Both LOAD and STORE wait for completion before the next EX advances.
    // Legacy errors halt; trap-mode errors drain and redirect on this edge.
    // FENCE can only enter EX after the older data response completed, so
    // its conservative full ordering requires no additional bus request.
    assign stall_x = dmem_fault || m_wait_x ||
                     ((mem_active || mem_start_x) && !mem_rsp_success);
    assign mem_re_x = load_issue_x && !mem_req_mmio &&
                      (EXTERNAL_DMEM == 0);
    assign mem_we_x = mem_req_fire && mem_req_write && !mem_req_mmio &&
                      (EXTERNAL_DMEM == 0);

    data_bus_adapter #(
        .REQ_WAIT_CYCLES(DMEM_REQ_WAIT_CYCLES),
        .RSP_WAIT_CYCLES(DMEM_RSP_WAIT_CYCLES)
    ) u_data_bus_adapter (
        .clk(clk), .rst_n(rst_n),
        .req_valid(local_endpoint_req_valid),
        .req_ready(local_req_ready), .req_write(local_endpoint_req_write),
        .req_mmio(local_endpoint_req_mmio), .req_access_ok(mem_req_access_ok),
        .mmio_rdata(mmio_read_data_x), .ram_rdata(mem_rdata_x),
        .rsp_valid(local_rsp_valid),
        .rsp_ready(mem_rsp_ready && !mem_rsp_external),
        .rsp_rdata(local_rsp_rdata), .rsp_error(local_rsp_error)
    );

    data_mem #(
        .WORDS(DMEM_WORDS),
        .BASE_ADDR(DMEM_BASE_ADDR),
        .INIT_FILE(DATA_FILE)
    ) u_data_mem (
        .clk       (clk),
        .re        (mem_re_x),
        .we        (mem_we_x),
        .addr      (mem_addr_x),
        .size      (mem_size_x),
        .wdata     (mem_wdata_x),
        .wstrb     (mem_wstrb_x),
        .rdata     (mem_rdata_x),
        .access_ok (mem_access_ok_x)
    );

    // Single-outstanding transaction state and immutable descriptor.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mem_active      <= 1'b0;
            req_sent        <= 1'b0;
            mem_write_q     <= 1'b0;
            mem_mmio_q      <= 1'b0;
            mem_pc_q        <= 32'd0;
            mem_rd_q        <= 5'd0;
            mem_funct3_q    <= 3'd0;
            mem_addr_q      <= 32'd0;
            mem_size_q      <= 2'd0;
            mem_wstrb_q     <= 4'd0;
            mem_wdata_q     <= 32'd0;
            mem_rs2_q       <= 32'd0;
            dmem_fault      <= 1'b0;
            load_pending    <= 1'b0;
            load_pc_q       <= 32'd0;
            load_rd_q       <= 5'd0;
            load_addr_lsb_q <= 2'd0;
            load_funct3_q   <= 3'd0;
            load_mmio_q     <= 1'b0;
            load_mmio_data_q <= 32'd0;
        end else begin
            if (mem_start_x) begin
                mem_active   <= 1'b1;
                mem_write_q  <= is_store_x;
                mem_mmio_q   <= mmio_region_x;
                mem_pc_q     <= pc_x;
                mem_rd_q     <= rd_addr_x;
                mem_funct3_q <= instr_x[14:12];
                mem_addr_q   <= mem_addr_x;
                mem_size_q   <= mem_size_x;
                mem_wstrb_q  <= mem_wstrb_x;
                mem_wdata_q  <= mem_wdata_x;
                mem_rs2_q    <= rs2_value_x;
                // Old load metadata names are retained for existing waves.
                load_pc_q       <= pc_x;
                load_rd_q       <= rd_addr_x;
                load_addr_lsb_q <= mem_addr_x[1:0];
                load_funct3_q   <= instr_x[14:12];
                load_mmio_q     <= mmio_region_x;
            end
            if (mem_req_fire) begin
                req_sent <= 1'b1;
                load_pending <= !mem_req_write;
                if (mem_req_mmio)
                    load_mmio_data_q <= mmio_read_data_x;
            end
            if (mem_rsp_fire) begin
                mem_active <= 1'b0;
                req_sent <= 1'b0;
                load_pending <= 1'b0;
                load_mmio_q  <= 1'b0;
                if (mem_rsp_error && (ENABLE_TRAPS == 0))
                    dmem_fault <= 1'b1;
            end
        end
    end

    // Display software output in ModelSim without creating hardware logic.
    // synthesis translate_off
    always @(posedge clk) begin
        if (SIM_CONSOLE_ECHO && uart_write_accept_x)
            $write("%c", mmio_endpoint_wdata_q[7:0]);
    end
    // synthesis translate_on

    /*
     * One-cycle pulse for each accepted write to MMIO_PUTCHAR_ADDR.
     * Software must poll the busy bit before issuing a new character.
     * The testbench
     * checks this byte.  The real serial output is the uart_tx port.
     */
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mmio_putchar_valid <= 1'b0;
            mmio_putchar_data  <= 8'd0;
        end else begin
            mmio_putchar_valid <= uart_write_accept_x;

            if (uart_write_accept_x)
                mmio_putchar_data <= mmio_endpoint_wdata_q[7:0];
        end
    end

    /*
     * ?????????
     */
    assign load_raw_data_x = mem_rsp_rdata;

    assign load_shifted_x =
        load_raw_data_x >>
        {load_addr_lsb_q, 3'b000};

    assign load_data_x =
        (load_funct3_q == 3'b000) ?
            {{24{load_shifted_x[7]}},
             load_shifted_x[7:0]} :

        (load_funct3_q == 3'b100) ?
            {24'd0, load_shifted_x[7:0]} :

        (load_funct3_q == 3'b001) ?
            {{16{load_shifted_x[15]}},
             load_shifted_x[15:0]} :

        (load_funct3_q == 3'b101) ?
            {16'd0, load_shifted_x[15:0]} :

            load_raw_data_x;

    /*
     * ?????????????
     */
    // synthesis translate_off
    always @(posedge clk) begin
        if ((ENABLE_TRAPS == 0) && mmio_putchar_write_x && uart_busy)
            $fatal(1, "UART write while busy pc=%h: poll 0x20000014 first", pc_x);

        if ((ENABLE_TRAPS == 0) && load_issue_x &&
            !mem_req_mmio && (EXTERNAL_DMEM == 0) &&
            mem_access_ok_x !== 1'b1) begin
            $fatal(
                1,
                "Unsupported load address pc=%h addr=%h size=%0d",
                pc_x,
                mem_addr_x,
                mem_size_x
            );
        end

        if ((ENABLE_TRAPS == 0) && load_issue_x &&
            mem_req_mmio &&
            !mmio_load_ok_x) begin
            $fatal(
                1,
                "Unsupported MMIO load pc=%h addr=%h size=%0d",
                pc_x,
                mem_addr_x,
                mem_size_x
            );
        end

        if ((ENABLE_TRAPS == 0) && mem_req_fire && mem_req_write &&
            !mem_req_mmio && (EXTERNAL_DMEM == 0) &&
            mem_access_ok_x !== 1'b1) begin
            $fatal(
                1,
                "Unsupported store address pc=%h addr=%h size=%0d",
                pc_x,
                mem_addr_x,
                mem_size_x
            );
        end

        if ((ENABLE_TRAPS == 0) && mem_req_fire && mem_req_write &&
            mem_req_mmio && !mmio_store_ok_x) begin
            $fatal(
                1,
                "Unsupported MMIO store pc=%h addr=%h size=%0d",
                pc_x,
                mem_addr_x,
                mem_size_x
            );
        end
    end
    // synthesis translate_on

    /*
     * EX/WB??????
     */
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wb_pc   <= 32'd0;
            wb_rd   <= 5'd0;
            wb_data <= 32'd0;
            wb_we   <= 1'b0;
        end else if (mem_rsp_success) begin
            wb_pc   <= mem_pc_q;
            wb_rd   <= mem_rd_q;
            wb_data <= load_data_x;
            wb_we   <= !mem_write_q && (mem_rd_q != 5'd0);
        end else if (m_complete_x) begin
            wb_pc<=m_pc_q;
            wb_rd<=m_rd_q;
            wb_data<=m_result;
            wb_we<=(m_rd_q!=0);
        end else if (!dmem_fault && !mem_active && !m_active && valid_x && !trap_event &&
                     !is_load_x && !is_store_x && !is_m_x) begin
            wb_pc <= pc_x;
            wb_rd <= rd_addr_x;

            wb_data <=
                ((ENABLE_TRAPS != 0) && is_csr_x) ? csr_read_data_x :
                is_jump_x ?
                (pc_x + 32'd4) :
                alu_result_x;

            wb_we <=
                writes_rd_x &&
                (rd_addr_x != 5'd0);
        end else begin
            // ?????????????
            wb_we <= 1'b0;
        end
    end

    /*
     * ?????
     *
     * ??????WB????
     * ????????RAM????????
     */
    reg counting_started;

    // Observation only: no profiler signal feeds instruction/bus control.
    // A normal redirect starts a recovery interval only when it wins the
    // architectural redirect priority. Stop at the next valid EX instruction;
    // the interval includes downstream fetch latency, not just branch logic.
    reg perf_redirect_pending;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            perf_cycle_events <= 6'b000000;
            perf_redirect_pending <= 1'b0;
        end else begin
            if (trap_event || mret_commit_x || imem_fault || dmem_fault)
                perf_redirect_pending <= 1'b0;
            else if (redirect_x && normal_redirect_x)
                perf_redirect_pending <= 1'b1;
            else if (valid_x)
                perf_redirect_pending <= 1'b0;

            // Exactly the same enable as cycle_count, including its first
            // counted edge. Consumers see this registered event one edge
            // later and must include the current event when snapshotting.
            perf_cycle_events <= 6'b000000;
            if (counting_started || (valid_x && instr_supported_x)) begin
                if (stall_x && (mem_active || mem_start_x)) begin
                    if (mem_req_mmio)
                        perf_cycle_events <= 6'b010000;
                    else if (mem_req_write)
                        perf_cycle_events <= 6'b001000;
                    else
                        perf_cycle_events <= 6'b000100;
                end else if (!valid_x && perf_redirect_pending &&
                             !trap_event && !mret_commit_x &&
                             !imem_fault && !dmem_fault)
                    perf_cycle_events <= 6'b100000;
                else if (!valid_x && !imem_fault && !dmem_fault)
                    perf_cycle_events <= 6'b000010;
                else
                    perf_cycle_events <= 6'b000001;
            end
        end
    end

    assign retire_to_wb =
        mem_rsp_success || m_complete_x ||
        (
            !dmem_fault &&
            valid_x &&
            !mem_active &&
            !m_active && !is_m_x &&
            !trap_event &&
            !is_load_x &&
            !is_store_x &&
            instr_supported_x
        );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            retire_valid     <= 1'b0;
            cycle_count      <= 64'd0;
            instret_count    <= 64'd0;
            counting_started <= 1'b0;
        end else begin
            retire_valid <= retire_to_wb;

            if (!counting_started) begin
                if (valid_x && instr_supported_x) begin
                    counting_started <= 1'b1;
                    cycle_count      <= 64'd1;
                end
            end else begin
                cycle_count <= cycle_count + 64'd1;
            end

            if (retire_valid)
                instret_count <= instret_count + 64'd1;
        end
    end

    // synthesis translate_off
    initial begin
        if (ENABLE_M != 0 && ENABLE_M != 1)
            $fatal(1, "cpu_top ENABLE_M must be zero or one");
        if ((ENABLE_EXTERNAL_IRQ != 0 && ENABLE_EXTERNAL_IRQ != 1) ||
            (ENABLE_SOFTWARE_IRQ != 0 && ENABLE_SOFTWARE_IRQ != 1))
            $fatal(1, "cpu_top machine interrupt switches must be zero or one");
        if ((ENABLE_EXTERNAL_IRQ != 0 || ENABLE_SOFTWARE_IRQ != 0) &&
            ENABLE_TRAPS != 1)
            $fatal(1, "cpu_top external/software interrupts require ENABLE_TRAPS=1");
    end
    // synthesis translate_on
endmodule
