`define USE_DDR_WEIGHTS
`timescale 1ns/1ps
// MN04 V1 inference core (GATE4).
//
// Descriptor-driven sequencer executing the 91-op program in
// sim\mn04\mem\op_desc.mem against the act memory:
//   opcodes: 0=CONV (kind 0=conv1,1=pw,2=dw3,3=dw5,4=fc)
//            1=SE_POOL, 2=SE_GATE, 3=RESIDUAL, 4=GAP
//
// Weight path: mn04_qspi_block_reader -> mn04_weight_block_cache (4 KB block
// windows, CH_PER_BLOCK output channels per window) + bias/mult/shift
// preload RAMs + 256 B activation LUT RAM (index = byte + 128).
// Act path: 32-bit streaming reads from mn04_act_mem; conv req_valid is
// COMBINATIONAL from the engine's issue so the 2-cycle cache/mem serve
// latency aligns with the MAC's internally delayed pair_valid.
// Requant: mn04_requantize_pipe (golden single-round contract) + 8-entry
// write-address FIFO keeping the 6-cycle latency hidden behind the MAC.
//
// Timing contract (verified trace in GATE4_婵°倗濮撮張顒勫极瑜版帒绠柕澶堝劜閸?md):
//   issue@C -> wcache/act_mem req@C -> data@C+2 == mac pair_valid@C+2.
//
// Fixed design constants (from gen_prep.py address map):
//   GATE_R = 0x180600 (SE gate value scratch written by the fc2 conv op)
module mn04_core #(
    parameter OP_FILE    = "op_desc.mem",
    parameter N_OPS      = 91,
    parameter N_CLASSES  = 7,
    parameter LUTS_BASE  = 24'h0,
    // Simulation image is zero-based.  Board integration must set this to
    // the reserved W25Q128 V1 partition (currently 0x400000).
    parameter FLASH_IMAGE_BASE = 24'h0,
    parameter FAST_BYTES = 1,
    parameter START_OP   = 0,  // targeted simulation; board uses default 0
    // When enabled, the descriptor ROM stores the 100-frame geometry and
    // each inference maps its temporal widths to 100/120/150 frames.
    parameter CLASS_WINDOW_MODE = 0,
    // DDR word-address base of the packed weight image (used only when built
    // with +define+USE_DDR_WEIGHTS; the QSPI weight path is the default).
    parameter [27:0] WEIGHT_BASE_WORD = 28'd0
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_i,
    // Execute an inclusive operation segment.  A scheduler may alternate
    // one short-window op and one long-window op while keeping each task's
    // intermediate activations in a separate DDR arena.  Geometry is changed
    // at descriptor decode; model weights and the 91-op ROM are shared.
    input  wire [8:0]  segment_start_op_i,
    input  wire [8:0]  segment_end_op_i,
    input  wire        short_window_i,
    input  wire [1:0]  class_window_mode_i,
    output wire        busy_o,
    output reg         done_o,
    output wire [23:0] flash_rd_addr_o,
    input  wire [7:0]  flash_rd_data_i,
    // Physical SPI-NOR pins.  The board-level mux must grant this reader
    // exclusive ownership before start_i is asserted.
    output wire        qspi_cs_o,
    output wire        qspi_sck_o,
    output wire        qspi_mosi_o,
    input  wire        qspi_miso_i,
    // Assert only when the activation row containing the *candidate* conv
    // request is resident and can still return at the fixed two-cycle hit
    // latency.  A miss must be filled before this goes high; it is not a
    // variable-latency response handshake.
    input  wire        conv_req_ready_i,
    // Look-ahead request for an external activation cache.  These signals
    // remain stable while ready is low because the engine holds term_index.
    output wire        conv_candidate_valid_o,
    output wire [23:0] conv_candidate_addr_o,
    output wire        conv_candidate_pad_o,
    output wire        scalar_candidate_valid_o,
    output wire [23:0] scalar_candidate_addr_o,
    output wire        scalar_mode_o,
    input  wire        scalar_req_ready_i,
    output wire        wr_en_o,
    output wire [23:0] wr_addr_o,
    output wire [7:0]  wr_data_o,
    // Write-backpressure handshake from the DDR write-merge bridge.  Must be
    // asserted whenever the bridge can accept one more byte.  The core's
    // requant-start sites are gated on this signal so that the pipeline never
    // over-produces writes faster than the bridge + bounded DDR write queue can
    // absorb; requants already in flight (<= RQ_DEPTH) are guaranteed to find a
    // free bridge slot at their write-fire time (see mn04_wmerge_bridge.v
    // STALL_THRESHOLD).  Tie to 1'b1 when no external write storage is used.
    input  wire        wr_ready_i,
    output wire        rd_req_valid_o,
    output wire [23:0] rd_byte_addr_o,
    output wire        rd_req_pad_o,
    input  wire        rd_rsp_valid_i,
    input  wire [31:0] rd_data_i,
    input  wire [1:0]  rd_lane_i,
    // Dedicated fixed-latency activation data path for the convolution MAC.
    // Variable-latency operations continue to use rd_data_i/rd_lane_i.
    input  wire [31:0] conv_rd_data_i,
    input  wire [1:0]  conv_rd_lane_i,
    output reg         dump_valid_o,
    output reg  [7:0]  dump_id_o,
    output reg  [15:0] dump_op_index_o,
    output reg  [31:0] cycle_count_o,
    output reg         logits_valid_o,
    output reg  [8*N_CLASSES-1:0] logits_o
`ifdef USE_DDR_WEIGHTS
    // DDR weight-image read master (256-bit user port, single-beat reads).
    // When built with USE_DDR_WEIGHTS the weight block cache is fed from DDR
    // instead of QSPI flash.  Same clock domain as clk for now; the sys_clk ->
    // ddr_core_clk CDC is added at the SoC integration step.
    , input  wire        ddr_init_done_i
    , output wire [27:0] ddr_araddr_o
    , output wire        ddr_arvalid_o
    , input  wire        ddr_arready_i
    , input  wire [255:0] ddr_rdata_i
    , input  wire [1:0]   ddr_rresp_i
    , input  wire        ddr_rvalid_i
    , output wire        ddr_rready_o
`endif
);
    localparam [3:0] S_IDLE=0, S_FETCH=1, S_PRE_BIAS=2, S_PRE_MULT=3, S_PRE_SHIFT=4,
                    S_LUT=5, S_WLOAD=6, S_CONV=7, S_POOL=8, S_GATE=9, S_RESID=10,
                    S_GAP=11, S_DRAIN=12, S_DONE=13;
    localparam [3:0] K_CONV1=0, K_PW=1, K_DW3=2, K_DW5=3, K_FC=4;
    localparam [2:0] OP_CONV=0, OP_POOL=1, OP_GATE=2, OP_RESIDUAL=3, OP_GAP=4;
    localparam integer RQ_DEPTH = 8;
    localparam [23:0] GATE_R_ADDR = 24'h180600;
    localparam [23:0] LOGIT_ADDR = 24'h180900;

    // ------------------------------------------------------------ registers
    reg [3:0]  st_r;
    reg [31:0] opmem [0:N_OPS*16-1];
    reg [31:0] d [0:15];
    reg [8:0]  op_act_r;
    reg [8:0]  segment_end_op_r;
    reg        short_window_r;
    reg [1:0]  class_window_mode_r;
    // 100 frames follow the same stride/padding chain as the 1000-frame ROM:
    // 100 -> 50 -> 25 -> 13 -> 7 -> 4.  Spatial frequency dimensions are
    // unchanged.  FC dimensions remain 1.  This avoids a second descriptor
    // ROM and the associated on-chip memory.
    function [15:0] short_width;
        input [15:0] full_width;
        begin
            case (full_width)
                16'd1000: short_width = 16'd100;
                16'd500:  short_width = 16'd50;
                16'd250:  short_width = 16'd25;
                16'd125:  short_width = 16'd13;
                16'd63:   short_width = 16'd7;
                16'd32:   short_width = 16'd4;
                default:  short_width = full_width;
            endcase
        end
    endfunction
    function [15:0] class_window_width;
        input [15:0] base_width;
        input [1:0] mode;
        begin
            case (base_width)
                16'd100: class_window_width = (mode == 2'd1) ? 16'd120 :
                                               (mode == 2'd2) ? 16'd150 : 16'd100;
                16'd50:  class_window_width = (mode == 2'd1) ? 16'd60 :
                                               (mode == 2'd2) ? 16'd75 : 16'd50;
                16'd25:  class_window_width = (mode == 2'd1) ? 16'd30 :
                                               (mode == 2'd2) ? 16'd38 : 16'd25;
                16'd13:  class_window_width = (mode == 2'd1) ? 16'd15 :
                                               (mode == 2'd2) ? 16'd19 : 16'd13;
                16'd7:   class_window_width = (mode == 2'd1) ? 16'd8 :
                                               (mode == 2'd2) ? 16'd10 : 16'd7;
                16'd4:   class_window_width = (mode == 2'd2) ? 16'd5 : 16'd4;
                default: class_window_width = base_width;
            endcase
        end
    endfunction
    function [15:0] decode_width;
        input [15:0] base_width;
        begin
            if (CLASS_WINDOW_MODE)
                decode_width = class_window_width(base_width, class_window_mode_r);
            else if (short_window_r)
                decode_width = short_width(base_width);
            else
                decode_width = base_width;
        end
    endfunction
    reg [3:0]  fetch_i_r;
    reg [4:0]  dump_cnt_r;   // 19 dump points -> needs 5 bits (4-bit wrapped at 16)

    reg [7:0]  op_opcode; reg [3:0] op_kind; reg op_uin, op_postlut, op_headclamp, op_dump;
    reg [15:0] op_lut_id;
    reg [15:0] op_ch_in, op_ch_out, op_h_in, op_w_in, op_h_out, op_w_out;
    reg [17:0] op_terms; reg [1:0] op_stride; reg [2:0] op_pad;
    reg [23:0] op_w_off, op_b_off, op_m_off, op_s_off, op_in_base, op_out_base;
    reg [23:0] op_wc_r;
    reg [31:0] resid_hw_r, resid_total_r;
    reg        resid_setup_r;
    reg [31:0] op_aux1, op_aux2, op_aux3, op_aux4, op_aux5;

    reg [9:0]  co_r, co_in_block_r, pool_co_r;
    reg [9:0]  wblock_r;  // weight-block index = co_r / ch_per_block (incremental)
    reg [11:0] wc_off_r;   // weight byte-offset within block = co_in_block_r * op_terms (incremental)
    reg [23:0] wc_block_offset_r;
    reg [23:0] wc_block_stride_r;
    reg [7:0]  oh_r; reg [9:0] ow_r;
    reg [23:0] conv_out_addr_r;
    reg        mac_run_r;
    reg [31:0] sum_cap_r;
    reg [15:0] pre_cnt_r; reg [31:0] pre_word_r;
    reg        pre_started_r, lut_started_r, wc_started_r;
    reg [15:0] pool_pix_r, gap_pix_r;
    reg [23:0] pool_addr_r;
    reg [3:0]  pool_pending_r, gap_pending_r;
    reg [2:0]  pool_delay_r, gap_delay_r;
    reg [31:0] sum_acc_r;
    reg [9:0]  gate_co_r; reg [7:0] gate_byte_r; reg [2:0] gate_phase_r;
    reg [15:0] gate_pix_r; reg gate_wait_r;
    reg [2:0] gate_delay_r;
    // op_h_in*op_w_in is a 16x16 variable multiply used only as a loop bound in
    // the pool/gap/gate states.  Computing it every cycle in its own (registered)
    // term keeps it off those compare paths.  gate_pix_term_r mirrors
    // gate_pix_r*op_ch_in incrementally so the per-pixel gate address no longer
    // runs a multiply between an APM result and the next APM input.
    reg [31:0] op_hw_r;
    reg [23:0] gate_pix_term_r;
    reg [31:0] resid_k_r, resid_k_d1_r, resid_k_d2_r, resid_k_d3_r;
    reg [23:0] resid_addr_a_r,resid_addr_b_r;
    reg        resid_phase_r, resid_ph_d1_r, resid_ph_d2_r, resid_ph_d3_r, rsp_phase_d2_r;
    reg [1:0]  resid_issue_r;
    reg [2:0]  resid_reads_outstanding_r;

    reg        rq_start_r;
    reg signed [31:0] rq_acc_r, rq_mult_r;
    reg signed [7:0]  rq_shift_r;
    reg [3:0]  rq_pending_r;
    reg [2:0]  rq_head_r, rq_tail_r;
    reg        rq_phase_r, rq_valid_phase_r;
    reg [7:0]  rq_phase_shift;   // GATE4 L001 fix: carries each requant
                                 // START's phase (rsp_phase_d2_r) through the
                                 // 7-cycle requantize pipe to its valid_o.
    reg [23:0] rq_fifo [0:RQ_DEPTH-1];
    reg signed [31:0] resid_ta_r;
    integer rdb_n, resid_dbg_n, resid_dbg_n2;
    reg        pad_d1_r, pad_d2_r;

    reg        wr_en_r; reg [23:0] wr_addr_r; reg [7:0] wr_data_r;
    reg        rd_req_valid_r; reg [23:0] rd_byte_addr_r;
    reg        eng_done_cap_r;
    reg        gate_have_r; reg [7:0] gate_byte2_r;
    reg [1:0]  drain_cnt_r;

    // Final head writes N_CLASSES int8 logits to the activation-memory vector.
    // Tap the same committed byte writes so a post-CNN Q16 softmax can consume
    // the complete vector without a separate DDR readback.  Valid pulses one
    // cycle after the final public dump boundary, after all writes drain.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            logits_valid_o <= 1'b0;
            logits_o <= {8*N_CLASSES{1'b0}};
        end else begin
            logits_valid_o <= 1'b0;
            if (wr_en_r && op_act_r == N_OPS-1 &&
                wr_addr_r >= LOGIT_ADDR && wr_addr_r < LOGIT_ADDR+N_CLASSES)
                logits_o[(wr_addr_r-LOGIT_ADDR)*8 +: 8] <= wr_data_r;
            if (dump_valid_o && dump_op_index_o == N_OPS-1)
                logits_valid_o <= 1'b1;
        end
    end

    reg        pre_active_r, lut_active_r, wc_load_active_r;
    reg [23:0] pre_addr_r, lut_addr_r;
    reg [15:0] pre_count_r;
    reg [7:0]  lut_ld_addr_r;

    // preload RAMs (declared here: used by the engine instantiations)
    reg signed [31:0] bias_ram [0:383];
    reg signed [31:0] mult_ram [0:383];
    reg signed [7:0]  shift_ram [0:383];
    reg [11:0] ch_per_block;

    // ------------------------------------------------------------ wires
    wire rq_valid_w; wire signed [7:0] rq_y;
    wire wc_loaded, wc_qspi_start, wc_byte_ready, wc_req_ready, wc_rsp_valid;
    wire [23:0] wc_qspi_addr; wire [15:0] wc_qspi_count;
    wire [7:0] wc_src_byte; wire wc_src_byte_valid;  // wc byte source (QSPI or DDR)
    wire [1:0] wc_lane; wire signed [7:0] wc_w0, wc_w1, wc_w2, wc_w3;
    wire qr_done; wire [7:0] qr_byte; wire qr_byte_valid;
    wire [7:0] lut_rd_data;
    wire eng4_busy, eng4_done, eng4_pair_req; wire [17:0] eng4_ti;
    wire signed [31:0] eng4_sum;
    wire eng1_busy, eng1_done, eng1_pair_req; wire [17:0] eng1_ti;
    wire signed [31:0] eng1_sum;

    wire rq_can_start = (rq_pending_r < RQ_DEPTH) && wr_ready_i;
    wire is_pw = (op_kind == K_PW || op_kind == K_FC);
    wire eng_busy = is_pw ? eng4_busy : eng1_busy;
    wire eng_done = is_pw ? eng4_done : eng1_done;
    wire signed [31:0] eng_sum = is_pw ? eng4_sum : eng1_sum;
    wire eng_preq = is_pw ? eng4_pair_req : eng1_pair_req;
    wire [17:0] eng_ti = is_pw ? eng4_ti : eng1_ti;

    wire in_conv_stream = (st_r == S_CONV) && mac_run_r;
    wire conv_candidate_valid = in_conv_stream && eng_preq && wc_loaded;
    wire conv_req = conv_candidate_valid && conv_req_ready_i;
    reg [1:0] init_phase_r;

    // engine launch (1-cycle pulse: mac_run_r is set on the same edge)
    wire eng_start_c = (st_r == S_CONV) && !mac_run_r && !eng_busy &&
                       (init_phase_r == 2'd3) && rq_can_start;
    wire eng_start4_c = eng_start_c && is_pw;
    wire eng_start1_c = eng_start_c && !is_pw;
    reg eng_start4_r, eng_start1_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            eng_start4_r <= 1'b0;
            eng_start1_r <= 1'b0;
        end else begin
            eng_start4_r <= eng_start4_c;
            eng_start1_r <= eng_start1_c;
        end
    end

    wire pre_start_c = pre_active_r && !pre_started_r;
    wire lut_start_c = lut_active_r && !lut_started_r;
    wire wc_load_start_c = wc_load_active_r && !wc_started_r;
    // aux5 stores the byte stride between weight-cache windows. Backbone
    // weights are packed tightly by output-channel blocks; appended classifier
    // weights may instead be padded to 4 KB. A zero aux5 keeps legacy images
    // using the original 4 KB stride. Advance a register at each block edge so
    // the weight address path needs only an adder, not a multiplier.
    wire [23:0] wc_flash_base_c = op_w_off + wc_block_offset_r;

    // (qspi mux assigns live next to the reader instantiation)

    // ------------------------------------------------------------ opmem fetch + decode
    always @(posedge clk) begin
        if (st_r == S_FETCH && fetch_i_r < 16) begin
            case (fetch_i_r)
                4'd0: d[0]  <= opmem[op_act_r*16 + 0]; 4'd1: d[1]  <= opmem[op_act_r*16 + 1];
                4'd2: d[2]  <= opmem[op_act_r*16 + 2]; 4'd3: d[3]  <= opmem[op_act_r*16 + 3];
                4'd4: d[4]  <= opmem[op_act_r*16 + 4]; 4'd5: d[5]  <= opmem[op_act_r*16 + 5];
                4'd6: d[6]  <= opmem[op_act_r*16 + 6]; 4'd7: d[7]  <= opmem[op_act_r*16 + 7];
                4'd8: d[8]  <= opmem[op_act_r*16 + 8]; 4'd9: d[9]  <= opmem[op_act_r*16 + 9];
                4'd10: d[10] <= opmem[op_act_r*16 + 10]; 4'd11: d[11] <= opmem[op_act_r*16 + 11];
                4'd12: d[12] <= opmem[op_act_r*16 + 12]; 4'd13: d[13] <= opmem[op_act_r*16 + 13];
                4'd14: d[14] <= opmem[op_act_r*16 + 14]; 4'd15: d[15] <= opmem[op_act_r*16 + 15];
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            op_opcode <= 0; op_kind <= 0; op_uin <= 0; op_postlut <= 0;
            op_headclamp <= 0; op_dump <= 0; op_lut_id <= 0;
            op_ch_in <= 0; op_ch_out <= 0; op_h_in <= 0; op_w_in <= 0;
            op_h_out <= 0; op_w_out <= 0; op_terms <= 0; op_stride <= 0; op_pad <= 0;
            op_w_off <= 0; op_b_off <= 0; op_m_off <= 0; op_s_off <= 0;
            op_in_base <= 0; op_out_base <= 0;
            op_aux1 <= 0; op_aux2 <= 0; op_aux3 <= 0; op_aux4 <= 0; op_aux5 <= 0;
            resid_hw_r <= 0;
        end else if (st_r == S_FETCH && fetch_i_r == 15) begin
            op_opcode    <= d[0][15:8];
            op_kind      <= d[0][3:0];
            op_uin       <= d[0][4];
            op_postlut   <= d[0][5];
            op_headclamp <= d[0][6];
            op_dump      <= d[0][7];
            op_lut_id    <= d[0][31:16];
            op_ch_in     <= d[1][15:0];
            op_ch_out    <= d[1][31:16];
            op_h_in      <= d[2][15:0];
            op_w_in      <= decode_width(d[2][31:16]);
            op_h_out     <= d[3][15:0];
            op_w_out     <= decode_width(d[3][31:16]);
            op_terms     <= d[4][17:0];
            op_stride    <= d[4][19:18];
            op_pad       <= d[4][22:20];
            op_w_off     <= d[5][23:0];
            op_b_off     <= d[6][23:0];
            op_m_off     <= d[7][23:0];
            op_s_off     <= d[8][23:0];
            op_in_base   <= d[9][23:0];
            op_out_base  <= d[10][23:0];
            op_aux1      <= d[11];
            op_aux2      <= d[12];
            op_aux3      <= d[13];
            op_aux4      <= d[14];
            // d[15] is read on this same edge, so its nonblocking update is
            // not visible here. Read the current ROM word directly.
            op_aux5      <= opmem[op_act_r*16 + 15];
            // Residual element count is used every issue cycle.  Calculate
            // H*W during descriptor decode, then multiply by C once on entry
            // to S_RESID instead of placing two multipliers on its issue path.
            resid_hw_r   <= {16'd0, d[2][15:0]} *
                            {16'd0, decode_width(d[2][31:16])};
        end
    end

    // CH_PER_BLOCK = floor(4096 / TERMS) for the weight-cache window
    always @(*) begin
        case (op_terms)
            18'd384: ch_per_block = 12'd10;
            18'd272: ch_per_block = 12'd15;
            18'd256: ch_per_block = 12'd16;
            18'd192: ch_per_block = 12'd21;
            18'd96:  ch_per_block = 12'd42;
            18'd80:  ch_per_block = 12'd51;
            18'd72:  ch_per_block = 12'd56;
            18'd64:  ch_per_block = 12'd64;
            18'd48:  ch_per_block = 12'd85;
            18'd32:  ch_per_block = 12'd128;
            18'd25:  ch_per_block = 12'd163;
            18'd24:  ch_per_block = 12'd170;
            18'd16:  ch_per_block = 12'd256;
            18'd9:   ch_per_block = 12'd455;
            18'd8:   ch_per_block = 12'd512;
            default: ch_per_block = 12'd1;
        endcase
    end

    // Constant-per-op product (input width x input channels).  Registering it
    // keeps the per-term conv address to a single multiply level: the serial
    // (ih*W + iw)*C becomes ih*(W*C) + iw*C with two independent products.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) op_wc_r <= 0;
        else op_wc_r <= op_w_in * op_ch_in;
    end

    // Same idea for the pool/gap/gate loop bound: one registered product
    // instead of a 16x16 multiply sitting directly on three compare paths.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) op_hw_r <= 0;
        else op_hw_r <= op_h_in * op_w_in;
    end

    // ------------------------------------------------------------ conv streaming act address
    // The per-term activation address is maintained INCREMENTALLY in registers
    // so the deep oh/ow multiplier tree runs only at pixel boundaries and not
    // on the per-term conv critical path (the 100 MHz ddr_clk path was
    // term_index -> serial multipliers -> cache tag -> miss index).  vaddr_r
    // advances on conv_req exactly like the engine's term_index_r, so the
    // candidate/read address is never one cycle stale.
    reg [4:0]  kh_r, kw_r;
    reg signed [16:0] ih_r, iw_r;
    reg [23:0] vaddr_r;
    reg        pad_r;

    wire [17:0] rem_c = op_terms - eng_ti;
    wire [17:0] burst_size_c = (rem_c > 18'd4) ? 18'd4 : rem_c;
    // per-op kernel step/wrap increments for the non-pw (kh,kw) walk:
    //   addr = base + (oh*stride+kh-pad)*WC + (ow*stride+kw-pad)*C + co
    //   kw+1 -> +C ; kw wraps (kh+1) -> +WC-(K-1)*C   (stride cancels out)
    wire [23:0] km1_c = (op_kind == K_DW5) ? ({8'd0, op_ch_in} << 2)
                                           : ({8'd0, op_ch_in} << 1);
    wire [23:0] wrap_incr = op_wc_r - km1_c;
    wire [4:0]  k_max = (op_kind == K_DW5) ? 5'd5 : 5'd3;

    // Term-0 setup is split over three idle cycles: coordinates/padding,
    // independent row/column products, then address sum.  This keeps both
    // stride decode and multiplication off the address-register path.
    reg signed [16:0] ih_init_r, iw_init_r;
    reg        pad_init_r;
    reg [23:0] row_term_r, col_term_r;
    // 17-bit signed multiplicands for the term-0 address products; is_pw uses
    // the 8/10-bit oh/ow values zero-extended into the same 17-bit container.
    wire signed [16:0] rt_m = is_pw ? {9'd0, oh_r} : ih_init_r;
    wire signed [16:0] ct_m = is_pw ? {7'd0, ow_r} : iw_init_r;
    reg [23:0] vaddr_init_r;
    reg        pad_init_c;
    reg signed [16:0] ih_init_c, iw_init_c;
    integer ih0, iw0;
    always @(*) begin
        if (is_pw) begin
            ih_init_c = 17'sd0; iw_init_c = 17'sd0;
            pad_init_c = 1'b0;
        end else begin
            ih0 = $signed(oh_r)*$signed({16'd0, op_stride}) - $signed(op_pad);
            iw0 = $signed(ow_r)*$signed({16'd0, op_stride}) - $signed(op_pad);
            ih_init_c = ih0[16:0]; iw_init_c = iw0[16:0];
            pad_init_c = !(ih0 >= 0 && ih0 < $signed({16'd0, op_h_in}) &&
                           iw0 >= 0 && iw0 < $signed({16'd0, op_w_in}));
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            init_phase_r <= 2'd0;
            ih_init_r <= 0; iw_init_r <= 0;
            pad_init_r <= 0; row_term_r <= 0; col_term_r <= 0;
            vaddr_init_r <= 0;
        end else if (st_r != S_CONV || mac_run_r || eng_start_c) begin
            init_phase_r <= 2'd0;
        end else if (!eng_busy) begin
            if (init_phase_r == 2'd0) begin
                ih_init_r <= ih_init_c;
                iw_init_r <= iw_init_c;
                pad_init_r <= pad_init_c;
                init_phase_r <= 2'd1;
            end else if (init_phase_r == 2'd1) begin
                // 17-bit multiplicands instead of a 32-bit sign-extended one:
                // the 32 x 24 product made PDS build a THREE-APM cascade
                // (N945 -> N1048_m1 -> N1048_m2, ~5.6 ns of APM delay), the
                // worst core200_clk path.  Bit-exact (only low 24 bits are
                // kept either way); needs <=2 parallel APMs for row, 1 for col.
                row_term_r <= rt_m * $signed({1'b0, op_wc_r});
                col_term_r <= ct_m * $signed({1'b0, op_ch_in});
                init_phase_r <= 2'd2;
            end else if (init_phase_r == 2'd2) begin
                // act_mem is NHWC: pixel*C + channel.
                vaddr_init_r <= op_in_base + row_term_r + col_term_r +
                    ((is_pw || op_kind == K_CONV1) ? 18'd0 : co_r);
                init_phase_r <= 2'd3;
            end
        end
    end

    wire kw_wrap = (kw_r == k_max - 5'd1);
    wire signed [16:0] ih_next = kw_wrap ? (ih_r + 17'sd1) : ih_r;
    wire signed [16:0] iw_next = kw_wrap ? iw_init_r : (iw_r + 17'sd1);
    wire pad_next = !(ih_next >= 17'sd0 && ih_next < $signed({1'b0, op_h_in}) &&
                      iw_next >= 17'sd0 && iw_next < $signed({1'b0, op_w_in}));
    wire [23:0] vaddr_next = vaddr_r + (kw_wrap ? wrap_incr : {8'd0, op_ch_in});

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            kh_r <= 0; kw_r <= 0; ih_r <= 0; iw_r <= 0;
            vaddr_r <= 0; pad_r <= 0;
        end else if (eng_start_c) begin
            kh_r <= 0; kw_r <= 0;
            ih_r <= ih_init_r; iw_r <= iw_init_r;
            vaddr_r <= vaddr_init_r; pad_r <= pad_init_r;
        end else if (conv_req) begin
            if (is_pw) begin
                vaddr_r <= vaddr_r + burst_size_c;
                pad_r <= 1'b0;
            end else begin
                kh_r <= kw_wrap ? kh_r + 5'd1 : kh_r;
                kw_r <= kw_wrap ? 5'd0 : kw_r + 5'd1;
                ih_r <= ih_next; iw_r <= iw_next;
                vaddr_r <= vaddr_next; pad_r <= pad_next;
            end
        end
    end

    assign conv_candidate_valid_o = conv_candidate_valid;
    assign conv_candidate_addr_o = vaddr_r;
    assign conv_candidate_pad_o = pad_r;
    // Residual phase tags assume the same fixed-latency hit as convolution.
    assign scalar_candidate_valid_o = (st_r == S_RESID) &&
        !resid_setup_r && (resid_k_r < resid_total_r) &&
        (resid_issue_r == 2'd0) && (rq_pending_r < (RQ_DEPTH - 2)) && wr_ready_i;
    assign scalar_candidate_addr_o = resid_phase_r ? resid_addr_b_r : resid_addr_a_r;
    assign scalar_mode_o = (st_r == S_RESID);

    // ------------------------------------------------------------ req context capture
    // At the conv_req (issue) edge, coherently capture the CURRENT term's
    // {term_index, pad} into one register set, so the weight cache / pad chain
    // both sample the SAME term (they previously sampled consecutive-cycle req
    // info and drifted by +/-1 term).
    reg [17:0] ctx_term_r;
    reg        ctx_pad_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin ctx_term_r <= 0; ctx_pad_r <= 0; end
        else if (conv_req) begin
            ctx_term_r <= eng_ti;
            ctx_pad_r   <= pad_r;
        end
    end

    // The streams sample the captured ctx ONE cycle after the issue edge
    // (their registers update at edge C+2 for issue@C).  Gate that sampling
    // with a DELAYED conv_req so the LAST term of a burst (when the engine's
    // issue has already gone low) is still latched instead of holding the
    // previous term's address/weight.
    reg conv_req_d1_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) conv_req_d1_r <= 0;
        else conv_req_d1_r <= conv_req;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin pad_d1_r <= 0; pad_d2_r <= 0; end
        else begin
            pad_d1_r <= conv_req_d1_r ? ctx_pad_r : 1'b0;
            pad_d2_r <= pad_d1_r;
        end
    end

    // The DDR activation cache uses synchronous block RAM.  Launch its read
    // on the issue edge so its registered word is ready for the engine's
    // fixed two-cycle MAC pair; weight/pad context stays on its own pipeline.
    assign rd_req_valid_o = conv_req ? 1'b1 : rd_req_valid_r;
    assign rd_byte_addr_o = (st_r == S_CONV) ? vaddr_r : rd_byte_addr_r;
    assign rd_req_pad_o = conv_req && pad_r;

    // rd_data_i follows the address captured at the preceding conv_req edge;
    // ctx_pad_r is captured on that same request edge. Use this shared request
    // context here so activation data and padding belong to the same term.
    wire [7:0] act_b0 = ctx_pad_r ? 8'd0 :
        is_pw ? conv_rd_data_i[7:0] : conv_rd_data_i[8*conv_rd_lane_i +: 8];
    wire [7:0] act_b1 = is_pw ? conv_rd_data_i[15:8] : 8'd0;
    wire [7:0] act_b2 = is_pw ? conv_rd_data_i[23:16] : 8'd0;
    wire [7:0] act_b3 = is_pw ? conv_rd_data_i[31:24] : 8'd0;
    wire signed [9:0] a0_v = op_uin ? {2'b00, act_b0} : {{2{act_b0[7]}}, act_b0};
    wire signed [9:0] a1_v = op_uin ? {2'b00, act_b1} : {{2{act_b1[7]}}, act_b1};
    wire signed [9:0] a2_v = op_uin ? {2'b00, act_b2} : {{2{act_b2[7]}}, act_b2};
    wire signed [9:0] a3_v = op_uin ? {2'b00, act_b3} : {{2{act_b3[7]}}, act_b3};

    wire [7:0] wc_byte = (wc_lane == 2'd0) ? wc_w0[7:0] :
                         (wc_lane == 2'd1) ? wc_w1[7:0] :
                         (wc_lane == 2'd2) ? wc_w2[7:0] : wc_w3[7:0];
    wire signed [7:0] w0_v = is_pw ? wc_w0 : $signed(wc_byte);
    wire signed [7:0] w1_v = is_pw ? wc_w1 : 8'sd0;
    wire signed [7:0] w2_v = is_pw ? wc_w2 : 8'sd0;
    wire signed [7:0] w3_v = is_pw ? wc_w3 : 8'sd0;

    // Timing-closure pipeline stage: register the activation and weight feeds
    // one extra cycle to break the distributed-RAM -> byte-mux -> MAC-multiply
    // critical path. The engine's pair_valid is correspondingly delayed from
    // issue_d2 to issue_d3 (see mn04_shared_layer_engine.v), so the MAC samples
    // act/w at C+3 instead of C+2 with bit-identical results.
    reg signed [9:0] a0_d1_r, a1_d1_r, a2_d1_r, a3_d1_r;
    reg signed [9:0] a0_r, a1_r, a2_r, a3_r;
    reg signed [7:0] w0_r, w1_r, w2_r, w3_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a0_d1_r <= 0; a1_d1_r <= 0; a2_d1_r <= 0; a3_d1_r <= 0;
            a0_r <= 0; a1_r <= 0; a2_r <= 0; a3_r <= 0;
            w0_r <= 0; w1_r <= 0; w2_r <= 0; w3_r <= 0;
        end else begin
            // Activation RAM data is available one cycle before the delayed
            // weight-cache response. Keep the activation beat aligned with
            // w*_r at the MAC input when consecutive 4-byte terms are issued.
            a0_d1_r <= a0_v; a1_d1_r <= a1_v; a2_d1_r <= a2_v; a3_d1_r <= a3_v;
            a0_r <= a0_d1_r; a1_r <= a1_d1_r; a2_r <= a2_d1_r; a3_r <= a3_d1_r;
            w0_r <= w0_v; w1_r <= w1_v; w2_r <= w2_v; w3_r <= w3_v;
        end
    end

    // ------------------------------------------------------------ submodules
    mn04_requantize_pipe rq (
        .clk(clk), .rst_n(rst_n), .start_i(rq_start_r),
        .acc_i(rq_acc_r), .mult_i(rq_mult_r), .shift_i(rq_shift_r),
        .valid_o(rq_valid_w), .y_o(rq_y)
    );

    mn04_shared_layer_engine #(.LANES(4)) eng4 (
        .clk(clk), .rst_n(rst_n), .uact_i(op_uin),
        .start_i(eng_start4_r), .layer_id_i(3'd0),
        .bias_i(bias_ram[co_r]), .terms_i(op_terms),
        .busy_o(eng4_busy), .done_o(eng4_done), .sum_o(eng4_sum),
        .term_index_o(eng4_ti), .lane_mask_o(),
        .pair_request_valid_o(eng4_pair_req), .pair_request_ready_i(conv_req_ready_i),
        .pair_response_valid_i(1'b1),
        .a0_i(a0_r), .a1_i(a1_r), .a2_i(a2_r), .a3_i(a3_r),
        .w0_i(w0_r), .w1_i(w1_r), .w2_i(w2_r), .w3_i(w3_r),
        .active_layer_o()
    );

    mn04_shared_layer_engine #(.LANES(1)) eng1 (
        .clk(clk), .rst_n(rst_n), .uact_i(op_uin),
        .start_i(eng_start1_r), .layer_id_i(3'd0),
        .bias_i(bias_ram[co_r]), .terms_i(op_terms),
        .busy_o(eng1_busy), .done_o(eng1_done), .sum_o(eng1_sum),
        .term_index_o(eng1_ti), .lane_mask_o(),
        .pair_request_valid_o(eng1_pair_req), .pair_request_ready_i(conv_req_ready_i),
        .pair_response_valid_i(1'b1),
        .a0_i(a0_r), .a1_i(a1_r), .a2_i(a2_r), .a3_i(a3_r),
        .w0_i(w0_r), .w1_i(w1_r), .w2_i(w2_r), .w3_i(w3_r),
        .active_layer_o()
    );

    mn04_weight_block_cache wc (
        .clk(clk), .rst_n(rst_n),
        .load_start_i(wc_load_start_c), .flash_base_i(wc_flash_base_c),
        .loaded_o(wc_loaded), .qspi_start_o(wc_qspi_start),
        .qspi_addr_o(wc_qspi_addr), .qspi_count_o(wc_qspi_count),
        .qspi_byte_i(wc_src_byte), .qspi_byte_valid_i(wc_src_byte_valid),
        .qspi_byte_ready_o(wc_byte_ready),
        .weight_offset_i(wc_off_r), .req_valid_i(conv_req_d1_r),
        .req_ready_o(wc_req_ready), .term_index_i(ctx_term_r),
        .rsp_valid_o(wc_rsp_valid), .byte_lane_o(wc_lane),
        .w0_o(wc_w0), .w1_o(wc_w1), .w2_o(wc_w2), .w3_o(wc_w3)
    );

    // reader start/addr/count mux + lut write-enable (declared before use)
`ifdef USE_DDR_WEIGHTS
    // wc is no longer a QSPI client: the DDR feeder serves it directly.
    wire qspi_start_o = pre_start_c || lut_start_c;
    wire qspi_byte_ready_o = pre_active_r || lut_active_r;
`else
    wire qspi_start_o = pre_start_c || lut_start_c || wc_qspi_start;
    wire qspi_byte_ready_o = pre_active_r || lut_active_r || (wc_load_active_r && wc_byte_ready);
`endif
    wire [23:0] qspi_addr_o = pre_active_r ? pre_addr_r :
                              (lut_active_r ? lut_addr_r : wc_qspi_addr);
    wire [15:0] qspi_count_o = pre_active_r ? pre_count_r :
                               (lut_active_r ? 16'd256 : wc_qspi_count);
    wire lut_ld_en_c = (st_r == S_LUT) && lut_active_r && qr_byte_valid;

    mn04_qspi_block_reader #(.SPI_DIV_HALF(2), .FAST_BYTES(FAST_BYTES)) qr (
        .clk(clk), .rst_n(rst_n), .start_i(qspi_start_o),
        .addr_i(FLASH_IMAGE_BASE + qspi_addr_o),
        .count_i(qspi_count_o), .busy_o(), .done_o(qr_done),
        .byte_o(qr_byte), .byte_valid_o(qr_byte_valid), .byte_ready_i(qspi_byte_ready_o),
        .flash_rd_addr_o(flash_rd_addr_o), .flash_rd_data_i(flash_rd_data_i),
        .cs_o(qspi_cs_o), .sck_o(qspi_sck_o),
        .mosi_o(qspi_mosi_o), .miso_i(qspi_miso_i)
    );

    // ---- weight cache byte source: DDR feeder (USE_DDR_WEIGHTS) or QSPI reader
`ifdef USE_DDR_WEIGHTS
    mn04_ddr_weight_feeder #(.FIFO_DEPTH(4), .WEIGHT_BASE_WORD(WEIGHT_BASE_WORD)) ddr_w (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done_i),
        .start_i(wc_qspi_start), .addr_i(wc_qspi_addr), .count_i(wc_qspi_count),
        .busy_o(), .done_o(),
        .byte_o(wc_src_byte), .byte_valid_o(wc_src_byte_valid),
        .byte_ready_i(wc_byte_ready),
        .araddr_o(ddr_araddr_o), .arvalid_o(ddr_arvalid_o), .arready_i(ddr_arready_i),
        .rdata_i(ddr_rdata_i), .rresp_i(ddr_rresp_i), .rvalid_i(ddr_rvalid_i),
        .rready_o(ddr_rready_o)
    );
`else
    assign wc_src_byte       = qr_byte;
    assign wc_src_byte_valid = qr_byte_valid;
`endif

    mn04_act_lut_ram lut (
        .clk(clk), .rst_n(rst_n),
        .ld_en_i(lut_ld_en_c), .ld_addr_i(lut_ld_addr_r), .ld_data_i(qr_byte),
        .rd_idx_i(rq_y + 8'd128), .rd_data_o(lut_rd_data)
    );

    // ------------------------------------------------------------ preload byte capture
`ifdef DEBUG_CORE
    integer dbg_pre0, dbg_pre1, dbg_pre2, dbg_lut0;
    always @(posedge clk) begin
        if (st_r == S_PRE_BIAS && pre_active_r && qr_byte_valid) dbg_pre0 = dbg_pre0 + 1;
        if (st_r == S_PRE_MULT && pre_active_r && qr_byte_valid) dbg_pre1 = dbg_pre1 + 1;
        if (st_r == S_PRE_SHIFT && pre_active_r && qr_byte_valid) dbg_pre2 = dbg_pre2 + 1;
        if (st_r == S_LUT && lut_active_r && qr_byte_valid) dbg_lut0 = dbg_lut0 + 1;
        if (pre_started_r && st_r == S_PRE_BIAS && !pre_active_r) $display("DBG pre bias bytes=%0d first4=%0d,%0d,%0d,%0d", dbg_pre0, bias_ram[0], bias_ram[1], bias_ram[2], bias_ram[3]);
        if (pre_started_r && st_r == S_PRE_MULT && !pre_active_r) $display("DBG pre mult bytes=%0d first4=%0d,%0d,%0d,%0d", dbg_pre1, mult_ram[0], mult_ram[1], mult_ram[2], mult_ram[3]);
        if (pre_started_r && st_r == S_PRE_SHIFT && !pre_active_r) $display("DBG pre shift bytes=%0d first4=%0d,%0d,%0d,%0d", dbg_pre2, shift_ram[0], shift_ram[1], shift_ram[2], shift_ram[3]);
        if (lut_started_r && st_r == S_LUT && !lut_active_r) $display("DBG lut bytes=%0d lut[112]=%0d lut[128]=%0d lut[200]=%0d", dbg_lut0, lut.lut[112], lut.lut[128], lut.lut[200]);
    end
`endif
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pre_cnt_r <= 0; pre_word_r <= 0;
        end else if (pre_active_r && qr_byte_valid) begin
            pre_word_r <= {qr_byte, pre_word_r[31:8]};
            if (st_r == S_PRE_SHIFT) begin
                shift_ram[pre_cnt_r] <= $signed(qr_byte);
                pre_cnt_r <= pre_cnt_r + 1'b1;
            end else begin
                // word write: pre_word_r holds the completed LE word only after the 4th
                // byte shifted in; write it at the next byte tick (cnt%4==0, cnt>=4).
                if (pre_cnt_r[1:0] == 2'd0 && pre_cnt_r >= 4) begin
                    if (st_r == S_PRE_BIAS) begin
                        bias_ram[pre_cnt_r[15:2]-1] <= $signed(pre_word_r);
                        if (pre_cnt_r[15:2]-1 < 4) $display("DBG prewr bias idx=%0d cnt=%0d word=%h", pre_cnt_r[15:2]-1, pre_cnt_r, pre_word_r);
                    end else begin
                        mult_ram[pre_cnt_r[15:2]-1] <= $signed(pre_word_r);
                        if (pre_cnt_r[15:2]-1 < 4) $display("DBG prewr mult idx=%0d cnt=%0d word=%h", pre_cnt_r[15:2]-1, pre_cnt_r, pre_word_r);
                    end
                end
                pre_cnt_r <= pre_cnt_r + 1'b1;
            end
        end else if (qr_done && (st_r == S_PRE_BIAS || st_r == S_PRE_MULT)) begin
            // flush the FINAL word: the in-stream write fires at the byte tick
            // cnt%4==0, so the last word (whose 4th byte is the last byte of the
            // load) never gets a tick -> write it here at the qr_done edge
            // (pre_cnt_r == total byte count, pre_word_r == last 4 bytes).
            if (st_r == S_PRE_BIAS) begin
                bias_ram[pre_cnt_r[15:2]-1] <= $signed(pre_word_r);
                $display("DBG prewr bias FINAL idx=%0d cnt=%0d word=%h", pre_cnt_r[15:2]-1, pre_cnt_r, pre_word_r);
            end else begin
                mult_ram[pre_cnt_r[15:2]-1] <= $signed(pre_word_r);
                $display("DBG prewr mult FINAL idx=%0d cnt=%0d word=%h", pre_cnt_r[15:2]-1, pre_cnt_r, pre_word_r);
            end
            pre_cnt_r <= 0;
            pre_word_r <= 0;
        end else if (qr_done && st_r == S_PRE_SHIFT) begin
            pre_cnt_r <= 0;
            pre_word_r <= 0;
        end
    end

    // LUT load capture
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) lut_ld_addr_r <= 0;
        else if (st_r == S_LUT && lut_active_r && qr_byte_valid)
            lut_ld_addr_r <= lut_ld_addr_r + 1'b1;
        else if (st_r != S_LUT)
            lut_ld_addr_r <= 0;
    end

    // ------------------------------------------------------------ requant bookkeeping
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rq_pending_r <= 0;
            rq_phase_r <= 0; rq_valid_phase_r <= 0;
            rq_phase_shift <= 0;
        end else begin
            // Pending-tracking hazard: if rq_start_r and rq_valid_w are both
            // high in the same cycle, two nonblocking writes to rq_pending_r
            // would collide and the LAST (decrement) wins, underflowing the
            // counter (0 -> -1 == 15) and deadlocking S_RESID/S_DRAIN.  The
            // residual stream has a start and a valid EVERY cycle, so this
            // must be handled explicitly as a net-zero case.
            if (rq_start_r && rq_valid_w) begin
                rq_pending_r <= rq_pending_r;      // net zero
                rq_phase_r <= ~rq_phase_r;
            end else begin
                if (rq_start_r) begin
                    rq_pending_r <= rq_pending_r + 1'b1;
                    rq_phase_r <= ~rq_phase_r;
                end
                if (rq_valid_w) begin
                    rq_pending_r <= rq_pending_r - 1'b1;
                end
            end
            // Free-running phase shift: shifts EVERY cycle (not only on
            // start/valid), so bit [7] carries the value pushed 8 cycles
            // ago.  GATE4 L001 fix: the pushed value must be the phase of
            // the request whose response fires THIS start, i.e. the phase
            // captured at the rsp edge.  rq_start_r goes high one cycle
            // AFTER the rsp edge (nonblocking), and resid_ph_d2_r at that
            // cycle already holds the NEXT (flipped) phase -- pushing
            // resid_ph_d2_r tagged every residual A-requant as B (first
            // valid vph=1, term_a written with the B writeback path).
            // rsp_phase_d2_r (updated on the rsp edge, L796) holds the
            // correct phase for the start that follows it.
            rq_phase_shift <= (rq_start_r)
                ? {rq_phase_shift[6:0], rsp_phase_d2_r}
                : {rq_phase_shift[6:0], 1'b0};
            // The extra rounding pipeline stage makes valid arrive one cycle
            // later.  Capture the pre-edge bit [6], which was pushed at T-8.
            rq_valid_phase_r <= rq_phase_shift[6];
        end
    end

    // ------------------------------------------------------------ main FSM
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st_r <= S_IDLE; op_act_r <= 0; fetch_i_r <= 0; dump_cnt_r <= 0;
            segment_end_op_r <= N_OPS-1; short_window_r <= 1'b0;
            class_window_mode_r <= 2'd0;
            co_r <= 0; co_in_block_r <= 0; oh_r <= 0; ow_r <= 0; mac_run_r <= 0;
            conv_out_addr_r <= 0;
            wblock_r <= 0; wc_off_r <= 0;
            wc_block_offset_r <= 0; wc_block_stride_r <= 24'd4096;
            sum_cap_r <= 0;
            pre_started_r <= 0; lut_started_r <= 0; wc_started_r <= 0;
            pre_active_r <= 0; lut_active_r <= 0; wc_load_active_r <= 0;
            pre_addr_r <= 0; pre_count_r <= 0; lut_addr_r <= 0;
            pool_co_r <= 0; pool_pix_r <= 0; pool_pending_r <= 0; pool_addr_r <= 0;
            pool_delay_r <= 0; sum_acc_r <= 0;
            gap_pix_r <= 0; gap_pending_r <= 0; gap_delay_r <= 0;
            gate_co_r <= 0; gate_byte_r <= 0; gate_phase_r <= 0;
            gate_pix_r <= 0; gate_wait_r <= 0; gate_delay_r <= 0;
            gate_pix_term_r <= 0;
            gate_have_r <= 0; gate_byte2_r <= 0;
            eng_done_cap_r <= 0;
            resid_k_r <= 0; resid_k_d1_r <= 0; resid_k_d2_r <= 0; resid_k_d3_r <= 0;
            resid_addr_a_r <= 0; resid_addr_b_r <= 0;
            resid_phase_r <= 0; resid_ph_d1_r <= 0; resid_ph_d2_r <= 0; resid_ph_d3_r <= 0;
            resid_issue_r <= 0;
            resid_reads_outstanding_r <= 0;
            resid_total_r <= 0; resid_setup_r <= 0;
            rsp_phase_d2_r <= 0;
            drain_cnt_r <= 0;
            done_o <= 0; cycle_count_o <= 0; dump_valid_o <= 0;
            dump_id_o <= 0; dump_op_index_o <= 0;
            rq_start_r <= 1'b0;
            rq_tail_r <= 0;
            rd_req_valid_r <= 1'b0;
            rd_byte_addr_r <= 24'd0;
        end else begin
            // rq_start_r is a 1-cycle pulse generated ONLY by this (main-FSM)
            // always: default-clear here, then the S_CONV eng_done / S_RESID
            // rsp branches override with 1'b1.  Previously the clear lived in
            // the requant-accounting always too, creating a MULTI-DRIVER on
            // rq_start_r: the simulator resolved the A-rsp starts as lost
            // (only every other residual start fired -> residual wrote never).
            rq_start_r <= 1'b0;
            rd_req_valid_r <= 1'b0;
            done_o <= 0; dump_valid_o <= 0;
            if (cycle_count_o != 32'hFFFFFFFF) cycle_count_o <= cycle_count_o + 1'b1;

            case (st_r)
                S_IDLE: begin
                    if (start_i) begin
                        op_act_r <= segment_start_op_i;
                        segment_end_op_r <= segment_end_op_i;
                        short_window_r <= short_window_i;
                        class_window_mode_r <= class_window_mode_i;
                        dump_cnt_r <= 0; st_r <= S_FETCH; fetch_i_r <= 0;
                    end
                end
                S_FETCH: begin
                    if (fetch_i_r < 15)
                        fetch_i_r <= fetch_i_r + 1'b1;
                    else begin
                        fetch_i_r <= 0;
                        case (d[0][15:8])
                            OP_CONV: begin
                                co_r <= 0; co_in_block_r <= 0; oh_r <= 0; ow_r <= 0;
                                conv_out_addr_r <= d[10][23:0];
                                wblock_r <= 0; wc_off_r <= 0;
                                wc_block_offset_r <= 0;
                                wc_block_stride_r <=
                                    (opmem[op_act_r*16 + 15][23:0] != 24'd0) ?
                                    opmem[op_act_r*16 + 15][23:0] : 24'd4096;
                                mac_run_r <= 0; wc_started_r <= 0;
                                st_r <= d[0][5] ? S_LUT : S_PRE_BIAS;
                            end
                            OP_POOL: begin
                                pool_co_r <= 0; pool_pix_r <= 0; pool_pending_r <= 0;
                                pool_addr_r <= d[9][23:0];
                                pool_delay_r <= 0;
                                sum_acc_r <= 0; st_r <= S_POOL;
                            end
                            OP_GAP: begin
                                pool_co_r <= 0; gap_pix_r <= 0; gap_pending_r <= 0;
                                gap_delay_r <= 0;
                                sum_acc_r <= 0; st_r <= S_GAP;
                            end
                            OP_GATE: begin
                                gate_co_r <= 0; gate_phase_r <= 0; gate_pix_r <= 0;
                                gate_pix_term_r <= 0;
                                gate_wait_r <= 0; gate_delay_r <= 0; st_r <= S_GATE;
                            end
                            OP_RESIDUAL: begin
                                resid_k_r <= 0; resid_phase_r <= 0; resid_k_d1_r <= 0;
                                // Descriptor registers latch on this same edge;
                                // use the current descriptor words, not the
                                // previous op's registered bases.
                                resid_addr_a_r <= d[9][23:0];
                                resid_addr_b_r <= d[14][23:0];
                                resid_k_d2_r <= 0; resid_k_d3_r <= 0;
                                resid_ph_d1_r <= 0; resid_ph_d2_r <= 0; resid_ph_d3_r <= 0;
                                resid_issue_r <= 0;
                                resid_reads_outstanding_r <= 0;
                                resid_setup_r <= 1'b1;
                                rsp_phase_d2_r <= 0; st_r <= S_RESID;
                            end
                            default: st_r <= S_DRAIN;
                        endcase
                    end
                end
                S_LUT: begin
                    lut_active_r <= 1'b1;
                    if (!lut_active_r) lut_addr_r <= LUTS_BASE + {8'd0, op_lut_id} * 16'd256;
                    if (lut_start_c) lut_started_r <= 1'b1;
                    if (qr_done && lut_started_r) begin
                        lut_active_r <= 1'b0; lut_started_r <= 0; st_r <= S_PRE_BIAS;
                    end
                end
                S_PRE_BIAS: begin
                    pre_active_r <= 1'b1;
                    if (!pre_active_r) begin
                        pre_addr_r <= op_b_off; pre_count_r <= op_ch_out * 16'd4;
                    end
                    if (pre_start_c) pre_started_r <= 1'b1;
                    if (qr_done && pre_started_r) begin
                        pre_active_r <= 1'b0; pre_started_r <= 0;
                        st_r <= S_PRE_MULT;
                    end
                end
                S_PRE_MULT: begin
                    pre_active_r <= 1'b1;
                    if (!pre_active_r) begin
                        pre_addr_r <= op_m_off; pre_count_r <= op_ch_out * 16'd4;
                    end
                    if (pre_start_c) pre_started_r <= 1'b1;
                    if (qr_done && pre_started_r) begin
                        pre_active_r <= 1'b0; pre_started_r <= 0;
                        st_r <= S_PRE_SHIFT;
                    end
                end
                S_PRE_SHIFT: begin
                    pre_active_r <= 1'b1;
                    if (!pre_active_r) begin
                        pre_addr_r <= op_s_off; pre_count_r <= op_ch_out;
                    end
                    if (pre_start_c) pre_started_r <= 1'b1;
                    if (qr_done && pre_started_r) begin
                        pre_active_r <= 1'b0; pre_started_r <= 0;
                        st_r <= S_WLOAD;
                    end
                end
                S_WLOAD: begin
                    wc_load_active_r <= 1'b1;
                    if (wc_load_start_c) wc_started_r <= 1'b1;
                    if (wc_loaded && wc_started_r) begin
                        wc_load_active_r <= 1'b0; wc_started_r <= 0; st_r <= S_CONV;
                    end
                end
                S_CONV: begin
                    if (mac_run_r && eng_done) eng_done_cap_r <= 1'b1;
                    if (eng_done_cap_r || (mac_run_r && eng_done)) begin
                        if (rq_can_start) begin
                            // requant of the finished pixel
                            rq_acc_r <= eng_sum;
                            rq_mult_r <= mult_ram[co_r];
                            rq_shift_r <= shift_ram[co_r];
                            rq_start_r <= 1'b1;
                            rq_fifo[rq_tail_r] <= conv_out_addr_r;
                            rq_tail_r <= rq_tail_r + 1'b1;
                            eng_done_cap_r <= 1'b0;
                            mac_run_r <= 1'b0;
                            conv_out_addr_r <= conv_out_addr_r + op_ch_out;
                            if (ow_r == op_w_out - 1) begin
                                ow_r <= 0;
                                if (oh_r == op_h_out - 1) begin
                                    oh_r <= 0;
                                    if (co_r == op_ch_out - 1) st_r <= S_DRAIN;
                                    else begin
                                        co_r <= co_r + 1'b1;
                                        conv_out_addr_r <= op_out_base + co_r + 1'b1;
                                        if (co_in_block_r == ch_per_block - 1) begin
                                            co_in_block_r <= 0; wc_started_r <= 0; st_r <= S_WLOAD;
                                            wblock_r <= wblock_r + 1'b1; wc_off_r <= 0;
                                            wc_block_offset_r <= wc_block_offset_r + wc_block_stride_r;
                                        end else begin
                                            co_in_block_r <= co_in_block_r + 1'b1;
                                            wc_off_r <= wc_off_r + op_terms[11:0];
                                        end
                                    end
                                end else oh_r <= oh_r + 1'b1;
                            end else ow_r <= ow_r + 1'b1;
                        end
                    end else if (!mac_run_r && eng_start_c) begin
                        mac_run_r <= 1'b1;
                    end
                end
                S_POOL: begin
                    // act_mem's data word is combinational from its held
                    // address.  Consecutive requests overwrite that address
                    // before the prior rd_rsp_valid is consumed.  Keep one
                    // read outstanding and wait for its response before the
                    // next pixel (also avoids increment/decrement writes to
                    // pool_pending_r colliding in one clock).
                    if (pool_pending_r != 0) begin
                        if (pool_delay_r != 0) pool_delay_r <= pool_delay_r - 1'b1;
                        else if (rd_rsp_valid_i) begin
                            sum_acc_r <= sum_acc_r + $signed({{24{rd_data_i[8*rd_lane_i+7]}},
                                                             rd_data_i[8*rd_lane_i +: 8]});
                            pool_pending_r <= 0;
                        end
                    end else if (pool_pix_r < op_hw_r) begin
                        rd_req_valid_r <= 1'b1;
                        rd_byte_addr_r <= pool_addr_r;
                        pool_addr_r <= pool_addr_r + op_ch_in;
                        pool_pix_r <= pool_pix_r + 1'b1;
                        pool_pending_r <= 1;
                        pool_delay_r <= 3;
                    end else if (rq_can_start) begin
                        rq_acc_r <= sum_acc_r; rq_mult_r <= op_aux1; rq_shift_r <= op_aux2[7:0];
                        rq_start_r <= 1'b1;
                        rq_fifo[rq_tail_r] <= op_out_base + pool_co_r;
                        rq_tail_r <= rq_tail_r + 1'b1;
                        if (pool_co_r == op_ch_out - 1) begin
                            pool_co_r <= pool_co_r + 1'b1; st_r <= S_DRAIN;
                        end else begin
                            pool_co_r <= pool_co_r + 1'b1;
                            pool_addr_r <= op_in_base + pool_co_r + 1'b1;
                            pool_pix_r <= 0; sum_acc_r <= 0;
                        end
                    end
                end
                S_GAP: begin
                    if (gap_pending_r != 0) begin
                        if (gap_delay_r != 0) gap_delay_r <= gap_delay_r - 1'b1;
                        else if (rd_rsp_valid_i) begin
                            sum_acc_r <= sum_acc_r + $signed({{24{rd_data_i[8*rd_lane_i+7]}},
                                                             rd_data_i[8*rd_lane_i +: 8]});
                            gap_pending_r <= 0;
                        end
                    end else if (gap_pix_r < op_hw_r) begin
                        rd_req_valid_r <= 1'b1;
                        rd_byte_addr_r <= op_in_base + gap_pix_r*op_ch_in + pool_co_r;
                        gap_pix_r <= gap_pix_r + 1'b1;
                        gap_pending_r <= 1;
                        gap_delay_r <= 3;
                    end else if (rq_can_start) begin
                        rq_acc_r <= sum_acc_r; rq_mult_r <= op_aux1; rq_shift_r <= op_aux2[7:0];
                        rq_start_r <= 1'b1;
                        rq_fifo[rq_tail_r] <= op_out_base + pool_co_r;
                        rq_tail_r <= rq_tail_r + 1'b1;
                        if (pool_co_r == op_ch_out - 1) begin
                            pool_co_r <= pool_co_r + 1'b1; st_r <= S_DRAIN;
                        end else begin
                            pool_co_r <= pool_co_r + 1'b1;
                            gap_pix_r <= 0; sum_acc_r <= 0;
                        end
                    end
                end
                S_GATE: begin
                    case (gate_phase_r)
                        3'd0: begin
                            rd_req_valid_r <= 1'b1;
                            rd_byte_addr_r <= GATE_R_ADDR + gate_co_r;
                            gate_delay_r <= 3;
                            gate_phase_r <= 3'd1;
                        end
                        3'd1: begin
                            // The request is registered at this edge, then
                            // traverses the activation-memory pipeline.  An
                            // earlier convolution response may still assert
                            // rd_rsp_valid_i, so do not consume it as gate.
                            if (gate_delay_r != 0) gate_delay_r <= gate_delay_r - 1'b1;
                            else if (rd_rsp_valid_i) begin
                                gate_byte_r <= rd_data_i[8*rd_lane_i +: 8];
                                gate_phase_r <= 3'd2; gate_pix_r <= 0; gate_wait_r <= 0;
                                gate_pix_term_r <= 24'd0;
                            end
                        end
                        3'd2: begin
                            if (gate_pix_r >= op_hw_r) begin
                                gate_phase_r <= 3'd0; gate_have_r <= 0;
                                if (gate_co_r == op_ch_out - 1) st_r <= S_DRAIN;
                                else gate_co_r <= gate_co_r + 1'b1;
                            end else if (!gate_have_r && !gate_wait_r && rq_can_start) begin
                                rd_req_valid_r <= 1'b1;
                                rd_byte_addr_r <= op_in_base + gate_pix_term_r + gate_co_r;
                                gate_wait_r <= 1'b1;
                                gate_delay_r <= 3;
                            end else if (gate_wait_r && gate_delay_r != 0) begin
                                gate_delay_r <= gate_delay_r - 1'b1;
                            end else if (gate_wait_r && rd_rsp_valid_i) begin
                                gate_byte2_r <= rd_data_i[8*rd_lane_i +: 8];
                                gate_wait_r <= 1'b0; gate_have_r <= 1'b1;
                            end else if (gate_have_r) begin
                                rq_acc_r <= $signed({{24{gate_byte2_r[7]}}, gate_byte2_r}) * {24'd0, gate_byte_r};
                                rq_mult_r <= op_aux1; rq_shift_r <= op_aux2[7:0];
                                rq_start_r <= 1'b1;
                                rq_fifo[rq_tail_r] <= op_in_base + gate_pix_term_r + gate_co_r;
                                rq_tail_r <= rq_tail_r + 1'b1;
                                gate_pix_r <= gate_pix_r + 1'b1;
                                gate_pix_term_r <= gate_pix_term_r + {8'd0, op_ch_in};
                                gate_have_r <= 1'b0;
                            end
                        end
                        default: gate_phase_r <= 3'd0;
                    endcase
                end
                S_RESID: begin
                    if (resid_setup_r) begin
                        resid_total_r <= resid_hw_r * {16'd0, op_ch_in};
                        resid_setup_r <= 1'b0;
                    end
                    if (scalar_candidate_valid_o && scalar_req_ready_i && !rd_rsp_valid_i)
                        resid_reads_outstanding_r <= resid_reads_outstanding_r + 1'b1;
                    else if (!(scalar_candidate_valid_o && scalar_req_ready_i) && rd_rsp_valid_i)
                        resid_reads_outstanding_r <= resid_reads_outstanding_r - 1'b1;
                    // Read requests must be PULSES (default clear), not a
                    // level: the act_mem serves one word per cycle the valid
                    // is high, so a level left high while rq_pending_r >= 6
                    // (issue blocked) keeps streaming responses forever and
                    // deadlocks the FSM (seen: resid_k frozen, pend ~6).
                    //
                    // Requests must ALSO be spaced 2 cycles apart: the
                    // act_mem's rd_data_o is combinational from the held
                    // rd_addr_r, and rd_rsp_valid_o fires 2 cycles after a
                    // request.  With back-to-back A/B requests (one every
                    // cycle) the response's data register samples the NEXT
                    // request's address (the rd_addr_r captured at the rsp
                    // posedge), so every residual requant consumed the wrong
                    // byte (observed: A-acc 74/59/133 instead of f0=3; all
                    // output saturated at +-127).  Issuing every other cycle
                    // keeps rd_addr_r frozen between requests, so the rsp
                    // data at T+2 = mem[addr@T].
                    // Requests must be spaced >=3 cycles apart: the act_mem's
                    // rd_data_o is combinational from the held rd_addr_r, and
                    // rd_rsp_valid_o fires 2 cycles after a request.  With
                    // back-to-back A/B requests (one every 1-2 cycles) the
                    // response's data register samples the NEXT request's
                    // address (the rd_addr_r captured at the rsp posedge), so
                    // every residual requant consumed the wrong byte (observed:
                    // A-acc 74/59/133 instead of pw[0..]; output saturated).
                    // Issuing every 3rd cycle keeps rd_addr_r frozen for the
                    // request whose rsp is at T+2, so the rsp data = the
                    // request's own byte. (A 2->3-cycle spacing costs ~0.5M
                    // cycles on a ~10M-cycle run; the conv path already relies
                    // on this >=3-cycle contract and stays bit-exact.)
                    rd_req_valid_r <= 1'b0;
                    resid_issue_r <= (resid_issue_r == 2'd2) ? 2'd0 : resid_issue_r + 1'b1;
                    // GATE4 L001 root cause: the k bound `op_h_in * op_w_in *
                    // op_ch_in` is a 16-BIT product (all operands 16-bit), so
                    // 64*500*8 = 256000 = 0x3E800 truncated to 0xE800 = 59392:
                    // the residual exited after 59392 pixels (23%), the dump
                    // fired mid-residual and the "L001" compared an INCOMPLETE
                    // tensor. Use a 32-bit product for the bound.
                    if (!resid_setup_r && resid_k_r < resid_total_r) begin
                        if (resid_issue_r == 2'd0 && rq_pending_r < (RQ_DEPTH - 2) &&
                            wr_ready_i && scalar_req_ready_i) begin
                            rd_req_valid_r <= 1'b1;
                            rd_byte_addr_r <= scalar_candidate_addr_o;
                            resid_k_d1_r <= resid_k_r;
                            resid_ph_d1_r <= resid_phase_r;
                            resid_phase_r <= ~resid_phase_r;
                            // k advances on the B issue (phase==1): the issue
                            // order is A(k),B(k),A(k+1),B(k+1),... so A and B
                            // pair the same k. (Verified against the golden:
                            // L001[k] = requant_A(pw[k]) + requant_B(f0[k]).)
                            if (resid_phase_r) begin
                                resid_k_r <= resid_k_r + 1'b1;
                                resid_addr_a_r <= resid_addr_a_r + 1'b1;
                                resid_addr_b_r <= resid_addr_b_r + 1'b1;
                            end
                        end
                    end else if (!resid_setup_r && rq_pending_r == 0 && resid_reads_outstanding_r == 0 &&
                                 !rd_rsp_valid_i && !rq_start_r) begin
                        st_r <= S_DRAIN;
                    end
                    resid_k_d2_r <= resid_k_d1_r;
                    resid_ph_d2_r <= resid_ph_d1_r;
                    resid_k_d3_r <= resid_k_d2_r;
                    resid_ph_d3_r <= resid_ph_d2_r;
                    if (rd_rsp_valid_i) begin
                        if (rdb_n < 12) begin rdb_n = rdb_n + 1;
                            $display("DBG residR kd2=%0d ph2=%0d lane=%0d data=%h",
                                     resid_k_d2_r, resid_ph_d2_r, rd_lane_i, rd_data_i);
                        end
                        // The act_mem serves a response 2 cycles after the
                        // request (rd_d1, rd_d2 -> rsp), so the response's k
                        // and phase must be tracked with a 2-stage delay (d2),
                        // NOT the 3-stage d3: d3 labels every response with
                        // the PREVIOUS request's tag (one request off), which
                        // sent the A data to the B requant and pushed the
                        // wrong write addresses (L001 mismatch ~100%).
                        rsp_phase_d2_r <= resid_ph_d2_r;
                        if (!resid_ph_d2_r) begin
                            rq_acc_r <= $signed({{24{rd_data_i[8*rd_lane_i+7]}},
                                                 rd_data_i[8*rd_lane_i +: 8]});
                            rq_mult_r <= op_aux1; rq_shift_r <= op_aux2[7:0];
                            rq_start_r <= 1'b1;
                            if (rdb_n < 12) begin rdb_n = rdb_n + 1;
                                $display("DBG residA kd2=%0d acc=%0d lane=%0d", resid_k_d2_r,
                                         $signed({{24{rd_data_i[8*rd_lane_i+7]}}, rd_data_i[8*rd_lane_i +: 8]}),
                                         rd_lane_i);
                            end
                        end else begin
                            rq_acc_r <= $signed({{24{rd_data_i[8*rd_lane_i+7]}},
                                                 rd_data_i[8*rd_lane_i +: 8]});
                            rq_mult_r <= op_aux3; rq_shift_r <= op_aux4[31:24];
                            rq_start_r <= 1'b1;
                            rq_fifo[rq_tail_r] <= op_out_base + resid_k_d2_r;
                            rq_tail_r <= rq_tail_r + 1'b1;
                            if (rdb_n < 12) begin rdb_n = rdb_n + 1;
                                $display("DBG residB kd2=%0d acc=%0d lane=%0d push=%0d", resid_k_d2_r,
                                         $signed({{24{rd_data_i[8*rd_lane_i+7]}}, rd_data_i[8*rd_lane_i +: 8]}),
                                         rd_lane_i, op_out_base + resid_k_d2_r);
                            end
                        end
                    end
                end
                S_DRAIN: begin
                    // Dump only after the requant pipeline has FULLY drained:
                    // rq_pending_r reads 0 one cycle BEFORE the last start's
                    // pending increment commits, so require 3 consecutive
                    // pending==0 (and no active start) cycles before dumping.
                    // This guarantees the final write (wr_en_r one cycle after
                    // the last valid, mem commit one cycle later) has landed
                    // before dump_region reads the act mem.
                    if (rq_pending_r == 0 && !rq_start_r) begin
                        if (drain_cnt_r == 2'd3) begin
                            drain_cnt_r <= 2'd0;
                            // dump_valid_o only for ops whose descriptor has the
                            // dump bit (d[0][7]); non-dump ops must still advance
                            // the op pointer but must NOT emit a dump event, or
                            // the tb's dump ids would drift from dump_map.
                            if (d[0][7]) begin
                                dump_valid_o <= 1'b1;
                                dump_id_o <= dump_cnt_r;
                                dump_op_index_o <= op_act_r;
                                dump_cnt_r <= dump_cnt_r + 1'b1;
                            end
                            if (op_act_r == segment_end_op_r || op_act_r == N_OPS - 1) st_r <= S_DONE;
                            else begin
                                op_act_r <= op_act_r + 1'b1; st_r <= S_FETCH; fetch_i_r <= 0;
                            end
                        end else drain_cnt_r <= drain_cnt_r + 1'b1;
                    end else drain_cnt_r <= 2'd0;
                end
                S_DONE: begin done_o <= 1'b1; st_r <= S_IDLE; end
            endcase
        end
    end

    // ------------------------------------------------------------ requant results -> write (single writer)
    reg signed [15:0] resid_sum_c;

    // synopsys translate_off
    // GATE4 debug: standalone always (NOT inside the FSM) so vopt cannot
    // elide it; prints the residual issue state for the first 12 cycles.
    always @(posedge clk) begin
        if (st_r == S_RESID && resid_dbg_n < 12) begin
            resid_dbg_n = resid_dbg_n + 1;
            $display("DBG residS cyc=%0d rspv=%0d k=%0d ph=%0d kd2=%0d ph2=%0d iss=%0d pend=%0d acc=%0d",
                     cycle_count_o, rd_rsp_valid_i, resid_k_r, resid_phase_r,
                     resid_k_d2_r, resid_ph_d2_r, resid_issue_r, rq_pending_r, rq_acc_r);
        end
        if (st_r == S_RESID && resid_dbg_n2 < 12 && rd_rsp_valid_i) begin
            resid_dbg_n2 = resid_dbg_n2 + 1;
            $display("DBG residR cyc=%0d kd2=%0d ph2=%0d lane=%0d data=%h",
                     cycle_count_o, resid_k_d2_r, resid_ph_d2_r, rd_lane_i, rd_data_i);
        end
    end
    integer wcload_n = 0;
    always @(posedge clk) begin
        if (op_act_r == 49 && wc_load_start_c && wcload_n < 4) begin
            wcload_n = wcload_n + 1;
            $display("WCLOAD49 cyc=%0d co_r=%0d co_in_block=%0d chpb=%0d base=%h op_w_off=%h",
                     cycle_count_o, co_r, co_in_block_r, ch_per_block, wc_flash_base_c, op_w_off);
        end
    end
    integer wcmem_n = 0;
    always @(posedge clk) begin
        if (op_act_r == 49 && st_r == S_CONV && co_r >= 16'd128 && wcmem_n < 6) begin
            wcmem_n = wcmem_n + 1;
            $display("WCMEM49 cyc=%0d co=%0d w[0]=%h w[1]=%h w[2]=%h w[3]=%h w[8]=%h w[9]=%h",
                     cycle_count_o, co_r, wc.wmem[0], wc.wmem[1], wc.wmem[2], wc.wmem[3],
                     wc.wmem[8], wc.wmem[9]);
        end
    end
    integer pool51_n = 0;
    always @(posedge clk) begin
        if (op_act_r == 51 && st_r == S_POOL && pool_pix_r >= op_hw_r &&
            rq_can_start && pool51_n < 8) begin
            pool51_n = pool51_n + 1;
            $display("POOL51 cyc=%0d co=%0d sum=%0d aux1=%0d aux2raw=%0d aux2signed=%0d",
                     cycle_count_o, pool_co_r, sum_acc_r, op_aux1, op_aux2[7:0],
                     $signed(op_aux2[7:0]));
        end
    end
`ifdef DEBUG_CORE
    integer dbg_alive, dbg_n;
    initial $display("DBG core alive (DEBUG_CORE defined)");
    always @(posedge clk) begin
        if (wr_en_r && op_act_r == 0 && dbg_n < 16) begin
            dbg_n = dbg_n + 1;
            $display("DBG wr op0 addr=%h data=%0d st=%0d co=%0d oh=%0d ow=%0d rq_y=%0d lut=%0d", wr_addr_r, wr_data_r, st_r, co_r, oh_r, ow_r, rq_y, lut_rd_data);
        end
        if (st_r == S_FETCH && op_act_r == 0 && dbg_n >= 0) begin
            $display("DBG op0 fetch: op_w_off=%h op_b_off=%h op_m_off=%h op_s_off=%h ch_in=%0d ch_out=%0d terms=%0d H=%0d W=%0d Hout=%0d Wout=%0d in=%h out=%h uin=%0d postlut=%0d lutid=%0d", op_w_off, op_b_off, op_m_off, op_s_off, op_ch_in, op_ch_out, op_terms, op_h_in, op_w_in, op_h_out, op_w_out, op_in_base, op_out_base, op_uin, op_postlut, op_lut_id);
        end
    end
`endif
    // synopsys translate_on
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_en_r <= 0; wr_addr_r <= 0; wr_data_r <= 0;
            rq_head_r <= 0;
        end else begin
            wr_en_r <= 1'b0;
            if (rq_valid_w) begin
                if (st_r == S_RESID) begin
                    if (rq_valid_phase_r) begin
                        wr_en_r <= 1'b1;
                        wr_addr_r <= rq_fifo[rq_head_r];
                        rq_head_r <= rq_head_r + 1'b1;
                        resid_sum_c = resid_ta_r + $signed(rq_y);
                        wr_data_r <= (resid_sum_c > 16'sd127) ? 8'sd127 :
                                     (resid_sum_c < -16'sd128) ? -8'sd128 :
                                     resid_sum_c[7:0];
                    end
                end else begin
                    wr_en_r <= 1'b1;
                    wr_addr_r <= rq_fifo[rq_head_r];
                    rq_head_r <= rq_head_r + 1'b1;
                    if (op_opcode == OP_CONV) begin
                        if (op_postlut) wr_data_r <= lut_rd_data;
                        else if (op_headclamp) wr_data_r <= rq_y[7] ? 8'd0 : rq_y;
                        else wr_data_r <= rq_y;
                    end else wr_data_r <= rq_y;
                end
            end
        end
    end

    // resid_ta capture on the A-valid
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) resid_ta_r <= 0;
        else if (rq_valid_w && st_r == S_RESID && !rq_valid_phase_r)
            resid_ta_r <= $signed(rq_y);
    end

    // GATE4 residual debug: exact phase/valid/start/d2 at each residual valid
    integer rqdbg_n = 0;
    always @(posedge clk) begin
        if (st_r == S_RESID && rq_valid_w && rqdbg_n < 24) begin
            rqdbg_n = rqdbg_n + 1;
            $display("DBG rqw cyc=%0d vph=%0d rta=%0d y=%0d wren=%0d waddr=%h head=%0d start=%0d d2=%0d sh5=%0d sh6=%0d",
                     cycle_count_o, rq_valid_phase_r, resid_ta_r, rq_y, wr_en_r, wr_addr_r, rq_head_r,
                     rq_start_r, resid_ph_d2_r, rq_phase_shift[5], rq_phase_shift[6]);
        end
    end

    // GATE4 block3 (op10) targeted debug: term_b input p and requant output tb
    integer b3_n = 0;
    always @(posedge clk) begin
        if (st_r == S_RESID && op_act_r == 10 && rd_rsp_valid_i
            && resid_ph_d2_r && b3_n < 40) begin
            b3_n = b3_n + 1;
            $display("DBG b3B k=%0d p=%0d mult=%0d shift=%0d",
                     resid_k_d2_r,
                     $signed({{24{rd_data_i[8*rd_lane_i+7]}}, rd_data_i[8*rd_lane_i +: 8]}),
                     op_aux3, op_aux4[31:24]);
        end
        if (st_r == S_RESID && op_act_r == 10 && rq_valid_w
            && rq_valid_phase_r && b3_n < 60) begin
            b3_n = b3_n + 1;
            $display("DBG b3tb k=%0d ta=%0d tb=%0d sum=%0d",
                     rq_head_r, resid_ta_r, rq_y,
                     resid_ta_r + $signed(rq_y));
        end
    end

    // ------------------------------------------------------------ outputs
    assign busy_o = (st_r != S_IDLE) && (st_r != S_DONE);
    assign wr_en_o = wr_en_r;
    assign wr_addr_o = wr_addr_r;
    assign wr_data_o = wr_data_r;

    integer rom_i;
    initial begin
        $readmemh(OP_FILE, opmem);
        for (rom_i = 0; rom_i < 16; rom_i = rom_i + 1) d[rom_i] = 32'd0;
    end
endmodule
