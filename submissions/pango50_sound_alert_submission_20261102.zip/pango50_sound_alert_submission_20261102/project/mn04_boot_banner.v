`timescale 1ns/1ps
// Diagnostic boot banner + periodic link-state word.  Prints "MN04-DIAG BOOT OK"
// once on power-up so the serial link health is instantly visible, then starts
// a 2-second periodic loop that re-prints just the short state word
// " DIAG <hi><lo>" so the user can read the live recognition/audio state WHILE
// holding KEY2 and playing sound (not just the power-up snapshot).  Each line
// is only 8 bytes and releases the TX between prints, so prob-dump P= lines
// still get through.
//
// state byte0 bits (msb->lsb):
//   b7 core_rst_n, b6 boot_init_done, b5 codec_ready_sync, b4 recognition_enable,
//   b3 pcm_overflow, b2 x0_overflow, b1 any x0 tick seen (sticky since reset),
//   b0 armed(rec&&!pcm&&!x0ovf)
module mn04_boot_banner #(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer PERIOD_MS = 200
)(
    input wire clk,
    input wire rst_n,
    input wire core_rst_n_i,
    input wire boot_init_done_i,
    input wire codec_ready_i,
    input wire recognition_enable_i,
    input wire pcm_overflow_i,
    input wire x0_overflow_i,
    input wire x0_valid_i,
    input wire [95:0] template_diag_i,
    output reg valid_o = 1'b0,
    output reg [7:0] data_o = 8'h00,
    input wire ready_i
);
    // Fixed header: "MN04-DIAG BOOT OK" (17 ascii + CR)
    reg [7:0] hdr [0:17];
    initial begin
        hdr[0]=8'h4D; hdr[1]=8'h4E; hdr[2]=8'h30; hdr[3]=8'h34;   // MN04
        hdr[4]=8'h2D; hdr[5]=8'h44; hdr[6]=8'h49; hdr[7]=8'h41;   // -DIA
        hdr[8]=8'h47; hdr[9]=8'h20; hdr[10]=8'h42;                // G B
        hdr[11]=8'h4F; hdr[12]=8'h4F; hdr[13]=8'h54;              // OOT
        hdr[14]=8'h20; hdr[15]=8'h4F; hdr[16]=8'h4B;              //  OK
        hdr[17]=8'h0D;                                            // CR
    end
    localparam integer HDR_N = 18;
    localparam integer TAIL_N = 35;   // " DIAG <hi> <lo> CR": D I A G ' ' h l CR = 8
    localparam integer PERIOD_CYCLES = (CLOCK_HZ / 1000) * PERIOD_MS; // ~200M ticks
    reg [4:0] idx;        // header index
    reg [5:0] tidx;
    reg [95:0] diag_latched;       // tail index
    reg phase;            // 0=header, 1=tail
    reg header_done;      // header fully sent
    reg sending;          // 1 while currently pushing bytes
    reg seen_x0;
    reg [7:0] b0;
    reg [31:0] period_cnt;
    wire period_up;       // everyone idle and period elapsed
    assign period_up = !sending && (period_cnt >= PERIOD_CYCLES[31:0] - 1);

    function [7:0] hexnibble;
        input [3:0] n;
        begin
            hexnibble = (n<10) ? (n+8'h30) : (n+8'h37);
        end
    endfunction
    function [7:0] sel_tail;
        input [5:0] i;
        input [7:0] b;
        begin
            case(i)
                4'd0: sel_tail = 8'h44;            // D
                4'd1: sel_tail = 8'h49;            // I
                4'd2: sel_tail = 8'h41;            // A
                4'd3: sel_tail = 8'h47;            // G
                4'd4: sel_tail = 8'h20;            // ' '
                4'd5: sel_tail = hexnibble(b[7:4]);
                4'd6: sel_tail = hexnibble(b[3:0]);
                6'd8: sel_tail=8'h54;
                6'd9: sel_tail=8'h20;
                default: if(i>=10 && i<34) sel_tail=hexnibble(diag_latched >> ((33-i)*4));
                         else sel_tail = 8'h0D;         // CR
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            diag_latched<=0;
            idx<=5'd0; tidx<=4'd0; phase<=1'b0; header_done<=1'b0;
            sending<=1'b0; valid_o<=1'b0; data_o<=8'h00;
            seen_x0<=1'b0; b0<=8'h00; period_cnt<=32'h0;
        end else begin
            if(x0_valid_i) seen_x0<=1'b1;
            b0<={core_rst_n_i, boot_init_done_i, codec_ready_i,
                 recognition_enable_i, pcm_overflow_i, x0_overflow_i,
                 seen_x0, (recognition_enable_i && !pcm_overflow_i && !x0_overflow_i)};
            // period counter: free-running but held low while actively sending
            if(!sending) begin
                if(period_cnt >= PERIOD_CYCLES[31:0]-1) period_cnt<=32'h0;
                else period_cnt<=period_cnt+1'b1;
            end
            if(sending) begin
                if(!valid_o) begin
                    valid_o<=1'b1;
                    if(phase==1'b0) begin
                        data_o<=hdr[idx[4:0]];
                    end else begin
                        data_o<=sel_tail(tidx,b0);
                    end
                end else if(ready_i) begin
                    valid_o<=1'b0;
                    if(phase==1'b0) begin
                        if(idx==HDR_N-1) begin
                            phase<=1'b1; tidx<=4'd0;
                        end else begin
                            idx<=idx+1'b1;
                        end
                    end else begin
                        if(tidx==TAIL_N-1) begin
                            sending<=1'b0;
                            phase<=1'b0; idx<=5'd0; tidx<=4'd0;
                        end else begin
                            tidx<=tidx+1'b1;
                        end
                    end
                end
            end else if(!header_done) begin
                // send the fixed header right after reset
                diag_latched<=template_diag_i; header_done<=1'b1; sending<=1'b1; phase<=1'b0; idx<=5'd0;
            end else if(period_up) begin
                // periodic tail refresh
                diag_latched<=template_diag_i;
                sending<=1'b1; phase<=1'b1; tidx<=4'd0;
            end else begin
                valid_o<=1'b0;
            end
        end
    end
endmodule