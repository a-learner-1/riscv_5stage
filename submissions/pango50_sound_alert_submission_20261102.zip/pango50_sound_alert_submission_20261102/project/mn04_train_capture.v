`timescale 1ns/1ps
// MES50HP button-controlled, class-batched audio feature capture.
// CNN categories occupy IDs 0..CNN_CLASS_COUNT-1; the three preset template
// categories follow them. A take is written directly into its fixed DDR slot
// while the audio frontend runs. Pressing the class key sends the previous
// category batch, then advances the selected category in the active family.
// Captures remain in their fixed DDR slots for board-local template/data use.
// Host upload is disabled by default and is not part of the board workflow.
module mn04_train_capture #(
    parameter [23:0] BATCH_BASE_BYTE = 24'h540000,
    parameter integer MEL_BINS      = 128,
    parameter integer RING_FRAMES   = 1000,
    parameter integer MAX_CAPTURE_FRAMES = 1000,
    parameter integer MIN_CAPTURE_FRAMES = 100,
    parameter integer MAX_RECORDS   = 8,
    parameter integer CNN_CLASS_COUNT = 8,
    parameter integer ENABLE_TEMPLATE_CAPTURE = 0,
    parameter integer CLOCK_HZ      = 100000000,
    parameter integer BAUD          = 115200,
    parameter integer TX_FIFO_DEPTH = 256,
    parameter integer EXPORT_CAPTURE_TO_HOST = 0,
    parameter integer CAPTURE_DIAGNOSTICS = 0
)(
    input wire clk, rst_n,
    input wire ddr_init_done_i,
    input wire template_mode_i,
    input wire category_advance_i,
    input wire local_capture_start_i,
    input wire local_capture_stop_i,
    input wire [1:0] overflow_i, // bit 0: x0 FIFO, bit 1: PCM FIFO
    // Diagnostic-only tap, before DDR. Feature order is frame-major.
    input wire [7:0] live_feature_i,
    input wire live_feature_valid_i,
    input wire signed [15:0] live_pcm_i,
    input wire live_pcm_valid_i,
    output wire uart_tx_o,
    output reg freeze_o,
    output wire task_busy_o,
    output wire stream_phase_o,
    output wire recording_o,
    output wire [3:0] selected_category_o,
    output wire [23:0] capture_ring_base_o,
    output wire selected_class_full_o,
    input wire freeze_ack_i,
    input wire ring_drained_i,
    input wire ring_frame_done_i,
    input wire [9:0] ring_next_slot_i,
    // AXI read master (interconnect master 5)
    output wire [27:0] ddr_araddr_o,
    output wire ddr_arvalid_o,
    input  wire ddr_arready_i,
    input  wire [255:0] ddr_rdata_i,
    input  wire [1:0] ddr_rresp_i,
    input  wire ddr_rvalid_i,
    output wire ddr_rready_o
);
    localparam integer SLOT_BYTES = MEL_BINS * RING_FRAMES;
    localparam integer CLASS_COUNT_W = $clog2(MAX_RECORDS + 1);
    localparam integer CLASS_INDEX_W = $clog2(MAX_RECORDS);
    localparam integer TEMPLATE_CLASS_COUNT = 3;
    localparam integer CLASS_TOTAL = ENABLE_TEMPLATE_CAPTURE ?
                                     CNN_CLASS_COUNT + TEMPLATE_CLASS_COUNT :
                                     CNN_CLASS_COUNT;
    localparam integer RECORD_ADDR_W = $clog2(CLASS_TOTAL * MAX_RECORDS);
    localparam integer TX_FIFO_PTR_BITS = $clog2(TX_FIFO_DEPTH);
    localparam [3:0] S_IDLE=4'd0, S_RECORD=4'd1, S_FREEZE=4'd2,
                     S_HDR=4'd3, S_RD=4'd4, S_RWAIT=4'd5, S_TX=4'd6,
                     S_TRAILER=4'd7, S_BATCH_HDR=4'd8,
                     S_BATCH_TRAILER=4'd9, S_DRAIN=4'd10,
                     S_DIAG_HDR=4'd11,S_DIAG_DATA=4'd12,
                     S_DIAG_TRAILER=4'd13,S_NEXT_RECORD=4'd14,S_DIAG_READ=4'd15;

    reg [3:0] state;
    reg [2:0] cnn_category_r;
    reg [1:0] template_category_r;
    reg [3:0] record_category_r,flush_category_r;
    wire [3:0] selected_category = (ENABLE_TEMPLATE_CAPTURE && template_mode_i) ?
                                   CNN_CLASS_COUNT + template_category_r :
                                   {1'b0,cnn_category_r};
    reg [CLASS_COUNT_W-1:0] record_count [0:CLASS_TOTAL-1];
    reg [9:0] record_frames [0:CLASS_TOTAL*MAX_RECORDS-1];
    reg [9:0] record_start_slot [0:CLASS_TOTAL*MAX_RECORDS-1];
    reg [1:0] record_status [0:CLASS_TOTAL*MAX_RECORDS-1];
    reg [23:0] active_slot_base_r;
    reg [CLASS_COUNT_W-1:0] flush_count_r;
    reg [CLASS_COUNT_W-1:0] flush_index_r;
    reg [9:0] capture_frames, dump_frames, row_start_slot, source_slot;
    reg [9:0] frame_index;
    reg [6:0] mel_index;
    reg [1:0] capture_status;
    reg [1:0] overflow_seen_r;
    reg [16:0] payload_bytes,payload_cnt;
    reg [7:0] xorsum;
    reg [255:0] beat;
    reg [3:0] hdr_idx;
    reg [1:0] trailer_idx;
    reg stop_pending_r;
    reg [23:0] transfer_slot_base_r;
    reg [7:0] transfer_code_r,transfer_status_r;
    reg [31:0] feature_crc,feature_count,pcm_crc,pcm_count,pcm_changes;
    reg [127:0] first_features;
    reg signed [15:0] pcm_min,pcm_max,pcm_previous;
    // Ten 32-bit words per take. No array reset: record_count is the validity
    // tag. Serial writes and synchronous reads infer a compact FPGA RAM rather
    // than twenty thousand individually reset diagnostic flip-flops.
    reg [31:0] record_diag_mem[0:CLASS_TOTAL*MAX_RECORDS*10-1];
    reg [3:0] diag_store_idx;
    reg [31:0] diag_read_word;
    reg [5:0] diag_idx;
    wire [RECORD_ADDR_W-1:0] transfer_record_addr=flush_category_r*MAX_RECORDS+flush_index_r;
    function [31:0] crc_byte(input [31:0] old,input [7:0] value);
        integer b; reg [31:0] c;
        begin c=old^value;
            for(b=0;b<8;b=b+1) c=c[0] ? ((c>>1)^32'hedb88320) : (c>>1);
            crc_byte=c;
        end
    endfunction
    function [7:0] diagnostic_byte(input [5:0] idx);
        reg [31:0] word_value;
        begin
            word_value=0;
            case(idx[5:2])
                0:word_value=32'h31304443; // CD01
                1:word_value=(flush_index_r<<8)|flush_category_r;
                2,3,4,5,6,7,8,9,10,11:word_value=diag_read_word;
                12:word_value={8'd0,transfer_slot_base_r};
                13:word_value={22'd0,dump_frames};
                14:word_value={22'd0,row_start_slot};
                default:word_value=0;
            endcase
            diagnostic_byte=word_value[8*idx[1:0]+:8];
        end
    endfunction

    reg [7:0] tx_fifo [0:TX_FIFO_DEPTH-1];
    reg [TX_FIFO_PTR_BITS-1:0] tx_wr_ptr,tx_rd_ptr;
    reg [TX_FIFO_PTR_BITS:0] tx_fifo_count;
    wire tx_ready,tx_pop,tx_fifo_empty,tx_fifo_full;
    wire [7:0] tx_data;
    reg tx_push;
    reg [7:0] tx_push_data;
    wire [23:0] next_slot_base;
    wire [RECORD_ADDR_W-1:0] active_record_addr = record_category_r * MAX_RECORDS +
                                                   record_count[record_category_r];
    reg [31:0] diag_store_word;
    always @* begin
        case(diag_store_idx)
            0:diag_store_word=feature_count;
            1:diag_store_word=~feature_crc;
            2,3,4,5:diag_store_word=first_features[32*(diag_store_idx-2)+:32];
            6:diag_store_word=pcm_count;
            7:diag_store_word={pcm_max,pcm_min};
            8:diag_store_word=pcm_changes;
            9:diag_store_word=~pcm_crc;
            default:diag_store_word=0;
        endcase
    end
    always @(posedge clk) begin
        if(CAPTURE_DIAGNOSTICS && rst_n && state==S_FREEZE &&
           freeze_ack_i && ring_drained_i && diag_store_idx<10)
            record_diag_mem[active_record_addr*10+diag_store_idx]<=diag_store_word;
        if(CAPTURE_DIAGNOSTICS && state==S_DIAG_READ)
            diag_read_word<=record_diag_mem[transfer_record_addr*10+diag_idx[5:2]-2];
    end
    wire [23:0] source_byte = transfer_slot_base_r +
                              mel_index * RING_FRAMES + source_slot;

    function [23:0] slot_base(input [3:0] category,input [CLASS_COUNT_W-1:0] index);
        integer linear_index;
        begin
            linear_index = category * MAX_RECORDS + index;
            slot_base = BATCH_BASE_BYTE + linear_index * SLOT_BYTES;
        end
    endfunction

    function [7:0] hdr_byte(input [3:0] idx,input [7:0] code,
                            input [9:0] slot,input [7:0] status,
                            input [16:0] length);
        case(idx)
            4'd0: hdr_byte=8'hAA;
            4'd1: hdr_byte=8'h55;
            4'd2: hdr_byte=code;
            4'd3: hdr_byte=length[7:0];
            4'd4: hdr_byte=length[15:8];
            4'd5: hdr_byte={7'b0,length[16]};
            4'd6: hdr_byte=slot[7:0];
            4'd7: hdr_byte={6'b0,slot[9:8]};
            default: hdr_byte=status;
        endcase
    endfunction

    assign next_slot_base = slot_base(selected_category,
                                       record_count[selected_category]);
    assign capture_ring_base_o = ((state==S_RECORD)||(state==S_FREEZE)) ?
                                 active_slot_base_r : next_slot_base;
    assign selected_category_o = selected_category;
    assign selected_class_full_o = (record_count[selected_category] >= MAX_RECORDS);
    assign recording_o = (state == S_RECORD);
    assign stream_phase_o = (state == S_RECORD) || (state == S_FREEZE);
    assign task_busy_o = (state != S_IDLE);

    uart_tx_8n1 #(.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD)) u_tx (
        .clk(clk),.rst_n(rst_n),.data_i(tx_data),.valid_i(!tx_fifo_empty),
        .ready_o(tx_ready),.tx_o(uart_tx_o));

    assign tx_fifo_empty = (tx_fifo_count == 0);
    assign tx_fifo_full = (tx_fifo_count == TX_FIFO_DEPTH);
    assign tx_data = tx_fifo[tx_rd_ptr];
    assign tx_pop = !tx_fifo_empty && tx_ready;

    always @* begin
        tx_push=1'b0;
        tx_push_data=8'h00;
        case(state)
            S_HDR: begin
                tx_push=!tx_fifo_full;
                tx_push_data=hdr_byte(hdr_idx,transfer_code_r,
                    {1'b0,flush_index_r},transfer_status_r,payload_bytes);
            end
            S_TX: begin
                tx_push=!tx_fifo_full;
                tx_push_data=beat[8*source_byte[4:0] +: 8];
            end
            S_TRAILER: begin
                tx_push=!tx_fifo_full;
                tx_push_data=(trailer_idx==0)?xorsum:8'h5A;
            end
            S_DIAG_HDR: begin
                tx_push=!tx_fifo_full;
                tx_push_data=hdr_byte(hdr_idx,8'hfd,{7'd0,flush_index_r},8'd0,17'd64);
            end
            S_DIAG_DATA: begin tx_push=!tx_fifo_full;tx_push_data=diagnostic_byte(diag_idx);end
            S_DIAG_TRAILER: begin
                tx_push=!tx_fifo_full;tx_push_data=(trailer_idx==0)?xorsum:8'h5a;
            end
            S_BATCH_HDR: begin
                tx_push=!tx_fifo_full;
                tx_push_data=hdr_byte(hdr_idx,8'hFE,
                    {6'd0,flush_category_r},flush_count_r,17'd0);
            end
            S_BATCH_TRAILER: begin
                tx_push=!tx_fifo_full;
                tx_push_data=(trailer_idx==0)?8'h00:8'h5A;
            end
            default: begin end
        endcase
    end

    assign ddr_araddr_o={4'b0,source_byte};
    assign ddr_arvalid_o=(state==S_RD);
    assign ddr_rready_o=1'b1;

    always @(posedge clk) begin
        if(rst_n && tx_push) tx_fifo[tx_wr_ptr]<=tx_push_data;
    end

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=S_IDLE;
            cnn_category_r<=3'd0;
            template_category_r<=2'd0;
            record_category_r<=4'd0;
            flush_category_r<=4'd0;
            active_slot_base_r<=BATCH_BASE_BYTE;
            flush_count_r<=0;
            flush_index_r<=0;
            capture_frames<=0;
            dump_frames<=0;
            row_start_slot<=0;
            source_slot<=0;
            frame_index<=0;
            mel_index<=0;
            capture_status<=0;
            overflow_seen_r<=0;
            payload_bytes<=0;
            payload_cnt<=0;
            xorsum<=0;
            beat<=0;
            hdr_idx<=0;
            trailer_idx<=0;
            stop_pending_r<=0;
            transfer_slot_base_r<=BATCH_BASE_BYTE;
            transfer_code_r<=0;
            transfer_status_r<=0;
            feature_crc<=32'hffffffff;feature_count<=0;first_features<=0;
            pcm_crc<=32'hffffffff;pcm_count<=0;pcm_changes<=0;
            pcm_min<=16'sh7fff;pcm_max<=16'sh8000;pcm_previous<=0;diag_idx<=0;diag_store_idx<=0;
            freeze_o<=0;
            tx_wr_ptr<=0;
            tx_rd_ptr<=0;
            tx_fifo_count<=0;
            for(i=0;i<CLASS_TOTAL;i=i+1) record_count[i]<=0;
            for(i=0;i<CLASS_TOTAL*MAX_RECORDS;i=i+1) begin
                record_frames[i]<=0;
                record_start_slot[i]<=0;
                record_status[i]<=0;
            end
        end else begin
            if(CAPTURE_DIAGNOSTICS && state==S_RECORD) begin
                if(live_feature_valid_i===1'b1) begin
                    feature_crc<=crc_byte(feature_crc,live_feature_i);
                    feature_count<=feature_count+1'b1;
                    if(feature_count<16) first_features[8*feature_count+:8]<=live_feature_i;
                end
                if(live_pcm_valid_i===1'b1) begin
                    pcm_crc<=crc_byte(crc_byte(pcm_crc,live_pcm_i[7:0]),live_pcm_i[15:8]);
                    pcm_count<=pcm_count+1'b1;
                    if(live_pcm_i<pcm_min) pcm_min<=live_pcm_i;
                    if(live_pcm_i>pcm_max) pcm_max<=live_pcm_i;
                    if(pcm_count!=0 && live_pcm_i!=pcm_previous) pcm_changes<=pcm_changes+1'b1;
                    pcm_previous<=live_pcm_i;
                end
            end
            if(tx_push) tx_wr_ptr<=tx_wr_ptr+1'b1;
            if(tx_pop) tx_rd_ptr<=tx_rd_ptr+1'b1;
            case({tx_push,tx_pop})
                2'b10: tx_fifo_count<=tx_fifo_count+1'b1;
                2'b01: tx_fifo_count<=tx_fifo_count-1'b1;
                default: tx_fifo_count<=tx_fifo_count;
            endcase

            if(state==S_RECORD && local_capture_stop_i===1'b1)
                stop_pending_r<=1'b1;

            case(state)
                S_IDLE: begin
                    freeze_o<=1'b0;
                    if(ddr_init_done_i && category_advance_i) begin
                        if(ENABLE_TEMPLATE_CAPTURE && template_mode_i) begin
                            template_category_r<=template_category_r+2'd1;
                            if(template_category_r==2'd2) template_category_r<=2'd0;
                        end else begin
                            cnn_category_r<=cnn_category_r+3'd1;
                            if(cnn_category_r==CNN_CLASS_COUNT-1) cnn_category_r<=3'd0;
                        end
                        if(1'b0 && EXPORT_CAPTURE_TO_HOST && record_count[selected_category]!=0) begin
                            flush_category_r<=selected_category;
                            flush_count_r<=record_count[selected_category];
                            flush_index_r<=0;
                            transfer_slot_base_r<=slot_base(selected_category,0);
                            transfer_code_r<={4'd0,selected_category};
                            flush_index_r<=0;
                            dump_frames<=record_frames[selected_category*MAX_RECORDS];
                            row_start_slot<=record_start_slot[selected_category*MAX_RECORDS];
                            source_slot<=record_start_slot[selected_category*MAX_RECORDS];
                            payload_bytes<=record_frames[selected_category*MAX_RECORDS]*MEL_BINS;
                            transfer_status_r<={6'd0,record_status[selected_category*MAX_RECORDS]};
                            frame_index<=0;
                            mel_index<=0;
                            hdr_idx<=0;
                            payload_cnt<=0;
                            xorsum<=0;
                            state<=S_HDR;
                        end else if(1'b0 && EXPORT_CAPTURE_TO_HOST) begin
                            flush_category_r<=selected_category;
                            flush_count_r<=record_count[selected_category];
                            flush_index_r<=0;
                            // Empty classes also get a marker, so the PC can
                            // distinguish a deliberate empty batch from a UART
                            // timeout or a disconnected board.
                            hdr_idx<=0;
                            state<=S_BATCH_HDR;
                        end
                    end else if(ddr_init_done_i && local_capture_start_i &&
                                record_count[selected_category]<MAX_RECORDS) begin
                        record_category_r<=selected_category;
                        active_slot_base_r<=next_slot_base;
                        capture_frames<=0;
                        dump_frames<=0;
                        payload_bytes<=0;
                        stop_pending_r<=0;
                        overflow_seen_r<=0;
                        feature_crc<=32'hffffffff;feature_count<=0;first_features<=0;
                        pcm_crc<=32'hffffffff;pcm_count<=0;pcm_changes<=0;
                        pcm_min<=16'sh7fff;pcm_max<=16'sh8000;pcm_previous<=0;
                        diag_store_idx<=0;
                        state<=S_RECORD;
                    end
                end
                S_RECORD: begin
                    if(|overflow_i) overflow_seen_r<=overflow_seen_r | overflow_i;
                    if(ring_frame_done_i) begin
                        if(((stop_pending_r || (local_capture_stop_i===1'b1)) &&
                            (capture_frames>=MIN_CAPTURE_FRAMES-1)) ||
                            capture_frames==MAX_CAPTURE_FRAMES-1) begin
                            dump_frames<=capture_frames+10'd1;
                            freeze_o<=1'b1;
                            state<=S_FREEZE;
                        end else begin
                            capture_frames<=capture_frames+10'd1;
                        end
                    end
                end
                S_FREEZE: begin
                    if(freeze_ack_i && ring_drained_i) begin
                      if(CAPTURE_DIAGNOSTICS && diag_store_idx<10) begin
                        diag_store_idx<=diag_store_idx+1'b1;
                      end else begin
                        if(ring_next_slot_i>=dump_frames)
                            row_start_slot<=ring_next_slot_i-dump_frames;
                        else
                            row_start_slot<=ring_next_slot_i+RING_FRAMES-dump_frames;
                        record_frames[active_record_addr]<=dump_frames;
                        if(ring_next_slot_i>=dump_frames)
                            record_start_slot[active_record_addr]<=ring_next_slot_i-dump_frames;
                        else
                            record_start_slot[active_record_addr]<=ring_next_slot_i+RING_FRAMES-dump_frames;
                        record_status[active_record_addr]<=overflow_seen_r | overflow_i;
                        record_count[record_category_r]<=record_count[record_category_r]+1'b1;
                        capture_status<=overflow_seen_r | overflow_i;
                        overflow_seen_r<=0;
                        stop_pending_r<=0;
                        freeze_o<=0;
                        state<=S_IDLE;
                      end
                    end
                end
                S_HDR: begin
                    if(tx_push) begin
                        if(hdr_idx==4'd8) begin
                            payload_cnt<=0;
                            mel_index<=0;
                            frame_index<=0;
                            source_slot<=row_start_slot;
                            state<=S_RD;
                        end else hdr_idx<=hdr_idx+1'b1;
                    end
                end
                S_RD: if(ddr_arready_i) state<=S_RWAIT;
                S_RWAIT: if(ddr_rvalid_i) begin
                    beat<=ddr_rdata_i;
                    state<=S_TX;
                end
                S_TX: begin
                    if(tx_push) begin
                        xorsum<=xorsum^beat[8*source_byte[4:0] +: 8];
                        if(payload_cnt==payload_bytes-1'b1) begin
                            trailer_idx<=0;
                            state<=S_TRAILER;
                        end else begin
                            payload_cnt<=payload_cnt+1'b1;
                            if(frame_index==dump_frames-1'b1) begin
                                frame_index<=0;
                                source_slot<=row_start_slot;
                                mel_index<=mel_index+1'b1;
                            end else begin
                                frame_index<=frame_index+1'b1;
                                if(source_slot==RING_FRAMES-1) source_slot<=0;
                                else source_slot<=source_slot+1'b1;
                            end
                            state<=S_RD;
                        end
                    end
                end
                S_TRAILER: begin
                    if(tx_push) begin
                        if(trailer_idx==1) begin
                            if(CAPTURE_DIAGNOSTICS) begin hdr_idx<=0;state<=S_DIAG_HDR;end
                            else state<=S_NEXT_RECORD;
                        end else trailer_idx<=trailer_idx+1'b1;
                    end
                end
                S_DIAG_HDR: if(tx_push) begin
                    if(hdr_idx==8) begin diag_idx<=0;xorsum<=0;state<=S_DIAG_READ;end
                    else hdr_idx<=hdr_idx+1'b1;
                end
                S_DIAG_READ: state<=S_DIAG_DATA;
                S_DIAG_DATA: if(tx_push) begin
                    xorsum<=xorsum^tx_push_data;
                    if(diag_idx==63) begin trailer_idx<=0;state<=S_DIAG_TRAILER;end
                    else begin diag_idx<=diag_idx+1'b1;state<=S_DIAG_READ;end
                end
                S_DIAG_TRAILER: if(tx_push) begin
                    if(trailer_idx==1) state<=S_NEXT_RECORD;
                    else trailer_idx<=trailer_idx+1'b1;
                end
                S_NEXT_RECORD: begin
                            if(flush_index_r+1'b1<flush_count_r) begin
                                flush_index_r<=flush_index_r+1'b1;
                                transfer_slot_base_r<=slot_base(flush_category_r,flush_index_r+1'b1);
                                transfer_code_r<={4'd0,flush_category_r};
                                dump_frames<=record_frames[flush_category_r*MAX_RECORDS+flush_index_r+1'b1];
                                row_start_slot<=record_start_slot[flush_category_r*MAX_RECORDS+flush_index_r+1'b1];
                                source_slot<=record_start_slot[flush_category_r*MAX_RECORDS+flush_index_r+1'b1];
                                payload_bytes<=record_frames[flush_category_r*MAX_RECORDS+flush_index_r+1'b1]*MEL_BINS;
                                transfer_status_r<={6'd0,record_status[flush_category_r*MAX_RECORDS+flush_index_r+1'b1]};
                                frame_index<=0;
                                mel_index<=0;
                                payload_cnt<=0;
                                xorsum<=0;
                                hdr_idx<=0;
                                state<=S_HDR;
                            end else begin
                                hdr_idx<=0;
                                state<=S_BATCH_HDR;
                            end
                end
                S_BATCH_HDR: begin
                    if(tx_push) begin
                        if(hdr_idx==4'd8) begin
                            trailer_idx<=0;
                            state<=S_BATCH_TRAILER;
                        end else hdr_idx<=hdr_idx+1'b1;
                    end
                end
                S_BATCH_TRAILER: begin
                    if(tx_push) begin
                        if(trailer_idx==1) state<=S_DRAIN;
                        else trailer_idx<=trailer_idx+1'b1;
                    end
                end
                S_DRAIN: begin
                    if(tx_fifo_empty && tx_ready) begin
                        record_count[flush_category_r]<=0;
                        state<=S_IDLE;
                    end
                end
                default: state<=S_IDLE;
            endcase
        end
    end
endmodule
