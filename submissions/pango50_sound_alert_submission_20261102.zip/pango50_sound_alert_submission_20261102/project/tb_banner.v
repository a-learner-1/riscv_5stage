`timescale 1ns/1ps
module tb_banner;
reg clk=0; reg rst_n=0;
wire [7:0] data_o; wire valid_o; wire ready_o;
wire tx_line;
always #5 clk=~clk;
mn04_boot_banner #(.CLOCK_HZ(100000000)) dut_b(
  .clk(clk),.rst_n(rst_n),.valid_o(valid_o),.data_o(data_o),.ready_i(ready_o));
uart_tx_8n1 #(.CLOCK_HZ(100000000),.BAUD(115200)) dut_u(
  .clk(clk),.rst_n(rst_n),.data_i(data_o),.valid_i(valid_o),.ready_o(ready_o),.tx_o(tx_line));
localparam BIT=8680;
integer bytes;
integer wrong;
reg [7:0] msg [0:17];
reg [7:0] val;
integer k;
initial begin
  bytes=0; wrong=0; val=0;
  msg[0]=8'h4D; msg[1]=8'h4E; msg[2]=8'h30; msg[3]=8'h34;
  msg[4]=8'h2D; msg[5]=8'h44; msg[6]=8'h49; msg[7]=8'h41;
  msg[8]=8'h47; msg[9]=8'h20; msg[10]=8'h42;
  msg[11]=8'h4F; msg[12]=8'h4F; msg[13]=8'h54;
  msg[14]=8'h20; msg[15]=8'h4F; msg[16]=8'h4B;
  msg[17]=8'h0D;
  #25 rst_n=1;
  wait(tx_line==0);
  for(bytes=0; bytes<18; bytes=bytes+1) begin
    #(BIT*1.5);
    val=0;
    for(k=0;k<8;k=k+1) begin
      val[k] = tx_line;
      #BIT;
    end
    if(val!==msg[bytes]) begin
      $display("BYTE %0d MISMATCH: got %h expect %h", bytes, val, msg[bytes]);
      wrong=wrong+1;
    end
    #BIT; // stop bit
    if(bytes<17) wait(tx_line==0);
  end
  $display("RESULT wrong=%0d", wrong);
  $finish;
end
endmodule