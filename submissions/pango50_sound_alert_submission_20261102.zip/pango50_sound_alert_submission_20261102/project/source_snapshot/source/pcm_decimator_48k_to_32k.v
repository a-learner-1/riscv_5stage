`timescale 1ns/1ps
// Linear-interpolation 3:2 decimator for the ES8311 48 kHz stream, producing
// the 32 kHz mono PCM the MN04 frontend expects (320000 samples = 10 s).
// Output sample m lands at input position m*3/2:
//   m even  (m = 2k)   -> position 3k     -> passthrough of input 3k
//   m odd   (m = 2k+1) -> position 3k+1.5 -> average of inputs 3k+1 and 3k+2
// So every three inputs yield two outputs (input 0, then the average of inputs
// 1 and 2). Linear interpolation provides a crude anti-alias stage; a polyphase
// FIR can replace it later if board-level accuracy requires.
module pcm_decimator_48k_to_32k(
    input  wire               clk,
    input  wire               rst_n,
    input  wire signed [15:0] sample_i,
    input  wire               sample_valid_i,
    output reg signed [15:0] sample_o,
    output reg                sample_valid_o
);
    reg [1:0] phase;
    reg signed [15:0] prev;

    wire signed [16:0] sum2 = prev + sample_i;

    // Round-half-away-from-zero division by two. The sum of two signed 16-bit
    // samples fits in 17 bits, so an arithmetic shift implements the exact
    // divide (no divider, matching the boxcar 3:1 decimator's style).
    function signed [15:0] average_two;
        input signed [16:0] value;
        begin
            if (value >= 0)
                average_two = (value + 17'sd1) >>> 1;
            else
                average_two = value >>> 1;
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            phase          <= 2'd0;
            prev           <= 16'sd0;
            sample_o       <= 16'sd0;
            sample_valid_o <= 1'b0;
        end else begin
            sample_valid_o <= 1'b0;
            if (sample_valid_i) begin
                if (phase == 2'd0) begin
                    sample_o       <= sample_i;
                    sample_valid_o <= 1'b1;
                    phase          <= 2'd1;
                end else if (phase == 2'd1) begin
                    prev           <= sample_i;
                    phase          <= 2'd2;
                end else begin // phase == 2'd2
                    sample_o       <= average_two(sum2);
                    sample_valid_o <= 1'b1;
                    phase          <= 2'd0;
                end
            end
        end
    end
endmodule
