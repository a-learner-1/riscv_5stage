`timescale 1ns/1ps
// PGL50H PLL wrapper for ES8311 MCLK.
// Exact clock: 50 MHz * 29 / 2 / 59 = 12.288136 MHz (11 ppm off 12.288).
// The codec divide-by-256 setting yields 48.0005 kHz with this MCLK. This is a real
// Pango PLL primitive, rather than an imprecise fabric counter divider.
// PGL50H belongs to Pango's PLL2 family, whose primitive is GTP_PLL_E3.
module es8311_mclk_pll(
    input  wire clkin1,
    output wire clkout0,
    // The same hardware PLL also produces the 25-MHz fabric clock.  Keeping
    // this on a PLL clock network avoids using a fabric divided signal as a
    // clock and gives the complete CNN data path a valid timing target.
    output wire sysclk_out,
    output wire pll_lock
);
    wire clkout0_ext_unused, clkout2_unused;
    wire clkout3_unused, clkout4_unused, clkout5_unused;
    wire clkswitch_flag_unused;

    GTP_PLL_E3 #(
        .CLKIN_FREQ(50.0),
        .PFDEN_EN("FALSE"), .VCOCLK_DIV2(1'b0),
        .DYNAMIC_RATIOI_EN("FALSE"), .DYNAMIC_RATIOM_EN("FALSE"),
        .DYNAMIC_RATIO0_EN("FALSE"), .DYNAMIC_RATIO1_EN("FALSE"),
        .DYNAMIC_RATIO2_EN("FALSE"), .DYNAMIC_RATIO3_EN("FALSE"),
        .DYNAMIC_RATIO4_EN("FALSE"), .DYNAMIC_RATIOF_EN("FALSE"),
        .STATIC_RATIOI(2), .STATIC_RATIOM(1), .STATIC_RATIOF(29),
        // 50 MHz * 29 / 2 / 59 = 12.288136 MHz (ES8311 MCLK), while output 1
        // divides the same 725-MHz VCO by 29 to obtain a 25.000-MHz system clock.
        .STATIC_RATIO0(59), .STATIC_RATIO1(29), .STATIC_RATIO2(50),
        .STATIC_RATIO3(50), .STATIC_RATIO4(50),
        .DYNAMIC_DUTY0_EN("FALSE"), .DYNAMIC_DUTY1_EN("FALSE"),
        .DYNAMIC_DUTY2_EN("FALSE"), .DYNAMIC_DUTY3_EN("FALSE"),
        .DYNAMIC_DUTY4_EN("FALSE"),
        .STATIC_DUTY0(50), .STATIC_DUTY1(50), .STATIC_DUTY2(50),
        .STATIC_DUTY3(50), .STATIC_DUTY4(50),
        .STATIC_PHASE0(0), .STATIC_PHASE1(0), .STATIC_PHASE2(0),
        .STATIC_PHASE3(0), .STATIC_PHASE4(0), .STATIC_PHASEF(0),
        .STATIC_CPHASE0(0), .STATIC_CPHASE1(0), .STATIC_CPHASE2(0),
        .STATIC_CPHASE3(0), .STATIC_CPHASE4(0),
        .CLK_CAS1_EN("FALSE"), .CLK_CAS2_EN("FALSE"),
        .CLK_CAS3_EN("FALSE"), .CLK_CAS4_EN("FALSE"),
        .CLKOUT5_SEL(0), .CLKIN_BYPASS_EN("FALSE"),
        .CLKOUT0_SYN_EN("FALSE"), .CLKOUT0_EXT_SYN_EN("FALSE"),
        .CLKOUT1_SYN_EN("FALSE"), .CLKOUT2_SYN_EN("FALSE"),
        .CLKOUT3_SYN_EN("FALSE"), .CLKOUT4_SYN_EN("FALSE"),
        .CLKOUT5_SYN_EN("FALSE"),
        .INTERNAL_FB("ENABLE"), .EXTERNAL_FB("DISABLE"),
        .DYNAMIC_LOOP_EN("FALSE"), .LOOP_MAPPING_EN("FALSE"),
        .BANDWIDTH("OPTIMIZED")
    ) pll_i (
        .CLKOUT0(clkout0), .CLKOUT0_EXT(clkout0_ext_unused),
        .CLKOUT1(sysclk_out), .CLKOUT2(clkout2_unused),
        .CLKOUT3(clkout3_unused), .CLKOUT4(clkout4_unused),
        .CLKOUT5(clkout5_unused), .CLKSWITCH_FLAG(clkswitch_flag_unused),
        .LOCK(pll_lock), .CLKIN1(clkin1), .CLKIN2(1'b0), .CLKFB(1'b0),
        .CLKIN_SEL(1'b0), .CLKIN_SEL_EN(1'b0), .PHASE_SEL(3'b000),
        .PFDEN(1'b0), .ICP_BASE(1'b0), .ICP_SEL(4'b0000),
        .LPFRES_SEL(3'b000), .CRIPPLE_SEL(1'b0), .PHASE_DIR(1'b0),
        .PHASE_STEP_N(1'b0), .LOAD_PHASE(1'b0),
        .RATIOI(10'd0), .RATIOM(7'd0), .RATIO0(10'd0), .RATIO1(10'd0),
        .RATIO2(10'd0), .RATIO3(10'd0), .RATIO4(10'd0), .RATIOF(10'd0),
        .DUTY0(10'd0), .DUTY1(10'd0), .DUTY2(10'd0), .DUTY3(10'd0),
        .DUTY4(10'd0), .CLKOUT0_SYN(1'b0), .CLKOUT0_EXT_SYN(1'b0),
        .CLKOUT1_SYN(1'b0), .CLKOUT2_SYN(1'b0), .CLKOUT3_SYN(1'b0),
        .CLKOUT4_SYN(1'b0), .CLKOUT5_SYN(1'b0), .PLL_PWD(1'b0),
        .RST(1'b0), .RSTODIV(1'b0)
    );
endmodule
