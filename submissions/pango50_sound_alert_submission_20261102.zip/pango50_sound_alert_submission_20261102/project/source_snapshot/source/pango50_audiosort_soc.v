`timescale 1ns/1ps
// Alternate tiny-model SoC. No edits to the original CNN/GRU SoC/topology.
// Internal integration. Package-pin locations remain deliberately unset.
module pango50_audiosort_soc #(
    // Live-audio firmware: event BRAM -> CPU time resampler -> CNN feature FIFO.
    // The known-cry self-test bitstream is preserved separately.
    parameter ROM_FILE="C:/Studying_file/pango50_audio_cnn_2/firmware/build/senior_event.hex"
)(input wire clk,rst_n,output wire [31:0] test_status_o,
  // ES8311 microphone ADC, standard I2S receive pins.  BCLK/LRCK are codec
  // clocks and DOUT is ADC serial data; do not connect the codec DIN here.
  input wire es8311_bclk_i,es8311_lrck_i,es8311_dout_i,
  output wire es8311_mclk_o,es8311_scl_o,
  inout wire es8311_sda_io,
  // Active-low local buttons and 115200-baud host command RX.
  input wire gpio_mode_btn_n_i,gpio_history_next_btn_n_i,uart_rx_i,
  output wire motor_in_o,
    // Screen disconnected: its six former J8 pins are static diagnostics.
  output wire diag_j8_8_o,diag_j8_9_o,diag_j8_10_o,
  output wire diag_j8_11_o,diag_j8_12_o,diag_j8_13_o,
  // DDR3 physical pins (Pango ddr3_test IP <-> external DRAM)
  output wire ddr_rst_n, ddr_ck, ddr_ck_n, ddr_cke, ddr_cs_n,
  output wire ddr_ras_n, ddr_cas_n, ddr_we_n, ddr_odt,
  output wire [14:0] ddr_a,
  output wire [2:0]  ddr_ba,
  inout  wire [3:0]  ddr_dqs, ddr_dqs_n,
  inout  wire [31:0] ddr_dq,
  output wire [3:0]  ddr_dm,
  // QSPI NOR flash pins (Winbond W25Q128JVEIQ) carrying the model runtime image
  output wire qspi_cs_o, qspi_sck_o, qspi_mosi_o,
  input  wire qspi_miso_i);
    // AXI4-Lite bus fabric replacing the old pango50_rib_router:
    //   cpu.ibus  -> ifetch_bridge  -> interconnect m0 (read only)
    //   cpu.dbus  -> loadstore_bridge -> interconnect m1 (full)
    //   interconnect s0/s1/s2 -> adapter0/1/2 -> rom/ram/cnn_status_mmio
    // ifetch bridge CPU-side wires (cpu.ibus_* <-> bridge.ibus_*)
    wire [31:0] if_addr_i;      // cpu.ibus_addr_o -> bridge.ibus_addr_i
    wire [31:0] if_data_i;     // cpu.ibus_data_o -> unused (read-only bridge)
    wire [31:0] if_data_o;      // bridge.ibus_data_o -> cpu.ibus_data_i
    wire [3:0]  if_sel_i;       // cpu.ibus_sel_o -> unused (read-only bridge)
    wire        if_we_i;        // cpu.ibus_we_o -> unused (read-only bridge)
    wire        if_req_valid_i; // cpu.ibus_req_valid_o -> bridge.ibus_req_valid_i
    wire        if_req_ready_o; // bridge.ibus_req_ready_o -> cpu.ibus_req_ready_i
    wire        if_rsp_valid_o; // bridge.ibus_rsp_valid_o -> cpu.ibus_rsp_valid_i
    wire        if_rsp_ready_i; // cpu.ibus_rsp_ready_o -> bridge.ibus_rsp_ready_i
    // ifetch bridge AXI read master -> interconnect m0
    wire [31:0] if_araddr_o;
    wire        if_arvalid_o;
    wire        if_arready_i;
    wire [31:0] if_rdata_i;
    wire [1:0]  if_rresp_i;
    wire        if_rvalid_i;
    wire        if_rready_o;
    // loadstore bridge CPU-side wires (cpu.dbus_* <-> bridge.dbus_*)
    wire [31:0] ls_addr_i;      // cpu.dbus_addr_o -> bridge.dbus_addr_i
    wire [31:0] ls_data_i;      // cpu.dbus_data_o -> bridge.dbus_data_i
    wire [31:0] ls_data_o;      // bridge.dbus_data_o -> cpu.dbus_data_i
    wire [3:0]  ls_sel_i;       // cpu.dbus_sel_o -> bridge.dbus_sel_i
    wire        ls_we_i;        // cpu.dbus_we_o -> bridge.dbus_we_i
    wire        ls_req_valid_i; // cpu.dbus_req_valid_o -> bridge.dbus_req_valid_i
    wire        ls_req_ready_o; // bridge.dbus_req_ready_o -> cpu.dbus_req_ready_i
    wire        ls_rsp_valid_o; // bridge.dbus_rsp_valid_o -> cpu.dbus_rsp_valid_i
    wire        ls_rsp_ready_i; // cpu.dbus_rsp_ready_o -> bridge.dbus_rsp_ready_i
    // loadstore bridge AXI full master -> interconnect m1
    wire [31:0] ls_awaddr_o;
    wire        ls_awvalid_o;
    wire        ls_awready_i;
    wire [31:0] ls_wdata_o;
    wire [3:0]  ls_wstrb_o;
    wire        ls_wvalid_o;
    wire        ls_wready_i;
    wire [1:0]  ls_bresp_i;
    wire        ls_bvalid_i;
    wire        ls_bready_o;
    wire [31:0] ls_araddr_o;
    wire        ls_arvalid_o;
    wire        ls_arready_i;
    wire [31:0] ls_rdata_i;
    wire [1:0]  ls_rresp_i;
    wire        ls_rvalid_i;
    wire        ls_rready_o;
    // interconnect <-> adapter shared nets (one set per slave)
    wire [31:0] ad0_awaddr, ad0_wdata, ad0_araddr, ad0_rdata;
    wire [3:0]  ad0_wstrb;
    wire        ad0_awvalid, ad0_wvalid, ad0_arvalid;
    wire        ad0_awready, ad0_wready, ad0_arready;
    wire [1:0]  ad0_bresp, ad0_rresp;
    wire        ad0_bvalid, ad0_rvalid;
    wire        ad0_bready, ad0_rready;
    wire [31:0] ad1_awaddr, ad1_wdata, ad1_araddr, ad1_rdata;
    wire [3:0]  ad1_wstrb;
    wire        ad1_awvalid, ad1_wvalid, ad1_arvalid;
    wire        ad1_awready, ad1_wready, ad1_arready;
    wire [1:0]  ad1_bresp, ad1_rresp;
    wire        ad1_bvalid, ad1_rvalid;
    wire        ad1_bready, ad1_rready;
    wire [31:0] ad2_awaddr, ad2_wdata, ad2_araddr, ad2_rdata;
    wire [3:0]  ad2_wstrb;
    wire        ad2_awvalid, ad2_wvalid, ad2_arvalid;
    wire        ad2_awready, ad2_wready, ad2_arready;
    wire [1:0]  ad2_bresp, ad2_rresp;
    wire        ad2_bvalid, ad2_rvalid;
    wire        ad2_bready, ad2_rready;
    // interconnect s3 <-> DDR3 bridge (CPU-side AXI4-Lite, sys_clk domain)
    wire [31:0] ad3_awaddr, ad3_wdata, ad3_araddr, ad3_rdata;
    wire [3:0]  ad3_wstrb;
    wire        ad3_awvalid, ad3_wvalid, ad3_arvalid;
    wire        ad3_awready, ad3_wready, ad3_arready;
    wire [1:0]  ad3_bresp, ad3_rresp;
    wire        ad3_bvalid, ad3_rvalid;
    wire        ad3_bready, ad3_rready;
    // DDR user-port (256-bit) nets between the bridge and ddr3_host_top
    wire [27:0] d_awaddr, d_araddr;
    wire [3:0]  d_awlen, d_arlen;
    wire        d_awvalid, d_awready, d_arvalid, d_arready;
    wire [255:0] d_wdata, d_rdata;
    wire [31:0] d_wstrb;
    wire        d_wready, d_rvalid, d_rlast;
    wire        ddr_core_clk, ddr_init_done, ddr_pll_lock;
    // CNN tile DDR3 user-port nets (frontend <-> ddr3_user_arbiter)
    wire [27:0] c1_awaddr, c1_araddr, c2_awaddr, c2_araddr,
                c3_awaddr, c3_araddr, c4_awaddr, c4_araddr;
    wire [3:0]  c1_awlen, c1_arlen, c2_awlen, c2_arlen,
                c3_awlen, c3_arlen, c4_awlen, c4_arlen;
    wire        c1_awvalid, c1_awready, c1_arvalid, c1_arready, c1_wready, c1_rlast, c1_rvalid;
    wire        c2_awvalid, c2_awready, c2_arvalid, c2_arready, c2_wready, c2_rlast, c2_rvalid;
    wire        c3_awvalid, c3_awready, c3_arvalid, c3_arready, c3_wready, c3_rlast, c3_rvalid;
    wire        c4_awvalid, c4_awready, c4_arvalid, c4_arready, c4_wready, c4_rlast, c4_rvalid;
    wire [255:0] c1_wdata, c1_rdata, c2_wdata, c2_rdata,
                 c3_wdata, c3_rdata, c4_wdata, c4_rdata;
    wire [31:0]  c1_wstrb, c2_wstrb, c3_wstrb, c4_wstrb;
    // arbiter slave <-> ddr3_host_top (single shared user port)
    wire [27:0] s_awaddr, s_araddr;
    wire [3:0]  s_awlen, s_arlen;
    wire        s_awvalid, s_awready, s_arvalid, s_arready;
    wire [255:0] s_wdata, s_rdata;
    wire [31:0]  s_wstrb;
    wire        s_wready, s_rvalid, s_rlast;
    // rib slave side of adapters -> rom/ram/cnn_status_mmio
    wire [31:0] rom_addr, rom_data_i, rom_data_o;
    wire [3:0]  rom_sel;
    wire        rom_we, rom_req_valid, rom_req_ready, rom_rsp_valid, rom_rsp_ready;
    wire [31:0] ram_addr, ram_data_i, ram_data_o;
    wire [3:0]  ram_sel;
    wire        ram_we, ram_req_valid, ram_req_ready, ram_rsp_valid, ram_rsp_ready;
    wire [31:0] mmio_addr, mmio_data_i, mmio_data_o;
    wire [3:0]  mmio_sel;
    wire        mmio_we, mmio_req_valid, mmio_req_ready, mmio_rsp_valid, mmio_rsp_ready;
    // Authoritative 6-class CNN result.  This—not the historical AudioSort
    // MMIO output—drives alert, history and TFT presentation.
    wire [2:0] senior_class_id;
    wire senior_class_valid;
    wire signed [7:0] senior_class_logit;
    wire [7:0] cnn_diag_status;
    wire diag_logmel_changed, diag_logmel_midrange;
    wire diag_fft_power_seen, diag_mel_power_seen, diag_logmel_positive;
    wire [4:0] cnn_debug_state;
    wire senior_frontend_busy;
    wire [2:0] display_state;
    wire display_update;
    wire alert_class_valid;
    wire [2:0] alert_class_id;
    wire realtime_mode;
    wire [4:0] history_count;
    wire signed [15:0] pcm48k_sample;
    wire pcm48k_sample_valid;
    wire signed [15:0] pcm_sample;
    wire pcm_sample_valid;
    wire [13:0] pcm_write_addr;
    wire [31:0] pcm_sample_count;
    wire signed [15:0] pcm_latest_sample;
    wire es8311_mclk;
    // Keep the inference/control fabric on the known-good board oscillator.
    // MCLK is generated by the PLL for the codec, but the former design also
    // clocked the whole fabric from PLL CLKOUT1.  A codec-clock/PLL bring-up
    // problem then left the I2S->CNN->motor path completely stopped while the
    // TFT (which already uses clk) could still show its red test picture.
    wire sys_clk = clk;
    wire pll_sysclk_unused;
    wire es8311_mclk_locked;
    // Explicit post-configuration reset for the TFT.  The initialized
    // counter is held low for 2^20 cycles of the known 50-MHz board clock
    // (about 21 ms), so the display always observes a real reset interval.
    reg [19:0] tft_boot_count = 20'd0;
    wire tft_reset_n = &tft_boot_count;
    always @(posedge clk)
        if (!tft_reset_n)
            tft_boot_count <= tft_boot_count + 1'b1;
    wire codec_init_done;
    wire codec_init_error;
    reg pcm_seen=1'b0;
    reg bclk_seen=1'b0,lrck_seen=1'b0,amplitude_seen=1'b0;
    reg [1:0] bclk_monitor=0,lrck_monitor=0;
    always @(posedge clk or negedge tft_reset_n)
        if (!tft_reset_n) begin
            pcm_seen<=1'b0;bclk_seen<=1'b0;lrck_seen<=1'b0;
            amplitude_seen<=1'b0;bclk_monitor<=0;lrck_monitor<=0;
        end else begin
            bclk_monitor<={bclk_monitor[0],es8311_bclk_i};
            lrck_monitor<={lrck_monitor[0],es8311_lrck_i};
            if (bclk_monitor[1]!=bclk_monitor[0]) bclk_seen<=1'b1;
            if (lrck_monitor[1]!=lrck_monitor[0]) lrck_seen<=1'b1;
            if (pcm48k_sample_valid) begin
                pcm_seen<=1'b1;
                if (pcm48k_sample>16'sd1000 || pcm48k_sample< -16'sd1000)
                    amplitude_seen<=1'b1;
            end
        end
    // I2S samples are produced by the 50-MHz receiver, while the CNN runs on
    // the PLL's 25-MHz fabric clock.  Transfer a held sample with a toggle;
    // the previous one-cycle pulse could be missed by the slower domain.
    reg signed [15:0] cdc_pcm_sample = 0;
    reg cdc_pcm_toggle = 0;
    always @(posedge clk or negedge tft_reset_n)
        if (!tft_reset_n) begin
            cdc_pcm_sample <= 0;
            cdc_pcm_toggle <= 0;
        end else if (pcm48k_sample_valid) begin
            cdc_pcm_sample <= pcm48k_sample;
            cdc_pcm_toggle <= ~cdc_pcm_toggle;
        end
    reg [2:0] cdc_toggle_sync = 0;
    always @(posedge sys_clk or negedge tft_reset_n)
        if (!tft_reset_n) cdc_toggle_sync <= 0;
        else cdc_toggle_sync <= {cdc_toggle_sync[1:0], cdc_pcm_toggle};
    wire cdc_pcm_valid = cdc_toggle_sync[2] ^ cdc_toggle_sync[1];
    // Hold the 50-MHz system domain in reset during FPGA startup.  Release
    // reset only after the direct-clock boot pulse and two system-clock edges.
    // KEY1 is bypassed for this board because it previously read as asserted.
    reg [1:0] sys_reset_sync=2'b00;
    always @(posedge sys_clk or negedge tft_reset_n)
        if (!tft_reset_n) sys_reset_sync<=2'b00;
        else sys_reset_sync<={sys_reset_sync[0],1'b1};
    // PLL LOCK is a diagnostic only.  It must never reset or stop the CPU,
    // CNN, microphone capture, or motor controller: that would turn a codec
    // clock fault into a silent system-wide failure.
    wire run_rst_n = sys_reset_sync[1];
    // A level interrupt marks each 1024-sample block in the 16 kHz PCM window.
    // It is the hand-off point for the model-matched PCM-to-Mel hardware.
    tinyriscv_core cpu(.clk(sys_clk),.rst_n(run_rst_n),.jtag_halt_i(1'b0),
        .int_i({7'd0,pcm_sample_count[10]}),
        .ibus_addr_o(if_addr_i),.ibus_data_o(if_data_i),.ibus_data_i(if_data_o),
        .ibus_sel_o(if_sel_i),.ibus_we_o(if_we_i),.ibus_req_valid_o(if_req_valid_i),.ibus_req_ready_i(if_req_ready_o),
        .ibus_rsp_valid_i(if_rsp_valid_o),.ibus_rsp_ready_o(if_rsp_ready_i),
        .dbus_addr_o(ls_addr_i),.dbus_data_o(ls_data_i),.dbus_data_i(ls_data_o),
        .dbus_sel_o(ls_sel_i),.dbus_we_o(ls_we_i),.dbus_req_valid_o(ls_req_valid_i),.dbus_req_ready_i(ls_req_ready_o),
        .dbus_rsp_valid_i(ls_rsp_valid_o),.dbus_rsp_ready_o(ls_rsp_ready_i));
    // tinyriscv_core exposes no flush output (its ctrl_flush_o stays internal),
    // so the fetch bridge flush is tied off: the bridge still completes any
    // in-flight read and presents rsp_valid, the core consumes/discards it,
    // and no deadlock can occur (see riscv_ibus_dbus_axi4lite_bridge_notes.md
    // section 3 - with flush_i=0 the behavior matches the old RIB exactly).
    riscv_ifetch_axi4lite_bridge ifetch_bridge(.clk(sys_clk),.rst_n(run_rst_n),
        .ibus_addr_i(if_addr_i),.ibus_req_valid_i(if_req_valid_i),.ibus_req_ready_o(if_req_ready_o),
        .ibus_data_o(if_data_o),.ibus_rsp_valid_o(if_rsp_valid_o),.ibus_rsp_ready_i(if_rsp_ready_i),
        .ibus_flush_i(1'b0),
        .m_araddr_o(if_araddr_o),.m_arvalid_o(if_arvalid_o),.m_arready_i(if_arready_i),
        .m_rdata_i(if_rdata_i),.m_rresp_i(if_rresp_i),.m_rvalid_i(if_rvalid_i),.m_rready_o(if_rready_o));
    riscv_dbus_axi4lite_bridge loadstore_bridge(.clk(sys_clk),.rst_n(run_rst_n),
        .dbus_addr_i(ls_addr_i),.dbus_data_i(ls_data_i),.dbus_sel_i(ls_sel_i),.dbus_we_i(ls_we_i),
        .dbus_req_valid_i(ls_req_valid_i),.dbus_req_ready_o(ls_req_ready_o),
        .dbus_data_o(ls_data_o),.dbus_rsp_valid_o(ls_rsp_valid_o),.dbus_rsp_ready_i(ls_rsp_ready_i),
        .m_awaddr_o(ls_awaddr_o),.m_awvalid_o(ls_awvalid_o),.m_awready_i(ls_awready_i),
        .m_wdata_o(ls_wdata_o),.m_wstrb_o(ls_wstrb_o),.m_wvalid_o(ls_wvalid_o),.m_wready_i(ls_wready_i),
        .m_bresp_i(ls_bresp_i),.m_bvalid_i(ls_bvalid_i),.m_bready_o(ls_bready_o),
        .m_araddr_o(ls_araddr_o),.m_arvalid_o(ls_arvalid_o),.m_arready_i(ls_arready_i),
        .m_rdata_i(ls_rdata_i),.m_rresp_i(ls_rresp_i),.m_rvalid_i(ls_rvalid_i),.m_rready_o(ls_rready_o));
    axi4lite_interconnect axi_bus(.clk(sys_clk),.rst_n(run_rst_n),
        .m0_araddr_i(if_araddr_o),.m0_arvalid_i(if_arvalid_o),.m0_arready_o(if_arready_i),
        .m0_rdata_o(if_rdata_i),.m0_rresp_o(if_rresp_i),.m0_rvalid_o(if_rvalid_i),.m0_rready_i(if_rready_o),
        .m1_awaddr_i(ls_awaddr_o),.m1_awvalid_i(ls_awvalid_o),.m1_awready_o(ls_awready_i),
        .m1_wdata_i(ls_wdata_o),.m1_wstrb_i(ls_wstrb_o),.m1_wvalid_i(ls_wvalid_o),.m1_wready_o(ls_wready_i),
        .m1_bresp_o(ls_bresp_i),.m1_bvalid_o(ls_bvalid_i),.m1_bready_i(ls_bready_o),
        .m1_araddr_i(ls_araddr_o),.m1_arvalid_i(ls_arvalid_o),.m1_arready_o(ls_arready_i),
        .m1_rdata_o(ls_rdata_i),.m1_rresp_o(ls_rresp_i),.m1_rvalid_o(ls_rvalid_i),.m1_rready_i(ls_rready_o),
        .s0_awaddr_o(ad0_awaddr),.s0_awvalid_o(ad0_awvalid),.s0_awready_i(ad0_awready),
        .s0_wdata_o(ad0_wdata),.s0_wstrb_o(ad0_wstrb),.s0_wvalid_o(ad0_wvalid),.s0_wready_i(ad0_wready),
        .s0_bresp_i(ad0_bresp),.s0_bvalid_i(ad0_bvalid),.s0_bready_o(ad0_bready),
        .s0_araddr_o(ad0_araddr),.s0_arvalid_o(ad0_arvalid),.s0_arready_i(ad0_arready),
        .s0_rdata_i(ad0_rdata),.s0_rresp_i(ad0_rresp),.s0_rvalid_i(ad0_rvalid),.s0_rready_o(ad0_rready),
        .s1_awaddr_o(ad1_awaddr),.s1_awvalid_o(ad1_awvalid),.s1_awready_i(ad1_awready),
        .s1_wdata_o(ad1_wdata),.s1_wstrb_o(ad1_wstrb),.s1_wvalid_o(ad1_wvalid),.s1_wready_i(ad1_wready),
        .s1_bresp_i(ad1_bresp),.s1_bvalid_i(ad1_bvalid),.s1_bready_o(ad1_bready),
        .s1_araddr_o(ad1_araddr),.s1_arvalid_o(ad1_arvalid),.s1_arready_i(ad1_arready),
        .s1_rdata_i(ad1_rdata),.s1_rresp_i(ad1_rresp),.s1_rvalid_i(ad1_rvalid),.s1_rready_o(ad1_rready),
        .s2_awaddr_o(ad2_awaddr),.s2_awvalid_o(ad2_awvalid),.s2_awready_i(ad2_awready),
        .s2_wdata_o(ad2_wdata),.s2_wstrb_o(ad2_wstrb),.s2_wvalid_o(ad2_wvalid),.s2_wready_i(ad2_wready),
        .s2_bresp_i(ad2_bresp),.s2_bvalid_i(ad2_bvalid),.s2_bready_o(ad2_bready),
        .s2_araddr_o(ad2_araddr),.s2_arvalid_o(ad2_arvalid),.s2_arready_i(ad2_arready),
        .s2_rdata_i(ad2_rdata),.s2_rresp_i(ad2_rresp),.s2_rvalid_i(ad2_rvalid),.s2_rready_o(ad2_rready),
        .s3_awaddr_o(ad3_awaddr),.s3_awvalid_o(ad3_awvalid),.s3_awready_i(ad3_awready),
        .s3_wdata_o(ad3_wdata),.s3_wstrb_o(ad3_wstrb),.s3_wvalid_o(ad3_wvalid),.s3_wready_i(ad3_wready),
        .s3_bresp_i(ad3_bresp),.s3_bvalid_i(ad3_bvalid),.s3_bready_o(ad3_bready),
        .s3_araddr_o(ad3_araddr),.s3_arvalid_o(ad3_arvalid),.s3_arready_i(ad3_arready),
        .s3_rdata_i(ad3_rdata),.s3_rresp_i(ad3_rresp),.s3_rvalid_i(ad3_rvalid),.s3_rready_o(ad3_rready));
    // DDR3 window (0x2000_0000): the bridge translates the interconnect slave-3
    // AXI4-Lite traffic to the 256-bit Pango controller user port, crossing
    // from sys_clk to ddr_core_clk.  A request is held until ddr_init_done.
    ddr3_axi_bridge ddr_bridge(
        .sys_clk(sys_clk),.sys_rst_n(run_rst_n),
        .ddr_clk(ddr_core_clk),.ddr_rst_n(run_rst_n),.ddr_init_done_i(ddr_init_done),
        .s_awaddr_i(ad3_awaddr),.s_awvalid_i(ad3_awvalid),.s_awready_o(ad3_awready),
        .s_wdata_i(ad3_wdata),.s_wstrb_i(ad3_wstrb),.s_wvalid_i(ad3_wvalid),.s_wready_o(ad3_wready),
        .s_bresp_o(ad3_bresp),.s_bvalid_o(ad3_bvalid),.s_bready_i(ad3_bready),
        .s_araddr_i(ad3_araddr),.s_arvalid_i(ad3_arvalid),.s_arready_o(ad3_arready),
        .s_rdata_o(ad3_rdata),.s_rresp_o(ad3_rresp),.s_rvalid_o(ad3_rvalid),.s_rready_i(ad3_rready),
        .d_awaddr_o(d_awaddr),.d_awlen_o(d_awlen),.d_awready_i(d_awready),.d_awvalid_o(d_awvalid),
        .d_wdata_o(d_wdata),.d_wstrb_o(d_wstrb),.d_wready_i(d_wready),
        .d_araddr_o(d_araddr),.d_arlen_o(d_arlen),.d_arready_i(d_arready),.d_arvalid_o(d_arvalid),
        .d_rdata_i(d_rdata),.d_rlast_i(d_rlast),.d_rvalid_i(d_rvalid));
    ddr3_host_top ddr_host(
        .ref_clk(clk),.resetn(run_rst_n),
        .core_clk_o(ddr_core_clk),.init_done_o(ddr_init_done),.pll_lock_o(ddr_pll_lock),
        .awaddr_i(s_awaddr),.awlen_i(s_awlen),.awready_o(s_awready),.awvalid_i(s_awvalid),
        .wdata_i(s_wdata),.wstrb_i(s_wstrb),.wready_o(s_wready),
        .araddr_i(s_araddr),.arlen_i(s_arlen),.arready_o(s_arready),.arvalid_i(s_arvalid),
        .rdata_o(s_rdata),.rlast_o(s_rlast),.rvalid_o(s_rvalid),
        .mem_rst_n(ddr_rst_n),.mem_ck(ddr_ck),.mem_ck_n(ddr_ck_n),.mem_cke(ddr_cke),
        .mem_cs_n(ddr_cs_n),.mem_ras_n(ddr_ras_n),.mem_cas_n(ddr_cas_n),.mem_we_n(ddr_we_n),
        .mem_odt(ddr_odt),.mem_a(ddr_a),.mem_ba(ddr_ba),
        .mem_dqs(ddr_dqs),.mem_dqs_n(ddr_dqs_n),.mem_dq(ddr_dq),.mem_dm(ddr_dm));
    // Shared user-port arbiter: the CPU window bridge (m0) and the four CNN
    // tiles (m1..m4) mux onto the single ddr3_host_top port, all on ddr_core_clk.
    senior_dbl_ddr3_user_arbiter ddr_arbiter(
        .clk(ddr_core_clk),.rst_n(run_rst_n),
        .m0_awaddr(d_awaddr),.m0_araddr(d_araddr),
        .m0_awlen(d_awlen),.m0_arlen(d_arlen),
        .m0_awvalid(d_awvalid),.m0_arvalid(d_arvalid),
        .m0_awready(d_awready),.m0_arready(d_arready),
        .m0_wdata(d_wdata),.m0_wstrb(d_wstrb),.m0_wready(d_wready),
        .m0_rdata(d_rdata),.m0_rlast(d_rlast),.m0_rvalid(d_rvalid),
        .m1_awaddr(c1_awaddr),.m1_araddr(c1_araddr),
        .m1_awlen(c1_awlen),.m1_arlen(c1_arlen),
        .m1_awvalid(c1_awvalid),.m1_arvalid(c1_arvalid),
        .m1_awready(c1_awready),.m1_arready(c1_arready),
        .m1_wdata(c1_wdata),.m1_wstrb(c1_wstrb),.m1_wready(c1_wready),
        .m1_rdata(c1_rdata),.m1_rlast(c1_rlast),.m1_rvalid(c1_rvalid),
        .m2_awaddr(c2_awaddr),.m2_araddr(c2_araddr),
        .m2_awlen(c2_awlen),.m2_arlen(c2_arlen),
        .m2_awvalid(c2_awvalid),.m2_arvalid(c2_arvalid),
        .m2_awready(c2_awready),.m2_arready(c2_arready),
        .m2_wdata(c2_wdata),.m2_wstrb(c2_wstrb),.m2_wready(c2_wready),
        .m2_rdata(c2_rdata),.m2_rlast(c2_rlast),.m2_rvalid(c2_rvalid),
        .m3_awaddr(c3_awaddr),.m3_araddr(c3_araddr),
        .m3_awlen(c3_awlen),.m3_arlen(c3_arlen),
        .m3_awvalid(c3_awvalid),.m3_arvalid(c3_arvalid),
        .m3_awready(c3_awready),.m3_arready(c3_arready),
        .m3_wdata(c3_wdata),.m3_wstrb(c3_wstrb),.m3_wready(c3_wready),
        .m3_rdata(c3_rdata),.m3_rlast(c3_rlast),.m3_rvalid(c3_rvalid),
        .m4_awaddr(c4_awaddr),.m4_araddr(c4_araddr),
        .m4_awlen(c4_awlen),.m4_arlen(c4_arlen),
        .m4_awvalid(c4_awvalid),.m4_arvalid(c4_arvalid),
        .m4_awready(c4_awready),.m4_arready(c4_arready),
        .m4_wdata(c4_wdata),.m4_wstrb(c4_wstrb),.m4_wready(c4_wready),
        .m4_rdata(c4_rdata),.m4_rlast(c4_rlast),.m4_rvalid(c4_rvalid),
        .s_awaddr(s_awaddr),.s_araddr(s_araddr),
        .s_awlen(s_awlen),.s_arlen(s_arlen),
        .s_awvalid(s_awvalid),.s_arvalid(s_arvalid),
        .s_awready(s_awready),.s_arready(s_arready),
        .s_wdata(s_wdata),.s_wstrb(s_wstrb),.s_wready(s_wready),
        .s_rdata(s_rdata),.s_rlast(s_rlast),.s_rvalid(s_rvalid));
    axi4lite_to_rib_slave_adapter adapter0(.clk(sys_clk),.rst_n(run_rst_n),
        .s_awaddr_i(ad0_awaddr),.s_awvalid_i(ad0_awvalid),.s_awready_o(ad0_awready),
        .s_wdata_i(ad0_wdata),.s_wstrb_i(ad0_wstrb),.s_wvalid_i(ad0_wvalid),.s_wready_o(ad0_wready),
        .s_bresp_o(ad0_bresp),.s_bvalid_o(ad0_bvalid),.s_bready_i(ad0_bready),
        .s_araddr_i(ad0_araddr),.s_arvalid_i(ad0_arvalid),.s_arready_o(ad0_arready),
        .s_rdata_o(ad0_rdata),.s_rresp_o(ad0_rresp),.s_rvalid_o(ad0_rvalid),.s_rready_i(ad0_rready),
        .rib_addr_o(rom_addr),.rib_data_o(rom_data_i),.rib_sel_o(rom_sel),.rib_we_o(rom_we),
        .rib_req_valid_o(rom_req_valid),.rib_req_ready_i(rom_req_ready),
        .rib_rsp_valid_i(rom_rsp_valid),.rib_rsp_ready_o(rom_rsp_ready),.rib_data_i(rom_data_o));
    axi4lite_to_rib_slave_adapter adapter1(.clk(sys_clk),.rst_n(run_rst_n),
        .s_awaddr_i(ad1_awaddr),.s_awvalid_i(ad1_awvalid),.s_awready_o(ad1_awready),
        .s_wdata_i(ad1_wdata),.s_wstrb_i(ad1_wstrb),.s_wvalid_i(ad1_wvalid),.s_wready_o(ad1_wready),
        .s_bresp_o(ad1_bresp),.s_bvalid_o(ad1_bvalid),.s_bready_i(ad1_bready),
        .s_araddr_i(ad1_araddr),.s_arvalid_i(ad1_arvalid),.s_arready_o(ad1_arready),
        .s_rdata_o(ad1_rdata),.s_rresp_o(ad1_rresp),.s_rvalid_o(ad1_rvalid),.s_rready_i(ad1_rready),
        .rib_addr_o(ram_addr),.rib_data_o(ram_data_i),.rib_sel_o(ram_sel),.rib_we_o(ram_we),
        .rib_req_valid_o(ram_req_valid),.rib_req_ready_i(ram_req_ready),
        .rib_rsp_valid_i(ram_rsp_valid),.rib_rsp_ready_o(ram_rsp_ready),.rib_data_i(ram_data_o));
    axi4lite_to_rib_slave_adapter adapter2(.clk(sys_clk),.rst_n(run_rst_n),
        .s_awaddr_i(ad2_awaddr),.s_awvalid_i(ad2_awvalid),.s_awready_o(ad2_awready),
        .s_wdata_i(ad2_wdata),.s_wstrb_i(ad2_wstrb),.s_wvalid_i(ad2_wvalid),.s_wready_o(ad2_wready),
        .s_bresp_o(ad2_bresp),.s_bvalid_o(ad2_bvalid),.s_bready_i(ad2_bready),
        .s_araddr_i(ad2_araddr),.s_arvalid_i(ad2_arvalid),.s_arready_o(ad2_arready),
        .s_rdata_o(ad2_rdata),.s_rresp_o(ad2_rresp),.s_rvalid_o(ad2_rvalid),.s_rready_i(ad2_rready),
        .rib_addr_o(mmio_addr),.rib_data_o(mmio_data_i),.rib_sel_o(mmio_sel),.rib_we_o(mmio_we),
        .rib_req_valid_o(mmio_req_valid),.rib_req_ready_i(mmio_req_ready),
        .rib_rsp_valid_i(mmio_rsp_valid),.rib_rsp_ready_o(mmio_rsp_ready),.rib_data_i(mmio_data_o));
    pango50_rib_memory #(.READ_ONLY(1),.INIT_FILE(ROM_FILE)) rom(
        .clk(sys_clk),.rst_n(run_rst_n),.addr_i(rom_addr),.data_i(rom_data_i),.sel_i(rom_sel),.we_i(rom_we),
        .req_valid_i(rom_req_valid),.req_ready_o(rom_req_ready),.rsp_valid_o(rom_rsp_valid),
        .rsp_ready_i(rom_rsp_ready),.data_o(rom_data_o));
    pango50_rib_memory ram(
        .clk(sys_clk),.rst_n(run_rst_n),.addr_i(ram_addr),.data_i(ram_data_i),.sel_i(ram_sel),.we_i(ram_we),
        .req_valid_i(ram_req_valid),.req_ready_o(ram_req_ready),.rsp_valid_o(ram_rsp_valid),
        .rsp_ready_i(ram_rsp_ready),.data_o(ram_data_o));
    wire control_event;
    caregiver_mode_history_controller #(.CLOCK_HZ(50000000)) mode_history_ctrl(.clk(sys_clk),.rst_n(run_rst_n),
        .class_id_i(senior_class_id),.class_valid_i(senior_class_valid),
        .gpio_mode_btn_n_i(gpio_mode_btn_n_i),.gpio_history_next_btn_n_i(gpio_history_next_btn_n_i),.uart_rx_i(uart_rx_i),
        .realtime_mode_o(realtime_mode),.display_state_o(display_state),.display_update_o(display_update),
        .alert_class_valid_o(alert_class_valid),.alert_class_id_o(alert_class_id),.history_count_o(history_count),
        .control_event_o(control_event));
    wire [15:0] pcm_magnitude = pcm_sample[15] ? (~pcm_sample + 16'd1) : pcm_sample;
    // A vibration starts as soon as the CNN identifies one of the five cry
    // classes (0..4); class 5 is background and never starts the motor.  The
    // cry-class result alone guarantees a fixed minimum vibration, and a
    // continuing cry (PCM above threshold) extends it until 250 ms of quiet
    // audio.  This drops the earlier rule that the baby must still be loud at
    // the instant the seven-second window finishes, which left intermittent
    // cries with no vibration at all.
    localparam integer CRY_QUIET_TICKS = 12500000; // 250 ms at 50 MHz
    localparam integer VIBRATE_TICKS   = 40000000; // 800 ms at 50 MHz
    reg [23:0] cry_audio_hold_ticks=0;
    reg [25:0] vibrate_ticks=0;
    wire motor_on = (vibrate_ticks != 0);
    always @(posedge sys_clk or negedge run_rst_n)
        if(!run_rst_n)
            cry_audio_hold_ticks<=0;
        else if(pcm_sample_valid && pcm_magnitude > 16'd1000)
            cry_audio_hold_ticks<=CRY_QUIET_TICKS;
        else if(cry_audio_hold_ticks != 0)
            cry_audio_hold_ticks<=cry_audio_hold_ticks-1'b1;
    wire cry_audio_present = (cry_audio_hold_ticks != 0);
    always @(posedge sys_clk or negedge run_rst_n)
        if(!run_rst_n)
            vibrate_ticks<=0;
        else if(senior_class_valid && (senior_class_id <= 3'd4))
            vibrate_ticks<=VIBRATE_TICKS;
        else if(vibrate_ticks!=0 && cry_audio_present)
            vibrate_ticks<=VIBRATE_TICKS;
        else if(vibrate_ticks!=0)
            vibrate_ticks<=vibrate_ticks-1'b1;
    assign motor_in_o = run_rst_n && motor_on;
    // No display logic in this diagnostic build.  J8-8..13 are reassigned
    // below to stable milestones that can be read with a multimeter.
    // Kept as visible RTL blocks so the PDS hierarchy makes the microphone
    // data path explicit: ES8311 -> I2S receiver -> PCM ring buffer.
    es8311_i2s_receiver mic_i2s_rx(.clk(clk),.rst_n(tft_reset_n),
        .bclk_i(es8311_bclk_i),.lrck_i(es8311_lrck_i),.dout_i(es8311_dout_i),
        .sample_o(pcm48k_sample),.sample_valid_o(pcm48k_sample_valid));
    // Codec LRCK is 48.0005 kHz (12.288136-MHz MCLK / 256), decimated /3 to
    // 16.00018 kHz, matching the model's 16-kHz contract within 11 ppm.
    pcm_decimator_48k_to_16k mic_decimator(.clk(sys_clk),.rst_n(run_rst_n),
        .sample_i(cdc_pcm_sample),.sample_valid_i(cdc_pcm_valid),
        .sample_o(pcm_sample),.sample_valid_o(pcm_sample_valid));
    es8311_mclk_pll es8311_mclk_i(.clkin1(clk),.clkout0(es8311_mclk),.sysclk_out(pll_sysclk_unused),
        .pll_lock(es8311_mclk_locked));
    // Do not gate a clock with pll_lock.  The lock signal remains visible in
    // the RTL hierarchy while MCLK drives the external ES8311 pin directly.
    assign es8311_mclk_o=es8311_mclk;
    es8311_i2c_init #(.CLOCK_HZ(50000000)) es8311_setup(
        .clk(clk),.scl_o(es8311_scl_o),.sda_io(es8311_sda_io),
        .done_o(codec_init_done),.error_o(codec_init_error));
    audio_pcm_ring_buffer #(.ADDR_BITS(14)) pcm_capture(.clk(sys_clk),.rst_n(run_rst_n),
        .sample_i(pcm_sample),.sample_valid_i(pcm_sample_valid),
        .write_addr_o(pcm_write_addr),.sample_count_o(pcm_sample_count),
        .latest_sample_o(pcm_latest_sample));
    // Full deployment-package path: 16 kHz PCM -> Log-Mel -> model_dbl_int8
    // CNN -> caregiver alert/history presentation.  Event length defaults to
    // 700 10-ms frames (about seven seconds), as specified by the package.
    wire cnn_compute_busy;
    // RISC-V-programmed shared-engine descriptor.  The legacy stream core
    // remains the active inference implementation until its replacement has
    // passed bit-exact verification against model_dbl_int8.
    wire senior_engine_start;
    wire [2:0] senior_engine_layer;
    wire [17:0] senior_engine_terms;
    wire signed [31:0] senior_engine_bias;
    wire [31:0] senior_engine_input_base, senior_engine_output_base;
    wire [31:0] senior_engine_weight_base, senior_engine_quant_base;
    wire [13:0] event_read_word_addr;
    wire [31:0] event_read_word_data;
    wire [9:0] event_frame_count;
    wire event_ready,event_overflow,event_release,cnn_pending;
    wire cpu_feature_start,cpu_feature_valid,cpu_feature_ready;
    wire signed [7:0] cpu_feature;
    senior_dbl_audio_inference_frontend senior_cnn_frontend(
        .clk(sys_clk),.rst_n(run_rst_n),.pcm16_i(pcm_sample),.pcm16_valid_i(pcm_sample_valid),
        .busy_o(senior_frontend_busy),.class_valid_o(senior_class_valid),
        .class_index_o(senior_class_id),.class_logit_o(senior_class_logit),.cnn_busy_o(cnn_compute_busy),
        .diag_status_o(cnn_diag_status),
        .diag_logmel_changed_o(diag_logmel_changed),
        .diag_logmel_midrange_o(diag_logmel_midrange),
        .diag_fft_power_seen_o(diag_fft_power_seen),
        .diag_mel_power_seen_o(diag_mel_power_seen),
        .diag_logmel_positive_o(diag_logmel_positive),
        .debug_state_o(cnn_debug_state),
        .cnn_pending_o(cnn_pending),
        .event_read_word_addr_i(event_read_word_addr),.event_read_word_data_o(event_read_word_data),
        .event_frame_count_o(event_frame_count),.event_ready_o(event_ready),
        .event_overflow_o(event_overflow),.event_release_i(event_release),
        .cpu_feature_start_i(cpu_feature_start),.cpu_feature_i(cpu_feature),
        .cpu_feature_valid_i(cpu_feature_valid),.cpu_feature_ready_o(cpu_feature_ready),
        .ddr_core_clk_i(ddr_core_clk),.ddr_rst_n_i(run_rst_n),.ddr_init_done_i(ddr_init_done),
        .qspi_cs_o(qspi_cs_o),.qspi_sck_o(qspi_sck_o),
        .qspi_mosi_o(qspi_mosi_o),.qspi_miso_i(qspi_miso_i),
        .c1_awaddr_o(c1_awaddr),.c1_araddr_o(c1_araddr),
        .c1_awlen_o(c1_awlen),.c1_arlen_o(c1_arlen),
        .c1_awvalid_o(c1_awvalid),.c1_arvalid_o(c1_arvalid),
        .c1_awready_i(c1_awready),.c1_arready_i(c1_arready),
        .c1_wdata_o(c1_wdata),.c1_wstrb_o(c1_wstrb),.c1_wready_i(c1_wready),
        .c1_rdata_i(c1_rdata),.c1_rlast_i(c1_rlast),.c1_rvalid_i(c1_rvalid),
        .c2_awaddr_o(c2_awaddr),.c2_araddr_o(c2_araddr),
        .c2_awlen_o(c2_awlen),.c2_arlen_o(c2_arlen),
        .c2_awvalid_o(c2_awvalid),.c2_arvalid_o(c2_arvalid),
        .c2_awready_i(c2_awready),.c2_arready_i(c2_arready),
        .c2_wdata_o(c2_wdata),.c2_wstrb_o(c2_wstrb),.c2_wready_i(c2_wready),
        .c2_rdata_i(c2_rdata),.c2_rlast_i(c2_rlast),.c2_rvalid_i(c2_rvalid),
        .c3_awaddr_o(c3_awaddr),.c3_araddr_o(c3_araddr),
        .c3_awlen_o(c3_awlen),.c3_arlen_o(c3_arlen),
        .c3_awvalid_o(c3_awvalid),.c3_arvalid_o(c3_arvalid),
        .c3_awready_i(c3_awready),.c3_arready_i(c3_arready),
        .c3_wdata_o(c3_wdata),.c3_wstrb_o(c3_wstrb),.c3_wready_i(c3_wready),
        .c3_rdata_i(c3_rdata),.c3_rlast_i(c3_rlast),.c3_rvalid_i(c3_rvalid),
        .c4_awaddr_o(c4_awaddr),.c4_araddr_o(c4_araddr),
        .c4_awlen_o(c4_awlen),.c4_arlen_o(c4_arlen),
        .c4_awvalid_o(c4_awvalid),.c4_arvalid_o(c4_arvalid),
        .c4_awready_i(c4_awready),.c4_arready_i(c4_arready),
        .c4_wdata_o(c4_wdata),.c4_wstrb_o(c4_wstrb),.c4_wready_i(c4_wready),
        .c4_rdata_i(c4_rdata),.c4_rlast_i(c4_rlast),.c4_rvalid_i(c4_rvalid));
    senior_dbl_status_mmio cnn_status_mmio(
        .clk(sys_clk),.rst_n(run_rst_n),.addr_i(mmio_addr),.data_i(mmio_data_i),
        .sel_i(mmio_sel),.we_i(mmio_we),.req_valid_i(mmio_req_valid),.req_ready_o(mmio_req_ready),
        .rsp_valid_o(mmio_rsp_valid),.rsp_ready_i(mmio_rsp_ready),.data_o(mmio_data_o),
        .busy_i(senior_frontend_busy),.class_valid_i(senior_class_valid),
        .class_id_i(senior_class_id),.class_logit_i(senior_class_logit),
        .realtime_mode_i(realtime_mode),.display_state_i(display_state),
        .history_count_i(history_count),.alert_class_valid_i(alert_class_valid),
        .alert_class_id_i(alert_class_id),
        .engine_start_o(senior_engine_start),.engine_layer_o(senior_engine_layer),
        .engine_terms_o(senior_engine_terms),.engine_bias_o(senior_engine_bias),
        .engine_input_base_o(senior_engine_input_base),.engine_output_base_o(senior_engine_output_base),
        .engine_weight_base_o(senior_engine_weight_base),.engine_quant_base_o(senior_engine_quant_base),
        .event_read_word_addr_o(event_read_word_addr),.event_read_word_data_i(event_read_word_data),
        .event_frame_count_i(event_frame_count),.event_ready_i(event_ready),
        .event_overflow_i(event_overflow),.event_release_o(event_release),.cnn_pending_i(cnn_pending),
        .cpu_feature_start_o(cpu_feature_start),.cpu_feature_o(cpu_feature),
        .cpu_feature_valid_o(cpu_feature_valid),.cpu_feature_ready_i(cpu_feature_ready));
    // J8 diagnostic snapshot: pins 23..29 and 31..32 hold the last result.
    // Unlike the old background-streak multiplexer, pins 23..25 ALWAYS show
    // the raw class ID. Pins 30/33 are sticky upstream Log-Mel monitors.
    reg [2:0] last_class_id = 3'b0;
    reg cnn_result_seen = 1'b0;
    reg cnn_compute_seen = 1'b0;
    reg diag_cpu_start_seen = 1'b0;
    reg diag_event_ready_seen = 1'b0;
    reg [31:0] diag_cpu_progress = 32'd0;
    reg diag_cpu_progress_seen = 1'b0;
    // Observe the RAM-side accepted write, where address and data have
    // already passed through the AXI bridge and the AXI-to-RIB adapter.
    // This captures the firmware's 0x1000ffe0 progress/error word even if
    // AW and W handshakes occurred in different upstream cycles.
    always @(posedge sys_clk or negedge run_rst_n)
        if (!run_rst_n) begin
            diag_cpu_progress <= 32'd0;
            diag_cpu_progress_seen <= 1'b0;
        end else if (ram_req_valid && ram_req_ready && ram_we &&
                     ram_sel == 4'hf && ram_addr == 32'h1000ffe0) begin
            diag_cpu_progress <= ram_data_i;
            diag_cpu_progress_seen <= 1'b1;
        end
    // CPU-to-CNN feature-stream health.  A valid result must be preceded by
    // exactly 10240 accepted bytes and at least two distinct feature values.
    reg [13:0] diag_feature_count = 14'd0;
    reg diag_feature_complete = 1'b0, diag_feature_seen = 1'b0;
    reg diag_feature_ever_complete = 1'b0;
    reg diag_feature_changed = 1'b0;
    reg diag_feature_midrange = 1'b0;
    reg signed [7:0] diag_last_feature = 8'sd0;
    reg result_feature_complete = 1'b0, result_feature_changed = 1'b0;
    reg result_feature_midrange = 1'b0;
    always @(posedge sys_clk or negedge run_rst_n)
        if (!run_rst_n) begin
            last_class_id <= 0;
            cnn_result_seen <= 0;
            cnn_compute_seen <= 0;
            diag_cpu_start_seen <= 0;
            diag_event_ready_seen <= 0;
            diag_feature_count <= 0;
            diag_feature_complete <= 0;
            diag_feature_ever_complete <= 0;
            diag_feature_seen <= 0;
            diag_feature_changed <= 0;
            diag_feature_midrange <= 0;
            diag_last_feature <= 0;
            result_feature_complete <= 0;
            result_feature_changed <= 0;
            result_feature_midrange <= 0;
        end else begin
            if (senior_class_valid) begin
                last_class_id <= senior_class_id;
                cnn_result_seen <= 1'b1;
                result_feature_complete <= diag_feature_complete;
                result_feature_changed <= diag_feature_changed;
                result_feature_midrange <= diag_feature_midrange;
            end
            if (cnn_compute_busy) cnn_compute_seen <= 1'b1;
            if (diag_feature_complete) diag_feature_ever_complete <= 1'b1;
            if (event_ready) diag_event_ready_seen <= 1'b1;
            if (cpu_feature_start) begin
                diag_cpu_start_seen <= 1'b1;
                diag_feature_count <= 0;
                diag_feature_complete <= 1'b0;
                diag_feature_seen <= 1'b0;
                diag_feature_changed <= 1'b0;
                diag_feature_midrange <= 1'b0;
            end
            if (cpu_feature_valid && cpu_feature_ready) begin
                if (diag_feature_seen && cpu_feature != diag_last_feature)
                    diag_feature_changed <= 1'b1;
                if (cpu_feature != 8'sh80 && cpu_feature != 8'sd127)
                    diag_feature_midrange <= 1'b1;
                diag_last_feature <= cpu_feature;
                diag_feature_seen <= 1'b1;
                if (diag_feature_count == 14'd10239)
                    diag_feature_complete <= 1'b1;
                else if (diag_feature_count < 14'd10240)
                    diag_feature_count <= diag_feature_count + 1'b1;
            end
        end
    // Normal-audio diagnosis.  J8-12 selects the meaning of J8-8..10:
    //   0: boot progress / event ready / CPU start milestones;
    //   1: low three bits of firmware error code 0xee0000xx.
    // J8-11 and J8-13 stay as feature-complete and result-seen milestones.
    wire diag_cpu_error = diag_cpu_progress[31:24] == 8'hee;
    assign diag_j8_8_o  = diag_cpu_error ? diag_cpu_progress[0] : diag_cpu_progress_seen;
    assign diag_j8_9_o  = diag_cpu_error ? diag_cpu_progress[1] : diag_event_ready_seen;
    assign diag_j8_10_o = diag_cpu_error ? diag_cpu_progress[2] : diag_cpu_start_seen;
    assign diag_j8_11_o = diag_feature_ever_complete;
    assign diag_j8_12_o = diag_cpu_error;
    assign diag_j8_13_o = cnn_result_seen;
    // Every debounced key press or complete UART byte flashes LED8 for 200 ms.
    localparam integer CONTROL_LED_FLASH_TICKS = 10000000; // 200 ms @ 50 MHz
    reg [23:0] control_led_flash_ticks = 0;
    always @(posedge sys_clk or negedge run_rst_n)
        if (!run_rst_n)
            control_led_flash_ticks <= 0;
        else if (control_event)
            control_led_flash_ticks <= CONTROL_LED_FLASH_TICKS;
        else if (control_led_flash_ticks != 0)
            control_led_flash_ticks <= control_led_flash_ticks - 1'b1;
    reg [31:0] sw_test_status=0;
    // Board LEDs are mapped to test_status_o[23:30] in the FDC.
    // Diagnostic UI: LED1 heartbeat; LED2 codec configuration (flashes on
    // error); LED3 recent BCLK+LRCK; LED4 recent PCM; LED5 audio above threshold;
    // LED6 CNN compute busy; LED7 each completed inference; LED8 key/UART event.
    reg [24:0] heartbeat_ticks=0;
    reg heartbeat=0;
    reg [23:0] bclk_alive_ticks=0,lrck_alive_ticks=0,pcm_alive_ticks=0,result_ticks=0;
    always @(posedge sys_clk or negedge run_rst_n) begin
        if(!run_rst_n) begin
            heartbeat_ticks<=0;heartbeat<=0;
            bclk_alive_ticks<=0;lrck_alive_ticks<=0;pcm_alive_ticks<=0;result_ticks<=0;
        end else begin
            if(heartbeat_ticks==24999999) begin heartbeat_ticks<=0;heartbeat<=~heartbeat;end
            else heartbeat_ticks<=heartbeat_ticks+1'b1;
            if(bclk_monitor[1]!=bclk_monitor[0]) bclk_alive_ticks<=12500000;
            else if(bclk_alive_ticks!=0) bclk_alive_ticks<=bclk_alive_ticks-1'b1;
            if(lrck_monitor[1]!=lrck_monitor[0]) lrck_alive_ticks<=12500000;
            else if(lrck_alive_ticks!=0) lrck_alive_ticks<=lrck_alive_ticks-1'b1;
            if(pcm_sample_valid) pcm_alive_ticks<=12500000;
            else if(pcm_alive_ticks!=0) pcm_alive_ticks<=pcm_alive_ticks-1'b1;
            if(senior_class_valid) result_ticks<=12500000;
            else if(result_ticks!=0) result_ticks<=result_ticks-1'b1;
        end
    end
    // J8-36 reports a mismatch in the six QSPI model-section signatures.
    // J8-29 reports that all six signatures were read; J8-28 reports that
    // all six CNN stages completed.  These are stable after a result and
    // distinguish a weight-image fault from an input/preprocessing fault.
    // J8-34 = ddr_init_done, J8-35 = DDR PLL lock.  Both live in the
    // ddr_core_clk domain and are asynchronous to sys_clk, so a 2-FF
    // synchronizer removes metastability before the pin drives.  The ES8311
    // MCLK PLL lock is diagnostic-only and is intentionally not on a J8 pin.
    reg [1:0] ddr_init_done_sync=0, ddr_lock_sync=0;
    always @(posedge sys_clk or negedge run_rst_n)
        if (!run_rst_n) begin
            ddr_init_done_sync <= 2'd0;
            ddr_lock_sync <= 2'd0;
        end else begin
            ddr_init_done_sync <= {ddr_init_done_sync[0], ddr_init_done};
            ddr_lock_sync <= {ddr_lock_sync[0], ddr_pll_lock};
        end
    // Bits 2..22 already constrain the free J8 GPIOs.  Note the final pair:
    // bit22=physical pin35 (AB4), bit21=physical pin36 (AA4).
    wire [20:0] j8_diagnostics = {
        ddr_lock_sync[1], cnn_diag_status[7], ddr_init_done_sync[1], diag_logmel_changed,
        result_feature_midrange, diag_logmel_positive,
        diag_logmel_midrange, cnn_diag_status[6], cnn_diag_status[5],
        result_feature_changed, result_feature_complete,
        last_class_id[2], last_class_id[1], last_class_id[0],
        cnn_result_seen, cnn_compute_seen, cry_audio_present,
        (pcm_alive_ticks!=0),
        ((bclk_alive_ticks!=0)&&(lrck_alive_ticks!=0)),
        codec_init_error, codec_init_done};
    assign test_status_o={codec_init_error,
                          (control_led_flash_ticks!=0), (result_ticks!=0), cnn_compute_busy,
                          cry_audio_present, (pcm_alive_ticks!=0),
                          ((bclk_alive_ticks!=0)&&(lrck_alive_ticks!=0)),
                          (codec_init_error ? heartbeat : codec_init_done), heartbeat,
                          j8_diagnostics, sw_test_status[1:0]};
    // test_status capture: a full-word RAM-window write to 0x1000fff0 is
    // observed on the s1 AXI channel.  s1 is driven by adapter1, so this is
    // live hardware status—not a test-only or unconnected signal.
    always @(posedge sys_clk)
        if(ad1_awvalid && ad1_awready && ad1_wvalid && ad1_wready &&
           ad1_awaddr==32'h1000fff0 && ad1_wstrb==4'hf)
            sw_test_status<=ad1_wdata;
endmodule

// ES8311 register writer. Each 3-byte transaction is independently framed
// START/address/register/data/ACK/STOP. SDA is open-drain and ACK is sampled
// after each transmitted byte. A cold Flash boot can finish before the codec
// supply is ready, so failed transactions are retried after a power-up delay.
module es8311_i2c_init #(
    parameter integer CLOCK_HZ=50000000,
    parameter integer I2C_HZ=100000,
    parameter integer STARTUP_WAIT_MS=100,
    parameter integer RETRY_WAIT_MS=500
)(input wire clk, output reg scl_o=1'b1, inout wire sda_io,
  output reg done_o=1'b0, output reg error_o=1'b0);
    localparam integer HALF_PERIOD=CLOCK_HZ/(2*I2C_HZ);
    // power_count advances once per I2C half-period tick, not each clk.
    localparam integer TICKS_PER_MS=CLOCK_HZ/(1000*HALF_PERIOD);
    localparam integer POWER_WAIT=TICKS_PER_MS*STARTUP_WAIT_MS;
    localparam integer RETRY_WAIT=TICKS_PER_MS*RETRY_WAIT_MS;
    localparam [3:0] WAIT_POWER=0, START=1, BIT_LOW=2, BIT_HIGH=3,
                     ACK_LOW=4, ACK_HIGH=5, STOP_LOW=6, STOP_HIGH=7,
                     STOP_RELEASE=8, GAP=9, FINISHED=10, FAILED=11;
    reg [15:0] div_count=0;
    reg [19:0] power_count=0;
    reg [12:0] gap_count=0;
    reg [3:0] state=WAIT_POWER;
    reg [4:0] reg_index=0;
    reg [1:0] byte_index=0;
    reg [2:0] bit_index=7;
    reg [7:0] shift_byte=0;
    reg sda_low=0;
    reg nack_pending=0;
    reg [1:0] retry_count=0;
    wire [7:0] reg_addr, reg_data;
    wire [7:0] tx_byte=(byte_index==0) ? 8'h30 :
                       (byte_index==1) ? reg_addr : reg_data;
    assign sda_io=sda_low ? 1'b0 : 1'bz;

    // ES8311 ADC startup and 16-bit I2S.  MCLK/4 gives BCLK and MCLK/256
    // gives LRCK (64 BCLKs per stereo frame).  With this board's 12.288136-MHz
    // MCLK, LRCK is 48.0005 kHz; the /3 decimator yields 16.00018 kHz.
    function [7:0] addr_at; input [4:0] n; begin case(n)
         0, 1: addr_at=8'h44;  2:addr_at=8'h01;  3:addr_at=8'h02;
         4:addr_at=8'h03;       5:addr_at=8'h16;  6:addr_at=8'h04;
         7:addr_at=8'h05;       8:addr_at=8'h0B;  9:addr_at=8'h0C;
        10:addr_at=8'h10;      11:addr_at=8'h11; 12:addr_at=8'h00;
        13:addr_at=8'h01;      14:addr_at=8'h06; 15:addr_at=8'h07;
        16:addr_at=8'h08;      17:addr_at=8'h09; 18:addr_at=8'h0A;
        19:addr_at=8'h17;      20:addr_at=8'h0E; 21:addr_at=8'h14;
        22:addr_at=8'h0D;      23:addr_at=8'h15; 24:addr_at=8'h13;
        25:addr_at=8'h1B;      26:addr_at=8'h1C; 27:addr_at=8'h44;
        default:addr_at=8'h00;
    endcase end endfunction
    function [7:0] data_at; input [4:0] n; begin case(n)
         0, 1: data_at=8'h08;  2:data_at=8'h30;  3:data_at=8'h00;
         4:data_at=8'h10;      5:data_at=8'h24;  6:data_at=8'h10;
         7:data_at=8'h00;      8:data_at=8'h00;  9:data_at=8'h00;
        10:data_at=8'h1F;     11:data_at=8'h7F; 12:data_at=8'hC0;
        13:data_at=8'h3F;     14:data_at=8'h03; 15:data_at=8'h00;
        16:data_at=8'hFF;     17:data_at=8'h0C; 18:data_at=8'h0C;
        19:data_at=8'hBF;     20:data_at=8'h02; 21:data_at=8'h1A;
        22:data_at=8'h01;     23:data_at=8'h40; 24:data_at=8'h10;
        25:data_at=8'h0A;     26:data_at=8'h6A; 27:data_at=8'h08;
        default:data_at=8'h00;
    endcase end endfunction
    assign reg_addr=addr_at(reg_index);
    assign reg_data=data_at(reg_index);

    always @(posedge clk) begin
        if(div_count==HALF_PERIOD-1) begin
            div_count<=0;
            case(state)
                WAIT_POWER: begin
                    scl_o<=1'b1; sda_low<=1'b0;
                    if(power_count==((error_o ? RETRY_WAIT : POWER_WAIT)-1)) begin
                        state<=START;power_count<=0;
                    end
                    else power_count<=power_count+1'b1;
                end
                START: begin scl_o<=1'b1;sda_low<=1'b1;byte_index<=0;bit_index<=7;shift_byte<=8'h30;state<=BIT_LOW;end
                BIT_LOW: begin scl_o<=1'b0;sda_low<=~shift_byte[7];state<=BIT_HIGH;end
                BIT_HIGH: begin
                    scl_o<=1'b1;
                    if(bit_index==0) state<=ACK_LOW;
                    else begin bit_index<=bit_index-1'b1;shift_byte<={shift_byte[6:0],1'b0};state<=BIT_LOW;end
                end
                ACK_LOW: begin scl_o<=1'b0;sda_low<=1'b0;state<=ACK_HIGH;end
                ACK_HIGH: begin
                    scl_o<=1'b1;
                    if(sda_io!==1'b0) begin nack_pending<=1'b1;state<=STOP_LOW;end
                    else if(byte_index==2) state<=STOP_LOW;
                    else begin byte_index<=byte_index+1'b1;bit_index<=7;shift_byte<=(byte_index==0)?reg_addr:reg_data;state<=BIT_LOW;end
                end
                STOP_LOW: begin scl_o<=1'b0;sda_low<=1'b1;state<=STOP_HIGH;end
                STOP_HIGH: begin scl_o<=1'b1;sda_low<=1'b1;state<=STOP_RELEASE;end
                STOP_RELEASE: begin scl_o<=1'b1;sda_low<=1'b0;gap_count<=0;state<=GAP;end
                GAP: begin
                    if(gap_count==((reg_index==12)?13'd5000:13'd100)) begin
                        if(nack_pending) begin
                            if(retry_count<2) begin
                                retry_count<=retry_count+1'b1;
                                nack_pending<=1'b0;state<=START;
                            end else begin
                                // Restart the whole register sequence: some
                                // earlier writes may already have succeeded.
                                error_o<=1'b1;
                                retry_count<=0;
                                nack_pending<=1'b0;
                                reg_index<=0;
                                power_count<=0;
                                state<=WAIT_POWER;
                            end
                        end else begin
                            retry_count<=0;
                            if(reg_index==27) begin
                                done_o<=1'b1;error_o<=1'b0;state<=FINISHED;
                            end
                            else begin reg_index<=reg_index+1'b1;state<=START;end
                        end
                    end else gap_count<=gap_count+1'b1;
                end
                FINISHED: begin scl_o<=1'b1;sda_low<=1'b0;end
                FAILED: begin scl_o<=1'b1;sda_low<=1'b0;end
                default: state<=FAILED;
            endcase
        end else div_count<=div_count+1'b1;
    end
endmodule
