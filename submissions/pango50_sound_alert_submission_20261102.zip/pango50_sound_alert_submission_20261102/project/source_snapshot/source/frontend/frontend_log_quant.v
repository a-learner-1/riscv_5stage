// frontend_log_quant.v  -- pipe10 (200 MHz) variant
// V1 audio frontend stage 5: log -> normalize -> quantize to int8 x0.
// Matches ref_model.to_x0 bit-exactly:
//   U = E + EPS (EPS=343597, Q35 of 1e-5)
//   e = flog2(U); mant = (U >> (e-8)) & 0xFF        (e>=8)
//   t = e*LN2_Q16 + LOG_LUT[mant] - C_Q16            (Q16; LN2_Q16=45426, C_Q16=1295001)
//   x0 = clip(rnd32(t * K_Q16), -128, 127)           (K_Q16=692421)
//
// pipe10 change (vs pipe8):
//   pipe8 packed the whole 3-step leading-one search (shift by 32/16/8) and the
//   64-bit remainder shift into ONE cycle: 11 LUT levels, 8.58 ns of data delay
//   at the PGL50H slow corner -> the worst core200 path in the integrated build
//   (u_audio/u_frontend/u_log, slack -3.901 ns against a 5 ns clock).
//   pipe10 gives each binary-search step its own pipeline stage and resolves the
//   last four exponent bits with a parallel nibble encoder instead of four more
//   compare/shift steps. Arithmetic is unchanged: every stage performs exactly
//   the compare-and-shift the original search performed, only truncating bits
//   that are provably zero after the shift, and the mantissa is still selected
//   from the ORIGINAL U with the full exponent, so results are bit-identical for
//   every input (verified in tb_log_quant_pipe10 against the pipe8 module,
//   including the e<8 left-shift corner).
//   Depth per stage drops from 11 levels to 3-5; latency grows 6 -> 8 cycles.
//   Streaming (E_valid -> x0_valid) and the 128-band done pulse are unchanged.

module frontend_log_quant #(
    parameter W_E   = 63,
    parameter W_X0  = 8
)(
    input  wire                clk,
    input  wire                rst_n,
    input  wire                start,
    input  wire signed [W_E-1:0]   E_in,
    input  wire                E_valid,
    output reg  signed [W_X0-1:0]  x0_out,
    output reg                 x0_valid,
    output reg                 done
);

    localparam EPS    = 343597;      // 1e-5 * 2^35
    localparam LN2_Q16 = 45426;
    localparam C_Q16   = 1295001;
    localparam K_Q16   = 692421;

    reg [15:0] log_lut [0:255];
    initial begin
        $readmemh("rom/log_lut.mem", log_lut);
    end

    // ---- pipeline registers ----
    reg signed [W_E-1:0]  uA;      // A : U = E + EPS
    reg                   vA;
    reg [31:0]            r32;     // B1: U >> 32 (or U), low 32 bits
    reg [5:0]             e32;     // B1: 32 when that shift happened
    reg signed [W_E-1:0]  uB1;     // original U carried for the mantissa select
    reg                   vB1;
    reg [15:0]            r16;     // B2: r32 >> 16 (or r32), low 16 bits
    reg [5:0]             e48;     // B2: e32 + 16 when that shift happened
    reg signed [W_E-1:0]  uB2;
    reg                   vB2;
    reg [5:0]             eB;      // B3: full exponent e
    reg signed [W_E-1:0]  uB3;
    reg                   vB3;
    reg [7:0]             mantB;   // B4: mantissa from uB3 with eB
    reg [5:0]             eC;      // B4 latches the exponent for stage C
    reg signed [21:0]     eCmul;   // B4 also pre-computes e*LN2 so stage C is a pure adder
    reg                   vB;
    (* keep *) reg signed [21:0]     tC;  // keep: without this the tool folds the
                                        // stage-C adder into the stage-D multiplier
                                        // inputs, making eCmul(APM)->APM one 6-level
                                        // path (worst log cone). Keeping tC splits it.
    reg                   vC;
    reg signed [41:0]     prodD;
    // stage D is split in two so no 42-bit constant multiply sits in one 5 ns
    // cycle: the 20-bit constant is halved, both partial products are
    // registered and the shift-add lands one cycle later.  Exact integer
    // arithmetic, only the latency grows.
    localparam integer K_LO = 692421 & 1023;         // low 10 bits
    localparam integer K_HI = 692421 >> 10;          // high bits
    reg signed [41:0]     ppD_lo, ppD_hi;
    reg                   vD1a;   // tC * K_Q16 (Q16*Q16 -> 42 bit)
    reg                   vD1;
    reg signed [W_X0-1:0] x0D;
    reg                   vD;

    reg [7:0]  done_band;    // counts completed bands at stage D2 (0..128)

    // 2-bit leading-one index of a nibble: 0..3, 0 for n==0.
    // A single LUT level per output bit.
    function [1:0] idx4;
        input [3:0] n;
        begin
            idx4[1] = n[3] | n[2];
            idx4[0] = n[3] | (~n[2] & n[1]);
        end
    endfunction

    // 4-bit leading-one index of a 16-bit value (0..15, 0 when zero):
    // nibble-valid vector + 4:1 select. Equals the four remaining binary-search
    // steps of the pipe8 design, in three LUT levels instead of eight.
    wire [3:0] nibv = {|r16[15:12], |r16[11:8], |r16[7:4], |r16[3:0]};
    wire [3:0] e16  = nibv[3] ? (4'd12 + {2'b00, idx4(r16[15:12])}) :
                      nibv[2] ? (4'd8  + {2'b00, idx4(r16[11:8])})  :
                      nibv[1] ? (4'd4  + {2'b00, idx4(r16[7:4])})   :
                                {2'b00, idx4(r16[3:0])};

    // round-half-away(x>>32), 42-bit -> signed
    function automatic signed [8:0] rnd32;
        input signed [41:0] x;
        begin
            if (x >= 0)
                rnd32 = (x + 42'sd2147483648) >>> 32;
            else
                rnd32 = -(((-x) + 42'sd2147483648) >>> 32);
        end
    endfunction

    // clip to [-128,127]
    function automatic signed [W_X0-1:0] clip8;
        input signed [8:0] x;
        begin
            if (x > 127)      clip8 = 8'sd127;
            else if (x < -128) clip8 = -8'sd128;
            else               clip8 = x[7:0];
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            uA <= {W_E{1'b0}};   vA <= 1'b0;
            r32 <= 32'd0; e32 <= 6'd0; uB1 <= {W_E{1'b0}}; vB1 <= 1'b0;
            r16 <= 16'd0; e48 <= 6'd0; uB2 <= {W_E{1'b0}}; vB2 <= 1'b0;
            eB  <= 6'd0;  uB3 <= {W_E{1'b0}}; vB3 <= 1'b0;
            mantB <= 8'd0; eC <= 6'd0; vB <= 1'b0;
            eCmul <= 22'sd0;
            tC <= 22'sd0;        vC <= 1'b0;
            prodD <= 42'sd0;     vD1 <= 1'b0;
            ppD_lo <= 42'sd0;    ppD_hi <= 42'sd0;   vD1a <= 1'b0;
            x0D <= {W_X0{1'b0}}; vD <= 1'b0;
            x0_out <= {W_X0{1'b0}}; x0_valid <= 1'b0;
            done_band <= 8'd0; done <= 1'b0;
        end else begin
            x0_valid <= 1'b0;
            done <= 1'b0;

            // stage A: consume input
            if (E_valid) begin
                uA <= E_in + EPS;
                vA <= 1'b1;
            end else begin
                vA <= 1'b0;
            end

            // stage B1: search step 1 -- shift by 32 if any of bits 62..32
            if (vA) begin
                e32 <= (|uA[62:32]) ? 6'd32 : 6'd0;
                r32 <= (|uA[62:32]) ? {1'b0, uA[62:32]} : uA[31:0];
                uB1 <= uA;
                vB1 <= 1'b1;
            end else begin
                vB1 <= 1'b0;
            end

            // stage B2: search step 2 -- shift by 16 if any of bits 31..16
            if (vB1) begin
                e48 <= e32 + ((|r32[31:16]) ? 6'd16 : 6'd0);
                r16 <= (|r32[31:16]) ? r32[31:16] : r32[15:0];
                uB2 <= uB1;
                vB2 <= 1'b1;
            end else begin
                vB2 <= 1'b0;
            end

            // stage B3: last four exponent bits from the nibble encoder.
            // e = 32/16 base + leading-one index of r16, identical to
            // flog2_hi6 + flog2_lo3 (the shift-by-8 step plus 4/2/1 steps).
            if (vB2) begin
                eB  <= e48 + {2'b00, e16};
                uB3 <= uB2;
                vB3 <= 1'b1;
            end else begin
                vB3 <= 1'b0;
            end

            // stage B4: mantissa from the ORIGINAL U with the full exponent
            if (vB3) begin
                mantB <= (eB >= 8) ? uB3[eB-1 -: 8]
                                   : ((uB3 << (8 - eB)) & 8'hFF);
                eC <= eB;
                eCmul <= $signed({1'b0, eB}) * $signed({1'b0, LN2_Q16});
                vB <= 1'b1;
            end else begin
                vB <= 1'b0;
            end

            // stage C
            if (vB) begin
                tC <= eCmul
                      + $signed({1'b0, log_lut[mantB]}) - 22'sd1295001;
                vC <= 1'b1;
            end else begin
                vC <= 1'b0;
            end

            // stage D1: partial products of the halved constant
            if (vC) begin
                ppD_lo <= tC * K_LO;
                ppD_hi <= tC * K_HI;
                vD1a <= 1'b1;
            end else begin
                vD1a <= 1'b0;
            end

            // stage D2: shift-add, then the valid continues as before
            prodD <= (ppD_hi <<< 10) + ppD_lo;
            vD1   <= vD1a;

            // stage D2: round-half-away, clip and emit
            if (vD1) begin
                x0D <= clip8(rnd32(prodD));
                vD <= 1'b1;
                done_band <= done_band + 8'd1;
            end else begin
                vD <= 1'b0;
            end

            if (vD) begin
                x0_out <= x0D;
                x0_valid <= 1'b1;
                if (done_band == 128) begin
                    done <= 1'b1;
                    done_band <= 8'd0;
                end
            end
        end
    end

endmodule