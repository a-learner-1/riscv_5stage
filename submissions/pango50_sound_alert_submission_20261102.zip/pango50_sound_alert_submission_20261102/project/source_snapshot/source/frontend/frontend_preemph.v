// frontend_preemph.v
// V1 audio frontend stage 1: p[n] = x[n] - round(0.97*32768 * x[n-1] >> 15)
// Streaming, 2-cycle latency, p[0] = x[0].  Rounding = round-half-away.
// A_PRE = 31785 (Q15 of 0.97).  |p| <= 64553 -> 17-bit signed out.
// p_valid pulses together with p_out.
//
// 200 MHz retime: the 16x15 constant multiply, the rounding add and the
// 17-bit subtract used to share one 5 ns clock.  x_prev is a plain delay of
// the input (no feedback), so the product can be registered without changing
// any sample value; only the pipeline latency grows from 1 to 2 cycles.
// p_out/p_valid stay paired, which is all the framing stage consumes.

module frontend_preemph #(
    parameter W_IN  = 16,
    parameter W_OUT = 17
)(
    input  wire                clk,
    input  wire                rst_n,
    input  wire                en,           // sample valid
    input  wire signed [W_IN-1:0]  s_in,     // PCM sample
    output reg  signed [W_OUT-1:0] p_out,    // preemphasized sample
    output reg                 p_valid
);

    localparam A_PRE = 31785;

    reg signed [W_IN-1:0] x_prev;

    // stage A: product of the previous sample with the constant coefficient
    reg  signed [30:0] prod_r;
    reg  signed [16:0] s17_r;
    reg                valid_a_r;

    wire signed [30:0] prod_w = x_prev * A_PRE;                 // 16x15-bit
    // explicit signed 17-bit operand (avoid mixed-sign unsigned promotion)
    wire signed [16:0] s17 = {{(17-W_IN){s_in[W_IN-1]}}, s_in};

    // stage B: round the registered product and subtract
    wire signed [15:0] rnd_w  = (prod_r >= 0)
        ? (prod_r + 16'sd16384) >>> 15
        : -(((-prod_r) + 16'sd16384) >>> 15);
    wire signed [16:0] r17 = {{2{rnd_w[15]}}, rnd_w};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_prev    <= {W_IN{1'b0}};
            prod_r    <= 31'sd0;
            s17_r     <= 17'sd0;
            valid_a_r <= 1'b0;
        end else if (en) begin
            x_prev    <= s_in;
            prod_r    <= prod_w;
            s17_r     <= s17;
            valid_a_r <= 1'b1;
        end else begin
            valid_a_r <= 1'b0;
        end
    end

    // stage B: round the registered product (the rounding add plus the
    // sign-negate chain was still the preemph critical path), then stage C
    // subtracts.  p_out/p_valid stay paired, so the extra cycle is transparent
    // to the framing stage.
    reg signed [15:0] rnd_r;
    reg signed [16:0] s17_d;
    reg               valid_b_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rnd_r <= 16'sd0; s17_d <= 17'sd0; valid_b_r <= 1'b0;
        end else begin
            rnd_r <= rnd_w; s17_d <= s17_r; valid_b_r <= valid_a_r;
        end
    end

    wire signed [16:0] r17_d = {{2{rnd_r[15]}}, rnd_r};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p_out   <= {W_OUT{1'b0}};
            p_valid <= 1'b0;
        end else begin
            p_valid <= valid_b_r;
            if (valid_b_r) p_out <= s17_d - r17_d;
        end
    end

endmodule
