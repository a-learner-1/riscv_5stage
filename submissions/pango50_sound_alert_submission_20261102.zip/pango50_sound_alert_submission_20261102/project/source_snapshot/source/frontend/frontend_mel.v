// frontend_mel.v
// V1 audio frontend stage 4: 128-band mel filterbank (kaldi, fmin=0, fmax=15000,
// n_fft=1024 -> 513 power bins; Nyquist column always 0).  Sparse coefficients:
// E_full[m] = sum_b power_q[b] * coeff_q[m,b],  coeff_q = round(coeff*32767).
// E_full = E_float * 2^35 (power_q = |X|^2*2^20, coeff_q ~2^15).
//
// Consumes 513 power bins (43-bit signed, serial with power_in_valid),
// emits 128 band energies (63-bit signed, mel_valid) then done.
// ROMs: mel_bin.mem (948x10), mel_coeff.mem (948x16), mel_start.mem (128x13),
//       mel_count.mem (128x5).
//
// Pipeline:
//   e_idx -> (coeff_r, bin_r)                 [stage 1]
//   pow_ram[bin_r], coeff_r -> (pow_r, coeff_d_r) [stage 2]
//   coeff_d_r * pow_r -> partial products      [stage 3]
//   partial sum -> prod_r                      [stage 4]
//   acc += prod_r                              [stage 5]
//
// 200 MHz retime: stage 3 used to be a single 16x43 signed multiply feeding a
// 59-bit product.  That one multiplier is the worst path of the frontend
// (measured 13.2 ns, 10 levels).  The operand is now split into two exact
// parts, pow = hi*2^22 + lo (hi = arithmetic upper 21 bits, lo = raw lower 22
// bits), so prod = coeff*hi*2^22 + coeff*lo with two 16x23 multiplies that can
// be registered separately and summed one cycle later.  The arithmetic is
// bit-exact integer arithmetic (no rounding, no re-ordering of the band
// accumulation), so band energies are unchanged; only the latency grows by one
// cycle, which the drain counter below accounts for.

module frontend_mel #(
    parameter W_POW = 43,
    parameter W_E   = 63
)(
    input  wire                clk,
    input  wire                rst_n,
    input  wire                start,
    input  wire signed [W_POW-1:0] power_in,
    input  wire                power_in_valid,
    output reg  signed [W_E-1:0]   mel_out,
    output reg                 mel_valid,
    output reg                 done
);

    // ---- ROMs ----
    reg [9:0]  mel_bin_rom  [0:947];
    reg [15:0] mel_coeff_rom[0:947];
    reg [12:0] mel_start_rom[0:127];
    reg [4:0]  mel_count_rom[0:127];
    initial begin
        $readmemh("rom/mel_bin.mem",   mel_bin_rom);
        $readmemh("rom/mel_coeff.mem", mel_coeff_rom);
        $readmemh("rom/mel_start.mem", mel_start_rom);
        $readmemh("rom/mel_count.mem", mel_count_rom);
    end

    // ---- power RAM (513 bins, async read) ----
    // PDS mapped this 513x43 array into distributed RAM, and the async read mux
    // (4.9 ns for one logic level) became the mel critical path.  Force block
    // RAM: the read result already lands in pow_r one cycle later, so the BRAM
    // output register replaces the fabric register and the latency is unchanged.
    reg [9:0] p_cnt;         // write pointer 0..512
    reg [9:0] bin_r;         // stage 1 index, used by the BRAM read below
    // Block RAM only takes legal widths
    // array is not one of them, so PDS silently fell back to distributed RAM
    // for every ram_style spelling we tried.  Splitting the word into 36+7
    // legal pieces lets each array infer its own block RAM.
    reg [35:0] pow_lo_ram [0:512];
    reg [6:0]  pow_hi_ram [0:512];
    reg signed [W_POW-1:0] pow_d;
    always @(posedge clk) begin
        if (power_in_valid) begin
            pow_lo_ram[p_cnt] <= power_in[35:0];
            pow_hi_ram[p_cnt] <= power_in[42:36];
        end
        pow_d <= {pow_hi_ram[bin_r], pow_lo_ram[bin_r]};
    end

    // ---- FSM ----
    localparam S_LOAD = 3'd0, S_MEL = 3'd1, S_DONE = 3'd2, S_DRAIN = 3'd3;
    reg [2:0] state;
    reg [6:0] band;          // 0..127
    reg [4:0] e_cnt;         // 0..count-1 within band (count can be up to 24)
    reg signed [W_E-1:0] acc;

    // pipeline registers
    reg signed [15:0] coeff_r;   // stage 1: mel_coeff_rom[e_idx]
    reg signed [15:0] coeff_d_r; // stage 2: registered coefficient
    reg signed [15:0] coeff_e_r; // stage 3: realigned with pow_r
    (* keep *) reg signed [W_POW-1:0] pow_r; // stage 3: registered power bin
    // limb products: 16x12 or 16x11 signed -> at most 28 bits
    reg signed [27:0] pw_lo_lo;   // stage 4: coeff_e_r * pow_lo[10:0]
    reg signed [27:0] pw_lo_hi;   // stage 4: coeff_e_r * pow_lo[21:11]
    reg signed [27:0] pw_hi_lo;   // stage 4: coeff_e_r * pow_hi[9:0]
    reg signed [27:0] pw_hi_hi;   // stage 4: coeff_e_r * pow_hi[20:10]
    // stage 4b: two narrow half-products, then stage 5 joins them.  Keeping the
    // two halves in their natural widths (39b / 37b) instead of widening every
    // intermediate to 63 bits cuts the carry chain from a 3-adder 63-bit tree
    // to 2 narrow adds plus a single wide add.
    reg signed [38:0] pp_lo_r;    // stage 4b: coeff_e_r * pow_lo (<= 2^37)
    reg signed [36:0] pp_hi_r;    // stage 4b: coeff_e_r * pow_hi (<= 2^35)
    reg signed [W_E-1:0] prod_r;  // stage 5: exact limb-combined product
    reg        v1, v2, v3, v4, v5, v6;
    reg [2:0]  drain_r;

    wire [4:0]  cnt   = mel_count_rom[band];
    wire [12:0] e_idx = mel_start_rom[band] + {{8{1'b0}}, e_cnt};

    // exact split: pow = hi*2^22 + lo, lo is the raw low 22 bits (0..2^22-1),
    // hi is the arithmetic (signed) upper part.
    wire signed [22:0] pow_lo = {1'b0, pow_r[21:0]};          // 0..4194303
    wire signed [20:0] pow_hi = pow_r[W_POW-1:22];            // signed 21 bits

    // stage-3b: split each wide operand into limbs so every partial product fits
    // a single APM (no 2x cascade).  pow_lo is unsigned (0..2^22-1); pow_hi is
    // signed 21-bit.  Each limb is carried as a NON-NEGATIVE signed value:
    // pow_lo[10:0] and pow_lo[21:11] are 0..2047, so the signed container must
    // be 12 bits wide (11 bits would turn 2047 into -1); pow_hi[9:0] is 0..1023
    // so 11 bits suffice, while pow_hi[20:10] is genuinely signed.
    wire signed [11:0] loA = {1'b0, pow_r[10:0]};        // pow_lo[10:0], 0..2047
    wire signed [11:0] loB = {1'b0, pow_r[21:11]};       // pow_lo[21:11], 0..2047
    wire signed [10:0] hiA = {1'b0, pow_r[31:22]};       // pow_hi[9:0], 0..1023
    wire signed [10:0] hiB = pow_r[42:32];               // pow_hi[20:10] signed

    // stage 4b assembly: sign-extend each 28-bit limb product into the natural
    // width of its half-product *before* shifting (a shift keeps its operand
    // width, so shifting a narrow value would silently drop the high bits).
    wire signed [38:0] pll_x = {{(39-28){pw_lo_lo[27]}}, pw_lo_lo};
    wire signed [38:0] plh_x = {{(39-28){pw_lo_hi[27]}}, pw_lo_hi};
    wire signed [36:0] phl_x = {{(37-28){pw_hi_lo[27]}}, pw_hi_lo};
    wire signed [36:0] phh_x = {{(37-28){pw_hi_hi[27]}}, pw_hi_hi};
    wire signed [38:0] pp_lo_w = (plh_x <<< 11) + pll_x;   // == coeff*pow_lo
    wire signed [36:0] pp_hi_w = (phh_x <<< 10) + phl_x;   // == coeff*pow_hi

    // stage 5 assembly: join the two half-products into the exact product.
    wire signed [W_E-1:0] pph_x = {{(W_E-37){pp_hi_r[36]}}, pp_hi_r};
    wire signed [W_E-1:0] ppl_x = {{(W_E-39){pp_lo_r[38]}}, pp_lo_r};
    wire signed [W_E-1:0] prod_w = (pph_x <<< 22) + ppl_x;  // == coeff*pow_r

    // (pow_r is loaded from the block RAM output inside the pipeline below)

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_LOAD;
            p_cnt <= 10'd0;
            band <= 7'd0;
            e_cnt <= 5'd0;
            acc <= {W_E{1'b0}};
            coeff_r <= 16'd0;
            bin_r <= 10'd0;
            coeff_d_r <= 16'd0;
            coeff_e_r <= 16'd0;
            pw_lo_lo <= 28'sd0; pw_lo_hi <= 28'sd0;
            pw_hi_lo <= 28'sd0; pw_hi_hi <= 28'sd0;
            pp_lo_r <= 39'sd0;
            pp_hi_r <= 37'sd0;
            prod_r <= {W_E{1'b0}};
            v1 <= 1'b0; v2 <= 1'b0; v3 <= 1'b0; v4 <= 1'b0; v5 <= 1'b0; v6 <= 1'b0;
            drain_r <= 3'd0;
            mel_out <= {W_E{1'b0}};
            mel_valid <= 1'b0;
            done <= 1'b0;
        end else begin
            mel_valid <= 1'b0;
            done <= 1'b0;

            // pipeline: latch every cycle; valid bits gate real terms.
            v1      <= (state == S_MEL);
            coeff_r <= mel_coeff_rom[e_idx];
            bin_r   <= mel_bin_rom[e_idx];
            v2      <= v1;
            coeff_d_r <= coeff_r;

            v3      <= v2;
            coeff_e_r <= coeff_d_r;
            pow_r   <= pow_d;
            // stage 4: four single-APM limb products (16 x 12 / 16 x 11 signed)
            v4      <= v3;
            pw_lo_lo <= coeff_e_r * loA;
            pw_lo_hi <= coeff_e_r * loB;
            pw_hi_lo <= coeff_e_r * hiA;
            pw_hi_hi <= coeff_e_r * hiB;
            // stage 4b: two narrow half-products (registered, short adds)
            v5      <= v4;
            pp_lo_r <= pp_lo_w;
            pp_hi_r <= pp_hi_w;
            // stage 5: join halves into the exact product; acc is gated on v6
            v6      <= v5;
            prod_r  <= prod_w;

            case (state)
                S_LOAD: begin
                    if (power_in_valid) begin
                        if (p_cnt == 512) begin
                            state <= S_MEL;
                            band <= 7'd0;
                            e_cnt <= 5'd0;
                            acc <= {W_E{1'b0}};
                        end
                        p_cnt <= p_cnt + 10'd1;
                    end
                end
                S_MEL: begin
                    acc <= acc + (v6 ? prod_r : {W_E{1'b0}});
                    if (e_cnt == cnt - 5'd1) begin
                        // last term issued; drain the 6 remaining stages then emit
                        state <= S_DRAIN;
                        drain_r <= 3'd0;
                    end else begin
                        e_cnt <= e_cnt + 5'd1;
                    end
                end
                S_DRAIN: begin
                    if (drain_r == 3'd6) begin
                        // acc now holds the full band sum (v6 has dropped to 0)
                        mel_out <= acc;
                        mel_valid <= 1'b1;
                        if (band == 127) begin
                            state <= S_DONE;
                            done <= 1'b1;
                        end else begin
                            band <= band + 7'd1;
                            e_cnt <= 5'd0;
                            acc <= {W_E{1'b0}};
                            state <= S_MEL;
                        end
                    end else begin
                        acc <= acc + (v6 ? prod_r : {W_E{1'b0}});
                        drain_r <= drain_r + 3'd1;
                    end
                end
                S_DONE: begin
                    state <= S_LOAD;
                    p_cnt <= 10'd0;
                end
            endcase
        end
    end

endmodule
