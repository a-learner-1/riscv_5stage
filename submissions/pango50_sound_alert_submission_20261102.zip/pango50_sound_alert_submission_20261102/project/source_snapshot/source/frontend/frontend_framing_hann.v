// frontend_framing_hann.v
// V1 audio frontend stage 2: frame extraction + centered Hann window.
// For frame k: wnd[m] = y[reflect(base+m)] * hann_q15[m-112] (>>15, rnd) for
//   m in [112,912), else 0.  base = k*320 - 512 (torch.stft center=True, win
//   centered with WIN_OFF=112).  y[s] = p[s+1] (preemph out len N-1), reflect.
// Hann periodic=False.
//
// GATE5: STREAMING sliding-window redesign.  The 320000x17 on-chip p_ram is
// GONE (was 5.44 Mb, 2.25x the device DRM total).  The module now accepts
// preemph samples serially (pcm_valid/pcm_in, gated by pcm_ready) and keeps
// only a 1024-sample circular buffer (~1 DRM).  Frames are emitted
// automatically: frame k fires when sample count reaches
//   trig(k) = min(k*HOP + 513, P_DEPTH)
// (i.e. when the right edge k*HOP+512 of the FFT frame has arrived), and the
// buffer then holds exactly the 1024 samples [k*HOP-511 .. k*HOP+512] that
// the frame's reflect-mapped taps need.  Left/right reflect at the signal
// edges folds back into this window (edges only ~400 samples beyond a
// frame's center), so no extra edge buffer is required.  One in-flight sample
// (fed by the producer in the cycle before the trigger) is accepted at
// RUN cycle 0; it only perturbs the far-left zeroed taps.
//
// Pipeline (sync-read buffer, so +1 cycle vs the old async design):
//   run_cnt=m: issue buf read for tap m;          (m in [0,1024))
//   run_cnt=m+1: data for tap m arrives in p_buf_q;
//   run_cnt=m+2: capture hann(m), p(m);
//   run_cnt=m+3: register hann(m)*p(m);
//   run_cnt=m+4: emit wnd(m) = rnd15(registered product).
//   done pulses after each frame (1024 wnd samples).
//
// CONTINUOUS=1 (sliding-window mode): never halts at MAX_FRAMES; frame_idx_o
// wraps mod MAX_FRAMES and the absolute counter abs_frame drives trigger/base,
// so 5s/10s sliding windows can run on a continuously arriving stream.

module frontend_framing_hann #(
    parameter P_DEPTH    = 320000,
    parameter P_AW       = 19,          // 2^19 = 524288 >= 320000
    parameter W_IN       = 17,          // preemph sample width
    parameter WIN_OFF    = 112,
    parameter HOP        = 320,
    parameter NFFT       = 1024,
    parameter WIN_LEN    = 800,
    parameter MAX_FRAMES = 1000,
    // CONTINUOUS=1: run forever for a sliding-window feature stream.  The
    // module never enters ST_HALT; frame_idx_o wraps mod MAX_FRAMES so the
    // downstream feature buffer treats MAX_FRAMES as the window depth.  The
    // trigger and frame base use a separate wide absolute counter (abs_frame)
    // so they keep advancing past MAX_FRAMES.  Wide counters bound continuous
    // run to ~18 h (abs_frame*HOP in signed 32-bit) before overflow; that is
    // fine for board acceptance, but a day-scale field deployment should
    // harden the tap address to pure mod-1024 arithmetic (see header).
    parameter CONTINUOUS = 0,
    parameter BUF_DEPTH  = 1024,
    parameter BUF_AW     = 10
)(
    input  wire                clk,
    input  wire                rst_n,

    // streaming preemph sample input (pcm_ready gated)
    input  wire                pcm_valid,
    input  wire signed [W_IN-1:0] pcm_in,
    output wire                pcm_ready,

    // windowed frame output (serial), one frame per start
    output reg  signed [W_IN-1:0] wnd_out,
    output reg                 wnd_valid,
    output reg  [9:0]          frame_idx_o,
    output reg                 done
);

    // ---- hann ROM (Q15, 0..32768, async read) ----
    // 800 x 16 = 12.8kbit.  PDS maps it to a block RAM whose output drives the
    // windowing APM through a route-dominated path; tried ram_style=distributed
    // (IGNORED by PDS - netlist checksum unchanged) so leave it unannotated.
    reg [15:0] hann_rom [0:WIN_LEN-1];
    initial begin
        $readmemh("rom/hann_q15.mem", hann_rom);
    end

    // ---- circular sample buffer (1R1W SDP, synchronous read) ----
    reg signed [W_IN-1:0] p_buf [0:BUF_DEPTH-1];
    reg        wr_buf;
    reg [BUF_AW-1:0] wr_idx;
    reg signed [W_IN-1:0] p_wr_data;   // pcm_in held from the accept cycle
    reg signed [W_IN-1:0] hold_sample; // 1st in-flight sample (arrives TRIG)
    reg                  hold_valid;
    reg signed [W_IN-1:0] hold_sample2; // 2nd in-flight sample (arrives RUN0)
    reg                  hold2_valid;
    reg        rd_en;
    reg [BUF_AW-1:0] rd_idx;
    reg signed [W_IN-1:0] p_buf_q;
    always @(posedge clk) begin
        if (wr_buf) p_buf[wr_idx] <= p_wr_data;
    end
    always @(posedge clk) begin
        if (rd_en) p_buf_q <= p_buf[rd_idx];
    end

    // ---- FSM ----
    localparam ST_IDLE = 3'd0, ST_RUN = 3'd1, ST_HALT = 3'd2, ST_TRIG = 3'd3;
    reg [2:0] state;
    reg [10:0] run_cnt;                 // 0..1026
    reg [31:0] samp_cnt;            // accepted preemph samples (wide, continuous)
    reg [9:0]  frames_done;         // frame slot index (wraps mod MAX_FRAMES)
    reg [31:0] abs_frame;           // absolute frame count (trigger/base source)
    reg [31:0] trig_reg;            // trigger sample count for next frame
    reg [31:0] trig_m1;   // trig_reg - 1: keeps the 32-bit adder off the base_reg CE path
    reg signed [31:0] base_reg;

    wire any_hold = hold_valid || hold2_valid;
    wire accept = pcm_valid && (state == ST_IDLE) && !any_hold;
    wire flush_hold = (state == ST_IDLE) && hold_valid;
    wire flush_hold2 = (state == ST_IDLE) && !hold_valid && hold2_valid;
    // Combinational ready: low while the frame is being emitted (TRIG/RUN) or
    // while held samples are still being flushed.  At the IDLE->TRIG boundary
    // the registered state lets the producer feed two samples across; they
    // arrive during TRIG (hold) and RUN run_cnt==0 (hold2) and are flushed
    // into their natural slots after the frame ends.
    wire capture_inflight = pcm_valid && (state == ST_TRIG);
    wire capture_inflight2 = pcm_valid && (state == ST_RUN) && (run_cnt == 11'd0);
    assign pcm_ready = (state == ST_IDLE) && !any_hold;

    // trigger for frame k: min(k*HOP + 513, P_DEPTH); CONTINUOUS drops the
    // finite-end cap because the stream never ends.
    function automatic [31:0] trig;
        input [31:0] k;
        reg [31:0] w;
        begin
            w = k * HOP + 513;
            trig = (CONTINUOUS || w <= P_DEPTH) ? w : P_DEPTH;
        end
    endfunction

    // ---- combinational address / window logic ----
    // s = base_reg + run_cnt is a pure counter during a frame, so carry it as a
    // register that advances with run_cnt.  Computing it combinationally put a
    // 32-bit adder in front of the reflection mux and run_cnt -> p_rd_addr ->
    // rd_idx was a 6-level worst path.  Loading it with base_reg when ST_TRIG
    // hands over to ST_RUN keeps the value identical cycle for cycle.
    reg  signed [31:0] s_val_r;
    wire signed [31:0] s_val  = s_val_r;
    reg signed [31:0] p_rd_addr;
    always @(*) begin
        if (CONTINUOUS) begin
            // Endless sliding stream: every tapped sample is interior to the
            // circular buffer, so only the left edge (negative s) reflects;
            // there is no finite right edge to reflect at.
            if (s_val < 0)
                p_rd_addr = (~s_val) + 1;                    // -s
            else
                p_rd_addr = s_val;
        end else begin
            if (s_val < 0)
                p_rd_addr = (~s_val) + 1;                    // -s
            else if (s_val >= (P_DEPTH - 1))                 // ny = P_DEPTH-1
                p_rd_addr = (2 * (P_DEPTH - 1) - 2) - s_val; // 2*ny-2-s
            else
                p_rd_addr = s_val;
        end
        p_rd_addr = p_rd_addr + 1;                       // y[s] = p[s+1]
    end
    wire [BUF_AW-1:0] rd_idx_w = p_rd_addr[BUF_AW-1:0];

    // capture-side window flag for tap (run_cnt-2)
    wire [10:0] cap_idx = run_cnt - 11'd2;
    wire [9:0] hann_idx_cap = cap_idx[9:0] - WIN_OFF;
    wire in_win_cap = (cap_idx >= WIN_OFF) && (cap_idx < WIN_OFF + WIN_LEN);
    // product-stage window flag for tap (run_cnt-4), i.e. after the midpoint flop
    wire [10:0] prod_idx = run_cnt - 11'd4;
    wire in_win_prod = (prod_idx >= WIN_OFF) && (prod_idx < WIN_OFF + WIN_LEN);

    // ---- pipeline ----
    reg signed [W_IN-1:0] p_val_reg;
    reg [15:0] hann_val_reg;
    // Midpoint flops between the window ROM and the windowing multiplier.  The
    // ROM infers a block RAM whose output register sits in the BRAM column, and
    // the ~8.2 ns route from there to the APM was the whole frontend's worst
    // path.  Registering both operands once more lets the placer put this pair
    // between the two sites, so the distance splits across two cycles instead
    // of one.  (* keep *) stops the tool from folding it back into the BRAM
    // output register.
    (* keep *) reg [15:0] hann_val_r2;
    (* keep *) reg signed [W_IN-1:0] p_val_r2;
    reg signed [32:0] hann_prod_r;
    reg hann_prod_in_win_r;
    reg signed [32:0] rnd_absq;   // |hann_prod| + 16384, rounded radicand
    reg               rnd_negq;   // sign of the original product
    reg               wnd_rWin;   // in-window flag, delayed one cycle

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            run_cnt <= 11'd0;
            s_val_r <= 32'sd0;
            samp_cnt <= 32'd0;
            frames_done <= 10'd0;
            abs_frame <= 32'd0;
            trig_reg <= trig(32'd0);
            trig_m1  <= trig(32'd0) - 32'd1;
            base_reg <= 32'sd0;
            p_val_reg <= {W_IN{1'b0}};
            hann_val_reg <= 16'd0;
            hann_val_r2 <= 16'd0;
            p_val_r2 <= {W_IN{1'b0}};
            hann_prod_r <= 33'sd0;
            hann_prod_in_win_r <= 1'b0;
            rnd_absq <= 33'sd0;
            rnd_negq <= 1'b0;
            wnd_rWin <= 1'b0;
            p_wr_data <= {W_IN{1'b0}};
            hold_sample <= {W_IN{1'b0}};
            hold_valid <= 1'b0;
            hold_sample2 <= {W_IN{1'b0}};
            hold2_valid <= 1'b0;
            wnd_out <= {W_IN{1'b0}};
            wnd_valid <= 1'b0;
            done <= 1'b0;
            wr_buf <= 1'b0;
            rd_en <= 1'b0;
        end else begin
            wnd_valid <= 1'b0;
            done <= 1'b0;
            wr_buf <= 1'b0;
            rd_en <= 1'b0;
            case (state)
                ST_IDLE: begin
                    if (flush_hold) begin
                        // Flush the 1st held in-flight sample (arrived TRIG).
                        wr_buf <= 1'b1;
                        wr_idx <= samp_cnt[BUF_AW-1:0];
                        p_wr_data <= hold_sample;
                        hold_valid <= 1'b0;
                        samp_cnt <= samp_cnt + {{(P_AW-1){1'b0}}, 1'b1};
                        if (samp_cnt == trig_m1) begin
                            state <= ST_TRIG;
                            base_reg <= (32'sd320 * abs_frame) - 32'sd512;
                        end
                    end else if (flush_hold2) begin
                        // Flush the 2nd held in-flight sample (arrived RUN0).
                        wr_buf <= 1'b1;
                        wr_idx <= samp_cnt[BUF_AW-1:0];
                        p_wr_data <= hold_sample2;
                        hold2_valid <= 1'b0;
                        samp_cnt <= samp_cnt + {{(P_AW-1){1'b0}}, 1'b1};
                        if (samp_cnt == trig_m1) begin
                            state <= ST_TRIG;
                            base_reg <= (32'sd320 * abs_frame) - 32'sd512;
                        end
                    end else if (accept) begin
                        wr_buf <= 1'b1;
                        wr_idx <= samp_cnt[BUF_AW-1:0];
                        p_wr_data <= pcm_in;
                        samp_cnt <= samp_cnt + {{(P_AW-1){1'b0}}, 1'b1};
                        if (samp_cnt == trig_m1) begin
                            state <= ST_TRIG;
                            base_reg <= (32'sd320 * abs_frame) - 32'sd512;
                        end
                    end
                end
                ST_TRIG: begin
                    // One-cycle handshake stage: pcm_ready is low.  Capture the
                    // first in-flight sample into HOLD, then begin RUN.
                    if (capture_inflight) begin
                        hold_sample <= pcm_in;
                        hold_valid <= 1'b1;
                    end
                    state <= ST_RUN;
                    run_cnt <= 11'd0;
                    s_val_r <= base_reg;      // s at run_cnt == 0
                end
                ST_RUN: begin
                    // Capture the second in-flight sample (arrives run_cnt==0)
                    if (capture_inflight2) begin
                        hold_sample2 <= pcm_in;
                        hold2_valid <= 1'b1;
                    end
                    // issue buffer read for tap run_cnt (0..1023)
                    if (run_cnt < NFFT) begin
                        rd_en <= 1'b1;
                        rd_idx <= rd_idx_w;
                    end
                    // capture hann(run_cnt-2), p(run_cnt-2)  (run_cnt 2..1025)
                    if (run_cnt >= 11'd2 && run_cnt <= NFFT + 11'd1) begin
                        hann_val_reg <= in_win_cap ? hann_rom[hann_idx_cap] : 16'd0;
                        p_val_reg <= p_buf_q;
                    end
                    // midpoint stage: move the BRAM/ROM results into fabric flops (2..1025)
                    if (run_cnt >= 11'd3 && run_cnt <= NFFT + 11'd2) begin
                        hann_val_r2 <= hann_val_reg;
                        p_val_r2    <= p_val_reg;
                    end
                    // Register the product for tap run_cnt-4 (4..1027).
                    if (run_cnt >= 11'd4 && run_cnt <= NFFT + 11'd3) begin
                        hann_prod_r <= $signed({1'b0, hann_val_r2}) * p_val_r2;
                        hann_prod_in_win_r <= in_win_prod;
                    end
                    // Stage the rounding radicand (abs + bias, plus its sign)
                    // into its own register (5..1028) so the abs/round chain is
                    // split from the shift/sign step below.
                    if (run_cnt >= 11'd5 && run_cnt <= NFFT + 11'd4) begin
                        rnd_absq <= (hann_prod_r >= 0)
                                  ? (hann_prod_r + 33'sd16384)
                                  : (-hann_prod_r + 33'sd16384);
                        rnd_negq <= (hann_prod_r < 0);
                        wnd_rWin <= hann_prod_in_win_r;
                    end
                    // Emit: shift already-registered radicand, re-apply the sign
                    // (6..1029).  Right shift is wiring; only sign/select logic
                    // sits between the two registers.  Out-of-window force 0.
                    if (run_cnt >= 11'd6 && run_cnt <= NFFT + 11'd5) begin
                        wnd_out <= wnd_rWin ? (rnd_negq ? -($signed(rnd_absq) >>> 15)
                                                        :  ($signed(rnd_absq) >>> 15))
                                            : 17'sd0;
                        wnd_valid <= 1'b1;
                        frame_idx_o <= frames_done;
                    end
                    if (run_cnt == NFFT + 11'd5) begin
                        done <= 1'b1;
                        abs_frame <= abs_frame + 32'd1;
                        if (CONTINUOUS) begin
                            // Sliding window: keep emitting forever.  The slot
                            // index wraps mod MAX_FRAMES (downstream feature
                            // buffer overwrites the oldest frame); the trigger
                            // and base advance from the absolute counter.
                            frames_done <= (frames_done == MAX_FRAMES - 10'd1) ? 10'd0
                                         : frames_done + 10'd1;
                            state <= ST_IDLE;
                            trig_reg <= trig(abs_frame + 32'd1);
                            trig_m1  <= trig(abs_frame + 32'd1) - 32'd1;
                        end else begin
                            frames_done <= frames_done + 10'd1;
                            if (frames_done + 10'd1 == MAX_FRAMES) begin
                                state <= ST_HALT;
                            end else begin
                                state <= ST_IDLE;
                                trig_reg <= trig(frames_done + 10'd1);
                                trig_m1  <= trig(frames_done + 10'd1) - 32'd1;
                            end
                        end
                    end
                    run_cnt <= run_cnt + 11'd1;
                    s_val_r <= s_val_r + 32'sd1;
                end
                ST_HALT: begin
                    // all frames emitted; stop accepting
                end
            endcase
        end
    end

    // round-half-away(x>>15), x 33-bit signed -> 17-bit
    function automatic signed [16:0] rnd_15;
        input signed [32:0] x;
        begin
            if (x >= 0)
                rnd_15 = (x + 33'sd16384) >>> 15;
            else
                rnd_15 = -(((-x) + 33'sd16384) >>> 15);
        end
    endfunction

endmodule
