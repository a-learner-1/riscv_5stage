// frontend_fft1024.v
// V1 audio frontend stage 3: 1024-pt radix-2 DIT FFT (iterative), no per-stage
// scaling.  Bit-reversed serial input load; data path 32-bit signed; twiddle
// Q17 (x32768) with rnd(.,15) on products.  Output per bin k (0..512):
//   power_q[k] = rnd(re,5)^2 + rnd(im,5)^2   (= |X|^2 * 2^20)
// Matches ref_model.fft1024_power exactly.
//
// GATE5: data RAMs re_ram/im_ram are now 1R1W simple-dual-port with a
// REGISTERED read (rd_en/rd_a -> re_q/im_q one cycle later) so PDS infers
// DRM (was Sdm-4010 multiple async read ports).  The two butterfly operand
// reads are time-multiplexed: b_i read in cycle 0, b_i2 read in cycle 1.
// Butterfly: 13 cycles. Four complex products share one 32x18 multiplier;
// the lower duty cycle fits the 100-frame/s audio stream and releases APMs.
// Twiddle ROMs unchanged (async read).
//
// Serial wnd input (1024 samples), then emits 513 power values, then done.

module frontend_fft1024 #(
    parameter W_WND = 17,
    parameter W_FFT = 32,
    parameter W_POW = 43
)(
    input  wire                clk,
    input  wire                rst_n,
    input  wire                start,
    input  wire signed [W_WND-1:0] wnd_in,
    input  wire                wnd_in_valid,
    output reg  signed [W_POW-1:0] power_out,
    output reg                 power_valid,
    output reg                 done
);

    localparam N = 1024;

    // ---- twiddle ROMs (18-bit signed, x32768, async read) ----
    reg signed [17:0] tw_re_rom [0:511];
    reg signed [17:0] tw_im_rom [0:511];
    initial begin
        $readmemh("rom/tw_re_q17.mem", tw_re_rom);
        $readmemh("rom/tw_im_q17.mem", tw_im_rom);
    end

    // ---- data RAMs (1R1W simple-dual-port, synchronous read) ----
    reg signed [W_FFT-1:0] re_ram [0:N-1];
    reg signed [W_FFT-1:0] im_ram [0:N-1];
    reg fft_wr_en;
    reg [9:0] fft_wr_addr;
    reg signed [W_FFT-1:0] fft_wr_re;
    reg signed [W_FFT-1:0] fft_wr_im;
    // write port
    always @(posedge clk) begin
        if (fft_wr_en) begin
            re_ram[fft_wr_addr] <= fft_wr_re;
            im_ram[fft_wr_addr] <= fft_wr_im;
        end
    end
    // read port (registered, CE-gated)
    reg        rd_en;
    reg  [9:0] rd_addr;
    reg signed [W_FFT-1:0] re_q, im_q;
    always @(posedge clk) begin
        if (rd_en) begin
            re_q <= re_ram[rd_addr];
            im_q <= im_ram[rd_addr];
        end
    end

    function [9:0] bitrev;
        input [9:0] v;
        integer b;
        begin
            bitrev = 10'd0;
            for (b = 0; b < 10; b = b + 1)
                bitrev = {bitrev[8:0], v[b]};
        end
    endfunction

    // ---- FSM ----
    localparam S_LOAD = 3'd0, S_FFT = 3'd1, S_OUT = 3'd2, S_DONE = 3'd3;
    reg [2:0] state;
    reg [9:0] cnt;          // load/out counter
    reg [3:0] stage;        // 1..10
    reg [8:0] jj;           // global butterfly 0..511
    reg [3:0] bf;           // butterfly cycle 0..6
    reg [15:0] half;        // 2^(stage-1)
    reg [9:0] step;         // 512/half
    // half-1 is constant for a whole stage, so carry it as a register instead of
    // a subtractor on the critical path.  (half -> subtractor -> AND -> 10x10
    // twiddle-index multiply -> ROM address was the last failing FFT cone.)
    reg [15:0] half_m1;     // half - 1

    wire [15:0] jj_mod_h = jj & half_m1;
    wire [9:0] b_i  = {1'b0, (2 * jj) - jj_mod_h};
    wire [9:0] b_i2 = b_i + half[9:0];
    wire [9:0] b_k  = step * jj_mod_h[9:0];

    // butterfly pipeline
    reg signed [W_FFT-1:0] ar, ai, br, bi;
    reg signed [17:0] twr, twi;
    reg signed [47:0] pr, pi;
    reg signed [49:0] p1, p2, p3, p4;
    // Register the shared multiplier's operands one cycle before each product
    // so the twiddle-ROM/mux is not in the same 100 MHz path as the 32x18
    // multiply.  The four products are still bit-identical, just retimed.
    // (* keep *): without it the tool retimes these into the APM's own input
    // registers, which makes the twiddle ROM output route straight across to the
    // multiplier (1 level, ~8.5 ns route) instead of landing in a fabric flop
    // the placer can put midway between the ROM and the APM.
    (* keep *) reg  signed [31:0] mul_a_r;
    (* keep *) reg  signed [17:0] mul_b_r;
    wire signed [49:0] mul_y;
    frontend_mul32x18_pipe butterfly_multiplier(.clk(clk),.a(mul_a_r),.b(mul_b_r),.p(mul_y));
    reg signed [32:0] tr, ti;
    reg signed [W_FFT-1:0] ar2, ai2;
    // Power output is not required every cycle.  Register the rounded FFT
    // values, the two squares, and their sum on separate cycles so the DRM
    // read, round, multipliers, and adder do not share one 100 MHz path.
    reg [2:0] out_phase;
    // The power output is squared, so the sign of the rounded FFT value is
    // irrelevant: |rnd(re,5)|^2 == rnd(re,5)^2.  Round the MAGNITUDE and drop
    // the round-half-away re-negation, then split the magnitude -> round ->
    // square onto separate cycles so the 32-bit negation, the add/shift and
    // the APM square never share one 100 MHz path.
    reg signed [W_FFT-1:0] mag_re_r, mag_im_r;
    reg signed [26:0] power_re_r, power_im_r;
    reg signed [W_POW-1:0] power_re_sq_r, power_im_sq_r;
    wire signed [W_POW-1:0] re_square,im_square;
    frontend_square27_pipe #(.W(W_POW)) re_squarer(.clk(clk),.a(power_re_r),.p(re_square));
    frontend_square27_pipe #(.W(W_POW)) im_squarer(.clk(clk),.a(power_im_r),.p(im_square));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_LOAD;
            cnt <= 10'd0;
            stage <= 4'd1;
            jj <= 9'd0;
            bf <= 4'd0;
            half <= 16'd1;
            half_m1 <= 16'd0;
            step <= 10'd512;
            power_out <= {W_POW{1'b0}};
            power_valid <= 1'b0;
            done <= 1'b0;
            fft_wr_en <= 1'b0;
            rd_en <= 1'b0;
            rd_addr <= 10'd0;
            out_phase <= 2'd0;
            mag_re_r <= {W_FFT{1'b0}};
            mag_im_r <= {W_FFT{1'b0}};
            power_re_r <= 27'sd0;
            power_im_r <= 27'sd0;
            power_re_sq_r <= {W_POW{1'b0}};
            power_im_sq_r <= {W_POW{1'b0}};
        end else begin
            power_valid <= 1'b0;
            done <= 1'b0;
            fft_wr_en <= 1'b0;
            rd_en <= 1'b0;
            case (state)
                S_LOAD: begin
                    if (wnd_in_valid) begin
                        fft_wr_en <= 1'b1;
                        fft_wr_addr <= bitrev(cnt);
                        fft_wr_re <= {{(W_FFT-W_WND){wnd_in[W_WND-1]}}, wnd_in};
                        fft_wr_im <= {W_FFT{1'b0}};
                        if (cnt == N - 1)
                            state <= S_FFT;
                        else
                            cnt <= cnt + 10'd1;
                    end
                end
                S_FFT: begin
                    bf <= bf + 4'd1;
                    case (bf)
                        4'd0: begin   // issue read A (b_i); data -> re_q/im_q
                                      // during bf1 (sync read, +1 latency)
                            rd_en <= 1'b1;
                            rd_addr <= b_i;
                        end
                        4'd1: begin   // issue read B (b_i2); capture twiddle
                            rd_en <= 1'b1;
                            rd_addr <= b_i2;
                            twr <= tw_re_rom[b_k];
                            twi <= tw_im_rom[b_k];
                        end
                        4'd2: begin   // capture A (b_i data, read during bf1)
                            ar  <= re_q;
                            ai  <= im_q;
                        end
                        4'd3: begin   // capture B (b_i2 data, read during bf2)
                            br  <= re_q;
                            bi  <= im_q;
                        end
                        4'd4: begin
                            mul_a_r <= br;  mul_b_r <= twr;   // prep p1 = br*twr
                            ar2 <= ar;
                            ai2 <= ai;
                        end
                        4'd5: begin
                            mul_a_r <= bi;  mul_b_r <= twi;   // prep p2 = bi*twi
                        end
                        4'd6: begin
                            mul_a_r <= br;  mul_b_r <= twi;   // prep p3 = br*twi
                        end
                        4'd7: begin
                            p1 <= mul_y;
                            mul_a_r <= bi;  mul_b_r <= twr;   // prep p4 = bi*twr
                        end
                        4'd8: p2 <= mul_y;
                        4'd9: begin p3 <= mul_y; pr <= p1-p2; end
                        4'd10: p4 <= mul_y;
                        4'd11: pi <= p3 + p4;
                        4'd12: begin  // preserve the original 48-bit modular result
                            tr <= rnd_15(pr);
                            ti <= rnd_15(pi);
                        end
                        4'd13: begin  // write A: re[i]=a+tr
                            fft_wr_en <= 1'b1;
                            fft_wr_addr <= b_i;
                            fft_wr_re <= ar2 + tr;
                            fft_wr_im <= ai2 + ti;
                        end
                        4'd14: begin  // write B: re[i+half]=a-tr; advance
                            fft_wr_en <= 1'b1;
                            fft_wr_addr <= b_i2;
                            fft_wr_re <= ar2 - tr;
                            fft_wr_im <= ai2 - ti;
                            if (jj == 511) begin
                                jj <= 9'd0;
                                bf <= 4'd0;
                                if (stage == 10) begin
                                    state <= S_OUT;
                                    cnt <= 10'd0;
                                    rd_en <= 1'b1;   // prefetch bin 0
                                    rd_addr <= 10'd0;
                                end else begin
                                    stage <= stage + 4'd1;
                                    half <= half << 1;
                                    half_m1 <= (half << 1) - 16'd1;
                                    step <= step >> 1;
                                end
                            end else begin
                                jj <= jj + 9'd1;
                                bf <= 4'd0;
                            end
                        end
                    endcase
                end
                S_OUT: begin
                    // The final butterfly prefetched bin 0.  Its synchronous
                    // read lands during the first S_OUT cycle (cnt=0).
                    if (cnt == 0) begin
                        cnt <= 10'd1;
                    end else begin
                        case (out_phase)
                            3'd0: begin
                                // magnitude: |x| (one 32-bit negation, signed)
                                mag_re_r <= re_q[W_FFT-1] ? -re_q : re_q;
                                mag_im_r <= im_q[W_FFT-1] ? -im_q : im_q;
                                out_phase <= 3'd1;
                            end
                            3'd1: begin
                                // round the magnitude: (|x| + 16) >>> 5
                                power_re_r <= (mag_re_r + 32'sd16) >>> 5;
                                power_im_r <= (mag_im_r + 32'sd16) >>> 5;
                                out_phase <= 3'd2;
                            end
                            3'd2: out_phase <= 3'd3;
                            3'd3: out_phase <= 3'd4;
                            3'd4: out_phase <= 3'd5;
                            3'd5: begin
                                power_re_sq_r <= re_square;
                                power_im_sq_r <= im_square;
                                rd_en <= 1'b1;
                                rd_addr <= cnt; // next bin; 513 is a harmless dummy
                                out_phase <= 3'd6;
                            end
                            3'd6: begin
                                power_out <= power_re_sq_r + power_im_sq_r;
                                power_valid <= 1'b1;
                                out_phase <= 3'd0;
                                if (cnt == 513) begin
                                    state <= S_DONE;
                                    done <= 1'b1;
                                end else begin
                                    cnt <= cnt + 10'd1;
                                end
                            end
                        endcase
                    end
                end
                S_DONE: begin
                    state <= S_LOAD;
                    cnt <= 10'd0;
                    stage <= 4'd1;
                    half <= 16'd1;
                    half_m1 <= 16'd0;
                    step <= 10'd512;
                end
            endcase
        end
    end

    // rnd(x,15) half-away, 48-bit -> 33-bit
    function automatic signed [32:0] rnd_15;
        input signed [47:0] x;
        begin
            if (x >= 0)
                rnd_15 = (x + 48'sd16384) >>> 15;
            else
                rnd_15 = -(((-x) + 48'sd16384) >>> 15);
        end
    endfunction

endmodule

// Two registered partial products replace the combinational DSP cascade.
// A = signed(A[31:16])*2^16 + unsigned(A[15:0]); exact signed 50-bit result.
module frontend_mul32x18_pipe(input wire clk,input wire signed [31:0] a,
    input wire signed [17:0] b,output reg signed [49:0] p);
    reg signed [34:0] lo;
    reg signed [33:0] hi;
    always @(posedge clk) begin
        lo <= $signed({1'b0,a[15:0]}) * b;
        hi <= $signed(a[31:16]) * b;
        p <= {{15{lo[34]}},lo} + {hi,16'b0};
    end
endmodule

// Exact square modulo 2^W, with only <=15x15 DSP products per stage.
// Signed a = hi*2^14 + lo; a^2 = lo^2 + hi*lo*2^15 + hi^2*2^28.
// No pipeline reset is needed: the consumer waits all three stages before use.
module frontend_square27_pipe #(parameter W=43)(input wire clk,
    input wire signed [26:0] a,output reg signed [W-1:0] p);
    reg [29:0] lo2;
    reg signed [27:0] cross_product;
    reg signed [25:0] hi2;
    reg [W-1:0] sum_lo,sum_hi;
    wire signed [W-1:0] cross_ext={{(W-28){cross_product[27]}},cross_product};
    wire signed [W-1:0] hi_ext={{(W-26){hi2[25]}},hi2};
    always @(posedge clk) begin
        lo2 <= $signed({1'b0,a[13:0]}) * $signed({1'b0,a[13:0]});
        cross_product <= $signed(a[26:14]) * $signed({1'b0,a[13:0]});
        hi2 <= $signed(a[26:14]) * $signed(a[26:14]);
        sum_lo <= {{(W-30){1'b0}},lo2} + (cross_ext << 15);
        sum_hi <= hi_ext << 28;
        p <= sum_lo + sum_hi;
    end
endmodule
