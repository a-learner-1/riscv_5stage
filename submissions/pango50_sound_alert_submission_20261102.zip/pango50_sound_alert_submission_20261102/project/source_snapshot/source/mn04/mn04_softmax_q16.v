`timescale 1ns/1ps
// N_CLASSES int8 logits -> Q0.16 probabilities, class 0 in low bits.
// Uses one small exp ROM and a shared bit-serial divider (no APM multiplier).
// The ROM is exp(-delta*s_logits) in Q0.24, where s_logits comes from the
// calibrated head. Latency is approximately 2*N_CLASSES + N_CLASSES*41
// clocks plus setup; maximum selection is serialized to ease timing closure.
module mn04_softmax_q16 #(
    parameter LUT_FILE = "softmax_exp_q24.mem",
    parameter N_CLASSES = 7
)(
    input  wire         clk,
    input  wire         rst_n,
    input  wire         logits_valid_i,
    input  wire [8*N_CLASSES-1:0]  logits_i,
    output reg          probs_valid_o,
    output wire [16*N_CLASSES-1:0] probs_q16_o,
    output wire         busy_o
);
    localparam [2:0] S_IDLE=0, S_MAX=1, S_EXP=2, S_DIV_INIT=3,
                     S_DIV=4, S_DONE=5;
    reg [2:0] state_r;
    reg signed [7:0] logits_r [0:N_CLASSES-1];
    reg signed [7:0] max_r;
    reg [23:0] exp_rom [0:255];
    reg [23:0] exp_r [0:N_CLASSES-1];
    reg [15:0] prob_r [0:N_CLASSES-1];
    reg [26:0] sum_r;
    reg [2:0] index_r;
    reg [5:0] bits_r;
    reg [39:0] numerator_r, quotient_r;
    reg [27:0] remainder_r;
    integer j;

    initial $readmemh(LUT_FILE, exp_rom);
    wire signed [8:0] diff_w =
        $signed({max_r[7], max_r}) -
        $signed({logits_r[index_r][7], logits_r[index_r]});
    wire [27:0] trial_w = {remainder_r[26:0], numerator_r[39]};
    wire take_w = trial_w >= {1'b0, sum_r};
    wire [27:0] next_rem_w = take_w ? trial_w - {1'b0, sum_r} : trial_w;
    wire [39:0] next_quot_w = {quotient_r[38:0], take_w};

    genvar g;
    generate for (g=0; g<N_CLASSES; g=g+1) begin : g_probs
        assign probs_q16_o[g*16 +: 16] = prob_r[g];
    end endgenerate
    assign busy_o = (state_r != S_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= S_IDLE;
            probs_valid_o <= 1'b0;
            max_r <= 0;
            sum_r <= 0;
            index_r <= 0;
            bits_r <= 0;
            numerator_r <= 0;
            quotient_r <= 0;
            remainder_r <= 0;
            for (j=0; j<N_CLASSES; j=j+1) begin
                logits_r[j] <= 0;
                exp_r[j] <= 0;
                prob_r[j] <= 0;
            end
        end else begin
            probs_valid_o <= 1'b0;
            case (state_r)
                S_IDLE: if (logits_valid_i) begin
                    for (j=0; j<N_CLASSES; j=j+1)
                        logits_r[j] <= logits_i[j*8 +: 8];
                    max_r <= $signed(logits_i[7:0]);
                    sum_r <= 0;
                    index_r <= 1;
                    state_r <= S_MAX;
                end
                // Scan one stored logit per cycle. This removes the wide
                // logits-to-max combinational comparator chain from the
                // 100 MHz path while preserving the exact maximum.
                S_MAX: begin
                    if ($signed(logits_r[index_r]) > max_r)
                        max_r <= $signed(logits_r[index_r]);
                    if (index_r == N_CLASSES-1) begin
                        index_r <= 0;
                        state_r <= S_EXP;
                    end else index_r <= index_r + 1'b1;
                end
                S_EXP: begin
                    exp_r[index_r] <= exp_rom[diff_w[7:0]];
                    sum_r <= sum_r + {3'b000, exp_rom[diff_w[7:0]]};
                    if (index_r == N_CLASSES-1) begin
                        index_r <= 0;
                        state_r <= S_DIV_INIT;
                    end else index_r <= index_r + 1'b1;
                end
                S_DIV_INIT: begin
                    numerator_r <= {exp_r[index_r], 16'b0};
                    quotient_r <= 0;
                    remainder_r <= 0;
                    bits_r <= 6'd40;
                    state_r <= S_DIV;
                end
                S_DIV: begin
                    numerator_r <= {numerator_r[38:0], 1'b0};
                    quotient_r <= next_quot_w;
                    remainder_r <= next_rem_w;
                    bits_r <= bits_r - 1'b1;
                    if (bits_r == 6'd1) begin
                        prob_r[index_r] <= next_quot_w[16] ? 16'hffff : next_quot_w[15:0];
                        if (index_r == N_CLASSES-1) state_r <= S_DONE;
                        else begin
                            index_r <= index_r + 1'b1;
                            state_r <= S_DIV_INIT;
                        end
                    end
                end
                S_DONE: begin
                    probs_valid_o <= 1'b1;
                    state_r <= S_IDLE;
                end
                default: state_r <= S_IDLE;
            endcase
        end
    end
endmodule
