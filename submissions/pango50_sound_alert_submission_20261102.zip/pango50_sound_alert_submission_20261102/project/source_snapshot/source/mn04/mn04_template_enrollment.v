`timescale 1ns/1ps
// Capture the first one-second feature map of each button-controlled pure
// template take directly into the matcher's on-chip template RAM. The audio
// ring writer still stores the complete take in DDR; this parallel path only
// enrolls a fixed 128 x 100 map and never sends captured bytes over UART.
module mn04_template_enrollment #(
    parameter integer CNN_CLASS_COUNT = 6,
    parameter integer MEL_BINS = 128,
    parameter integer WINDOW_FRAMES = 100,
    parameter integer PURE_TEMPLATE_CLASSES = 3,
    parameter integer MAPS_PER_CLASS = 2,
    parameter integer USE_CPU_SLOT_SELECT = 0,
    parameter integer MAP_INDEX_W = $clog2(PURE_TEMPLATE_CLASSES*MAPS_PER_CLASS),
    // Bytes discarded at the start of a take so the K5 button click is not
    // stored as part of the template.
    parameter integer WARMUP_FRAMES = 400
)(
    input wire clk,
    input wire rst_n,
    input wire capture_recording_i,
    input wire [3:0] capture_category_i,
    input wire [1:0] overflow_i,
    input wire signed [7:0] x0_i,
    input wire x0_valid_i,
    input wire [MAP_INDEX_W-1:0] cpu_selected_slot_i,
    input wire [PURE_TEMPLATE_CLASSES*MAPS_PER_CLASS-1:0] existing_valid_mask_i,
    output wire template_load_we_o,
    output wire [17:0] template_load_addr_o,
    output wire signed [7:0] template_load_data_o,
    output wire [PURE_TEMPLATE_CLASSES*MAPS_PER_CLASS-1:0] valid_mask_o,
    output reg [PURE_TEMPLATE_CLASSES*MAPS_PER_CLASS-1:0] invalid_mask_o,
    output reg enrollment_commit_o,
    output reg [3:0] enrollment_category_o,
    output reg [MAP_INDEX_W-1:0] enrollment_map_o
);
    localparam integer WINDOW_SIZE = MEL_BINS * WINDOW_FRAMES;
    localparam integer MAP_COUNT = PURE_TEMPLATE_CLASSES * MAPS_PER_CLASS;
    localparam integer SAMPLE_COUNT_W = $clog2(WINDOW_SIZE + 1);
    localparam integer MAP_COUNT_W = $clog2(MAPS_PER_CLASS + 1);

    reg capture_active_r, enroll_active_r;
    reg overflow_seen_r;
    reg [3:0] template_category_r;
    reg [MAP_INDEX_W-1:0] map_index_r;
    reg [SAMPLE_COUNT_W-1:0] sample_count_r;
    reg [MAP_COUNT_W-1:0] class_map_count_r [0:PURE_TEMPLATE_CLASSES-1];
    reg [MAP_COUNT-1:0] valid_mask_r;
    reg signed [7:0] x0_data_d_r;
    reg [15:0] warm_bytes_r;
    reg load_we_d_r;
    reg [17:0] load_addr_d_r;
    integer i;

    wire category_is_template = capture_category_i >= CNN_CLASS_COUNT &&
                                capture_category_i < CNN_CLASS_COUNT + PURE_TEMPLATE_CLASSES;
    wire [3:0] incoming_template_category = capture_category_i - CNN_CLASS_COUNT;
    wire [MAP_COUNT-1:0] occupied_slots=(existing_valid_mask_i|valid_mask_r)&~invalid_mask_o;
    wire cpu_slot_available=cpu_selected_slot_i>=incoming_template_category*MAPS_PER_CLASS &&
        cpu_selected_slot_i<(incoming_template_category+1)*MAPS_PER_CLASS &&
        !occupied_slots[cpu_selected_slot_i];
    wire slot_available=USE_CPU_SLOT_SELECT ? cpu_slot_available :
        (class_map_count_r[incoming_template_category]<MAPS_PER_CLASS);
    wire enrollment_starts_now = !capture_active_r && capture_recording_i &&
        category_is_template && slot_available;
    wire [MAP_INDEX_W-1:0] incoming_map_index = USE_CPU_SLOT_SELECT ? cpu_selected_slot_i :
        incoming_template_category * MAPS_PER_CLASS + class_map_count_r[incoming_template_category];
    wire enrollment_stream_active = enroll_active_r || enrollment_starts_now;
    wire [MAP_INDEX_W-1:0] active_map_index = enrollment_starts_now ? incoming_map_index : map_index_r;

    assign valid_mask_o = valid_mask_r;
    // Register the write port once so the template RAM sees a clean synchronous
    // write, independent of front-end valid pulse width and button debounce.
    assign template_load_we_o = load_we_d_r;
    assign template_load_addr_o = load_addr_d_r;
    assign template_load_data_o = x0_data_d_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            capture_active_r <= 1'b0;
            overflow_seen_r <= 1'b0;
            enroll_active_r <= 1'b0;
            template_category_r <= 0;
            map_index_r <= 0;
            sample_count_r <= 0;
            valid_mask_r <= 0;
            invalid_mask_o <= 0;
            load_we_d_r <= 1'b0;
            load_addr_d_r <= 0;
            x0_data_d_r <= 0;
            warm_bytes_r <= 16'd0;
            enrollment_commit_o <= 1'b0;
            enrollment_category_o <= 0;
            enrollment_map_o <= 0;
            for (i=0;i<PURE_TEMPLATE_CLASSES;i=i+1)
                class_map_count_r[i] <= 0;
        end else begin
            load_we_d_r <= 1'b0;
            enrollment_commit_o <= 1'b0;

            if (!capture_active_r && capture_recording_i) begin
                capture_active_r <= 1'b1;
                overflow_seen_r <= |overflow_i;
                sample_count_r <= 0;
                // Each take gets its own warm-up interval.  Without resetting
                // this counter here, only the first template take discarded
                // the K5/start transient; later takes included it.
                warm_bytes_r <= WARMUP_FRAMES * MEL_BINS;
                if (category_is_template && slot_available) begin
                    enroll_active_r <= 1'b1;
                    template_category_r <= incoming_template_category;
                    map_index_r <= incoming_map_index;
                    invalid_mask_o[incoming_map_index] <= 1'b1;
                end else begin
                    enroll_active_r <= 1'b0;
                end
            end

            if (capture_recording_i && enrollment_stream_active && x0_valid_i &&
                sample_count_r < WINDOW_SIZE) begin
                // On the exact start edge, treat a simultaneous first feature
                // byte as warm-up too; nonblocking assignments would otherwise
                // see the previous take's (usually zero) counter value.
                if (enrollment_starts_now && WARMUP_FRAMES != 0) begin
                    warm_bytes_r <= WARMUP_FRAMES * MEL_BINS - 1;
                end else if (warm_bytes_r != 16'd0) begin
                    warm_bytes_r <= warm_bytes_r - 1'b1;
                end else begin
                load_we_d_r <= 1'b1;
                load_addr_d_r <= active_map_index * WINDOW_SIZE + sample_count_r;
                x0_data_d_r <= x0_i;
                sample_count_r <= sample_count_r + 1'b1;
                end
            end

            if (capture_recording_i && |overflow_i)
                overflow_seen_r <= 1'b1;

            if (capture_active_r && !capture_recording_i) begin
                capture_active_r <= 1'b0;
                if (enroll_active_r && sample_count_r == WINDOW_SIZE &&
                    !overflow_seen_r && overflow_i == 0) begin
                    valid_mask_r[map_index_r] <= 1'b1;
                    invalid_mask_o[map_index_r] <= 1'b0;
                    class_map_count_r[template_category_r] <=
                        class_map_count_r[template_category_r] + 1'b1;
                    enrollment_commit_o <= 1'b1;
                    enrollment_category_o <= CNN_CLASS_COUNT + template_category_r;
                    enrollment_map_o <= map_index_r;
                end
                enroll_active_r <= 1'b0;
                sample_count_r <= 0;
            end
        end
    end
endmodule
