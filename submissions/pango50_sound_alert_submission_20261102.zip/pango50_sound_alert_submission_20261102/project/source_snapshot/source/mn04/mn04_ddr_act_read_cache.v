`timescale 1ns/1ps
// Direct-mapped 32-byte-line activation read cache for the DDR3 user port.
// A conv candidate is accepted on a hit or for a padded zero term; other misses
// fetch their beat before the MAC issues the term. Non-conv reads can wait for
// a variable response.
// Direct-mapped tag lookup uses an address hash so separate activation arenas
// and skip paths do not systematically collide. Throughput and mapped FPGA
// resources still need board-level measurement.
module mn04_ddr_act_read_cache #(
    parameter integer LINE_BITS = 6  // 6=64 lines/2 KiB; 8=256 lines/8 KiB
)(
    input  wire         clk,
    input  wire         rst_n,
    input  wire         flush_i,
    input  wire         write_invalidate_i,
    input  wire [23:0]  write_addr_i,
    input  wire         writes_drained_i,
    input  wire         candidate_valid_i,
    input  wire [23:0]  candidate_addr_i,
    input  wire         candidate_pad_i,
    output wire         candidate_ready_o,
    input  wire         rd_req_valid_i,
    input  wire [23:0]  rd_byte_addr_i,
    input  wire         rd_req_pad_i,
    output reg          rd_rsp_valid_o,
    output reg  [31:0]  rd_data_o,
    output reg  [1:0]   rd_lane_o,
    // Convolution consumes a fixed three-cycle request pipeline and must see
    // the synchronous BRAM result as soon as the registered line read lands.
    // Keep this fast path separate from rd_data_o, whose registered response
    // contract is used by variable-latency scalar/pool/gate operations.
    output wire [31:0]  conv_data_o,
    output wire [1:0]   conv_lane_o,
    output reg  [27:0]  ddr_araddr_o,
    output reg          ddr_arvalid_o,
    input  wire         ddr_arready_i,
    input  wire [255:0] ddr_rdata_i,
    input  wire [1:0]   ddr_rresp_i,
    input  wire         ddr_rvalid_i,
    output wire         ddr_rready_o
);
    localparam IDLE=0, SEND_AR=1, WAIT_R=2;
    localparam LINE_COUNT=(1 << LINE_BITS);
    assign ddr_rready_o = 1'b1;  // single-outstanding read: always accept
    reg [1:0] state_r;
    reg [18:0] line_tags [0:LINE_COUNT-1];
    // A registered full-line read maps the 64 KiB data array into block RAM.
    // Selecting a 32-bit slice directly from an indexed array made PDS map
    // all 2048 x 256 bits into distributed LUT RAM.
    (* ram_style = "block" *) reg [255:0] line_data [0:LINE_COUNT-1];
    reg [255:0] read_line_r;
    reg [2:0] hit_word_r;
    reg [1:0] hit_lane_r;
    reg [LINE_COUNT-1:0] line_valid_r;
    reg [18:0] fetch_tag_r;
    reg [LINE_BITS-1:0] fetch_idx_r;
    reg pending_nonconv_r;
    reg [23:0] pending_addr_r;
    reg pending_conv_r;
    reg [23:0] pending_conv_addr_r;
    reg discard_fetch_r;
    reg protect_r;
    reg hit_d1_r, hit_d2_r, hit_pad_d1_r;

    assign conv_data_o = hit_pad_d1_r ? 32'd0 :
                         read_line_r[32*hit_word_r +: 32];
    assign conv_lane_o = hit_lane_r;

    function [LINE_BITS-1:0] line_index;
        input [23:0] addr;
        begin line_index = addr[LINE_BITS+4:5] ^ addr[23:18]; end
    endfunction
    wire [LINE_BITS-1:0] write_idx = line_index(write_addr_i);
    wire [LINE_BITS-1:0] candidate_idx = line_index(candidate_addr_i);
    wire [LINE_BITS-1:0] read_idx = line_index(rd_byte_addr_i);
    wire invalidate_line = write_invalidate_i &&
                           line_valid_r[write_idx] &&
                           line_tags[write_idx] == write_addr_i[23:5];
    wire candidate_hit = line_valid_r[candidate_idx] &&
                         line_tags[candidate_idx] == candidate_addr_i[23:5] &&
                         !(invalidate_line && write_idx == candidate_idx) && !flush_i;
    wire read_hit = line_valid_r[read_idx] &&
                    line_tags[read_idx] == rd_byte_addr_i[23:5] &&
                    !(invalidate_line && write_idx == read_idx) && !flush_i;
    // Keeping valid out of this hit/ready path avoids feeding the core's
    // term-limit arithmetic back through the cache tag lookup into the scalar
    // issue enable.
    // Registering the hit takes the tag lookup + 32-bit compare off the core's
    // candidate path.  The register alone is NOT enough: the line has to drop
    // ready in the very cycle it is invalidated or flushed (the cache unit test
    // checks exactly this), so AND it with those same-cycle guards.  Those two
    // signals are shallow compared with the tag compare.
    reg candidate_ready_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) candidate_ready_r <= 1'b0;
        else        candidate_ready_r <= (state_r == IDLE) &&
                                         (candidate_pad_i || candidate_hit);
    end
    // Gate only on the INDEX match, not the full invalidate_line tag compare:
    // using invalidate_line here put the write-side 19-bit tag compare on the
    // candidate -> conv_req -> engine-issue path (a 12-level cone).  Dropping
    // ready when the write index merely coincides is conservative -- the core
    // just waits one cycle -- and keeps the guard to a 9-bit equality.
    wire invalidate_same_idx = write_invalidate_i && (write_idx == candidate_idx);
    assign candidate_ready_o = candidate_ready_r && !flush_i && !invalidate_same_idx;
    // The conv-miss bookkeeping genuinely did depend combinationally on the tag
    // compare (resid_addr_* -> tag lookup -> compare -> pending_conv_addr_r/CE was
    // a 9-level cone).  That one CAN be registered: the miss only needs to latch
    // the address, so keep a one-cycle-old copy of the candidate address and let
    // the CE become a register output.
    reg candidate_miss_r;
    reg [23:0] cand_addr_d1;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            candidate_miss_r <= 1'b0;
            cand_addr_d1 <= 24'd0;
        end else begin
            cand_addr_d1 <= candidate_addr_i;
            candidate_miss_r <= (state_r == IDLE) && candidate_valid_i &&
                                !candidate_pad_i && !candidate_hit && !pending_conv_r;
        end
    end

    wire nonconv_miss_c = rd_req_valid_i && !rd_req_pad_i && !read_hit;

    // The nonconv (scalar/read) miss decision also hung combinationally on the tag

    // compare, so rd_byte_addr/wr-addr -> tag lookup -> compare -> miss_addr ->

    // fetch_idx_r/CE was a 9-level cone.  Register it exactly like the conv side:

    // one-cycle-old decision plus a one-cycle-old address.

    reg nonconv_miss_r;

    reg [23:0] rd_byte_addr_d1;

    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            nonconv_miss_r <= 1'b0;

            rd_byte_addr_d1 <= 24'd0;

        end else begin

            rd_byte_addr_d1 <= rd_byte_addr_i;

            nonconv_miss_r <= nonconv_miss_c;

        end

    end

    wire nonconv_miss = nonconv_miss_r;
    wire [23:0] miss_addr = pending_nonconv_r ? pending_addr_r :
                             nonconv_miss_r ? rd_byte_addr_d1 : pending_conv_addr_r;
    wire want_fill = (pending_nonconv_r || nonconv_miss ||
                     pending_conv_r) &&
                     writes_drained_i && !write_invalidate_i &&
                     !protect_r && !flush_i;

    // One synchronous read port and one synchronous write port.  The existing
    // two-cycle hit-valid pipeline leaves a cycle to select the requested word.
    always @(posedge clk) begin
        // Keep the BRAM read port enabled.  Gating its clock enable with the
        // current convolution issue creates a long control->address->hit->CE
        // path that cannot close at the 100 MHz DDR user clock.
        read_line_r <= line_data[read_idx];
        if (state_r == WAIT_R && ddr_rvalid_i)
            line_data[fetch_idx_r] <= ddr_rdata_i;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= IDLE;
            fetch_tag_r <= 0; fetch_idx_r <= 0;
            line_valid_r <= 0;
            pending_nonconv_r <= 0; pending_addr_r <= 0;
            pending_conv_r <= 0; pending_conv_addr_r <= 0;
            discard_fetch_r <= 0;
            protect_r <= 0; hit_d1_r <= 0; hit_d2_r <= 0;
            hit_pad_d1_r <= 0;
            rd_rsp_valid_o <= 0; rd_data_o <= 0; rd_lane_o <= 0;
            ddr_araddr_o <= 0; ddr_arvalid_o <= 0;
        end else begin
            protect_r <= candidate_valid_i && candidate_ready_o;
            hit_d1_r <= rd_req_valid_i && (rd_req_pad_i || read_hit);
            hit_d2_r <= hit_d1_r;
            hit_pad_d1_r <= rd_req_valid_i && rd_req_pad_i;
            // Pool/gate/residual consumers expect a three-edge response from
            // the core's registered request pulse. The conv MAC bypasses this
            // variable-latency handshake through conv_data_o/conv_lane_o.
            rd_rsp_valid_o <= hit_d2_r;
            // The request address is already stable at the issue edge.
            // Capturing its slice unconditionally avoids routing the tag-hit
            // comparator back to a register clock enable.
            hit_word_r <= rd_byte_addr_i[4:2];
            hit_lane_r <= rd_byte_addr_i[1:0];
            if (hit_d1_r) begin
                // A convolution's out-of-bounds terms are valid zero-valued
                // inputs. Never expose an uninitialized cache line for them.
                rd_data_o <= hit_pad_d1_r ? 32'd0 :
                             read_line_r[32*hit_word_r +: 32];
                rd_lane_o <= hit_lane_r;
            end
            if (flush_i) line_valid_r <= 0;
            else if (invalidate_line) line_valid_r[write_idx] <= 0;
            if (nonconv_miss && !pending_nonconv_r) begin
                pending_nonconv_r <= 1;
                pending_addr_r <= rd_byte_addr_d1;
            end
            // Register conv misses before the DDR launch.  This separates
            // the core's candidate/state decode from fetch index and AR
            // registers without changing the fixed-latency hit path.
            if (candidate_miss_r) begin
                pending_conv_r <= 1;
                pending_conv_addr_r <= cand_addr_d1;
            end
            if (candidate_hit) pending_conv_r <= 0;
            if (flush_i) begin
                pending_nonconv_r <= 0;
                pending_conv_r <= 0;
                discard_fetch_r <= 1;
            end

            case (state_r)
                IDLE: if (want_fill) begin
                    fetch_tag_r <= miss_addr[23:5];
                    fetch_idx_r <= line_index(miss_addr);
                    // This cache master feeds the full AXI byte-address port
                    // of mn04_axi4_ddr_bridge. Keep a 32-byte-aligned byte
                    // address here; the bridge converts it to the Pango
                    // controller's word-address units.
                    ddr_araddr_o <= {4'b0, miss_addr[23:5], 5'b0};
                    ddr_arvalid_o <= 1;
                    state_r <= SEND_AR;
                    discard_fetch_r <= 0;
                    if (!pending_nonconv_r && !nonconv_miss_r)
                        pending_conv_r <= 0;
                end
                SEND_AR: if (ddr_arvalid_o && ddr_arready_i) begin
                    ddr_arvalid_o <= 0;
                    state_r <= WAIT_R;
                end
                WAIT_R: if (ddr_rvalid_i) begin
                    line_tags[fetch_idx_r] <= fetch_tag_r;
                    line_valid_r[fetch_idx_r] <= !flush_i && !discard_fetch_r &&
                        !(write_invalidate_i && write_addr_i[23:5] == fetch_tag_r);
                    state_r <= IDLE;
                    if (pending_nonconv_r &&
                        pending_addr_r[23:5] == fetch_tag_r &&
                        !discard_fetch_r && !flush_i) begin
                        rd_data_o <= ddr_rdata_i[8*{pending_addr_r[4:2],2'b00} +: 32];
                        rd_lane_o <= pending_addr_r[1:0];
                        rd_rsp_valid_o <= 1;
                        pending_nonconv_r <= 0;
                    end
                end
                default: state_r <= IDLE;
            endcase
            if (flush_i) pending_nonconv_r <= 0;
        end
    end
endmodule
