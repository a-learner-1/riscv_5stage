`timescale 1ns/1ps
// Clock-domain wrapper for the CPU5 supervisor. The main audio/CNN/DDR fabric
// remains on ddr_clk; the CPU and its local ROM/BRAM/control registers run from
// the board's 50-MHz oscillator. Low-rate events cross with toggle handshakes,
// and their payloads are held stable until the destination captures them.
module mn04_cpu5_control_cdc #(
    parameter integer CLOCK_HZ=50000000,
    parameter FIRMWARE_FILE="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_replacement_20261028/control_cpu5.mem",
    parameter DATA_FILE="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_replacement_20261028/control_cpu5_data.mem",
    parameter [15:0] BABY_THRESHOLD=59637,KNOCK_THRESHOLD=47841,
    parameter [15:0] SIREN_THRESHOLD=49152,CAR_THRESHOLD=29491,
    parameter [15:0] TEMPLATE_THRESHOLD=26214
)(
    input wire src_clk_i,cpu_clk_i,rst_n,core_rst_n_i,
    input wire [5:0] key_n_i,
    input wire boot_ready_i,codec_ready_i,recognition_i,capture_busy_i,recording_i,alert_i,
    input wire snapshot_ready_i,job_done_i,
    input wire cnn_valid_i,
    input wire [95:0] cnn_probabilities_i,
    input wire template_valid_i,
    input wire [1:0] template_class_i,
    input wire [15:0] template_score_i,
    input wire [3:0] capture_category_i,
    input wire [14:0] template_slot_mask_i,
    input wire template_commit_i,
    output wire [5:0] command_key_n_o,
    output wire job_authorized_o,
    output wire [3:0] template_slot_o,
    output reg event_valid_o,
    output reg [3:0] event_class_o,
    output wire [31:0] firmware_signature_o,command_count_o,irq_count_o,
    output wire [31:0] isa_selftest_o
);
    reg [1:0] cpu_reset_pipe;
    always @(posedge cpu_clk_i or negedge rst_n) begin
        if(!rst_n) cpu_reset_pipe<=2'b00;
        else if(!core_rst_n_i) cpu_reset_pipe<=2'b00;
        else cpu_reset_pipe<={cpu_reset_pipe[0],1'b1};
    end
    wire cpu_rst_n=cpu_reset_pipe[1];

    // Stable level/status crossings into the CPU clock domain.
    reg [5:0] key_meta,key_sync;
    reg boot_meta,boot_sync,codec_meta,codec_sync,recognition_meta,recognition_sync;
    reg capture_busy_meta,capture_busy_sync,recording_meta,recording_sync,alert_meta,alert_sync;
    reg [3:0] category_meta,category_sync;
    reg [14:0] slot_mask_meta,slot_mask_sync;
    always @(posedge cpu_clk_i or negedge cpu_rst_n) begin
        if(!cpu_rst_n) begin
            key_meta<=6'h3f;key_sync<=6'h3f;
            boot_meta<=0;boot_sync<=0;codec_meta<=0;codec_sync<=0;
            recognition_meta<=0;recognition_sync<=0;
            capture_busy_meta<=0;capture_busy_sync<=0;
            recording_meta<=0;recording_sync<=0;alert_meta<=0;alert_sync<=0;
            category_meta<=0;category_sync<=0;slot_mask_meta<=0;slot_mask_sync<=0;
        end else begin
            key_meta<=key_n_i;key_sync<=key_meta;
            boot_meta<=boot_ready_i;boot_sync<=boot_meta;
            codec_meta<=codec_ready_i;codec_sync<=codec_meta;
            recognition_meta<=recognition_i;recognition_sync<=recognition_meta;
            capture_busy_meta<=capture_busy_i;capture_busy_sync<=capture_busy_meta;
            recording_meta<=recording_i;recording_sync<=recording_meta;
            alert_meta<=alert_i;alert_sync<=alert_meta;
            category_meta<=capture_category_i;category_sync<=category_meta;
            slot_mask_meta<=template_slot_mask_i;slot_mask_sync<=slot_mask_meta;
        end
    end

    // Convert source-domain one-cycle events to toggles. The associated data
    // buses are latched in the source domain and remain unchanged between
    // events, then receive two destination sampling stages before use.
    reg snapshot_prev,job_prev,cnn_prev,template_prev,commit_prev;
    reg snapshot_toggle_src,job_toggle_src,cnn_toggle_src,template_toggle_src,commit_toggle_src;
    reg [95:0] cnn_payload_src;
    reg [17:0] template_payload_src;
    always @(posedge src_clk_i or negedge rst_n) begin
        if(!rst_n) begin
            snapshot_prev<=0;job_prev<=0;cnn_prev<=0;template_prev<=0;commit_prev<=0;
            snapshot_toggle_src<=0;job_toggle_src<=0;cnn_toggle_src<=0;
            template_toggle_src<=0;commit_toggle_src<=0;
            cnn_payload_src<=0;template_payload_src<=0;
        end else if(!core_rst_n_i) begin
            snapshot_prev<=0;job_prev<=0;cnn_prev<=0;template_prev<=0;commit_prev<=0;
            snapshot_toggle_src<=0;job_toggle_src<=0;cnn_toggle_src<=0;
            template_toggle_src<=0;commit_toggle_src<=0;
            cnn_payload_src<=0;template_payload_src<=0;
        end else begin
            snapshot_prev<=snapshot_ready_i;job_prev<=job_done_i;cnn_prev<=cnn_valid_i;
            template_prev<=template_valid_i;commit_prev<=template_commit_i;
            if(snapshot_ready_i && !snapshot_prev) snapshot_toggle_src<=~snapshot_toggle_src;
            if(job_done_i && !job_prev) job_toggle_src<=~job_toggle_src;
            if(cnn_valid_i && !cnn_prev) begin
                cnn_toggle_src<=~cnn_toggle_src;
                cnn_payload_src<=cnn_probabilities_i;
            end
            if(template_valid_i && !template_prev) begin
                template_toggle_src<=~template_toggle_src;
                template_payload_src<={template_class_i,template_score_i};
            end
            if(template_commit_i && !commit_prev) commit_toggle_src<=~commit_toggle_src;
        end
    end

    reg [4:0] event_meta,event_sync,event_seen;
    reg [95:0] cnn_data_meta,cnn_data_sync,cnn_data_cpu;
    reg [17:0] template_data_meta,template_data_sync,template_data_cpu;
    reg snapshot_cpu,job_cpu,cnn_cpu,template_cpu,commit_cpu;
    always @(posedge cpu_clk_i or negedge cpu_rst_n) begin
        if(!cpu_rst_n) begin
            event_meta<=0;event_sync<=0;event_seen<=0;
            cnn_data_meta<=0;cnn_data_sync<=0;cnn_data_cpu<=0;
            template_data_meta<=0;template_data_sync<=0;template_data_cpu<=0;
            snapshot_cpu<=0;job_cpu<=0;cnn_cpu<=0;template_cpu<=0;commit_cpu<=0;
        end else begin
            event_meta<={commit_toggle_src,template_toggle_src,cnn_toggle_src,job_toggle_src,snapshot_toggle_src};
            event_sync<=event_meta;
            event_seen<=event_sync;
            cnn_data_meta<=cnn_payload_src;cnn_data_sync<=cnn_data_meta;
            template_data_meta<=template_payload_src;template_data_sync<=template_data_meta;
            snapshot_cpu<=event_sync[0]^event_seen[0];
            job_cpu<=event_sync[1]^event_seen[1];
            cnn_cpu<=event_sync[2]^event_seen[2];
            template_cpu<=event_sync[3]^event_seen[3];
            commit_cpu<=event_sync[4]^event_seen[4];
            if(event_sync[2]^event_seen[2]) cnn_data_cpu<=cnn_data_sync;
            if(event_sync[3]^event_seen[3]) template_data_cpu<=template_data_sync;
        end
    end

    wire [5:0] command_key_cpu;
    wire job_authorized_cpu,event_valid_cpu;
    wire [3:0] template_slot_cpu,event_class_cpu;
    wire [31:0] firmware_signature_cpu,command_count_cpu,irq_count_cpu,isa_selftest_cpu;
    mn04_cpu5_control #(
        .CLOCK_HZ(CLOCK_HZ),.FIRMWARE_FILE(FIRMWARE_FILE),.DATA_FILE(DATA_FILE),
        .BABY_THRESHOLD(BABY_THRESHOLD),.KNOCK_THRESHOLD(KNOCK_THRESHOLD),
        .SIREN_THRESHOLD(SIREN_THRESHOLD),.CAR_THRESHOLD(CAR_THRESHOLD),
        .TEMPLATE_THRESHOLD(TEMPLATE_THRESHOLD)
    ) u_control (
        .clk(cpu_clk_i),.rst_n(cpu_rst_n),.key_n_i(key_sync),
        .boot_ready_i(boot_sync),.codec_ready_i(codec_sync),.recognition_i(recognition_sync),
        .capture_busy_i(capture_busy_sync),.recording_i(recording_sync),.alert_i(alert_sync),
        .snapshot_ready_i(snapshot_cpu),.job_done_i(job_cpu),
        .cnn_valid_i(cnn_cpu),.cnn_probabilities_i(cnn_data_cpu),
        .template_valid_i(template_cpu),.template_class_i(template_data_cpu[17:16]),
        .template_score_i(template_data_cpu[15:0]),.capture_category_i(category_sync),
        .template_slot_mask_i(slot_mask_sync),.template_commit_i(commit_cpu),
        .command_key_n_o(command_key_cpu),.job_authorized_o(job_authorized_cpu),
        .template_slot_o(template_slot_cpu),.event_valid_o(event_valid_cpu),
        .event_class_o(event_class_cpu),.firmware_signature_o(firmware_signature_cpu),
        .command_count_o(command_count_cpu),.irq_count_o(irq_count_cpu),.isa_selftest_o(isa_selftest_cpu)
    );

    // Return the supervisor's levels to the fabric clock domain. Event class
    // is bundled with a toggle so the one-cycle CPU pulse cannot be missed.
    reg event_toggle_cpu;
    always @(posedge cpu_clk_i or negedge cpu_rst_n) begin
        if(!cpu_rst_n) event_toggle_cpu<=0;
        else if(event_valid_cpu) event_toggle_cpu<=~event_toggle_cpu;
    end
    reg [5:0] command_meta,command_sync;
    reg authorized_meta,authorized_sync;
    reg [3:0] slot_meta,slot_sync;
    reg [31:0] signature_meta,signature_sync,count_meta,count_sync,irq_meta,irq_sync,selftest_meta,selftest_sync;
    reg event_toggle_meta,event_toggle_sync,event_toggle_seen;
    reg [3:0] event_class_meta,event_class_sync;
    always @(posedge src_clk_i or negedge rst_n) begin
        if(!rst_n) begin
            command_meta<=6'h3f;command_sync<=6'h3f;
            authorized_meta<=0;authorized_sync<=0;slot_meta<=0;slot_sync<=0;
            signature_meta<=0;signature_sync<=0;count_meta<=0;count_sync<=0;
            irq_meta<=0;irq_sync<=0;selftest_meta<=0;selftest_sync<=0;
            event_toggle_meta<=0;event_toggle_sync<=0;event_toggle_seen<=0;
            event_class_meta<=0;event_class_sync<=0;event_valid_o<=0;event_class_o<=0;
        end else if(!core_rst_n_i) begin
            command_meta<=6'h3f;command_sync<=6'h3f;
            authorized_meta<=0;authorized_sync<=0;slot_meta<=0;slot_sync<=0;
            signature_meta<=0;signature_sync<=0;count_meta<=0;count_sync<=0;
            irq_meta<=0;irq_sync<=0;selftest_meta<=0;selftest_sync<=0;
            event_toggle_meta<=0;event_toggle_sync<=0;event_toggle_seen<=0;
            event_class_meta<=0;event_class_sync<=0;event_valid_o<=0;event_class_o<=0;
        end else begin
            command_meta<=command_key_cpu;command_sync<=command_meta;
            authorized_meta<=job_authorized_cpu;authorized_sync<=authorized_meta;
            slot_meta<=template_slot_cpu;slot_sync<=slot_meta;
            signature_meta<=firmware_signature_cpu;signature_sync<=signature_meta;
            count_meta<=command_count_cpu;count_sync<=count_meta;
            irq_meta<=irq_count_cpu;irq_sync<=irq_meta;
            selftest_meta<=isa_selftest_cpu;selftest_sync<=selftest_meta;
            event_toggle_meta<=event_toggle_cpu;event_toggle_sync<=event_toggle_meta;
            event_toggle_seen<=event_toggle_sync;
            event_class_meta<=event_class_cpu;event_class_sync<=event_class_meta;
            event_valid_o<=event_toggle_sync^event_toggle_seen;
            if(event_toggle_sync^event_toggle_seen) event_class_o<=event_class_sync;
        end
    end
    assign command_key_n_o=command_sync;
    assign job_authorized_o=authorized_sync;
    assign template_slot_o=slot_sync;
    assign firmware_signature_o=signature_sync;
    assign command_count_o=count_sync;
    assign irq_count_o=irq_sync;
    assign isa_selftest_o=selftest_sync;
endmodule
