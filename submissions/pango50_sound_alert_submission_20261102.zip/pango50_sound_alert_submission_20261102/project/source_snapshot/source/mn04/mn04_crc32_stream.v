`timescale 1ns/1ps
// Streaming CRC-32 (IEEE 802.3, reflected, init 0xFFFFFFFF, final XOR).
// One byte takes eight clocks; the caller offers a byte only while ready_o is
// high.  crc_o is the final value for every byte accepted since start_i, which
// lets a protocol engine compare it against a trailer at any point.
module mn04_crc32_stream (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_i,
    input  wire [7:0]  data_i,
    input  wire        valid_i,
    output wire        ready_o,
    output reg         busy_o,
    output reg  [31:0] crc_o
);
    reg [31:0] raw_r;
    reg [7:0]  byte_r;
    reg [2:0]  bit_r;

    wire       lsb = raw_r[0] ^ byte_r[bit_r];
    wire [31:0] shifted = {1'b0, raw_r[31:1]};
    wire [31:0] next_crc = lsb ? (shifted ^ 32'hEDB88320) : shifted;
    wire [31:0] final_crc = ~next_crc;

    assign ready_o = !busy_o;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            raw_r <= 32'hFFFFFFFF;
            byte_r <= 8'h00;
            bit_r <= 3'd0;
            busy_o <= 1'b0;
            crc_o <= 32'h00000000;
        end else if (start_i) begin
            raw_r <= 32'hFFFFFFFF;
            bit_r <= 3'd0;
            busy_o <= 1'b0;
            crc_o <= 32'h00000000;
        end else if (!busy_o && valid_i) begin
            byte_r <= data_i;
            bit_r <= 3'd0;
            busy_o <= 1'b1;
        end else if (busy_o) begin
            raw_r <= next_crc;
            if (bit_r == 3'd7) begin
                busy_o <= 1'b0;
                crc_o <= final_crc;
            end else begin
                bit_r <= bit_r + 3'd1;
            end
        end
    end
endmodule
