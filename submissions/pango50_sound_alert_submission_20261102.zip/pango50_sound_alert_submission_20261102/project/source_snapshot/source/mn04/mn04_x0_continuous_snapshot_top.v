`timescale 1ns/1ps
// Shared x0 ring writer plus short/long snapshot copy. Two DDR masters:
// ring writes (board arbiter m3 after boot) and DMA reads/writes (m4).
module mn04_x0_continuous_snapshot_top #(
    parameter integer SHORT_HOP_FRAMES = 75,
    parameter integer ENABLE_LONG_WINDOW = 1,
    parameter integer CLASS_WINDOW_MODE = 0,
    parameter integer UNIFORM_120_WINDOW = 0
)(
    input  wire clk,
    input  wire rst_n,
    input  wire ddr_init_done_i,
    input  wire overflow_clear_i,
    input  wire [23:0] ring_base_byte_i,
    input  wire epoch_reset_i,
    input  wire signed [7:0] x0_i,
    input  wire x0_valid_i,
    input  wire recognition_enable_i,
    input  wire short_snapshot_accept_i,
    input  wire long_snapshot_accept_i,
    output wire short_snapshot_ready_o,
    output wire long_snapshot_ready_o,
    output wire [1:0] short_snapshot_mode_o,
    // 1 = the snapshot window carries no bin above the silence floor.
    output wire        window_quiet_o,
    output wire x0_overflow_o,
    output wire ring_drained_o,
    output wire snapshot_busy_o,
    output wire ring_frame_done_o,
    output wire [9:0] ring_next_frame_slot_o,
    output wire [27:0] ring_awaddr_o,
    output wire ring_awvalid_o,
    input  wire ring_awready_i,
    output wire [255:0] ring_wdata_o,
    output wire [31:0] ring_wstrb_o,
    output wire ring_wvalid_o,
    output wire ring_wlast_o,
    input  wire ring_wready_i,
    input  wire [1:0] ring_bresp_i,
    input  wire ring_bvalid_i,
    output wire ring_bready_o,
    output wire [27:0] dma_awaddr_o,
    output wire dma_awvalid_o,
    input  wire dma_awready_i,
    output wire [255:0] dma_wdata_o,
    output wire [31:0] dma_wstrb_o,
    output wire dma_wvalid_o,
    output wire dma_wlast_o,
    input  wire dma_wready_i,
    input  wire [1:0] dma_bresp_i,
    input  wire dma_bvalid_i,
    output wire dma_bready_o,
    output wire [27:0] dma_araddr_o,
    output wire dma_arvalid_o,
    input  wire dma_arready_i,
    input  wire [255:0] dma_rdata_i,
    input  wire [1:0] dma_rresp_i,
    input  wire dma_rvalid_i,
    output wire dma_rready_o
);
    wire frame_done, ring_drained, dma_busy, dma_done_short, dma_done_long;
    // Quantized Log-Mel values are not an independently calibrated sound-level
    // measurement. The former ad-hoc gate observed only two feature frames,
    // and updated only if a feature byte coincided with DMA completion. Its
    // reset value could therefore suppress unrelated subsequent CNN results.
    // Let the trained background class and calibrated event thresholds decide.
    // A future energy gate needs PCM calibration and snapshot-aligned metadata.
    assign window_quiet_o = 1'b0;
    wire [9:0] next_slot, snapshot_slot;
    assign ring_drained_o = ring_drained;
    assign ring_frame_done_o = frame_done;
    assign ring_next_frame_slot_o = next_slot;
    wire dma_start, dma_short;
    wire [1:0] dma_window_mode;
    mn04_x0_writer #(.N_FRAMES(1000),
        .CONTINUOUS(1)) u_ring_writer (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done_i),
        .overflow_clear_i(overflow_clear_i),
        .x0_valid_i(x0_valid_i), .x0_data_i(x0_i), .x0_ready_o(),
        .x0_base_byte_i(ring_base_byte_i),
        .done_o(), .frame_done_o(frame_done),
        .next_frame_slot_o(next_slot), .overflow_o(x0_overflow_o),
        .ddr_awaddr_o(ring_awaddr_o), .ddr_awvalid_o(ring_awvalid_o),
        .ddr_awready_i(ring_awready_i), .ddr_wdata_o(ring_wdata_o),
        .ddr_wstrb_o(ring_wstrb_o),
        .ddr_wvalid_o(ring_wvalid_o), .ddr_wlast_o(ring_wlast_o),
        .ddr_wready_i(ring_wready_i),
        .ddr_bresp_i(ring_bresp_i), .ddr_bvalid_i(ring_bvalid_i),
        .ddr_bready_o(ring_bready_o),
        .drained_o(ring_drained));
    generate if (CLASS_WINDOW_MODE) begin : g_class_windows
        mn04_class_window_snapshot_manager #(
            .UNIFORM_120_WINDOW(UNIFORM_120_WINDOW)) u_manager (
            .clk(clk),.rst_n(rst_n),.epoch_reset_i(epoch_reset_i),
            .recognition_enable_i(recognition_enable_i && !x0_overflow_o),
            .frame_done_i(frame_done),.next_frame_slot_i(next_slot),
            .snapshot_accept_i(short_snapshot_accept_i),
            .dma_busy_i(dma_busy),.dma_done_i(dma_done_short),
            .dma_start_o(dma_start),.dma_window_mode_o(dma_window_mode),
            .dma_next_frame_slot_o(snapshot_slot),
            .snapshot_ready_o(short_snapshot_ready_o),
            .snapshot_window_mode_o(short_snapshot_mode_o));
        assign dma_short=1'b1;
        assign long_snapshot_ready_o=1'b0;
    end else begin : g_legacy_windows
        mn04_snapshot_manager #(.SHORT_HOP_FRAMES(SHORT_HOP_FRAMES),
            .ENABLE_LONG_WINDOW(ENABLE_LONG_WINDOW)) u_manager (
            .clk(clk), .rst_n(rst_n), .epoch_reset_i(epoch_reset_i),
            .recognition_enable_i(recognition_enable_i && !x0_overflow_o),
            .frame_done_i(frame_done), .next_frame_slot_i(next_slot),
            .short_snapshot_accept_i(short_snapshot_accept_i),
            .long_snapshot_accept_i(long_snapshot_accept_i),
            .dma_busy_i(dma_busy), .dma_done_short_i(dma_done_short),
            .dma_done_long_i(dma_done_long), .dma_start_o(dma_start),
            .dma_short_o(dma_short), .dma_next_frame_slot_o(snapshot_slot),
            .short_snapshot_ready_o(short_snapshot_ready_o),
            .long_snapshot_ready_o(long_snapshot_ready_o));
        assign dma_window_mode=2'd0;
        assign short_snapshot_mode_o=2'd0;
    end endgenerate
    mn04_x0_snapshot_dma #(.CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
        .UNIFORM_120_WINDOW(UNIFORM_120_WINDOW)) u_snapshot_dma (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done_i),
        .ring_base_byte_i(ring_base_byte_i),
        .start_i(dma_start), .short_i(dma_short),
        .class_window_mode_i(dma_window_mode),
        .next_frame_slot_i(snapshot_slot), .busy_o(dma_busy),
        .done_o(), .done_short_o(dma_done_short),
        .done_long_o(dma_done_long),
        .ddr_awaddr_o(dma_awaddr_o), .ddr_awvalid_o(dma_awvalid_o),
        .ddr_awready_i(dma_awready_i), .ddr_wdata_o(dma_wdata_o),
        .ddr_wstrb_o(dma_wstrb_o),
        .ddr_wvalid_o(dma_wvalid_o), .ddr_wlast_o(dma_wlast_o),
        .ddr_wready_i(dma_wready_i),
        .ddr_bresp_i(dma_bresp_i), .ddr_bvalid_i(dma_bvalid_i),
        .ddr_bready_o(dma_bready_o),
        .ddr_araddr_o(dma_araddr_o), .ddr_arvalid_o(dma_arvalid_o),
        .ddr_arready_i(dma_arready_i), .ddr_rdata_i(dma_rdata_i),
        .ddr_rresp_i(dma_rresp_i), .ddr_rvalid_i(dma_rvalid_i),
        .ddr_rready_o(dma_rready_o));
    assign snapshot_busy_o = dma_busy;
endmodule
