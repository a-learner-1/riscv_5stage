`timescale 1ns/1ps
// Serial class-conditioned template aid for the six-class CNN head.
// One probability component is compared per clock. This keeps the L1 matcher
// off the CNN result's critical path while adding only a few microseconds.
module mn04_cnn_template_fuser #(
    parameter PROTOTYPE_FILE = "",
    parameter [23:0] VALID_MASK = 24'h000000,
    parameter integer TEMPLATE_WEIGHT_Q2 = 1
)(
    input wire clk,
    input wire rst_n,
    input wire start_i,
    input wire [95:0] probabilities_i,
    input wire [1:0] window_mode_i, // 0=100f, 1=120f, 2=150f
    output reg valid_o,
    output reg [95:0] fused_probabilities_o
);
    localparam integer SLOT_COUNT = 24;
    localparam integer WORDS_PER_SLOT = 6;
    localparam [2:0] ST_IDLE=3'd0, ST_CLASS_START=3'd1,
                     ST_READ=3'd2, ST_DIFF=3'd3,
                     ST_ACCUM=3'd4, ST_CLASS_DONE=3'd5;

    reg [15:0] prototype_mem [0:SLOT_COUNT*WORDS_PER_SLOT-1];
    reg [2:0] state_r;
    reg [1:0] mode_r;
    reg [95:0] probabilities_r;
    reg [2:0] class_index_r;
    reg [1:0] template_index_r;
    reg [2:0] probability_index_r;
    reg [17:0] distance_sum_r;
    reg [15:0] best_similarity_r;
    reg [4:0] slot_base_r;
    reg class_active_r;
    reg [15:0] prototype_probability_r, current_probability_r;
    reg [15:0] absolute_difference_r;

    reg active_class;
    reg [4:0] slot_base;
    reg [15:0] selected_prototype_probability;
    reg [15:0] difference_value;
    reg [17:0] complete_distance, half_distance;
    reg [15:0] current_similarity, best_with_current;
    reg [17:0] fused_numerator;
    integer prototype_word_index;

    initial begin
        if (PROTOTYPE_FILE != "") $readmemh(PROTOTYPE_FILE, prototype_mem);
    end

    // Mode-specific category-to-template mapping.
    always @* begin
        active_class = 1'b0;
        slot_base = 5'd0;
        case (mode_r)
            2'd0: begin
                if (VALID_MASK != 24'h03ffff) begin
                    if (class_index_r == 0) begin active_class=1'b1; slot_base=0; end
                    else if (class_index_r == 4) begin active_class=1'b1; slot_base=3; end
                    else if (class_index_r == 5) begin active_class=1'b1; slot_base=6; end
                end
            end
            2'd1: begin
                // Uniform 120-frame deployments use three templates for all
                // six classes, packed contiguously into slots 0..17.
                if (VALID_MASK == 24'h03ffff) begin
                    active_class = 1'b1;
                    slot_base = {class_index_r, 1'b0} + class_index_r;
                end else if (class_index_r == 0) begin
                    active_class=1'b1; slot_base=9;
                end else if (class_index_r == 3) begin
                    active_class=1'b1; slot_base=12;
                end
            end
            2'd2: begin
                if (VALID_MASK != 24'h03ffff) begin
                    if (class_index_r == 0) begin active_class=1'b1; slot_base=15; end
                    else if (class_index_r == 1) begin active_class=1'b1; slot_base=18; end
                    else if (class_index_r == 2) begin active_class=1'b1; slot_base=21; end
                end
            end
            default: begin active_class=1'b0; slot_base=0; end
        endcase

        prototype_word_index = ((slot_base_r + template_index_r) * WORDS_PER_SLOT) +
                               probability_index_r;
        selected_prototype_probability = prototype_mem[prototype_word_index];
        if (current_probability_r >= prototype_probability_r)
            difference_value = current_probability_r - prototype_probability_r;
        else
            difference_value = prototype_probability_r - current_probability_r;
        complete_distance = distance_sum_r + absolute_difference_r;
        half_distance = complete_distance >> 1;
        if (half_distance >= 18'd65535)
            current_similarity = 16'd0;
        else
            current_similarity = 16'd65535 - half_distance[15:0];
        best_with_current = (current_similarity > best_similarity_r) ?
                            current_similarity : best_similarity_r;
        fused_numerator = ((4 - TEMPLATE_WEIGHT_Q2) *
                           probabilities_r[class_index_r*16 +: 16]) +
                          (TEMPLATE_WEIGHT_Q2 * best_similarity_r);
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= ST_IDLE;
            mode_r <= 2'd0;
            probabilities_r <= 96'd0;
            class_index_r <= 3'd0;
            template_index_r <= 2'd0;
            probability_index_r <= 3'd0;
            distance_sum_r <= 18'd0;
            best_similarity_r <= 16'd0;
            slot_base_r <= 5'd0;
            class_active_r <= 1'b0;
            prototype_probability_r <= 16'd0;
            current_probability_r <= 16'd0;
            absolute_difference_r <= 16'd0;
            fused_probabilities_o <= 96'd0;
            valid_o <= 1'b0;
        end else begin
            valid_o <= 1'b0;
            case (state_r)
                ST_IDLE: begin
                    if (start_i) begin
                        probabilities_r <= probabilities_i;
                        mode_r <= window_mode_i;
                        fused_probabilities_o <= probabilities_i;
                        class_index_r <= 3'd0;
                        template_index_r <= 2'd0;
                        probability_index_r <= 3'd0;
                        distance_sum_r <= 18'd0;
                        best_similarity_r <= 16'd0;
                        slot_base_r <= 5'd0;
                        class_active_r <= 1'b0;
                        if (VALID_MASK == 24'd0) begin
                            valid_o <= 1'b1;
                        end else begin
                            state_r <= ST_CLASS_START;
                        end
                    end
                end

                ST_CLASS_START: begin
                    class_active_r <= active_class;
                    if (!active_class) begin
                        if (class_index_r == 3'd5) begin
                            valid_o <= 1'b1;
                            state_r <= ST_IDLE;
                        end else begin
                            class_index_r <= class_index_r + 1'b1;
                        end
                    end else begin
                        slot_base_r <= slot_base;
                        template_index_r <= 2'd0;
                        probability_index_r <= 3'd0;
                        distance_sum_r <= 18'd0;
                        best_similarity_r <= 16'd0;
                        state_r <= ST_READ;
                    end
                end

                ST_READ: begin
                    if (!class_active_r) begin
                        state_r <= ST_CLASS_DONE;
                    end else if (!VALID_MASK[slot_base_r + template_index_r]) begin
                        distance_sum_r <= 18'd0;
                        probability_index_r <= 3'd0;
                        if (template_index_r == 2'd2) begin
                            state_r <= ST_CLASS_DONE;
                        end else begin
                            template_index_r <= template_index_r + 1'b1;
                        end
                    end else begin
                        prototype_probability_r <= selected_prototype_probability;
                        current_probability_r <= probabilities_r[probability_index_r*16 +: 16];
                        state_r <= ST_DIFF;
                    end
                end

                ST_DIFF: begin
                    absolute_difference_r <= difference_value;
                    state_r <= ST_ACCUM;
                end

                ST_ACCUM: begin
                    if (probability_index_r == 3'd5) begin
                        if (best_with_current > best_similarity_r)
                            best_similarity_r <= best_with_current;
                        distance_sum_r <= 18'd0;
                        probability_index_r <= 3'd0;
                        if (template_index_r == 2'd2)
                            state_r <= ST_CLASS_DONE;
                        else
                            begin
                                template_index_r <= template_index_r + 1'b1;
                                state_r <= ST_READ;
                            end
                    end else begin
                        distance_sum_r <= complete_distance;
                        probability_index_r <= probability_index_r + 1'b1;
                        state_r <= ST_READ;
                    end
                end

                ST_CLASS_DONE: begin
                    if (best_similarity_r != 16'd0)
                        fused_probabilities_o[class_index_r*16 +: 16] <=
                            fused_numerator[17:2];
                    if (class_index_r == 3'd5) begin
                        valid_o <= 1'b1;
                        state_r <= ST_IDLE;
                    end else begin
                        class_index_r <= class_index_r + 1'b1;
                        state_r <= ST_CLASS_START;
                    end
                end

                default: state_r <= ST_IDLE;
            endcase
        end
    end
endmodule
