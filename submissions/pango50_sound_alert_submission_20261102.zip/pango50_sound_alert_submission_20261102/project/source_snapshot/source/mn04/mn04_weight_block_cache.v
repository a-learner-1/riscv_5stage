`timescale 1ns/1ps
// MN04 on-chip 4 KB weight block cache (GATE4 copy of
// senior_dbl_weight_block_cache.v, unchanged semantics).
module mn04_weight_block_cache #(
    parameter integer BLOCK_BYTES = 4096
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        load_start_i,
    input  wire [23:0] flash_base_i,
    output reg         loaded_o,
    output reg         qspi_start_o,
    output wire [23:0] qspi_addr_o,
    output wire [15:0] qspi_count_o,
    input  wire [7:0]  qspi_byte_i,
    input  wire        qspi_byte_valid_i,
    output wire        qspi_byte_ready_o,
    input  wire [11:0] weight_offset_i,
    input  wire        req_valid_i,
    output wire        req_ready_o,
    input  wire [17:0] term_index_i,
    output reg         rsp_valid_o,
    output wire [1:0]  byte_lane_o,
    output wire signed [7:0] w0_o, w1_o, w2_o, w3_o
);
    localparam integer NWORDS = BLOCK_BYTES/4;
    localparam integer WAW = (NWORDS <= 2) ? 1 : $clog2(NWORDS);
    reg [11:0] write_addr;
    reg [31:0] write_word_r;
    reg [1:0]  byte_lane_r;
    reg        loading;
    reg        rsp_d1;

    // Per-byte-lane distributed RAM arrays — four independent 8b-wide banks
    // so each read-address register copy drives a SEPARATE RAM instance.
    // This cuts the read_word[*] fanout from 1024 cells to 256 cells each,
    // resolving the >4 ns routing penalty on read_word[3] (fanout 255).
    reg [7:0] wmem_b0 [0:NWORDS-1];
    reg [7:0] wmem_b1 [0:NWORDS-1];
    reg [7:0] wmem_b2 [0:NWORDS-1];
    reg [7:0] wmem_b3 [0:NWORDS-1];

    // Four physically-independent read-address copies.  Each drives only its
    // own byte-lane RAM bank so PDS synthesis cannot merge them.
    reg [WAW-1:0] read_word_b0;
    reg [WAW-1:0] read_word_b1;
    reg [WAW-1:0] read_word_b2;
    reg [WAW-1:0] read_word_b3;

    assign qspi_addr_o       = flash_base_i;
    assign qspi_count_o      = BLOCK_BYTES[15:0];
    assign qspi_byte_ready_o = loading;
    assign req_ready_o       = loaded_o;

    wire [11:0] byte_addr = weight_offset_i + term_index_i[11:0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            loading <= 1'b0; loaded_o <= 1'b0; write_addr <= 12'd0;
            qspi_start_o <= 1'b0;
            rsp_valid_o <= 1'b0; rsp_d1 <= 1'b0;
            read_word_b0 <= 0; read_word_b1 <= 0;
            read_word_b2 <= 0; read_word_b3 <= 0;
            byte_lane_r <= 0;
        end else begin
            qspi_start_o <= 1'b0;
            rsp_valid_o  <= rsp_d1;
            rsp_d1       <= req_valid_i && loaded_o;

            if (load_start_i && !loading) begin
                loading <= 1'b1; loaded_o <= 1'b0;
                write_addr <= 12'd0; qspi_start_o <= 1'b1;
            end
            if (loading && qspi_byte_valid_i) begin
                write_word_r <= {qspi_byte_i, write_word_r[31:8]};
                if (write_addr[1:0] == 2'd3) begin
                    // Before the fourth byte shifts in, the previous three
                    // bytes occupy [31:8]; [7:0] belongs to the preceding word.
                    wmem_b0[write_addr[11:2]] <= write_word_r[15:8];
                    wmem_b1[write_addr[11:2]] <= write_word_r[23:16];
                    wmem_b2[write_addr[11:2]] <= write_word_r[31:24];
                    wmem_b3[write_addr[11:2]] <= qspi_byte_i;
                end
                if (write_addr == (BLOCK_BYTES-1)) begin
                    loading <= 1'b0; loaded_o <= 1'b1;
                end else begin
                    write_addr <= write_addr + 1'b1;
                end
            end

            if (loaded_o && req_valid_i) begin
                read_word_b0 <= byte_addr[11:2];
                read_word_b1 <= byte_addr[11:2];
                read_word_b2 <= byte_addr[11:2];
                read_word_b3 <= byte_addr[11:2];
                byte_lane_r <= byte_addr[1:0];
            end
        end
    end

    // GATE4 stream-align fix: word bytes + lane are COMBINATIONAL from the
    // held read_word_* / byte_lane_r, so w(term C) is valid during cycle C+2,
    // exactly when the engine's pair_valid fires for term C.
    // Each byte lane is served by a physically independent RAM bank + its
    // own read-address register, reducing per-net fanout 4×.
    assign byte_lane_o = byte_lane_r;
    assign w0_o = wmem_b0[read_word_b0];
    assign w1_o = wmem_b1[read_word_b1];
    assign w2_o = wmem_b2[read_word_b2];
    assign w3_o = wmem_b3[read_word_b3];
endmodule
