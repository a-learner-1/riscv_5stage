`timescale 1ns/1ps
// MN04 4-lane signed/unsigned int8 MAC (GATE4 adaptation of
// senior_dbl_shared_mac.v).  Adds uact_i: when high, the activation bytes are
// treated as UNSIGNED [0,255] (V1 unsigned chain), zero-extended into the
// product; when low they are signed int8.  Weight bytes are always signed.
// Product width 18-bit signed covers 255*127 and 128*127 exactly.
module mn04_shared_mac (
    input  wire        clk, input  wire rst_n,
    input  wire        uact_i,
    input  wire        start_i, input  wire signed [31:0] bias_i,
    input  wire [17:0] terms_i,
    input  wire signed [9:0] act0_i, act1_i, act2_i, act3_i,
    input  wire signed [7:0] w0_i, w1_i, w2_i, w3_i,
    input  wire [3:0]  lane_valid_i,
    input  wire        pair_valid_i, output wire pair_ready_o,
    output reg         busy_o, output reg done_o, output reg signed [31:0] sum_o
);
    reg [17:0] remaining_r;
    reg signed [17:0] p0_r, p1_r, p2_r, p3_r;
    reg [3:0]  lane_valid_r;
    reg        burst_pending_r;

    assign pair_ready_o = busy_o && (remaining_r != 0);

    // product per lane: unsigned-act mode -> {2'b0,act[7:0]} x w ; signed mode -> act10 x w
    wire signed [17:0] prod0 = uact_i ? ($signed({2'b00, act0_i[7:0]}) * $signed(w0_i))
                                      : ($signed(act0_i) * $signed(w0_i));
    wire signed [17:0] prod1 = uact_i ? ($signed({2'b00, act1_i[7:0]}) * $signed(w1_i))
                                      : ($signed(act1_i) * $signed(w1_i));
    wire signed [17:0] prod2 = uact_i ? ($signed({2'b00, act2_i[7:0]}) * $signed(w2_i))
                                      : ($signed(act2_i) * $signed(w2_i));
    wire signed [17:0] prod3 = uact_i ? ($signed({2'b00, act3_i[7:0]}) * $signed(w3_i))
                                      : ($signed(act3_i) * $signed(w3_i));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            remaining_r <= 0; busy_o <= 0; done_o <= 0; sum_o <= 0;
            p0_r <= 0; p1_r <= 0; p2_r <= 0; p3_r <= 0;
            lane_valid_r <= 0; burst_pending_r <= 0;
        end else begin
            done_o <= 0;
            if (start_i && !busy_o) begin
                sum_o <= bias_i;
                remaining_r <= terms_i;
                busy_o <= (terms_i != 0);
                lane_valid_r <= 0; burst_pending_r <= 0;
                if (terms_i == 0) done_o <= 1;
            end else if (burst_pending_r && (remaining_r == 0)) begin
                sum_o <= sum_o
                       + (lane_valid_r[0] ? p0_r : 18'sd0)
                       + (lane_valid_r[1] ? p1_r : 18'sd0)
                       + (lane_valid_r[2] ? p2_r : 18'sd0)
                       + (lane_valid_r[3] ? p3_r : 18'sd0);
                burst_pending_r <= 0; busy_o <= 0; done_o <= 1;
            end else if (pair_valid_i && pair_ready_o) begin
                p0_r <= prod0; p1_r <= prod1; p2_r <= prod2; p3_r <= prod3;
                lane_valid_r <= lane_valid_i;
                if (burst_pending_r)
                    sum_o <= sum_o
                           + (lane_valid_r[0] ? p0_r : 18'sd0)
                           + (lane_valid_r[1] ? p1_r : 18'sd0)
                           + (lane_valid_r[2] ? p2_r : 18'sd0)
                           + (lane_valid_r[3] ? p3_r : 18'sd0);
                burst_pending_r <= 1;
                remaining_r <= remaining_r
                             - {14'd0, lane_valid_i[3]} - {14'd0, lane_valid_i[2]}
                             - {14'd0, lane_valid_i[1]} - {14'd0, lane_valid_i[0]};
            end
        end
    end
endmodule
