`timescale 1ns/1ps
// Translate the one core's logical activation addresses into two disjoint
// DDR regions.  The frontend snapshot writer must use the same mapping.
// Long: 0x000000..0x18FFFF; short: 0x200000..0x38FFFF.
module mn04_dual_arena_addr (
    input  wire        short_context_i,
    input  wire [23:0] core_read_addr_i,
    input  wire [23:0] core_write_addr_i,
    output wire [23:0] ddr_read_addr_o,
    output wire [23:0] ddr_write_addr_o
);
    wire [23:0] offset = short_context_i ? 24'h200000 : 24'h000000;
    assign ddr_read_addr_o = core_read_addr_i + offset;
    assign ddr_write_addr_o = core_write_addr_i + offset;
endmodule
