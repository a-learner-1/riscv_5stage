`timescale 1ns/1ps
// Boundary between the MN04 core, dual-window scheduler, and alert/display
// backend. PCM, feature snapshots, DDR and QSPI are supplied by the board SoC.
// This module does not replace those missing board integrations.
module mn04_five_class_realtime_control #(
    parameter SOFTMAX_LUT_FILE="softmax_exp_q24.mem",
    parameter integer CONTINUE_WHILE_ALERT=1,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,
    input wire short_snapshot_ready_i,long_snapshot_ready_i,
    input wire core_busy_i,core_done_i,
    input wire core_logits_valid_i,
    input wire [39:0] core_logits_i,
    input wire template_result_valid_i,
    input wire [1:0] template_result_class_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire work_key_n_i,confirm_key_n_i,uart_rx_i,
    input wire template_preview_i,
    input wire [3:0] template_preview_class_i,
    input wire external_task_busy_i,
    input wire set_time_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    output wire core_start_o,
    output wire [8:0] core_start_op_o,core_end_op_o,
    output wire core_short_window_o,core_context_short_o,
    output wire short_snapshot_accept_o,long_snapshot_accept_o,
    output wire short_result_valid_o,long_result_valid_o,
    output wire motor_o,recognition_enable_o,work_mode_o,
    output wire panel_ready_o,panel_busy_o,
    output wire tft_nrst_o,tft_backlight_o,
    output wire tft_sclk_o,tft_mosi_o,tft_dc_o,tft_cs_n_o
);
    wire [79:0] probs;
    wire probs_valid,softmax_busy,alert_accept,confirm_pulse;
    reg result_short_r;

    // The context is stable throughout the final core operation. Retain it
    // while the shared softmax converts that operation's five logits.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) result_short_r <= 1'b0;
        else if (core_logits_valid_i) result_short_r <= core_context_short_o;
    end
    mn04_softmax_q16 #(.LUT_FILE(SOFTMAX_LUT_FILE),.N_CLASSES(5))
        softmax(.clk(clk),.rst_n(rst_n),
        .logits_valid_i(core_logits_valid_i),.logits_i(core_logits_i),
        .probs_valid_o(probs_valid),.probs_q16_o(probs),
        .busy_o(softmax_busy));
    mn04_dual_window_scheduler #(
        .CONTINUE_WHILE_ALERT(CONTINUE_WHILE_ALERT)) scheduler(
        .clk(clk),.rst_n(rst_n),
        .short_ready_i(short_snapshot_ready_i),
        .long_ready_i(long_snapshot_ready_i),
        .recognition_enable_i(recognition_enable_o),
        .alert_i(alert_accept),.confirmed_i(confirm_pulse),
        .core_busy_i(core_busy_i),.core_done_i(core_done_i),
        .core_start_o(core_start_o),.core_start_op_o(core_start_op_o),
        .core_end_op_o(core_end_op_o),
        .core_short_window_o(core_short_window_o),
        .core_context_short_o(core_context_short_o),
        .short_result_valid_o(short_result_valid_o),
        .long_result_valid_o(long_result_valid_o),
        .alert_latched_o(),
        .short_snapshot_accept_o(short_snapshot_accept_o),
        .long_snapshot_accept_o(long_snapshot_accept_o));
    v1_board_postcnn_top #(.FIVE_CLASS_MODE(1),.ONE_SHOT_MODE(1),
        .CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ),
        .RESET_CYCLES(RESET_CYCLES),
        .PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) backend(
        .clk(clk),.rst_n(rst_n),
        .work_key_n_i(work_key_n_i),
        .confirm_key_n_i(confirm_key_n_i),.uart_rx_i(uart_rx_i),
        .template_preview_i(template_preview_i),
        .template_preview_class_i(template_preview_class_i),
        .external_task_busy_i(external_task_busy_i),
        .probs_valid_i(probs_valid),.probs_q16_i({32'd0,probs}),
        .template_result_valid_i(template_result_valid_i),
        .template_result_class_i(template_result_class_i),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .short_window_i(result_short_r),
        .set_time_i(set_time_i),.set_hour_i(set_hour_i),
        .set_minute_i(set_minute_i),.set_second_i(set_second_i),
        .motor_o(motor_o),.recognition_enable_o(recognition_enable_o),
        .work_mode_o(work_mode_o),.alert_accept_o(alert_accept),
        .confirm_pulse_o(confirm_pulse),
        .panel_ready_o(panel_ready_o),.panel_busy_o(panel_busy_o),
        .tft_nrst_o(tft_nrst_o),.tft_backlight_o(tft_backlight_o),
        .tft_sclk_o(tft_sclk_o),.tft_mosi_o(tft_mosi_o),
        .tft_dc_o(tft_dc_o),.tft_cs_n_o(tft_cs_n_o));
endmodule
