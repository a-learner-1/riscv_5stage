`timescale 1ns/1ps
// One outstanding classic Wishbone transaction -> independent AXI4-Lite
// channels. AW and W may be accepted in either order; acknowledge only B/R.
module mn04_wishbone_axil_bridge(
    input wire clk,rst_n,
    input wire wb_cyc_i,wb_stb_i,wb_we_i,
    input wire [31:0] wb_addr_i,wb_data_i,
    input wire [3:0] wb_sel_i,
    output reg wb_ack_o,wb_err_o,
    output reg [31:0] wb_data_o,
    output reg [31:0] awaddr_o,araddr_o,wdata_o,
    output reg [3:0] wstrb_o,
    output reg awvalid_o,wvalid_o,arvalid_o,
    input wire awready_i,wready_i,arready_i,
    input wire bvalid_i,rvalid_i,
    input wire [1:0] bresp_i,rresp_i,
    input wire [31:0] rdata_i,
    output wire bready_o,rready_o
);
    reg [1:0] state;
    localparam IDLE=0,WRITE=1,READ=2,RELEASE=3;
    assign bready_o=state==WRITE && !awvalid_o && !wvalid_o;
    assign rready_o=state==READ && !arvalid_o;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=IDLE;wb_ack_o<=0;wb_err_o<=0;wb_data_o<=0;
            awaddr_o<=0;araddr_o<=0;wdata_o<=0;wstrb_o<=0;
            awvalid_o<=0;wvalid_o<=0;arvalid_o<=0;
        end else begin
            wb_ack_o<=0;wb_err_o<=0;
            if(awvalid_o && awready_i) awvalid_o<=0;
            if(wvalid_o && wready_i) wvalid_o<=0;
            if(arvalid_o && arready_i) arvalid_o<=0;
            case(state)
                IDLE: if(wb_cyc_i && wb_stb_i) begin
                    if(wb_we_i) begin
                        awaddr_o<=wb_addr_i;wdata_o<=wb_data_i;wstrb_o<=wb_sel_i;
                        awvalid_o<=1;wvalid_o<=1;state<=WRITE;
                    end else begin
                        araddr_o<=wb_addr_i;arvalid_o<=1;state<=READ;
                    end
                end
                WRITE: if(bready_o && bvalid_i) begin
                    wb_ack_o<=bresp_i==0;wb_err_o<=bresp_i!=0;state<=RELEASE;
                end
                READ: if(rready_o && rvalid_i) begin
                    wb_ack_o<=rresp_i==0;wb_err_o<=rresp_i!=0;
                    wb_data_o<=rdata_i;state<=RELEASE;
                end
                RELEASE: if(!wb_cyc_i || !wb_stb_i) state<=IDLE;
            endcase
        end
    end
endmodule
