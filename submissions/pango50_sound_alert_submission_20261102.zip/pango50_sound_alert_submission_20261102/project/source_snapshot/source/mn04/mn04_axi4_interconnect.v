`timescale 1ns/1ps
// Round-robin arbiter muxing five full-AXI4 (256-bit, single-beat) masters
// onto one full-AXI4 slave (mn04_axi4_ddr_bridge). This is the AXI4 successor
// to senior_dbl_ddr3_user_arbiter; it runs entirely in the DDR user clock
// domain.
//
// Each master is single-outstanding and holds awvalid/arvalid (and wvalid)
// until its ready. The arbiter grants one master, forwards its aw/w/ar
// channels to the slave, returns the slave's b/r responses to that master
// only, and releases the grant once the response handshake completes:
//   write = aw handshake + w handshake, then bvalid (master bready=1)
//   read  = ar handshake, then rvalid (master rready=1)
// Masters keep bready/rready high (single-outstanding => always can accept),
// so the response is a single beat and the grant drops after one b/r handshake.
module mn04_axi4_interconnect #(parameter integer ENABLE_M6=0) (
    input  wire clk, rst_n,
    // ---- master 0 ----
    input  wire [27:0] m0_awaddr, m0_araddr,
    input  wire [3:0]  m0_awlen,  m0_arlen,
    input  wire        m0_awvalid, m0_arvalid,
    output wire        m0_awready, m0_arready,
    input  wire [255:0] m0_wdata,
    input  wire [31:0]  m0_wstrb,
    input  wire        m0_wvalid, m0_wlast,
    output wire        m0_wready,
    output wire [1:0]  m0_bresp,
    output wire        m0_bvalid,
    input  wire        m0_bready,
    output wire [255:0] m0_rdata,
    output wire [1:0]  m0_rresp,
    output wire        m0_rlast, m0_rvalid,
    input  wire        m0_rready,
    // ---- master 1 ----
    input  wire [27:0] m1_awaddr, m1_araddr,
    input  wire [3:0]  m1_awlen,  m1_arlen,
    input  wire        m1_awvalid, m1_arvalid,
    output wire        m1_awready, m1_arready,
    input  wire [255:0] m1_wdata,
    input  wire [31:0]  m1_wstrb,
    input  wire        m1_wvalid, m1_wlast,
    output wire        m1_wready,
    output wire [1:0]  m1_bresp,
    output wire        m1_bvalid,
    input  wire        m1_bready,
    output wire [255:0] m1_rdata,
    output wire [1:0]  m1_rresp,
    output wire        m1_rlast, m1_rvalid,
    input  wire        m1_rready,
    // ---- master 2 ----
    input  wire [27:0] m2_awaddr, m2_araddr,
    input  wire [3:0]  m2_awlen,  m2_arlen,
    input  wire        m2_awvalid, m2_arvalid,
    output wire        m2_awready, m2_arready,
    input  wire [255:0] m2_wdata,
    input  wire [31:0]  m2_wstrb,
    input  wire        m2_wvalid, m2_wlast,
    output wire        m2_wready,
    output wire [1:0]  m2_bresp,
    output wire        m2_bvalid,
    input  wire        m2_bready,
    output wire [255:0] m2_rdata,
    output wire [1:0]  m2_rresp,
    output wire        m2_rlast, m2_rvalid,
    input  wire        m2_rready,
    // ---- master 3 ----
    input  wire [27:0] m3_awaddr, m3_araddr,
    input  wire [3:0]  m3_awlen,  m3_arlen,
    input  wire        m3_awvalid, m3_arvalid,
    output wire        m3_awready, m3_arready,
    input  wire [255:0] m3_wdata,
    input  wire [31:0]  m3_wstrb,
    input  wire        m3_wvalid, m3_wlast,
    output wire        m3_wready,
    output wire [1:0]  m3_bresp,
    output wire        m3_bvalid,
    input  wire        m3_bready,
    output wire [255:0] m3_rdata,
    output wire [1:0]  m3_rresp,
    output wire        m3_rlast, m3_rvalid,
    input  wire        m3_rready,
    // ---- master 4 ----
    input  wire [27:0] m4_awaddr, m4_araddr,
    input  wire [3:0]  m4_awlen,  m4_arlen,
    input  wire        m4_awvalid, m4_arvalid,
    output wire        m4_awready, m4_arready,
    input  wire [255:0] m4_wdata,
    input  wire [31:0]  m4_wstrb,
    input  wire        m4_wvalid, m4_wlast,
    output wire        m4_wready,
    output wire [1:0]  m4_bresp,
    output wire        m4_bvalid,
    input  wire        m4_bready,
    output wire [255:0] m4_rdata,
    output wire [1:0]  m4_rresp,
    output wire        m4_rlast, m4_rvalid,
    input  wire        m4_rready,
    // ---- master 5 (read-only: board-training capture) ----
    input  wire [27:0] m5_araddr,
    input  wire [3:0]  m5_arlen,
    input  wire        m5_arvalid,
    output wire        m5_arready,
    output wire [255:0] m5_rdata,
    output wire [1:0]  m5_rresp,
    output wire        m5_rlast, m5_rvalid,
    input  wire        m5_rready,
    // ---- master 6 (DDR template bank) ----
    input wire [27:0] m6_awaddr,m6_araddr,
    input wire [3:0] m6_awlen,m6_arlen,
    input wire m6_awvalid,m6_arvalid,
    output wire m6_awready,m6_arready,
    input wire [255:0] m6_wdata,
    input wire [31:0] m6_wstrb,
    input wire m6_wvalid,m6_wlast,
    output wire m6_wready,
    output wire [1:0] m6_bresp,
    output wire m6_bvalid,
    input wire m6_bready,
    output wire [255:0] m6_rdata,
    output wire [1:0] m6_rresp,
    output wire m6_rlast,m6_rvalid,
    input wire m6_rready,
    // ---- slave (toward the bridge) ----
    output wire [27:0] s_awaddr, s_araddr,
    output wire [3:0]  s_awlen,  s_arlen,
    output wire        s_awvalid, s_arvalid,
    input  wire        s_awready, s_arready,
    output wire [255:0] s_wdata,
    output wire [31:0]  s_wstrb,
    output wire        s_wvalid, s_wlast,
    input  wire        s_wready,
    input  wire [1:0]  s_bresp,
    input  wire        s_bvalid,
    output wire        s_bready,
    input  wire [255:0] s_rdata,
    input  wire [1:0]  s_rresp,
    input  wire        s_rlast, s_rvalid,
    output wire        s_rready
);
    // ---- packed master-side arrays ----
    wire [27:0] m_awaddr [0:6];
    wire [27:0] m_araddr [0:6];
    wire [3:0]  m_awlen  [0:6];
    wire [3:0]  m_arlen  [0:6];
    wire        m_awvalid[0:6];
    wire        m_arvalid[0:6];
    wire [255:0] m_wdata [0:6];
    wire [31:0]  m_wstrb [0:6];
    wire        m_wvalid [0:6];
    wire        m_wlast  [0:6];
    wire        m_bready [0:6];
    wire        m_rready [0:6];
    wire        m_awready[0:6];
    wire        m_wready [0:6];
    wire        m_arready[0:6];
    wire        m_bvalid [0:6];
    wire [1:0]  m_bresp  [0:6];
    wire        m_rvalid [0:6];
    wire [255:0] m_rdata [0:6];
    wire [1:0]  m_rresp  [0:6];
    wire        m_rlast  [0:6];

    assign m_awaddr[0] = m0_awaddr; assign m_awaddr[1] = m1_awaddr;
    assign m_awaddr[2] = m2_awaddr; assign m_awaddr[3] = m3_awaddr;
    assign m_awaddr[4] = m4_awaddr;
    assign m_araddr[0] = m0_araddr; assign m_araddr[1] = m1_araddr;
    assign m_araddr[2] = m2_araddr; assign m_araddr[3] = m3_araddr;
    assign m_araddr[4] = m4_araddr;
    assign m_awlen[0] = m0_awlen; assign m_awlen[1] = m1_awlen;
    assign m_awlen[2] = m2_awlen; assign m_awlen[3] = m3_awlen;
    assign m_awlen[4] = m4_awlen;
    assign m_arlen[0] = m0_arlen; assign m_arlen[1] = m1_arlen;
    assign m_arlen[2] = m2_arlen; assign m_arlen[3] = m3_arlen;
    assign m_arlen[4] = m4_arlen;
    assign m_awvalid[0] = m0_awvalid; assign m_awvalid[1] = m1_awvalid;
    assign m_awvalid[2] = m2_awvalid; assign m_awvalid[3] = m3_awvalid;
    assign m_awvalid[4] = m4_awvalid;
    assign m_arvalid[0] = m0_arvalid; assign m_arvalid[1] = m1_arvalid;
    assign m_arvalid[2] = m2_arvalid; assign m_arvalid[3] = m3_arvalid;
    assign m_arvalid[4] = m4_arvalid;
    assign m_wdata[0] = m0_wdata; assign m_wdata[1] = m1_wdata;
    assign m_wdata[2] = m2_wdata; assign m_wdata[3] = m3_wdata;
    assign m_wdata[4] = m4_wdata;
    assign m_wstrb[0] = m0_wstrb; assign m_wstrb[1] = m1_wstrb;
    assign m_wstrb[2] = m2_wstrb; assign m_wstrb[3] = m3_wstrb;
    assign m_wstrb[4] = m4_wstrb;
    assign m_wvalid[0] = m0_wvalid; assign m_wvalid[1] = m1_wvalid;
    assign m_wvalid[2] = m2_wvalid; assign m_wvalid[3] = m3_wvalid;
    assign m_wvalid[4] = m4_wvalid;
    assign m_wlast[0] = m0_wlast; assign m_wlast[1] = m1_wlast;
    assign m_wlast[2] = m2_wlast; assign m_wlast[3] = m3_wlast;
    assign m_wlast[4] = m4_wlast;
    assign m_bready[0] = m0_bready; assign m_bready[1] = m1_bready;
    assign m_bready[2] = m2_bready; assign m_bready[3] = m3_bready;
    assign m_bready[4] = m4_bready;
    assign m_rready[0] = m0_rready; assign m_rready[1] = m1_rready;
    assign m_rready[2] = m2_rready; assign m_rready[3] = m3_rready;
    assign m_rready[4] = m4_rready;
    // master 5 is read-only: its write channels are tied off
    assign m_awaddr[5] = 28'd0;   assign m_araddr[5] = m5_araddr;
    assign m_awlen[5]  = 4'd0;    assign m_arlen[5]  = m5_arlen;
    assign m_awvalid[5] = 1'b0;   assign m_arvalid[5] = m5_arvalid;
    assign m_wdata[5]  = 256'd0;
    assign m_wstrb[5]  = 32'd0;
    assign m_wvalid[5] = 1'b0;
    assign m_wlast[5]  = 1'b0;
    assign m_bready[5] = 1'b0;
    assign m_rready[5] = m5_rready;

    assign m_awaddr[6]=m6_awaddr;
    assign m_araddr[6]=m6_araddr;
    assign m_awlen[6]=m6_awlen;
    assign m_arlen[6]=m6_arlen;
    assign m_awvalid[6]=m6_awvalid;
    assign m_arvalid[6]=m6_arvalid;
    assign m_wdata[6]=m6_wdata;
    assign m_wstrb[6]=m6_wstrb;
    assign m_wvalid[6]=m6_wvalid;
    assign m_wlast[6]=m6_wlast;
    assign m_bready[6]=m6_bready;
    assign m_rready[6]=m6_rready;
    // ---- request vector + round-robin grant ----
    wire [6:0] req;
    assign req = { ENABLE_M6 && (m_awvalid[6] | m_arvalid[6]), m_awvalid[5] | m_arvalid[5],
                   m_awvalid[4] | m_arvalid[4],
                   m_awvalid[3] | m_arvalid[3],
                   m_awvalid[2] | m_arvalid[2],
                   m_awvalid[1] | m_arvalid[1],
                   m_awvalid[0] | m_arvalid[0] };

    reg [2:0] gnt;
    reg [2:0] gnt_nxt;
    reg       found;
    integer   k;
    always @(*) begin
        gnt_nxt = gnt;
        found   = 1'b0;
        for (k = 1; k <= 7 && !found; k = k + 1) begin
            if (req[(gnt + k) % 7]) begin
                gnt_nxt = (gnt + k) % 7;
                found   = 1'b1;
            end
        end
    end

    // ---- transaction lock ----
    reg busy;
    reg is_wr;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gnt   <= 3'd0;
            busy  <= 1'b0;
            is_wr <= 1'b0;
        end else if (!busy) begin
            if (|req) begin
                gnt   <= gnt_nxt;
                is_wr <= m_awvalid[gnt_nxt];
                busy  <= 1'b1;
            end
        end else begin
            if (is_wr) begin
                // write completes on the bvalid handshake (bready is held high)
                if (s_bvalid && s_bready) busy <= 1'b0;
            end else begin
                // read completes on the rvalid handshake (rready is held high)
                if (s_rvalid && s_rready) busy <= 1'b0;
            end
        end
    end

    // ---- forward the granted master's channels to the slave ----
    assign s_awvalid = busy && is_wr  && m_awvalid[gnt];
    assign s_awaddr  = m_awaddr[gnt];
    assign s_awlen   = m_awlen[gnt];
    assign s_wvalid  = busy && is_wr  && m_wvalid[gnt];
    assign s_wdata   = m_wdata[gnt];
    assign s_wstrb   = m_wstrb[gnt];
    assign s_wlast   = m_wlast[gnt];
    assign s_arvalid = busy && !is_wr && m_arvalid[gnt];
    assign s_araddr  = m_araddr[gnt];
    assign s_arlen   = m_arlen[gnt];

    // response acceptance: forward the granted master's ready (held high)
    assign s_bready  = busy && is_wr  && m_bready[gnt];
    assign s_rready  = busy && !is_wr && m_rready[gnt];

    // ---- return the slave's responses to the granted master only ----
    genvar i;
    generate
        for (i = 0; i < 7; i = i + 1) begin : gen_m
            assign m_awready[i] = (busy && is_wr  && gnt == i) ? s_awready : 1'b0;
            assign m_wready[i]  = (busy && is_wr  && gnt == i) ? s_wready  : 1'b0;
            assign m_arready[i] = (busy && !is_wr && gnt == i) ? s_arready : 1'b0;
            assign m_bvalid[i]  = (busy && is_wr  && gnt == i) ? s_bvalid  : 1'b0;
            assign m_bresp[i]   = s_bresp;
            assign m_rvalid[i]  = (busy && !is_wr && gnt == i) ? s_rvalid  : 1'b0;
            assign m_rdata[i]   = s_rdata;
            assign m_rresp[i]   = s_rresp;
            assign m_rlast[i]   = s_rlast;
        end
    endgenerate

    assign m0_awready = m_awready[0]; assign m1_awready = m_awready[1];
    assign m2_awready = m_awready[2]; assign m3_awready = m_awready[3];
    assign m4_awready = m_awready[4];
    assign m0_wready = m_wready[0]; assign m1_wready = m_wready[1];
    assign m2_wready = m_wready[2]; assign m3_wready = m_wready[3];
    assign m4_wready = m_wready[4];
    assign m0_arready = m_arready[0]; assign m1_arready = m_arready[1];
    assign m2_arready = m_arready[2]; assign m3_arready = m_arready[3];
    assign m4_arready = m_arready[4];
    assign m0_bvalid = m_bvalid[0]; assign m1_bvalid = m_bvalid[1];
    assign m2_bvalid = m_bvalid[2]; assign m3_bvalid = m_bvalid[3];
    assign m4_bvalid = m_bvalid[4];
    assign m0_bresp = m_bresp[0]; assign m1_bresp = m_bresp[1];
    assign m2_bresp = m_bresp[2]; assign m3_bresp = m_bresp[3];
    assign m4_bresp = m_bresp[4];
    assign m0_rvalid = m_rvalid[0]; assign m1_rvalid = m_rvalid[1];
    assign m2_rvalid = m_rvalid[2]; assign m3_rvalid = m_rvalid[3];
    assign m4_rvalid = m_rvalid[4];
    assign m0_rdata = m_rdata[0]; assign m1_rdata = m_rdata[1];
    assign m2_rdata = m_rdata[2]; assign m3_rdata = m_rdata[3];
    assign m4_rdata = m_rdata[4];
    assign m0_rresp = m_rresp[0]; assign m1_rresp = m_rresp[1];
    assign m2_rresp = m_rresp[2]; assign m3_rresp = m_rresp[3];
    assign m4_rresp = m_rresp[4];
    assign m0_rlast = m_rlast[0]; assign m1_rlast = m_rlast[1];
    assign m2_rlast = m_rlast[2]; assign m3_rlast = m_rlast[3];
    assign m4_rlast = m_rlast[4];
    assign m5_arready = m_arready[5];
    assign m5_rvalid = m_rvalid[5];
    assign m5_rdata  = m_rdata[5];
    assign m5_rresp  = m_rresp[5];
    assign m5_rlast  = m_rlast[5];
    assign m6_awready=m_awready[6];
    assign m6_arready=m_arready[6];
    assign m6_wready=m_wready[6];
    assign m6_bresp=m_bresp[6];
    assign m6_bvalid=m_bvalid[6];
    assign m6_rdata=m_rdata[6];
    assign m6_rresp=m_rresp[6];
    assign m6_rlast=m_rlast[6];
    assign m6_rvalid=m_rvalid[6];
endmodule
