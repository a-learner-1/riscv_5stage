`timescale 1ns/1ps
// Full-resolution template bytes live in external DDR, not 192 KiB of DRM.
// A 2 KiB tagged read cache serves variable-latency matcher/SD requests.
// Enrollment and SD restore are byte streams; a FIFO absorbs feature bursts.
module mn04_template_ddr_bank #(
    parameter [23:0] BASE_BYTE=24'hf00000,
    parameter integer MAP_BYTES=12800,MAP_COUNT=15
)(
    input wire clk,rst_n,ddr_ready_i,
    input wire load_we_i,
    input wire [17:0] load_addr_i,
    input wire [7:0] load_data_i,
    output wire writes_drained_o,
    output reg fault_o,
    input wire rd_req_i,
    input wire [17:0] rd_addr_i,
    output wire rd_valid_o,
    output wire signed [7:0] rd_data_o,
    output wire [27:0] awaddr_o,araddr_o,
    output wire awvalid_o,arvalid_o,
    input wire awready_i,arready_i,
    output wire [255:0] wdata_o,
    output wire [31:0] wstrb_o,
    output wire wvalid_o,wlast_o,
    input wire wready_i,
    input wire [1:0] bresp_i,rresp_i,
    input wire bvalid_i,rvalid_i,
    input wire [255:0] rdata_i,
    output wire bready_o,rready_o
);
    wire [23:0] load_byte_addr=BASE_BYTE+load_addr_i;
    wire [23:0] read_byte_addr=BASE_BYTE+rd_addr_i;
    wire fifo_ready,fifo_empty,byte_valid,byte_ready,writer_drained;
    wire [23:0] byte_addr;
    wire [7:0] byte_data;
    wire [31:0] cached_word;
    wire [1:0] cached_lane;
    wire cache_valid;
    reg read_pending;
    assign writes_drained_o=fifo_empty && writer_drained && !load_we_i;
    assign rd_valid_o=cache_valid && read_pending;
    assign rd_data_o=cached_word >> (cached_lane*8);
    mn04_wmerge_bridge #(.DEPTH(256),.STALL_THRESHOLD(256)) write_fifo(
        .clk(clk),.rst_n(rst_n),.wr_en_i(load_we_i),.wr_addr_i(load_byte_addr),
        .wr_data_i(load_data_i),.wr_ready_o(fifo_ready),.empty_o(fifo_empty),
        .mem_wr_en_o(byte_valid),.mem_wr_addr_o(byte_addr),.mem_wr_data_o(byte_data),
        .mem_wr_ready_i(byte_ready));
    mn04_ddr_act_byte_writer writer(
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(ddr_ready_i),
        .byte_valid_i(byte_valid),.byte_addr_i(byte_addr),.byte_data_i(byte_data),.byte_ready_o(byte_ready),
        .ddr_awaddr_o(awaddr_o),.ddr_awvalid_o(awvalid_o),.ddr_awready_i(awready_i),
        .ddr_wdata_o(wdata_o),.ddr_wstrb_o(wstrb_o),.ddr_wvalid_o(wvalid_o),
        .ddr_wlast_o(wlast_o),.ddr_wready_i(wready_i),.ddr_bresp_i(bresp_i),
        .ddr_bvalid_i(bvalid_i),.ddr_bready_o(bready_o),.drained_o(writer_drained));
    mn04_ddr_act_read_cache #(.LINE_BITS(6)) cache(
        .clk(clk),.rst_n(rst_n),.flush_i(1'b0),
        .write_invalidate_i(load_we_i),.write_addr_i(load_byte_addr),
        .writes_drained_i(writes_drained_o),
        .candidate_valid_i(1'b0),.candidate_addr_i(24'd0),.candidate_pad_i(1'b0),.candidate_ready_o(),
        .rd_req_valid_i(rd_req_i && !read_pending),.rd_byte_addr_i(read_byte_addr),.rd_req_pad_i(1'b0),
        .rd_rsp_valid_o(cache_valid),.rd_data_o(cached_word),.rd_lane_o(cached_lane),
        .conv_data_o(),.conv_lane_o(),.ddr_araddr_o(araddr_o),.ddr_arvalid_o(arvalid_o),
        .ddr_arready_i(arready_i),.ddr_rdata_i(rdata_i),.ddr_rresp_i(rresp_i),
        .ddr_rvalid_i(rvalid_i),.ddr_rready_o(rready_o));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin fault_o<=0;read_pending<=0;end
        else begin
            if(rd_valid_o) read_pending<=0;
            if(rd_req_i) begin
                if(read_pending || rd_addr_i>=MAP_BYTES*MAP_COUNT) fault_o<=1;
                else read_pending<=1;
            end
            if(load_we_i && (!fifo_ready || load_addr_i>=MAP_BYTES*MAP_COUNT)) fault_o<=1;
            if((bvalid_i && bresp_i!=0) || (rvalid_i && rresp_i!=0)) fault_o<=1;
        end
    end
endmodule
