`timescale 1ns/1ps
// RV32IM five-stage VexRiscv Lite: local instruction/RAM Wishbone, control
// transactions converted to AXI4-Lite. Sticky completion interrupts carry only
// scores/status; bulk audio, template and CNN traffic stays in hardware DMA.
module mn04_rv32im_control #(
    parameter integer CLOCK_HZ=100000000,
    parameter FIRMWARE_FILE="C:/Studying_file/pango50_sound_alert_v1/firmware/control_rv32im/build/control.mem",
    parameter [15:0] BABY_THRESHOLD=59637,KNOCK_THRESHOLD=47841,
    parameter [15:0] SIREN_THRESHOLD=49152,CAR_THRESHOLD=29491,
    parameter [15:0] TEMPLATE_THRESHOLD=26214
)(
    input wire clk,rst_n,
    input wire [5:0] key_n_i,
    input wire boot_ready_i,codec_ready_i,recognition_i,capture_busy_i,recording_i,alert_i,
    input wire snapshot_ready_i,job_done_i,
    input wire cnn_valid_i,
    input wire [95:0] cnn_probabilities_i,
    input wire template_valid_i,
    input wire [1:0] template_class_i,
    input wire [15:0] template_score_i,
    input wire [3:0] capture_category_i,
    input wire [14:0] template_slot_mask_i,
    input wire template_commit_i,
    output wire [5:0] command_key_n_o,
    output reg job_authorized_o,
    output reg [3:0] template_slot_o,
    output reg event_valid_o,
    output reg [3:0] event_class_o,
    output reg [31:0] firmware_signature_o,command_count_o,irq_count_o,
    output reg [31:0] isa_selftest_o
);
    wire tick_ms;
    wire [5:0] press;
    reg [5:0] pending_keys;
    reg [5:0] hold_ms[0:5];
    reg [31:0] milliseconds;
    v1_ms_tick #(.CLOCK_HZ(CLOCK_HZ)) timer(.clk(clk),.rst_n(rst_n),.tick_ms_o(tick_ms));
    genvar k;
    generate for(k=0;k<6;k=k+1) begin:g_keys
        v1_key_debounce key(.clk(clk),.rst_n(rst_n),.tick_ms_i(tick_ms),.key_n_i(key_n_i[k]),.press_o(press[k]));
        assign command_key_n_o[k]=(hold_ms[k]==0);
    end endgenerate
    reg [31:0] rom[0:2047],ram[0:1023];
    initial $readmemh(FIRMWARE_FILE,rom);
    wire icyc,istb,dcyc,dstb,dwe;
    wire [29:0] ia,da;
    wire [31:0] dw;
    wire [3:0] ds;
    reg iack,local_ack;
    reg [31:0] ir,local_data;
    wire [31:0] data_addr={da,2'b00};
    wire mmio=data_addr[31];
    wire wb_ack,wb_err;
    wire [31:0] wb_data;
    wire [31:0] awaddr,araddr,wdata,rdata;
    wire [3:0] wstrb;
    wire awvalid,arvalid,wvalid,bready,rready;
    reg awheld,wheld,bvalid,rvalid;
    reg [31:0] awaddr_r,wdata_r,rdata_r;
    reg [3:0] wstrb_r;
    wire awready=!awheld && !bvalid;
    wire wready=!wheld && !bvalid;
    wire arready=!rvalid;
    wire write_accept=awheld && wheld && !bvalid;
    wire [7:0] offset=awaddr_r[7:0];
    wire word_write=write_accept && wstrb_r==4'hf;
    wire [5:0] irq_clear=word_write && offset==8'h24 ? wdata_r[5:0] : 6'd0;
    wire [5:0] key_clear=word_write && offset==8'h08 ? wdata_r[5:0] : 6'd0;
    wire [5:0] irq_force=word_write && offset==8'h2c ? wdata_r[5:0] : 6'd0;
    wire [5:0] sources={template_commit_i,job_done_i,template_valid_i,
                         cnn_valid_i,snapshot_ready_i,|press};
    reg [5:0] irq_pending,irq_mask;
    reg [95:0] cnn_mailbox;
    reg [31:0] template_mailbox;
    reg [15:0] threshold[0:5];
    reg [15:0] template_threshold;
    reg [31:0] required_windows,max_gap_ms,overrun_count;
    wire interrupt_request=|(irq_pending & irq_mask);
    wire command_active=command_key_n_o!=6'h3f;
    integer n;
    assign rdata=rdata_r;
    mn04_wishbone_axil_bridge bus_bridge(
        .clk(clk),.rst_n(rst_n),.wb_cyc_i(dcyc && mmio),.wb_stb_i(dstb && mmio),
        .wb_we_i(dwe),.wb_addr_i(data_addr),.wb_data_i(dw),.wb_sel_i(ds),
        .wb_ack_o(wb_ack),.wb_err_o(wb_err),.wb_data_o(wb_data),
        .awaddr_o(awaddr),.araddr_o(araddr),.wdata_o(wdata),.wstrb_o(wstrb),
        .awvalid_o(awvalid),.wvalid_o(wvalid),.arvalid_o(arvalid),
        .awready_i(awready),.wready_i(wready),.arready_i(arready),
        .bvalid_i(bvalid),.rvalid_i(rvalid),.bresp_i(2'b00),.rresp_i(2'b00),
        .rdata_i(rdata),.bready_o(bready),.rready_o(rready));
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            iack<=0;local_ack<=0;ir<=0;local_data<=0;
            awheld<=0;wheld<=0;bvalid<=0;rvalid<=0;
            awaddr_r<=0;wdata_r<=0;wstrb_r<=0;rdata_r<=0;
            pending_keys<=0;irq_pending<=0;irq_mask<=0;milliseconds<=0;
            cnn_mailbox<=0;template_mailbox<=0;overrun_count<=0;
            firmware_signature_o<=0;command_count_o<=0;irq_count_o<=0;isa_selftest_o<=0;
            job_authorized_o<=0;template_slot_o<=0;event_valid_o<=0;event_class_o<=0;
            required_windows<=1;max_gap_ms<=2000;template_threshold<=TEMPLATE_THRESHOLD;
            threshold[0]<=65535;threshold[1]<=BABY_THRESHOLD;threshold[2]<=KNOCK_THRESHOLD;
            threshold[3]<=SIREN_THRESHOLD;threshold[4]<=65535;threshold[5]<=CAR_THRESHOLD;
            for(n=0;n<6;n=n+1) hold_ms[n]<=0;
        end else begin
            iack<=icyc && istb && !iack;
            if(icyc && istb && !iack) ir<=(ia<2048)?rom[ia[10:0]]:32'h0000006f;
            local_ack<=dcyc && dstb && !mmio && !local_ack;
            if(dcyc && dstb && !mmio && !local_ack) begin
                if(data_addr<8192) local_data<=rom[da[10:0]];
                else if(data_addr>=32'h10000 && data_addr<32'h11000) begin
                    local_data<=ram[da[9:0]];
                    if(dwe) for(n=0;n<4;n=n+1) if(ds[n]) ram[da[9:0]][n*8+:8]<=dw[n*8+:8];
                end else local_data<=0;
            end
            if(tick_ms) milliseconds<=milliseconds+1'b1;
            pending_keys<=(pending_keys & ~key_clear)|press;
            irq_pending<=(irq_pending & ~irq_clear)|sources|irq_force;
            if(cnn_valid_i) begin
                if(!irq_pending[2] || irq_clear[2]) cnn_mailbox<=cnn_probabilities_i;
                else overrun_count<=overrun_count+1'b1;
            end
            if(template_valid_i) begin
                if(!irq_pending[3] || irq_clear[3]) template_mailbox<={template_score_i,14'd0,template_class_i};
                else overrun_count<=overrun_count+1'b1;
            end
            if(job_done_i || !recognition_i || alert_i) job_authorized_o<=0;
            event_valid_o<=0;
            for(n=0;n<6;n=n+1) if(tick_ms && hold_ms[n]!=0) hold_ms[n]<=hold_ms[n]-1'b1;
            if(awvalid && awready) begin awheld<=1;awaddr_r<=awaddr;end
            if(wvalid && wready) begin wheld<=1;wdata_r<=wdata;wstrb_r<=wstrb;end
            if(bvalid && bready) bvalid<=0;
            if(rvalid && rready) rvalid<=0;
            if(write_accept) begin
                awheld<=0;wheld<=0;bvalid<=1;
                if(word_write) case(offset)
                    8'h0c: begin
                        for(n=0;n<6;n=n+1) if(wdata_r[n]) hold_ms[n]<=40;
                        command_count_o<=command_count_o+1'b1;
                    end
                    8'h14:firmware_signature_o<=wdata_r;
                    8'h24:irq_count_o<=irq_count_o+1'b1;
                    8'h28:irq_mask<=wdata_r[5:0];
                    8'h34:if(boot_ready_i && recognition_i && !alert_i) job_authorized_o<=wdata_r[0];
                    8'h40:begin event_valid_o<=1;event_class_o<=wdata_r[3:0];end
                    8'h4c:template_slot_o<=wdata_r[3:0];
                    8'h50:template_threshold<=wdata_r[15:0];
                    8'h54:required_windows<=wdata_r;
                    8'h58:max_gap_ms<=wdata_r;
                    8'h5c:isa_selftest_o<=wdata_r;
                    8'h80,8'h84,8'h88,8'h8c,8'h90,8'h94:threshold[(offset-8'h80)>>2]<=wdata_r[15:0];
                endcase
            end
            if(arvalid && arready) begin
                rvalid<=1;rdata_r<=0;
                case(araddr[7:0])
                    8'h00:rdata_r<={26'd0,pending_keys};
                    8'h04:rdata_r<={25'd0,command_active,alert_i,recording_i,capture_busy_i,recognition_i,codec_ready_i,boot_ready_i};
                    8'h10:rdata_r<=command_count_o;
                    8'h14:rdata_r<=firmware_signature_o;
                    8'h20:rdata_r<={26'd0,irq_pending};
                    8'h28:rdata_r<={26'd0,irq_mask};
                    8'h30:rdata_r<=irq_count_o;
                    8'h34:rdata_r<={31'd0,job_authorized_o};
                    8'h38:rdata_r<=milliseconds;
                    8'h3c:rdata_r<=template_mailbox;
                    8'h44:rdata_r<={28'd0,capture_category_i};
                    8'h48:rdata_r<={17'd0,template_slot_mask_i};
                    8'h4c:rdata_r<={28'd0,template_slot_o};
                    8'h50:rdata_r<={16'd0,template_threshold};
                    8'h54:rdata_r<=required_windows;
                    8'h58:rdata_r<=max_gap_ms;
                    8'h5c:rdata_r<=isa_selftest_o;
                    8'h60,8'h64,8'h68,8'h6c,8'h70,8'h74:rdata_r<={16'd0,cnn_mailbox[((araddr[7:0]-8'h60)>>2)*16+:16]};
                    8'h78:rdata_r<=overrun_count;
                    8'h80,8'h84,8'h88,8'h8c,8'h90,8'h94:rdata_r<={16'd0,threshold[(araddr[7:0]-8'h80)>>2]};
                endcase
            end
        end
    end
    VexRiscv cpu(.clk(clk),.reset(!rst_n),.externalResetVector(32'd0),
        .timerInterrupt(1'b0),.softwareInterrupt(1'b0),.externalInterruptArray({31'd0,interrupt_request}),
        .iBusWishbone_CYC(icyc),.iBusWishbone_STB(istb),.iBusWishbone_ACK(iack),
        .iBusWishbone_WE(),.iBusWishbone_ADR(ia),.iBusWishbone_DAT_MISO(ir),.iBusWishbone_DAT_MOSI(),
        .iBusWishbone_SEL(),.iBusWishbone_ERR(1'b0),.iBusWishbone_CTI(),.iBusWishbone_BTE(),
        .dBusWishbone_CYC(dcyc),.dBusWishbone_STB(dstb),.dBusWishbone_ACK(mmio?wb_ack:local_ack),
        .dBusWishbone_WE(dwe),.dBusWishbone_ADR(da),.dBusWishbone_DAT_MISO(mmio?wb_data:local_data),
        .dBusWishbone_DAT_MOSI(dw),.dBusWishbone_SEL(ds),.dBusWishbone_ERR(mmio && wb_err),
        .dBusWishbone_CTI(),.dBusWishbone_BTE());
endmodule
