`timescale 1ns/1ps
// Full AXI4 (256-bit, single-beat) slave -> Pango DDR3 stripped user port.
//
// Presents the standard five-channel AXI4 interface (aw/w/b/ar/r with
// valid/ready on every channel, wlast, bresp, rresp) and drives the fixed
// Pango controller port, which has NO WVALID / RREADY / B channel: write data
// is pulled beat-by-beat via WREADY, read data is pushed via RVALID and must
// be accepted.
//
// Addresses: the AXI side uses 28-bit BYTE addresses; the Pango port uses
// 28-bit addresses where byte address = addr<<2 and one beat covers 32 bytes.
// The bridge converts byte addr -> Pango word addr = {addr[27:5],3'b000} and
// passes wstrb/wdata through unchanged (the master already positions the byte
// in its 256-bit lane). Single-outstanding, single-beat only.
module mn04_axi4_ddr_bridge (
    input  wire        clk,
    input  wire        rst_n,
    // ---- full AXI4 slave ----
    input  wire [27:0] s_awaddr,
    input  wire [3:0]  s_awlen,
    input  wire        s_awvalid,
    output wire        s_awready,
    input  wire [255:0] s_wdata,
    input  wire [31:0]  s_wstrb,
    input  wire        s_wvalid,
    input  wire        s_wlast,
    output wire        s_wready,
    output wire [1:0]  s_bresp,
    output wire        s_bvalid,
    input  wire        s_bready,
    input  wire [27:0] s_araddr,
    input  wire [3:0]  s_arlen,
    input  wire        s_arvalid,
    output wire        s_arready,
    output wire [255:0] s_rdata,
    output wire [1:0]  s_rresp,
    output wire        s_rlast,
    output wire        s_rvalid,
    input  wire        s_rready,
    // ---- stripped Pango DDR user port (toward ddr3_host_top / mn04_ddr_behav) ----
    output wire [27:0] d_awaddr,
    output wire [3:0]  d_awlen,
    output wire        d_awvalid,
    input  wire        d_awready,
    output wire [255:0] d_wdata,
    output wire [31:0]  d_wstrb,
    input  wire        d_wready,
    output wire [27:0] d_araddr,
    output wire [3:0]  d_arlen,
    output wire        d_arvalid,
    input  wire        d_arready,
    input  wire [255:0] d_rdata,
    input  wire        d_rlast,
    input  wire        d_rvalid
);
    assign d_awlen = 4'd0;
    assign d_arlen = 4'd0;

    localparam [3:0] IDLE = 4'd0, W_AW = 4'd1, W_W = 4'd2, W_B = 4'd3,
                     R_AR = 4'd4, R_R = 4'd5, R_DATA = 4'd6;
    reg [2:0] state;
    reg       aw_lat, w_lat;
    reg [27:0] lat_awaddr, lat_araddr;
    reg [255:0] lat_wdata;
    reg [31:0]  lat_wstrb;
    reg [255:0] lat_rdata;

    // ready signals: accept a new transaction only when idle
    assign s_awready = (state == IDLE) && !aw_lat && !s_arvalid;
    assign s_wready  = (state == IDLE) && !w_lat && !s_arvalid;
    assign s_arready = (state == IDLE) && !aw_lat && !w_lat;

    // responses
    assign s_bvalid = (state == W_B);
    assign s_bresp  = 2'b00;
    assign s_rvalid = (state == R_DATA);
    assign s_rdata  = lat_rdata;
    assign s_rresp  = 2'b00;
    assign s_rlast  = (state == R_DATA);
    assign d_awaddr = {lat_awaddr[27:5], 3'b000};
    assign d_awvalid = (state == W_AW);
    assign d_wdata = lat_wdata;
    assign d_wstrb = lat_wstrb;
    assign d_araddr = {lat_araddr[27:5], 3'b000};
    assign d_arvalid = (state == R_AR);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state      <= IDLE;
            aw_lat     <= 1'b0; w_lat <= 1'b0;
            lat_awaddr <= 28'd0; lat_araddr <= 28'd0;
            lat_wdata  <= 256'd0; lat_wstrb <= 32'd0; lat_rdata <= 256'd0;
        end else begin
            case (state)
                IDLE: begin
                    // read priority (matches mn04_ddr_behav's read-over-write)
                    if (s_arvalid && s_arready) begin
                        lat_araddr <= s_araddr;
                        state      <= R_AR;
                    end else begin
                        if (s_awvalid && s_awready && !aw_lat) begin
                            aw_lat     <= 1'b1;
                            lat_awaddr <= s_awaddr;
                        end
                        if (s_wvalid && s_wready && !w_lat) begin
                            w_lat     <= 1'b1;
                            lat_wdata <= s_wdata;
                            lat_wstrb <= s_wstrb;
                        end
                        if ((aw_lat || (s_awvalid && s_awready)) &&
                            (w_lat  || (s_wvalid && s_wready))) begin
                            aw_lat <= 1'b0;
                            w_lat  <= 1'b0;
                            state  <= W_AW;
                        end
                    end
                end
                W_AW: begin
                    if (d_awready) state <= W_W;
                end
                W_W: begin
                    if (d_wready) state <= W_B;
                end
                W_B: begin
                    if (s_bready) state <= IDLE;
                end
                R_AR: begin
                    if (d_arready) state <= R_R;
                end
                R_R: begin
                    if (d_rvalid) begin
                        lat_rdata <= d_rdata;
                        state     <= R_DATA;
                    end
                end
                R_DATA: begin
                    if (s_rready) state <= IDLE;
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule
