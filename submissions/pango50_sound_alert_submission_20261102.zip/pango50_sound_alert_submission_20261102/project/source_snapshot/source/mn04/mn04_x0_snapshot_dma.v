`timescale 1ns/1ps
// Copy a stable 1 s or 10 s feature snapshot from the 1000-frame DDR ring
// into the corresponding MN04 activation arena. Copy order is oldest frame
// first, then all 128 mel bins: the producer can overwrite that oldest slot
// on its next 10 ms frame without corrupting the copy in progress.
module mn04_x0_snapshot_dma #(
    parameter [23:0] SHORT_BASE_BYTE = 24'h200000,
    parameter [23:0] LONG_BASE_BYTE  = 24'h000000,
    parameter integer CLASS_WINDOW_MODE = 0,
    parameter integer UNIFORM_120_WINDOW = 0
)(
    input  wire clk,
    input  wire rst_n,
    input  wire ddr_init_done_i,
    input  wire [23:0] ring_base_byte_i,
    input  wire start_i,
    input  wire short_i,
    input  wire [1:0] class_window_mode_i,
    input  wire [9:0] next_frame_slot_i,
    output wire busy_o,
    output reg done_o,
    output reg done_short_o,
    output reg done_long_o,
    output wire [27:0] ddr_awaddr_o,
    output wire ddr_awvalid_o,
    input  wire ddr_awready_i,
    output wire [255:0] ddr_wdata_o,
    output wire [31:0] ddr_wstrb_o,
    output wire ddr_wvalid_o,
    output wire ddr_wlast_o,
    input  wire ddr_wready_i,
    input  wire [1:0] ddr_bresp_i,
    input  wire ddr_bvalid_i,
    output wire ddr_bready_o,
    output wire [27:0] ddr_araddr_o,
    output wire ddr_arvalid_o,
    input  wire ddr_arready_i,
    input  wire [255:0] ddr_rdata_i,
    input  wire [1:0] ddr_rresp_i,
    input  wire ddr_rvalid_i,
    output wire ddr_rready_o
);
    localparam S_IDLE=3'd0, S_AR=3'd1, S_R=3'd2,
               S_W_ACCEPT=3'd3, S_W_DRAIN=3'd4;
    reg [2:0] state_r;
    reg short_r;
    reg [1:0] class_mode_r;
    reg [9:0] oldest_slot_r, frame_r;
    reg [6:0] mel_r;
    reg [7:0] byte_r;
    wire [9:0] n_frames = UNIFORM_120_WINDOW ? 10'd120 : CLASS_WINDOW_MODE ?
        ((class_mode_r == 2'd1) ? 10'd120 :
         (class_mode_r == 2'd2) ? 10'd150 : 10'd100) :
        (short_r ? 10'd100 : 10'd1000);
    wire [9:0] start_n_frames = UNIFORM_120_WINDOW ? 10'd120 : CLASS_WINDOW_MODE ?
        ((class_window_mode_i == 2'd1) ? 10'd120 :
         (class_window_mode_i == 2'd2) ? 10'd150 : 10'd100) :
        (short_i ? 10'd100 : 10'd1000);
    wire [10:0] oldest_sum = {1'b0,next_frame_slot_i} + 11'd1000 -
                             {1'b0,start_n_frames};
    reg  [23:0] snap_addr_r;   // snapshot read address accumulator
    reg  [9:0]  source_slot_r; // ring slot of the current frame
    wire [9:0] oldest_slot_new = (oldest_sum >= 11'd1000) ?
                                 (oldest_sum - 11'd1000) : oldest_sum[9:0];
    // The snapshot read address is carried as an ACCUMULATOR.  The per-beat step
    // is exactly +1000 (mel_r++), and a frame rollover is +1 in the ring slot
    // with mel_r back to 0.  Building ring_base + mel_r*1000 + slot combinationally
    // put a multiply plus add/compare/subtract on the clock bridge's araddr input
    // (12 levels; it became the worst core200_clk cone once the core was fixed).
    wire [9:0] source_slot_next = (source_slot_r == 10'd999) ?
                                  10'd0 : (source_slot_r + 10'd1);
    wire [23:0] target_byte = (short_r ? SHORT_BASE_BYTE : LONG_BASE_BYTE) +
                              mel_r * n_frames + frame_r;
    assign ddr_araddr_o = {4'b0, snap_addr_r};
    assign ddr_arvalid_o = state_r == S_AR;
    assign ddr_rready_o = 1'b1;   // single-outstanding read: always accept
    assign busy_o = state_r != S_IDLE;

    wire byte_ready, writer_drained;
    mn04_ddr_act_byte_writer u_byte_writer (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done_i),
        .byte_valid_i(state_r == S_W_ACCEPT),
        .byte_addr_i(target_byte), .byte_data_i(byte_r),
        .byte_ready_o(byte_ready), .ddr_awaddr_o(ddr_awaddr_o),
        .ddr_awvalid_o(ddr_awvalid_o), .ddr_awready_i(ddr_awready_i),
        .ddr_wdata_o(ddr_wdata_o), .ddr_wstrb_o(ddr_wstrb_o),
        .ddr_wvalid_o(ddr_wvalid_o), .ddr_wlast_o(ddr_wlast_o),
        .ddr_wready_i(ddr_wready_i),
        .ddr_bresp_i(ddr_bresp_i), .ddr_bvalid_i(ddr_bvalid_i),
        .ddr_bready_o(ddr_bready_o), .drained_o(writer_drained));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= S_IDLE;
            short_r <= 0;
            class_mode_r <= 0;
            oldest_slot_r <= 0;
            frame_r <= 0;
            mel_r <= 0;
            snap_addr_r <= 24'd0;
            source_slot_r <= 10'd0;
            byte_r <= 0;
            done_o <= 0;
            done_short_o <= 0;
            done_long_o <= 0;
        end else begin
            done_o <= 0;
            done_short_o <= 0;
            done_long_o <= 0;
            case (state_r)
                S_IDLE: if (start_i && ddr_init_done_i) begin
                    short_r <= short_i;
                    class_mode_r <= class_window_mode_i;
                    oldest_slot_r <= oldest_slot_new;
                    frame_r <= 0;
                    mel_r <= 0;
                    // frame 0, mel 0: read base = ring_base + oldest slot
                    source_slot_r <= oldest_slot_new;
                    snap_addr_r <= ring_base_byte_i + {14'd0, oldest_slot_new};
                    state_r <= S_AR;
                end
                S_AR: if (ddr_arready_i) state_r <= S_R;
                S_R: if (ddr_rvalid_i) begin
                    byte_r <= ddr_rdata_i[8*snap_addr_r[4:0] +: 8];
                    state_r <= S_W_ACCEPT;
                end
                S_W_ACCEPT: if (byte_ready) state_r <= S_W_DRAIN;
                S_W_DRAIN: if (writer_drained) begin
                    if (mel_r == 7'd127) begin
                        mel_r <= 0;
                        if (frame_r == n_frames - 10'd1) begin
                            done_o <= 1;
                            if (short_r) done_short_o <= 1;
                            else done_long_o <= 1;
                            state_r <= S_IDLE;
                        end else begin
                            // mel back to 0 and the ring slot advances by one
                            source_slot_r <= source_slot_next;
                            snap_addr_r <= ring_base_byte_i + {14'd0, source_slot_next};
                            frame_r <= frame_r + 1'b1;
                            state_r <= S_AR;
                        end
                    end else begin
                        snap_addr_r <= snap_addr_r + 24'd1000;  // next mel bin
                        mel_r <= mel_r + 1'b1;
                        state_r <= S_AR;
                    end
                end
                default: state_r <= S_IDLE;
            endcase
        end
    end
endmodule
