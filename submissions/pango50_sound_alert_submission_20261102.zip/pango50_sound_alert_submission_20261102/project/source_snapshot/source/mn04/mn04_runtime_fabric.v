`timescale 1ns/1ps
// One MN04 inference core (five- or eight-class image), shared DDR, QSPI boot,
// continuous x0 capture, optional template matching/update, and two frozen
// activation arenas. All ports below run on DDR user clock.
module mn04_runtime_fabric #(
    parameter OP_FILE="op_desc_five_class.mem",
    parameter [23:0] LUTS_BASE=24'd799858,
    parameter [23:0] FLASH_IMAGE_BASE=24'h400000,
    parameter [23:0] IMAGE_BYTES=24'd811890,
    parameter [31:0] IMAGE_CHECKSUM_EXPECTED=32'h053e2a11,
    parameter FAST_BYTES=0,
    parameter CACHE_LINE_BITS=9,
    parameter SHORT_HOP_FRAMES=75,
    parameter ENABLE_LONG_WINDOW=1,
    parameter integer CLASS_WINDOW_MODE=0,
    parameter integer UNIFORM_120_WINDOW=0,
    parameter N_CLASSES=5,
    parameter integer CAPTURE_CLOCK_HZ=100000000,
    parameter integer CAPTURE_BAUD=115200,
    parameter integer CAPTURE_TX_FIFO_DEPTH=256,
    parameter integer CAPTURE_DIAGNOSTICS=0,
    parameter integer ENABLE_TEMPLATE_CAPTURE=0,
    parameter integer ENABLE_LOCAL_TEMPLATE_ENROLLMENT=0,
    parameter integer ENABLE_SD_TEMPLATE_STORAGE=0,
    parameter integer CNN_CLASS_COUNT=8,
    parameter integer TEMPLATE_MAPS_PER_CLASS=2,
    parameter integer TEMPLATE_DDR_STORAGE=0,
    parameter integer CPU_TEMPLATE_SLOT_SELECT=0,
    parameter TEMPLATE_FILE="",
    parameter integer TEMPLATE_DOORBELL_MAPS=0,
    parameter integer TEMPLATE_SMOKE_ALARM_MAPS=0,
    parameter integer TEMPLATE_GAS_CO_ALARM_MAPS=0,
    parameter [3*TEMPLATE_MAPS_PER_CLASS-1:0] TEMPLATE_INITIAL_VALID_MASK=0,
    parameter [15:0] TEMPLATE_THRESHOLD_Q15=16'd26214,
    parameter integer TEMPLATE_CENTER_ALPHA_Q4=16,
    parameter integer TEMPLATE_FLASH_LOAD=0,
    parameter [23:0] TEMPLATE_FLASH_BASE=24'h610080,
    parameter [23:0] TEMPLATE_CONTAINER_BYTES=24'd104961
)(
    input wire clk,rst_n,
    input wire boot_start_i,
    input wire signed [7:0] x0_i,
    input wire x0_valid_i,
    input wire pcm_overflow_i,
    input wire signed [15:0] capture_pcm_debug_i,
    input wire capture_pcm_debug_valid_i,
    input wire recognition_enable_i,
    input wire short_snapshot_accept_i,long_snapshot_accept_i,
    output wire short_snapshot_ready_o,long_snapshot_ready_o,
    output wire [1:0] short_snapshot_mode_o,
    output wire x0_overflow_o,boot_init_done_o,
    input wire core_start_i,
    input wire [8:0] core_start_op_i,core_end_op_i,
    input wire core_short_window_i,core_context_short_i,
    input wire [1:0] core_class_window_mode_i,
    output wire core_busy_o,core_done_o,core_logits_valid_o,
    output wire [8*N_CLASSES-1:0] core_logits_o,
    output wire window_quiet_o,
    output wire template_result_valid_o,
    output wire [1:0] template_result_class_o,
    output wire [15:0] template_result_score_q15_o,
    output wire display_asset_we_o,
    output wire [14:0] display_asset_addr_o,
    output wire [7:0] display_asset_data_o,
    output wire [23:0] boot_flash_rd_addr_o,core_flash_rd_addr_o,
    input wire [7:0] boot_flash_rd_data_i,core_flash_rd_data_i,
    output wire qspi_cs_o,qspi_sck_o,qspi_mosi_o,
    input wire qspi_miso_i,
    input wire uart_rx_i,
    input wire sd_card_detect_n_i,
    input wire sd_miso_i,
    output wire sd_clk_o,sd_cs_n_o,sd_mosi_o,
    input wire template_capture_category_advance_i,
    input wire template_capture_start_i,
    input wire template_capture_stop_i,
    input wire template_capture_mode_i,
    output wire uart_tx_o,
    output wire capture_task_busy_o,
    output wire capture_recording_o,
    output wire [95:0] template_diag_o,
    output wire [3:0] capture_selected_category_o,
    input wire [3:0] cpu_template_slot_i,
    output wire [14:0] cpu_template_slot_mask_o,
    output wire cpu_template_commit_o,
    output wire [23:0] capture_ring_base_o,
    output wire [27:0] ddr_awaddr_o,ddr_araddr_o,
    output wire [3:0] ddr_awlen_o,ddr_arlen_o,
    output wire ddr_awvalid_o,ddr_arvalid_o,
    input wire ddr_awready_i,ddr_arready_i,
    output wire [255:0] ddr_wdata_o,
    output wire [31:0] ddr_wstrb_o,
    output wire ddr_wvalid_o,ddr_wlast_o,
    input wire ddr_wready_i,
    input wire [1:0] ddr_bresp_i,
    input wire ddr_bvalid_i,
    output wire ddr_bready_o,
    input wire [255:0] ddr_rdata_i,
    input wire [1:0] ddr_rresp_i,
    input wire ddr_rlast_i,ddr_rvalid_i,
    output wire ddr_rready_o
);
    localparam [27:0] WEIGHT_BASE_WORD=28'h100000;
    localparam integer TEMPLATE_MAP_COUNT=3*TEMPLATE_MAPS_PER_CLASS;
    localparam integer TEMPLATE_MAP_INDEX_W=$clog2(TEMPLATE_MAP_COUNT);
    localparam integer TEMPLATE_MAP_BYTES=TEMPLATE_MAP_COUNT*128*100;
    localparam integer DISPLAY_ASSET_BYTES=3*(64*64*2 + 16*72);
    wire update_holds_qspi;
    // An in-progress template update owns QSPI and must not race the compute
    // weight reader or start a new inference job.
    wire sd_store_busy,sd_store_boot_done;
    wire template_writes_drained,template_bank_fault;
    reg template_commit_pending;
    wire [TEMPLATE_MAP_COUNT-1:0] sd_template_valid_mask;
    wire recognition_enable_eff = recognition_enable_i && !update_holds_qspi &&
                                  !sd_store_busy && !template_commit_pending;
    wire core_start_eff = core_start_i && !update_holds_qspi && !sd_store_busy && !template_commit_pending;
    wire boot_cs,boot_sck,boot_mosi,core_cs,core_sck,core_mosi;
    wire model_boot_done;
    wire template_load_done,template_load_we;
    wire [17:0] template_load_addr;
    wire [7:0] template_load_data;
    wire matcher_load_we;
    wire [17:0] matcher_load_addr;
    wire signed [7:0] matcher_load_data;
    wire local_template_load_we;
    wire [17:0] local_template_load_addr;
    wire signed [7:0] local_template_load_data;
    wire [TEMPLATE_MAP_COUNT-1:0] local_template_valid_mask;
    wire [TEMPLATE_MAP_COUNT-1:0] local_template_invalid_mask;
    wire sd_template_load_we;
    wire [17:0] sd_template_load_addr;
    wire signed [7:0] sd_template_load_data;
    wire template_external_rd_en;
    wire [17:0] template_external_rd_addr;
    wire signed [7:0] template_external_rd_data;
    wire [TEMPLATE_MAP_COUNT-1:0] template_valid_mask =
        (TEMPLATE_INITIAL_VALID_MASK | local_template_valid_mask |
         sd_template_valid_mask) &
        ~local_template_invalid_mask & {TEMPLATE_MAP_COUNT{!template_bank_fault}};
    wire template_enrollment_commit;
    wire [3:0] template_enrollment_category;
    wire [TEMPLATE_MAP_INDEX_W-1:0] template_enrollment_map;
    generate if(TEMPLATE_MAPS_PER_CLASS==5) begin:g_cpu_mask15
        assign cpu_template_slot_mask_o=template_valid_mask;
    end else begin:g_cpu_mask6
        assign cpu_template_slot_mask_o={3'd0,template_valid_mask[5:4],3'd0,
            template_valid_mask[3:2],3'd0,template_valid_mask[1:0]};
    end endgenerate
    assign cpu_template_commit_o=template_enrollment_commit;
    wire matcher_ddr_req;
    wire [17:0] matcher_ddr_addr;
    wire template_bank_rd_valid;
    wire signed [7:0] template_bank_rd_data;
    reg template_read_owner_sd;
    reg [TEMPLATE_MAP_INDEX_W-1:0] template_persist_map;
    wire template_persist_commit=template_commit_pending && template_writes_drained && !sd_store_busy;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin template_commit_pending<=0;template_persist_map<=0;template_read_owner_sd<=0;end
        else begin
            if(template_persist_commit) template_commit_pending<=0;
            if(template_enrollment_commit) begin
                template_commit_pending<=ENABLE_SD_TEMPLATE_STORAGE;
                template_persist_map<=template_enrollment_map;
            end
            if(template_external_rd_en || matcher_ddr_req)
                template_read_owner_sd<=template_external_rd_en;
        end
    end
    wire [27:0] tb_awaddr,tb_araddr;
    wire tb_awvalid,tb_arvalid,tb_awready,tb_arready;
    wire [255:0] tb_wdata,tb_rdata;
    wire [31:0] tb_wstrb;
    wire tb_wvalid,tb_wlast,tb_wready,tb_bvalid,tb_bready,tb_rvalid,tb_rready;
    wire [1:0] tb_bresp,tb_rresp;
    generate if(TEMPLATE_DDR_STORAGE) begin:g_template_ddr
        mn04_template_ddr_bank #(.MAP_COUNT(TEMPLATE_MAP_COUNT)) bank(
            .clk(clk),.rst_n(rst_n),.ddr_ready_i(model_boot_done),
            .load_we_i(matcher_load_we),.load_addr_i(matcher_load_addr),.load_data_i(matcher_load_data),
            .writes_drained_o(template_writes_drained),.fault_o(template_bank_fault),
            .rd_req_i(template_external_rd_en || matcher_ddr_req),
            .rd_addr_i(template_external_rd_en ? template_external_rd_addr : matcher_ddr_addr),
            .rd_valid_o(template_bank_rd_valid),.rd_data_o(template_bank_rd_data),
            .awaddr_o(tb_awaddr),.araddr_o(tb_araddr),.awvalid_o(tb_awvalid),.arvalid_o(tb_arvalid),
            .awready_i(tb_awready),.arready_i(tb_arready),.wdata_o(tb_wdata),.wstrb_o(tb_wstrb),
            .wvalid_o(tb_wvalid),.wlast_o(tb_wlast),.wready_i(tb_wready),
            .bresp_i(tb_bresp),.rresp_i(tb_rresp),.bvalid_i(tb_bvalid),.rvalid_i(tb_rvalid),
            .rdata_i(tb_rdata),.bready_o(tb_bready),.rready_o(tb_rready));
    end else begin:g_no_template_ddr
        assign template_writes_drained=1'b1;assign template_bank_fault=1'b0;
        assign template_bank_rd_valid=1'b0;assign template_bank_rd_data=0;
        assign tb_awaddr=0;assign tb_araddr=0;assign tb_awvalid=0;assign tb_arvalid=0;
        assign tb_wdata=0;assign tb_wstrb=0;assign tb_wvalid=0;assign tb_wlast=1;
        assign tb_bready=1;assign tb_rready=1;
    end endgenerate
    wire tpl_cs,tpl_sck,tpl_mosi;
    wire [23:0] model_boot_flash_addr,tpl_flash_addr;
    // Boot-time selector stage and runtime updater share the QSPI pins with the
    // model loader, template loader and compute-weight reader.
    wire boot_ready_eff, sel_phase_eff;
    wire sel_cs, sel_sck, sel_mosi;
    wire [23:0] sel_rd_addr, selected_template_base;
    wire [23:0] selected_slot_base, display_assets_base;
    wire upd_busy, upd_cs, upd_sck, upd_mosi;
    wire display_cs, display_sck, display_mosi;
    wire [23:0] display_flash_addr;
    wire display_load_done, display_load_we;
    wire [16:0] display_load_addr;
    wire [7:0] display_load_data;
    wire template_loader_selected = boot_ready_eff && !template_load_done;
    wire display_loader_selected = boot_ready_eff && template_load_done && !display_load_done;
    // Readiness is a boot epoch, not the template writer's current idle flag.
    // A runtime enrollment can temporarily deassert writes_drained. Retracting
    // boot readiness then reset the frontend/ring writer and returned master 3
    // to the bootloader halfway through a live capture.
    reg boot_ready_latched;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) boot_ready_latched<=1'b0;
        else if(boot_ready_eff && template_load_done && display_load_done &&
                template_writes_drained && sd_store_boot_done)
            boot_ready_latched<=1'b1;
    end
    assign boot_init_done_o = boot_ready_latched;
    assign qspi_cs_o = !model_boot_done ? boot_cs :
                       sel_phase_eff ? sel_cs :
                       upd_busy ? upd_cs :
                       template_loader_selected ? tpl_cs :
                       display_loader_selected ? display_cs : core_cs;
    assign qspi_sck_o = !model_boot_done ? boot_sck :
                        sel_phase_eff ? sel_sck :
                        upd_busy ? upd_sck :
                        template_loader_selected ? tpl_sck :
                        display_loader_selected ? display_sck : core_sck;
    assign qspi_mosi_o = !model_boot_done ? boot_mosi :
                         sel_phase_eff ? sel_mosi :
                         upd_busy ? upd_mosi :
                         template_loader_selected ? tpl_mosi :
                         display_loader_selected ? display_mosi : core_mosi;
    assign boot_flash_rd_addr_o = sel_phase_eff ? sel_rd_addr :
                                  (template_loader_selected ? tpl_flash_addr :
                                   (display_loader_selected ? display_flash_addr :
                                                              model_boot_flash_addr));
    assign display_asset_we_o = display_load_we && (display_load_addr < DISPLAY_ASSET_BYTES);
    assign display_asset_addr_o = display_load_addr[14:0];
    assign display_asset_data_o = display_load_data;

    wire [27:0] boot_awaddr,ring_awaddr,dma_awaddr,dma_araddr;
    wire boot_awvalid,ring_awvalid,dma_awvalid,dma_arvalid;
    wire boot_awready,ring_awready,dma_awready,dma_arready;
    wire [255:0] boot_wdata,ring_wdata,dma_wdata,dma_rdata;
    wire [31:0] boot_wstrb,ring_wstrb,dma_wstrb;
    wire boot_wvalid,ring_wvalid,dma_wvalid,boot_wlast,ring_wlast,dma_wlast;
    wire boot_wready,ring_wready,dma_wready,dma_rvalid;
    wire [1:0] boot_bresp,ring_bresp,dma_bresp;
    wire boot_bvalid,ring_bvalid,dma_bvalid;
    wire boot_bready,ring_bready,dma_bready;
    wire [1:0] dma_rresp;
    wire dma_rready;
    // Keep writer input aligned to complete 128-byte frontend frames. When the
    // top-level task gate resets the audio frontend, restart phase tracking at
    // zero so its first post-wakeup feature frame is written from bin 0.
    wire capture_engine_busy;
    assign capture_task_busy_o=capture_engine_busy || template_commit_pending || sd_store_busy;
    wire capture_freeze;
    wire capture_stream_phase;
    wire snapshot_busy;
    wire ring_drained, ring_frame_done;
    reg freeze_active;
    reg task_aligned;
    reg [6:0] source_phase;
    reg live_ring_bank_r, live_ring_bank_d;
    reg live_ring_aligned_r;
    wire source_boundary = (source_phase == 7'd0);
    wire task_requested = recognition_enable_eff || capture_task_busy_o;
    wire task_frame_active = task_requested && (task_aligned || source_boundary);
    wire pass_ring_x0 = task_frame_active &&
        (capture_stream_phase ?
            capture_recording_o :
            ((!freeze_active && !(capture_freeze && source_boundary)) ||
             (freeze_active && !capture_freeze && source_boundary)));
    // Template matching consumes the live stream independently of the frozen
    // local DDR capture, so it can continue while the selected category is held.
    wire pass_matcher_x0 = task_frame_active && recognition_enable_eff;
    wire [23:0] active_ring_base = capture_stream_phase ? capture_ring_base_o :
                                   (live_ring_bank_r ? 24'h520000 : 24'h500000);
    wire ring_epoch_reset = live_ring_bank_r ^ live_ring_bank_d;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            source_phase <= 0;
            freeze_active <= 0;
            task_aligned <= 0;
            live_ring_bank_r <= 0;
            live_ring_bank_d <= 0;
            live_ring_aligned_r <= 0;
        end else begin
            live_ring_bank_d <= live_ring_bank_r;
            if (capture_stream_phase) live_ring_bank_r <= 1'b1;
            else if (!task_requested && ring_drained && !snapshot_busy)
                live_ring_bank_r <= 1'b0;
            if (!capture_stream_phase) live_ring_aligned_r <= 1'b0;
            else if (source_boundary) live_ring_aligned_r <= 1'b1;
            if (!task_requested) source_phase <= 7'd0;
            else if (x0_valid_i) source_phase <= source_phase + 1'b1;
            if (!task_requested) task_aligned <= 0;
            else if (source_boundary) task_aligned <= 1;
            if (source_boundary) freeze_active <= capture_freeze;
        end
    end
    wire [9:0] ring_next_slot;
    wire [27:0] cap_araddr;
    wire cap_arvalid,cap_arready;
    wire [255:0] cap_rdata;
    wire [1:0] cap_rresp;
    wire cap_rvalid,cap_rready;
    wire cap_tx;
    mn04_train_capture #(
        .CLOCK_HZ(CAPTURE_CLOCK_HZ),.BAUD(CAPTURE_BAUD),
        .TX_FIFO_DEPTH(CAPTURE_TX_FIFO_DEPTH),.EXPORT_CAPTURE_TO_HOST(1),
        .CAPTURE_DIAGNOSTICS(CAPTURE_DIAGNOSTICS),
        .ENABLE_TEMPLATE_CAPTURE(ENABLE_TEMPLATE_CAPTURE),
        .CNN_CLASS_COUNT(CNN_CLASS_COUNT)
    ) u_train_capture (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(boot_init_done_o),
        .template_mode_i(template_capture_mode_i),
        .category_advance_i(template_capture_category_advance_i),
        .local_capture_start_i(template_capture_start_i),
        .local_capture_stop_i(template_capture_stop_i),
        .overflow_i({pcm_overflow_i,x0_overflow_o}),
        .live_feature_i(x0_i),.live_feature_valid_i(x0_valid_i && pass_ring_x0),
        .live_pcm_i(capture_pcm_debug_i),.live_pcm_valid_i(capture_pcm_debug_valid_i),
        .uart_tx_o(cap_tx),
        .freeze_o(capture_freeze),.task_busy_o(capture_engine_busy),
        .stream_phase_o(capture_stream_phase),
        .recording_o(capture_recording_o),
        .selected_category_o(capture_selected_category_o),
        .capture_ring_base_o(capture_ring_base_o),
        .selected_class_full_o(),
        .freeze_ack_i(freeze_active),
        .ring_drained_i(ring_drained && !snapshot_busy),
        .ring_frame_done_i(ring_frame_done),
        .ring_next_slot_i(ring_next_slot),
        .ddr_araddr_o(cap_araddr),.ddr_arvalid_o(cap_arvalid),
        .ddr_arready_i(cap_arready),
        .ddr_rdata_i(cap_rdata),.ddr_rresp_i(cap_rresp),
        .ddr_rvalid_i(cap_rvalid),.ddr_rready_o(cap_rready));

    generate if (TEMPLATE_DOORBELL_MAPS + TEMPLATE_SMOKE_ALARM_MAPS +
                 TEMPLATE_GAS_CO_ALARM_MAPS > 0) begin : g_templates
        mn04_template_matcher #(
            .INITIAL_TEMPLATE_FILE(TEMPLATE_FILE),
            .DOORBELL_MAPS(TEMPLATE_DOORBELL_MAPS),
            .SMOKE_ALARM_MAPS(TEMPLATE_SMOKE_ALARM_MAPS),
            .GAS_CO_ALARM_MAPS(TEMPLATE_GAS_CO_ALARM_MAPS),
            .MAX_MAPS_PER_CLASS(TEMPLATE_MAPS_PER_CLASS),
            .EXTERNAL_TEMPLATE_MEMORY(TEMPLATE_DDR_STORAGE),
            .USE_TEMPLATE_VALID_MASK(ENABLE_LOCAL_TEMPLATE_ENROLLMENT),
            .THRESHOLD_Q15(TEMPLATE_THRESHOLD_Q15),
            .CENTER_ALPHA_Q4(TEMPLATE_CENTER_ALPHA_Q4)
        ) u_template_matcher (
            .clk(clk),.rst_n(rst_n),
            .enable_i(recognition_enable_eff),
            .x0_i(x0_i),.x0_valid_i(x0_valid_i && pass_matcher_x0),
            .template_load_we_i(matcher_load_we && !TEMPLATE_DDR_STORAGE),
            .template_load_addr_i(matcher_load_addr),
            .template_load_data_i(matcher_load_data),
            .template_external_rd_en_i(template_external_rd_en),
            .template_external_rd_addr_i(template_external_rd_addr),
            .template_external_rd_data_o(template_external_rd_data),
            .template_valid_mask_i(template_valid_mask),
            .template_ddr_rd_req_o(matcher_ddr_req),.template_ddr_rd_addr_o(matcher_ddr_addr),
            .template_ddr_rd_valid_i(template_bank_rd_valid && !template_read_owner_sd),
            .template_ddr_rd_data_i(template_bank_rd_data),
            .result_valid_o(template_result_valid_o),
            .result_class_o(template_result_class_o),
            .result_score_q15_o(template_result_score_q15_o),.busy_o());
    end else begin : g_no_templates
        assign matcher_ddr_req=1'b0;
        assign matcher_ddr_addr=0;
        assign template_external_rd_data=0;
        assign template_result_valid_o=1'b0;
        assign template_result_class_o=2'd0;
        assign template_result_score_q15_o=16'd0;
    end endgenerate

    generate if (ENABLE_LOCAL_TEMPLATE_ENROLLMENT && ENABLE_TEMPLATE_CAPTURE &&
                 (TEMPLATE_DOORBELL_MAPS + TEMPLATE_SMOKE_ALARM_MAPS +
                  TEMPLATE_GAS_CO_ALARM_MAPS > 0)) begin : g_local_template_enrollment
        mn04_template_enrollment #(
            .CNN_CLASS_COUNT(CNN_CLASS_COUNT),.MEL_BINS(128),
            .WINDOW_FRAMES(100),.PURE_TEMPLATE_CLASSES(3),.MAPS_PER_CLASS(TEMPLATE_MAPS_PER_CLASS),
            .USE_CPU_SLOT_SELECT(CPU_TEMPLATE_SLOT_SELECT)
        ) u_enrollment (
            .clk(clk),.rst_n(rst_n),
            .capture_recording_i(capture_recording_o),
            .capture_category_i(capture_selected_category_o),
            .cpu_selected_slot_i(cpu_template_slot_i[TEMPLATE_MAP_INDEX_W-1:0]),
            .existing_valid_mask_i(template_valid_mask),
            .overflow_i({pcm_overflow_i,x0_overflow_o}),
            .x0_i(x0_i),.x0_valid_i(x0_valid_i && pass_ring_x0),
            .template_load_we_o(local_template_load_we),
            .template_load_addr_o(local_template_load_addr),
            .template_load_data_o(local_template_load_data),
            .valid_mask_o(local_template_valid_mask),
            .invalid_mask_o(local_template_invalid_mask),
            .enrollment_commit_o(template_enrollment_commit),
            .enrollment_category_o(template_enrollment_category),
            .enrollment_map_o(template_enrollment_map));
    end else begin : g_no_local_template_enrollment
        assign local_template_load_we=1'b0;
        assign local_template_load_addr=18'd0;
        assign local_template_load_data=8'sd0;
        assign local_template_valid_mask=6'd0;
        assign local_template_invalid_mask=6'd0;
        assign template_enrollment_commit=1'b0;
        assign template_enrollment_category=4'd0;
        assign template_enrollment_map=3'd0;
    end endgenerate

    assign matcher_load_we = sd_template_load_we ? 1'b1 :
                             local_template_load_we ? 1'b1 : template_load_we;
    assign matcher_load_addr = sd_template_load_we ? sd_template_load_addr :
                               local_template_load_we ? local_template_load_addr :
                               template_load_addr;
    assign matcher_load_data = sd_template_load_we ? sd_template_load_data :
                               local_template_load_we ? local_template_load_data :
                               $signed(template_load_data);

    generate if (ENABLE_SD_TEMPLATE_STORAGE && ENABLE_LOCAL_TEMPLATE_ENROLLMENT &&
                 (TEMPLATE_DOORBELL_MAPS + TEMPLATE_SMOKE_ALARM_MAPS +
                  TEMPLATE_GAS_CO_ALARM_MAPS > 0)) begin : g_sd_template_storage
        mn04_template_sd_store #(.CLK_HZ(100000000),.BASE_LBA(1),
            .MAP_BYTES(12800),.BLOCK_BYTES(512),.MAP_COUNT(TEMPLATE_MAP_COUNT),
            .ASYNC_TEMPLATE_READ(TEMPLATE_DDR_STORAGE)) u_sd_store (
            .clk(clk),.rst_n(rst_n),
            .boot_start_i(boot_ready_eff && template_load_done && display_load_done),
            .card_detect_n_i(sd_card_detect_n_i),
            .enrollment_commit_i(template_persist_commit),
            .enrollment_map_i(template_persist_map),
            .valid_mask_o(sd_template_valid_mask),.boot_done_o(sd_store_boot_done),
            .busy_o(sd_store_busy),
            .template_rd_en_o(template_external_rd_en),
            .template_rd_addr_o(template_external_rd_addr),
            .template_rd_data_i(TEMPLATE_DDR_STORAGE ? template_bank_rd_data : template_external_rd_data),
            .template_rd_valid_i(template_bank_rd_valid && template_read_owner_sd),
            .template_load_we_o(sd_template_load_we),
            .template_load_addr_o(sd_template_load_addr),
            .template_load_data_o(sd_template_load_data),
            .sd_clk_o(sd_clk_o),.sd_cs_n_o(sd_cs_n_o),.sd_mosi_o(sd_mosi_o),
            .sd_miso_i(sd_miso_i));
    end else begin : g_no_sd_template_storage
        assign sd_template_valid_mask=6'd0;
        assign sd_store_boot_done=1'b1;
        assign sd_store_busy=1'b0;
        assign template_external_rd_en=1'b0;
        assign template_external_rd_addr=18'd0;
        assign sd_template_load_we=1'b0;
        assign sd_template_load_addr=18'd0;
        assign sd_template_load_data=8'sd0;
        assign sd_clk_o=1'b0;
        assign sd_cs_n_o=1'b1;
        assign sd_mosi_o=1'b1;
    end endgenerate

    generate if (TEMPLATE_FLASH_LOAD &&
                 (TEMPLATE_DOORBELL_MAPS + TEMPLATE_SMOKE_ALARM_MAPS > 0)) begin : g_template_flash_load
        reg sel_started_r, sel_rd_done_seen_r, sel_done_r, sel_slot_r;
        reg sel_start_pulse_r, sel_rd_start_pulse_r;        wire sel_rd_done, sel_rd_valid, sel_ready, sel_done;
        wire [7:0] sel_rd_byte;
        wire sel_active_valid, sel_slot;
        wire [31:0] sel_generation;
        wire [31:0] sel_container_bytes;
        wire [23:0] selected_container_length;

        // Read the 8 KiB selector journal once after the model boot, then load
        // the template maps from the committed slot.  A blank journal selects
        // slot A, matching the host-side contract.
        always @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                sel_started_r <= 1'b0; sel_rd_done_seen_r <= 1'b0;
                sel_done_r <= 1'b0; sel_slot_r <= 1'b0;
                sel_start_pulse_r <= 1'b0; sel_rd_start_pulse_r <= 1'b0;
            end else begin
                sel_start_pulse_r <= 1'b0; sel_rd_start_pulse_r <= 1'b0;
                if (model_boot_done && !sel_started_r) begin
                    sel_started_r <= 1'b1;
                    sel_start_pulse_r <= 1'b1;
                    sel_rd_start_pulse_r <= 1'b1;
                end
                if (sel_rd_done) sel_rd_done_seen_r <= 1'b1;
                if (sel_done && sel_rd_done_seen_r && !sel_done_r) begin
                    sel_done_r <= 1'b1;
                    sel_slot_r <= sel_active_valid ? sel_slot : 1'b0;
                end
            end
        end

        assign boot_ready_eff = sel_done_r;
        assign sel_phase_eff = model_boot_done && !sel_done_r;
        assign selected_slot_base = sel_slot_r ? 24'h640000 : 24'h610000;
        assign selected_template_base = selected_slot_base + 24'd128;
        assign selected_container_length =
            sel_active_valid ? sel_container_bytes[23:0] : TEMPLATE_CONTAINER_BYTES;
        assign display_assets_base = selected_slot_base + selected_container_length -
                                     DISPLAY_ASSET_BYTES;

        mn04_qspi_block_reader #(.FAST_BYTES(0)) u_selector_reader (
            .clk(clk),.rst_n(rst_n),.start_i(sel_rd_start_pulse_r),
            .addr_i(24'h670000),.count_i(16'd8192),
            .busy_o(),.done_o(sel_rd_done),
            .byte_o(sel_rd_byte),.byte_valid_o(sel_rd_valid),
            .byte_ready_i(sel_ready),
            .flash_rd_addr_o(sel_rd_addr),.flash_rd_data_i(8'h00),
            .cs_o(sel_cs),.sck_o(sel_sck),.mosi_o(sel_mosi),.miso_i(qspi_miso_i));

        mn04_template_selector #(.RECORDS(128)) u_boot_selector (
            .clk(clk),.rst_n(rst_n),.start_i(sel_start_pulse_r),
            .byte_i(sel_rd_byte),.valid_i(sel_rd_valid && sel_phase_eff),
            .ready_o(sel_ready),.done_o(sel_done),
            .active_valid_o(sel_active_valid),.slot_o(sel_slot),
            .generation_o(sel_generation),.container_bytes_o(sel_container_bytes),
            .first_erased_index_o(),.first_erased_valid_o(),
            .uncommitted_count_o(),.invalid_count_o(),.conflict_count_o());

        mn04_template_flash_loader #(
            .TEMPLATE_BASE(TEMPLATE_FLASH_BASE),
            .TEMPLATE_BYTES(TEMPLATE_MAP_BYTES),
            .FAST_BYTES(FAST_BYTES)
        ) u_template_flash_loader (
            .clk(clk),.rst_n(rst_n),.start_i(boot_ready_eff),
            .base_i(selected_template_base),.use_base_i(1'b1),
            .busy_o(),.done_o(template_load_done),
            .flash_rd_addr_o(tpl_flash_addr),
            .flash_rd_data_i(boot_flash_rd_data_i),
            .cs_o(tpl_cs),.sck_o(tpl_sck),.mosi_o(tpl_mosi),.miso_i(qspi_miso_i),
            .load_we_o(template_load_we),.load_addr_o(template_load_addr),
            .load_data_o(template_load_data));

        mn04_template_flash_loader #(
            .TEMPLATE_BYTES(DISPLAY_ASSET_BYTES),
            .FAST_BYTES(FAST_BYTES)
        ) u_template_display_loader (
            .clk(clk),.rst_n(rst_n),
            .start_i(boot_ready_eff && template_load_done),
            .base_i(display_assets_base),.use_base_i(1'b1),
            .busy_o(),.done_o(display_load_done),
            .flash_rd_addr_o(display_flash_addr),
            .flash_rd_data_i(boot_flash_rd_data_i),
            .cs_o(display_cs),.sck_o(display_sck),.mosi_o(display_mosi),
            .miso_i(qspi_miso_i),
            .load_we_o(display_load_we),.load_addr_o(display_load_addr),
            .load_data_o(display_load_data));

        // Runtime update path.  It is allowed only while recognition is off,
        // the training capture is idle and the core is not reading weights.
        wire upd_rx_valid, upd_msg_valid, upd_msg_ready, upd_tx, upd_tx_ready;
        wire [7:0] upd_rx_data, upd_msg_data;
        wire upd_idle_ok = boot_init_done_o && !recognition_enable_i &&
                           !capture_task_busy_o && !core_busy_o;
        wire upd_rx_gated = capture_task_busy_o ? 1'b1 : uart_rx_i;

        uart_rx_8n1 #(.CLOCK_HZ(100000000),.BAUD(115200)) u_upd_rx (
            .clk(clk),.rst_n(rst_n),.rx_i(upd_rx_gated),
            .data_o(upd_rx_data),.valid_o(upd_rx_valid));

        mn04_template_update u_template_update (
            .clk(clk),.rst_n(rst_n),.idle_ok_i(upd_idle_ok),
            .host_valid_i(upd_rx_valid),.host_data_i(upd_rx_data),
            .host_ready_o(),
            .msg_valid_o(upd_msg_valid),.msg_data_o(upd_msg_data),
            .msg_ready_i(upd_tx_ready),
            .qspi_cs_o(upd_cs),.qspi_sck_o(upd_sck),.qspi_mosi_o(upd_mosi),
            .qspi_miso_i(qspi_miso_i),.busy_o(upd_busy),
            .active_valid_o(),.active_slot_o(),.active_generation_o());

        uart_tx_8n1 #(.CLOCK_HZ(100000000),.BAUD(115200)) u_upd_tx (
            .clk(clk),.rst_n(rst_n),.data_i(upd_msg_data),
            .valid_i(upd_msg_valid),.ready_o(upd_tx_ready),.tx_o(upd_tx));

        assign update_holds_qspi = upd_busy;
        assign uart_tx_o = (upd_busy || !upd_tx_ready) ? upd_tx : cap_tx;
    end else begin : g_no_template_flash_load
        assign template_load_done=1'b1;
        assign template_load_we=1'b0;
        assign template_load_addr=18'd0;
        assign template_load_data=8'd0;
        assign display_load_done=1'b1;
        assign display_load_we=1'b0;
        assign display_load_addr=17'd0;
        assign display_load_data=8'd0;
        assign display_flash_addr=24'd0;
        assign display_cs=1'b1;
        assign display_sck=1'b0;
        assign display_mosi=1'b1;
        assign tpl_cs=1'b1;
        assign tpl_sck=1'b0;
        assign tpl_mosi=1'b1;
        assign tpl_flash_addr=24'd0;
        assign boot_ready_eff=model_boot_done;
        assign sel_phase_eff=1'b0;
        assign sel_cs=1'b1;
        assign sel_sck=1'b0;
        assign sel_mosi=1'b1;
        assign sel_rd_addr=24'd0;
        assign selected_template_base=TEMPLATE_FLASH_BASE;
        assign selected_slot_base=24'd0;
        assign display_assets_base=24'd0;
        assign upd_busy=1'b0;
        assign upd_cs=1'b1;
        assign upd_sck=1'b0;
        assign upd_mosi=1'b1;
        assign update_holds_qspi=1'b0;
        assign uart_tx_o=cap_tx;
    end endgenerate

    mn04_ddr_bootloader #(.FAST_BYTES(FAST_BYTES),
        .FLASH_BASE(FLASH_IMAGE_BASE),.IMAGE_BYTES(IMAGE_BYTES),
        .DDR_BASE_WORD(WEIGHT_BASE_WORD),
        .CHECKSUM_EXPECTED(IMAGE_CHECKSUM_EXPECTED)) u_boot (
        .clk(clk),.rst_n(rst_n),.start_i(boot_start_i),.busy_o(),
        .done_o(),.ddr_init_done_o(model_boot_done),.checksum_ok_o(),
        .flash_rd_addr_o(model_boot_flash_addr),
        .flash_rd_data_i(boot_flash_rd_data_i),
        .cs_o(boot_cs),.sck_o(boot_sck),.mosi_o(boot_mosi),
        .miso_i(qspi_miso_i),.ddr_awaddr_o(boot_awaddr),
        .ddr_awvalid_o(boot_awvalid),.ddr_awready_i(boot_awready),
        .ddr_wdata_o(boot_wdata),.ddr_wstrb_o(boot_wstrb),
        .ddr_wvalid_o(boot_wvalid),.ddr_wlast_o(boot_wlast),
        .ddr_wready_i(boot_wready),
        .ddr_bresp_i(boot_bresp),.ddr_bvalid_i(boot_bvalid),
        .ddr_bready_o(boot_bready));

    mn04_x0_continuous_snapshot_top #(.SHORT_HOP_FRAMES(SHORT_HOP_FRAMES),
        .ENABLE_LONG_WINDOW(ENABLE_LONG_WINDOW),
        .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
        .UNIFORM_120_WINDOW(UNIFORM_120_WINDOW)) u_snapshots (
        .clk(clk),.rst_n(rst_n && boot_init_done_o),
        .ddr_init_done_i(boot_init_done_o),
        .overflow_clear_i(template_capture_start_i),
        .ring_base_byte_i(active_ring_base),.epoch_reset_i(ring_epoch_reset),
        .x0_i(x0_i),.x0_valid_i(x0_valid_i && pass_ring_x0),
        .recognition_enable_i(recognition_enable_eff &&
                              (!capture_freeze || capture_stream_phase)),
        .short_snapshot_accept_i(short_snapshot_accept_i),
        .long_snapshot_accept_i(long_snapshot_accept_i),
        .short_snapshot_ready_o(short_snapshot_ready_o),
        .long_snapshot_ready_o(long_snapshot_ready_o),
        .short_snapshot_mode_o(short_snapshot_mode_o),.window_quiet_o(window_quiet_o),
        .x0_overflow_o(x0_overflow_o),
        .ring_drained_o(ring_drained),
        .ring_frame_done_o(ring_frame_done),
        .ring_next_frame_slot_o(ring_next_slot),
        .ring_awaddr_o(ring_awaddr),.ring_awvalid_o(ring_awvalid),
        .ring_awready_i(ring_awready),.ring_wdata_o(ring_wdata),
        .ring_wstrb_o(ring_wstrb),
        .ring_wvalid_o(ring_wvalid),.ring_wlast_o(ring_wlast),
        .ring_wready_i(ring_wready),
        .ring_bresp_i(ring_bresp),.ring_bvalid_i(ring_bvalid),
        .ring_bready_o(ring_bready),
        .snapshot_busy_o(snapshot_busy),
        .dma_awaddr_o(dma_awaddr),.dma_awvalid_o(dma_awvalid),
        .dma_awready_i(dma_awready),.dma_wdata_o(dma_wdata),
        .dma_wstrb_o(dma_wstrb),
        .dma_wvalid_o(dma_wvalid),.dma_wlast_o(dma_wlast),
        .dma_wready_i(dma_wready),
        .dma_bresp_i(dma_bresp),.dma_bvalid_i(dma_bvalid),
        .dma_bready_o(dma_bready),
        .dma_araddr_o(dma_araddr),.dma_arvalid_o(dma_arvalid),
        .dma_arready_i(dma_arready),.dma_rdata_i(dma_rdata),
        .dma_rresp_i(dma_rresp),.dma_rvalid_i(dma_rvalid),
        .dma_rready_o(dma_rready));

    wire conv_valid,conv_pad,scalar_valid,scalar_mode,rd_req_valid,rd_req_pad;
    wire [23:0] conv_addr,scalar_addr,rd_addr,wr_addr;
    wire wr_en,wr_ready;
    wire [7:0] wr_data;
    wire candidate_ready,rd_rsp_valid;
    wire [31:0] rd_data,conv_rd_data;
    wire [1:0] rd_lane,conv_rd_lane;
    wire [27:0] weight_araddr,act_araddr,write_awaddr;
    wire weight_arvalid,act_arvalid,write_awvalid;
    wire weight_arready,act_arready,write_awready;
    wire [255:0] weight_rdata,act_rdata,write_wdata;
    wire weight_rvalid,act_rvalid,write_wready;
    wire [1:0] weight_rresp,act_rresp;
    wire weight_rready,act_rready;
    wire write_wvalid,write_wlast;
    wire [1:0] write_bresp;
    wire write_bvalid,write_bready;
    wire [31:0] write_wstrb;
    wire writer_drained;
    // Latch the arena with the start handshake.  The scheduler's combinational
    // task choice must not feed every cache tag and DDR address in the fabric.
    reg active_short_r;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) active_short_r<=0;
        else if(core_start_eff) active_short_r<=core_context_short_i;
    end
    // The 91-op image keeps every activation below 0x200000 (the largest
    // tensor end is 0x1a1d80), so the arena select is one address bit.  This
    // avoids putting a 24-bit adder ahead of each cache lookup and write.
    wire [23:0] arena_offset={2'b00,active_short_r,21'b0};
    wire [23:0] conv_addr_p=conv_addr|arena_offset;
    wire [23:0] scalar_addr_p=scalar_addr|arena_offset;
    wire [23:0] rd_addr_p=rd_addr|arena_offset;
    wire [23:0] wr_addr_p=wr_addr|arena_offset;
    reg last_context_r;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) last_context_r<=0;
        else if(core_start_eff) last_context_r<=core_context_short_i;
    end
    reg cache_flush_r;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) cache_flush_r<=0;
        else cache_flush_r<=core_start_eff &&
            ((core_start_op_i==9'd0) || (core_context_short_i!=last_context_r));
    end
    // Descriptor fetch precedes every activation read by many cycles, so
    // clearing the cache one clock after start preserves behavior while
    // isolating the Softmax/alert decision from cache tag and miss logic.
    wire cache_flush=cache_flush_r;

    mn04_core #(.OP_FILE(OP_FILE),.N_OPS(91),.N_CLASSES(N_CLASSES),
        .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
        .LUTS_BASE(LUTS_BASE),.FLASH_IMAGE_BASE(FLASH_IMAGE_BASE),
        .FAST_BYTES(FAST_BYTES),.WEIGHT_BASE_WORD(WEIGHT_BASE_WORD)) u_core (
        .clk(clk),.rst_n(rst_n),.start_i(core_start_eff),
        .segment_start_op_i(core_start_op_i),
        .segment_end_op_i(core_end_op_i),
        .short_window_i(core_short_window_i),
        .class_window_mode_i(core_class_window_mode_i),
        .busy_o(core_busy_o),.done_o(core_done_o),
        .flash_rd_addr_o(core_flash_rd_addr_o),
        .flash_rd_data_i(core_flash_rd_data_i),
        .qspi_cs_o(core_cs),.qspi_sck_o(core_sck),
        .qspi_mosi_o(core_mosi),.qspi_miso_i(qspi_miso_i),
        .conv_req_ready_i(candidate_ready),
        .conv_candidate_valid_o(conv_valid),
        .conv_candidate_addr_o(conv_addr),
        .conv_candidate_pad_o(conv_pad),
        .scalar_candidate_valid_o(scalar_valid),
        .scalar_candidate_addr_o(scalar_addr),
        .scalar_mode_o(scalar_mode),
        .scalar_req_ready_i(candidate_ready),
        .wr_en_o(wr_en),.wr_addr_o(wr_addr),.wr_data_o(wr_data),
        .wr_ready_i(wr_ready),
        .rd_req_valid_o(rd_req_valid),.rd_byte_addr_o(rd_addr),
        .rd_req_pad_o(rd_req_pad),.rd_rsp_valid_i(rd_rsp_valid),
        .rd_data_i(rd_data),.rd_lane_i(rd_lane),
        .conv_rd_data_i(conv_rd_data),.conv_rd_lane_i(conv_rd_lane),
        .dump_valid_o(),.dump_id_o(),.dump_op_index_o(),
        .cycle_count_o(),.logits_valid_o(core_logits_valid_o),
        .logits_o(core_logits_o),.ddr_init_done_i(boot_init_done_o),
        .ddr_araddr_o(weight_araddr),.ddr_arvalid_o(weight_arvalid),
        .ddr_arready_i(weight_arready),.ddr_rdata_i(weight_rdata),
        .ddr_rresp_i(weight_rresp),.ddr_rvalid_i(weight_rvalid),
        .ddr_rready_o(weight_rready));

    mn04_ddr_act_read_cache #(.LINE_BITS(CACHE_LINE_BITS)) u_act_cache (
        .clk(clk),.rst_n(rst_n),.flush_i(cache_flush),
        .write_invalidate_i(wr_en),.write_addr_i(wr_addr_p),
        .writes_drained_i(writer_drained),
        .candidate_valid_i(conv_valid || scalar_valid),
        // Select the address from the registered core state, independent of
        // either candidate-valid computation.  This breaks the tag-hit/ready
        // feedback from the residual bound comparator to its own issue CE.
        .candidate_addr_i(scalar_mode ? scalar_addr_p : conv_addr_p),
        .candidate_pad_i(!scalar_mode && conv_pad),.candidate_ready_o(candidate_ready),
        .rd_req_valid_i(rd_req_valid),.rd_byte_addr_i(rd_addr_p),
        .rd_req_pad_i(rd_req_pad),.rd_rsp_valid_o(rd_rsp_valid),
        .rd_data_o(rd_data),.rd_lane_o(rd_lane),
        .conv_data_o(conv_rd_data),.conv_lane_o(conv_rd_lane),
        .ddr_araddr_o(act_araddr),.ddr_arvalid_o(act_arvalid),
        .ddr_arready_i(act_arready),.ddr_rdata_i(act_rdata),
        .ddr_rresp_i(act_rresp),.ddr_rvalid_i(act_rvalid),
        .ddr_rready_o(act_rready));

    wire bridge_valid,byte_ready;
    wire [23:0] bridge_addr;
    wire [7:0] bridge_data;
    mn04_wmerge_bridge u_write_bridge (
        .clk(clk),.rst_n(rst_n),.wr_en_i(wr_en),
        .wr_addr_i(wr_addr_p),.wr_data_i(wr_data),
        .wr_ready_o(wr_ready),.mem_wr_en_o(bridge_valid),
        .mem_wr_addr_o(bridge_addr),.mem_wr_data_o(bridge_data),
        .mem_wr_ready_i(byte_ready));
    mn04_ddr_act_byte_writer u_act_writer (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(boot_init_done_o),
        .byte_valid_i(bridge_valid),.byte_addr_i(bridge_addr),
        .byte_data_i(bridge_data),.byte_ready_o(byte_ready),
        .ddr_awaddr_o(write_awaddr),.ddr_awvalid_o(write_awvalid),
        .ddr_awready_i(write_awready),.ddr_wdata_o(write_wdata),
        .ddr_wstrb_o(write_wstrb),
        .ddr_wvalid_o(write_wvalid),.ddr_wlast_o(write_wlast),
        .ddr_wready_i(write_wready),
        .ddr_bresp_i(write_bresp),.ddr_bvalid_i(write_bvalid),
        .ddr_bready_o(write_bready),
        .drained_o(writer_drained));

    // master 3 = bootloader (before init) then ring writer (after init)
    wire m3_awready,m3_wready,m3_bvalid;
    wire [1:0] m3_bresp;
    wire [27:0] m3_awaddr=boot_init_done_o ? ring_awaddr : boot_awaddr;
    wire m3_awvalid=boot_init_done_o ? ring_awvalid : boot_awvalid;
    wire [255:0] m3_wdata=boot_init_done_o ? ring_wdata : boot_wdata;
    wire [31:0] m3_wstrb=boot_init_done_o ? ring_wstrb : boot_wstrb;
    wire m3_wvalid=boot_init_done_o ? ring_wvalid : boot_wvalid;
    wire m3_wlast=boot_init_done_o ? ring_wlast : boot_wlast;
    wire m3_bready=boot_init_done_o ? ring_bready : boot_bready;
    assign ring_awready=boot_init_done_o ? m3_awready : 1'b0;
    assign ring_wready=boot_init_done_o ? m3_wready : 1'b0;
    assign ring_bvalid=boot_init_done_o ? m3_bvalid : 1'b0;
    assign ring_bresp=m3_bresp;
    assign boot_awready=boot_init_done_o ? 1'b0 : m3_awready;
    assign boot_wready=boot_init_done_o ? 1'b0 : m3_wready;
    assign boot_bvalid=boot_init_done_o ? 1'b0 : m3_bvalid;
    assign boot_bresp=m3_bresp;

    mn04_axi4_interconnect #(.ENABLE_M6(TEMPLATE_DDR_STORAGE)) u_arbiter (
        .clk(clk),.rst_n(rst_n),
        // master 0 = activation write-back
        .m0_awaddr(write_awaddr),.m0_araddr(28'd0),
        .m0_awlen(4'd0),.m0_arlen(4'd0),
        .m0_awvalid(write_awvalid),.m0_arvalid(1'b0),
        .m0_awready(write_awready),.m0_arready(),
        .m0_wdata(write_wdata),.m0_wstrb(write_wstrb),
        .m0_wvalid(write_wvalid),.m0_wlast(write_wlast),
        .m0_wready(write_wready),
        .m0_bresp(write_bresp),.m0_bvalid(write_bvalid),.m0_bready(write_bready),
        .m0_rdata(),.m0_rresp(),.m0_rlast(),.m0_rvalid(),.m0_rready(1'b1),
        // master 1 = activation read cache
        .m1_awaddr(28'd0),.m1_araddr(act_araddr),
        .m1_awlen(4'd0),.m1_arlen(4'd0),
        .m1_awvalid(1'b0),.m1_arvalid(act_arvalid),
        .m1_awready(),.m1_arready(act_arready),
        .m1_wdata(256'd0),.m1_wstrb(32'd0),
        .m1_wvalid(1'b0),.m1_wlast(1'b0),.m1_wready(),
        .m1_bresp(),.m1_bvalid(),.m1_bready(1'b1),
        .m1_rdata(act_rdata),.m1_rresp(act_rresp),.m1_rlast(),.m1_rvalid(act_rvalid),
        .m1_rready(act_rready),
        // master 2 = weight feeder
        .m2_awaddr(28'd0),.m2_araddr(weight_araddr),
        .m2_awlen(4'd0),.m2_arlen(4'd0),
        .m2_awvalid(1'b0),.m2_arvalid(weight_arvalid),
        .m2_awready(),.m2_arready(weight_arready),
        .m2_wdata(256'd0),.m2_wstrb(32'd0),
        .m2_wvalid(1'b0),.m2_wlast(1'b0),.m2_wready(),
        .m2_bresp(),.m2_bvalid(),.m2_bready(1'b1),
        .m2_rdata(weight_rdata),.m2_rresp(weight_rresp),.m2_rlast(),.m2_rvalid(weight_rvalid),
        .m2_rready(weight_rready),
        // master 3 = bootloader -> ring writer
        .m3_awaddr(m3_awaddr),.m3_araddr(28'd0),
        .m3_awlen(4'd0),.m3_arlen(4'd0),
        .m3_awvalid(m3_awvalid),.m3_arvalid(1'b0),
        .m3_awready(m3_awready),.m3_arready(),
        .m3_wdata(m3_wdata),.m3_wstrb(m3_wstrb),
        .m3_wvalid(m3_wvalid),.m3_wlast(m3_wlast),
        .m3_wready(m3_wready),
        .m3_bresp(m3_bresp),.m3_bvalid(m3_bvalid),.m3_bready(m3_bready),
        .m3_rdata(),.m3_rresp(),.m3_rlast(),.m3_rvalid(),.m3_rready(1'b1),
        // master 4 = snapshot DMA (read + write)
        .m4_awaddr(dma_awaddr),.m4_araddr(dma_araddr),
        .m4_awlen(4'd0),.m4_arlen(4'd0),
        .m4_awvalid(dma_awvalid),.m4_arvalid(dma_arvalid),
        .m4_awready(dma_awready),.m4_arready(dma_arready),
        .m4_wdata(dma_wdata),.m4_wstrb(dma_wstrb),
        .m4_wvalid(dma_wvalid),.m4_wlast(dma_wlast),
        .m4_wready(dma_wready),
        .m4_bresp(dma_bresp),.m4_bvalid(dma_bvalid),.m4_bready(dma_bready),
        .m4_rdata(dma_rdata),.m4_rresp(dma_rresp),.m4_rlast(),.m4_rvalid(dma_rvalid),
        .m4_rready(dma_rready),
        // master 5 = board-training capture (read-only)
        .m5_araddr(cap_araddr),.m5_arlen(4'd0),
        .m5_arvalid(cap_arvalid),.m5_arready(cap_arready),
        .m5_rdata(cap_rdata),.m5_rresp(cap_rresp),.m5_rlast(),.m5_rvalid(cap_rvalid),
        .m5_rready(cap_rready),
        .m6_awaddr(tb_awaddr),.m6_araddr(tb_araddr),.m6_awlen(4'd0),.m6_arlen(4'd0),
        .m6_awvalid(tb_awvalid),.m6_arvalid(tb_arvalid),.m6_awready(tb_awready),.m6_arready(tb_arready),
        .m6_wdata(tb_wdata),.m6_wstrb(tb_wstrb),.m6_wvalid(tb_wvalid),.m6_wlast(tb_wlast),
        .m6_wready(tb_wready),.m6_bresp(tb_bresp),.m6_bvalid(tb_bvalid),.m6_bready(tb_bready),
        .m6_rdata(tb_rdata),.m6_rresp(tb_rresp),.m6_rlast(),.m6_rvalid(tb_rvalid),.m6_rready(tb_rready),
        // slave (toward the SoC bridge)
        .s_awaddr(ddr_awaddr_o),.s_araddr(ddr_araddr_o),
        .s_awlen(ddr_awlen_o),.s_arlen(ddr_arlen_o),
        .s_awvalid(ddr_awvalid_o),.s_arvalid(ddr_arvalid_o),
        .s_awready(ddr_awready_i),.s_arready(ddr_arready_i),
        .s_wdata(ddr_wdata_o),.s_wstrb(ddr_wstrb_o),
        .s_wvalid(ddr_wvalid_o),.s_wlast(ddr_wlast_o),
        .s_wready(ddr_wready_i),
        .s_bresp(ddr_bresp_i),.s_bvalid(ddr_bvalid_i),.s_bready(ddr_bready_o),
        .s_rdata(ddr_rdata_i),.s_rresp(ddr_rresp_i),.s_rlast(ddr_rlast_i),
        .s_rvalid(ddr_rvalid_i),.s_rready(ddr_rready_o));
    reg [15:0] diag_commits,diag_results,diag_score;
    always @(posedge clk or negedge rst_n) begin
      if(!rst_n) begin diag_commits<=0;diag_results<=0;diag_score<=0;end
      else begin
        if(template_enrollment_commit) diag_commits<=diag_commits+1'b1;
        if(template_result_valid_o) begin diag_results<=diag_results+1'b1;diag_score<=template_result_score_q15_o;end
      end
    end
    assign template_diag_o={diag_commits,diag_results,diag_score,
      {(16-TEMPLATE_MAP_COUNT){1'b0}},template_valid_mask,
      6'd0,capture_engine_busy,capture_recording_o,1'b0,template_writes_drained,
      pcm_overflow_i,x0_overflow_o,template_bank_fault,template_commit_pending,sd_store_busy,recognition_enable_eff,
      4'd0,capture_selected_category_o,4'd0,cpu_template_slot_i};
endmodule
