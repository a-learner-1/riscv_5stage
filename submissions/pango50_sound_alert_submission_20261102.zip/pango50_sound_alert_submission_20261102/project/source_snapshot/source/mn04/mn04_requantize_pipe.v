`timescale 1ns/1ps
// MN04 single-round requantize pipeline (GATE4).
//
// Implements EXACTLY the golden contract from export_mn04_golden.py
// requant_int32():
//     n   = acc * mult            (signed 64-bit product)
//     k   = 31 - shift            (shift: int8, may be negative)
//     rnd = round_away(|n| / 2^k) = (|n| + 2^(k-1)) >> k   (k==0 -> |n|)
//     y   = sign(n) * rnd, clamped to [-128, 127]
//
// NOTE: this REPLACES the old TFLite double-round requantize (high-mul +
// RoundingDivideByPOT + zero_point), which is NOT bit-equivalent to the
// golden single 64-bit multiply with round-half-away-from-zero.
//
// Pipeline (PNR-friendly split, 4 x 16x16 partial products):
//   s0: capture acc/mult/shift
//   s1: pp0..pp3 partial products
//   s2: n = pp0 + (pp1+pp2)<<16 + pp3<<32   (64-bit signed)
//   s3: mag = |n|, k = 31-shift, neg
//   s4: kk clamp; half = 2^(kk-1); biased magnitude = mag + half
//   s5: shift biased magnitude
//   s6: sign restore
//   s7: clamp [-128,127] and output register
module mn04_requantize_pipe (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_i,          // 1-cycle start pulse
    input  wire signed [31:0] acc_i,     // int32 accumulator
    input  wire signed [31:0] mult_i,    // q31 multiplier (int32)
    input  wire signed [7:0]  shift_i,   // int8 shift
    output reg         valid_o,
    output reg  signed [7:0] y_o
);
    reg        v_s0, v_s1, v_s2, v_s3, v_s4, v_s5, v_s6;
    reg signed [31:0] acc_r, mult_r;
    reg signed [7:0]  shift_r;
    reg [31:0] pp0_r;                 // a0*m0 unsigned
    reg signed [31:0] pp1_r, pp2_r;   // a0*m1s, a1s*m0
    reg signed [31:0] pp3_r;          // a1s*m1s
    reg signed [63:0] n_r;
    reg [63:0] mag_r;
    reg signed [8:0]  k_s3_r;         // 31 - shift (signed)
    reg [63:0] mag_half_r;
    reg [7:0]  kk_s4_r;
    reg        k64_s4_r, k_gt64_s4_r;
    reg [63:0] rnd_r;
    reg        neg_r, neg_s4_r, neg_s5_r;
    reg signed [63:0] y_pre_r;

    wire [15:0] a0 = acc_r[15:0];
    wire signed [15:0] a1 = acc_r[31:16];
    wire [15:0] m0 = mult_r[15:0];
    wire signed [15:0] m1 = mult_r[31:16];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            v_s0 <= 0; v_s1 <= 0; v_s2 <= 0; v_s3 <= 0; v_s4 <= 0;
            v_s5 <= 0; v_s6 <= 0;
            acc_r <= 0; mult_r <= 0; shift_r <= 0;
            pp0_r <= 0; pp1_r <= 0; pp2_r <= 0; pp3_r <= 0;
            n_r <= 0; mag_r <= 0; k_s3_r <= 0; mag_half_r <= 0;
            kk_s4_r <= 0; k64_s4_r <= 0; k_gt64_s4_r <= 0; rnd_r <= 0;
            neg_r <= 0; neg_s4_r <= 0; neg_s5_r <= 0;
            y_pre_r <= 0; valid_o <= 0; y_o <= 0;
        end else begin
            v_s0 <= start_i;
            if (start_i) begin
                acc_r <= acc_i; mult_r <= mult_i; shift_r <= shift_i;
            end
            // s1: partial products
            v_s1 <= v_s0;
            pp0_r <= a0 * m0;
            pp1_r <= $signed({16'd0, a0}) * m1;
            pp2_r <= a1 * $signed({16'd0, m0});
            pp3_r <= a1 * m1;
            // s2: 64-bit product  (NOTE: in Verilog <<< binds LOOSER than +,
            // so every shifted term must be parenthesized explicitly)
            v_s2 <= v_s1;
            n_r <= ({{32{pp3_r[31]}}, pp3_r} <<< 32)
                   + ({{32{pp1_r[31]}}, pp1_r} <<< 16)
                   + ({{32{pp2_r[31]}}, pp2_r} <<< 16)
                   + {32'd0, pp0_r};
            // s3: magnitude + k
            v_s3 <= v_s2;
            mag_r <= (n_r[63]) ? (~n_r + 64'd1) : n_r;
            k_s3_r <= 31 - shift_r;
            neg_r <= n_r[63];
            // s4: clamp k and add the rounding half; the variable right shift
            // is registered separately to shorten the 100 MHz critical path.
            v_s4 <= v_s3;
            begin : s4
                reg [7:0]  kk;
                reg [63:0] half_c;
                kk = (k_s3_r <= 9'sd0) ? 8'd0 : k_s3_r[7:0];
                half_c = (kk == 8'd0) ? 64'd0 : (64'd1 << (kk - 8'd1));
                kk_s4_r <= kk;
                mag_half_r <= mag_r + half_c;
                k64_s4_r <= (k_s3_r == 9'sd64);
                k_gt64_s4_r <= (k_s3_r > 9'sd64);
                neg_s4_r <= neg_r;
            end
            // s5: shift the rounded magnitude.
            v_s5 <= v_s4;
            neg_s5_r <= neg_s4_r;
            begin : s5
                // The frozen Python golden uses signed NumPy int64 here.
                // At k=64, (1 << 63) is -2^63, so (mag + half) >> 64
                // produces -1 for the model's sub-2^62 magnitudes.  The
                // subsequent sign restore flips the sign of that -1.  Keep
                // this boundary behavior to reproduce the frozen V1 output;
                // mathematically rounding a small value by 2^64 would be 0.
                if (k64_s4_r)
                    rnd_r <= 64'hffffffffffffffff;
                else if (k_gt64_s4_r)
                    rnd_r <= 64'd0;
                else
                    rnd_r <= mag_half_r >> kk_s4_r;
            end
            // s6: sign restore
            v_s6 <= v_s5;
            y_pre_r <= neg_s5_r ? (~rnd_r + 64'd1) : rnd_r;
            // s7: clamp to int8
            begin : s7
                reg signed [63:0] yp;
                reg [63:0] yp128;
                reg signed [7:0] yc;
                yp = y_pre_r;
                yp128 = y_pre_r + 64'd128;
                yc = (yp[63] == 1'b0 && |yp[62:7]) ? 8'sd127 :
                     (yp[63] == 1'b1 && yp128[63] == 1'b1) ? -8'sd128 : yp[7:0];
                valid_o <= v_s6;
                y_o <= yc;
            end
        end
    end
endmodule
