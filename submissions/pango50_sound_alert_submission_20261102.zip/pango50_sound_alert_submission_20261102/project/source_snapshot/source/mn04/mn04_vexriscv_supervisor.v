`timescale 1ns/1ps
// Five-stage VexRiscv (Min, RV32I) runs the board task-admission firmware.
// Wishbone instruction/data ports terminate locally; streaming DDR traffic
// remains on the existing accelerator fabric and never passes through CPU RAM.
module mn04_vexriscv_supervisor #(
    parameter integer CLOCK_HZ=100000000,
    parameter FIRMWARE_FILE="C:/Studying_file/pango50_sound_alert_v1/firmware/control_vexriscv/build/control.mem"
)(
    input wire clk,rst_n,
    input wire [5:0] key_n_i,
    input wire boot_ready_i,codec_ready_i,recognition_i,capture_busy_i,
    input wire recording_i,alert_i,
    output wire [5:0] command_key_n_o,
    output reg [31:0] firmware_signature_o,
    output reg [31:0] command_count_o
);
    localparam integer HOLD_MS=40;
    wire tick_ms;
    wire [5:0] press;
    reg [5:0] pending;
    reg [5:0] hold_ms[0:5];
    genvar k;
    v1_ms_tick #(.CLOCK_HZ(CLOCK_HZ)) timer(.clk(clk),.rst_n(rst_n),.tick_ms_o(tick_ms));
    generate for(k=0;k<6;k=k+1) begin:g_keys
        v1_key_debounce key(.clk(clk),.rst_n(rst_n),.tick_ms_i(tick_ms),
            .key_n_i(key_n_i[k]),.press_o(press[k]));
        assign command_key_n_o[k]=(hold_ms[k]==0);
    end endgenerate
    reg [31:0] rom[0:511];
    reg [31:0] ram[0:255];
    initial $readmemh(FIRMWARE_FILE,rom);
    wire icyc,istb,dcyc,dstb,dwe;
    wire [29:0] ia,da;
    wire [31:0] dw;
    wire [3:0] ds;
    reg iack,dack;
    reg [31:0] ir,dr;
    wire [31:0] data_addr={da,2'b00};
    wire data_accept=dcyc && dstb && !dack;
    wire [5:0] event_clear=(data_accept && dwe && data_addr==32'h80000008 && ds[0]) ? dw[5:0] : 6'd0;
    wire command_write=data_accept && dwe && data_addr==32'h8000000c && ds[0];
    wire command_active=(command_key_n_o!=6'h3f);
    integer n;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            iack<=0;dack<=0;ir<=0;dr<=0;pending<=0;
            firmware_signature_o<=0;command_count_o<=0;
            for(n=0;n<6;n=n+1) hold_ms[n]<=0;
        end else begin
            iack<=icyc && istb && !iack;
            if(icyc && istb && !iack)
                ir<=(ia<512) ? rom[ia[8:0]] : 32'h0000006f;
            dack<=data_accept;
            pending<=(pending & ~event_clear) | press;
            for(n=0;n<6;n=n+1) begin
                if(tick_ms && hold_ms[n]!=0) hold_ms[n]<=hold_ms[n]-1'b1;
                if(command_write && dw[n]) hold_ms[n]<=HOLD_MS;
            end
            if(command_write) command_count_o<=command_count_o+1'b1;
            if(data_accept) begin
                if(data_addr<2048) dr<=rom[da[8:0]];
                else if(data_addr>=32'h1000 && data_addr<32'h1400) begin
                    dr<=ram[da[7:0]];
                    if(dwe) for(n=0;n<4;n=n+1)
                        if(ds[n]) ram[da[7:0]][8*n+:8]<=dw[8*n+:8];
                end else case(data_addr)
                    32'h80000000:dr<={26'd0,pending};
                    32'h80000004:dr<={25'd0,command_active,alert_i,recording_i,capture_busy_i,
                                             recognition_i,codec_ready_i,boot_ready_i};
                    32'h80000010:dr<=command_count_o;
                    32'h80000014:begin
                        dr<=firmware_signature_o;
                        if(dwe && ds==4'hf) firmware_signature_o<=dw;
                    end
                    default:dr<=0;
                endcase
            end
        end
    end
    VexRiscv cpu(
        .clk(clk),.reset(!rst_n),.externalResetVector(32'd0),
        .timerInterrupt(1'b0),.softwareInterrupt(1'b0),.externalInterruptArray(32'd0),
        .iBusWishbone_CYC(icyc),.iBusWishbone_STB(istb),.iBusWishbone_ACK(iack),
        .iBusWishbone_WE(),.iBusWishbone_ADR(ia),.iBusWishbone_DAT_MISO(ir),
        .iBusWishbone_DAT_MOSI(),.iBusWishbone_SEL(),.iBusWishbone_ERR(1'b0),
        .iBusWishbone_CTI(),.iBusWishbone_BTE(),
        .dBusWishbone_CYC(dcyc),.dBusWishbone_STB(dstb),.dBusWishbone_ACK(dack),
        .dBusWishbone_WE(dwe),.dBusWishbone_ADR(da),.dBusWishbone_DAT_MISO(dr),
        .dBusWishbone_DAT_MOSI(dw),.dBusWishbone_SEL(ds),.dBusWishbone_ERR(1'b0),
        .dBusWishbone_CTI(),.dBusWishbone_BTE());
endmodule
