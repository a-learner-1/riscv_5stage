`timescale 1ns/1ps
// Six-class controller. In class-window mode it time-multiplexes 100/120/150
// frame snapshots and masks logits to the classes trained for that duration.
module mn04_six_class_realtime_control #(
    parameter SOFTMAX_LUT_FILE="softmax_exp_q24_six_class.mem",
    parameter integer CLASS_WINDOW_MODE=0,
    parameter integer UNIFORM_120_WINDOW_MODE=0,
    parameter integer CURRENT_FIVE_CLASS_MODE=0,
    parameter integer CPU_TASK_CONTROL=0,
    parameter CNN_TEMPLATE_FILE="",
    parameter [23:0] CNN_TEMPLATE_VALID_MASK=24'h000000,
    parameter integer CNN_TEMPLATE_WEIGHT_Q2=1,
    parameter [15:0] BABY_THRESHOLD_Q16=16'hffff,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] EMERGENCY_VEHICLE_THRESHOLD_Q16=16'hffff,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'hffff,
    parameter integer TEMPLATE_ONLY_MODE=0,
    parameter integer CONTINUE_WHILE_ALERT=1,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,
    input wire short_snapshot_ready_i,
    input wire [1:0] short_snapshot_mode_i,
    input wire core_busy_i,core_done_i,
    input wire core_logits_valid_i,
    input wire [47:0] core_logits_i,
    // 1 = the current window has no loud bin; force background.
    input wire window_quiet_i,
    input wire template_result_valid_i,
    input wire [1:0] template_result_class_i,
    input wire cpu_job_authorized_i,cpu_event_valid_i,
    input wire [3:0] cpu_event_class_i,
    output wire cpu_probs_valid_o,cpu_job_done_o,
    output wire [95:0] cpu_probs_o,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire work_key_n_i,confirm_key_n_i,uart_rx_i,
    input wire template_preview_i,
    input wire [3:0] template_preview_class_i,
    input wire external_task_busy_i,
    input wire set_time_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    output wire core_start_o,
    output wire [8:0] core_start_op_o,core_end_op_o,
    output wire core_short_window_o,core_context_short_o,
    output wire [1:0] core_class_window_mode_o,
    output wire short_snapshot_accept_o,
    output wire short_result_valid_o,
    output wire motor_o,recognition_enable_o,work_mode_o,
    output wire panel_ready_o,panel_busy_o,
    output wire tft_nrst_o,tft_backlight_o,
    output wire tft_sclk_o,tft_mosi_o,tft_dc_o,tft_cs_n_o
);
    wire [95:0] probs,fused_probs,backend_probs_comb;
    reg [95:0] backend_probs_r;
    wire [95:0] backend_probs=backend_probs_r;
    wire probs_valid,fused_valid,backend_probs_valid,softmax_busy,alert_accept,confirm_pulse;
    wire scheduler_snapshot_accept;
    wire [1:0] scheduler_window_mode;
    reg [1:0] result_mode_r;
    reg backend_probs_valid_r;
    // Template-only builds keep the CNN core idle and never hand a softmax
    // result to the alert path, so the board test measures the matcher alone.
    wire sched_core_start;
    wire [1:0] cpu_template_class=cpu_event_class_i-4'd7;
    wire [95:0] cpu_decided_probs = cpu_event_class_i<6 ?
        (96'hffff << (cpu_event_class_i*16)) : 96'd0;
    assign cpu_probs_o=backend_probs;
    assign cpu_probs_valid_o=backend_probs_valid;
    assign cpu_job_done_o=short_result_valid_o;
    assign core_start_o = TEMPLATE_ONLY_MODE ? 1'b0 : sched_core_start;
    assign backend_probs_valid=TEMPLATE_ONLY_MODE ? 1'b0 : backend_probs_valid_r;
    assign core_class_window_mode_o=CLASS_WINDOW_MODE ? scheduler_window_mode : 2'd0;
    assign short_snapshot_accept_o=scheduler_snapshot_accept &&
        !short_snapshot_ready_i && !core_busy_i && !softmax_busy &&
        !short_result_valid_o;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) result_mode_r<=2'd0;
        else if(core_start_o && core_start_op_o==9'd0)
            result_mode_r<=scheduler_window_mode;
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            backend_probs_r<=96'd0;
            backend_probs_valid_r<=1'b0;
        end else begin
            backend_probs_valid_r<=fused_valid;
            if(fused_valid) backend_probs_r<=backend_probs_comb;
        end
    end
    mn04_cnn_template_fuser #(
        .PROTOTYPE_FILE(CNN_TEMPLATE_FILE),
        .VALID_MASK(CNN_TEMPLATE_VALID_MASK),
        .TEMPLATE_WEIGHT_Q2(CNN_TEMPLATE_WEIGHT_Q2)) cnn_template_fuser(
        .clk(clk),.rst_n(rst_n),.start_i(probs_valid),
        .probabilities_i(probs),.window_mode_i(result_mode_r),
        .valid_o(fused_valid),.fused_probabilities_o(fused_probs));

    // The three fixed-duration modes share the same six-output head:
    // 100f = background/dog/car; 120f = background/emergency vehicle;
    // 150f = background/baby/knock.
    reg [95:0] mode_probs;
    always @* begin
        mode_probs=fused_probs;
        if(CLASS_WINDOW_MODE && !UNIFORM_120_WINDOW_MODE) begin
            case(result_mode_r)
                2'd0: begin
                    mode_probs[1*16 +: 16]=16'd0;
                    mode_probs[2*16 +: 16]=16'd0;
                    mode_probs[3*16 +: 16]=16'd0;
                end
                2'd1: begin
                    mode_probs[1*16 +: 16]=16'd0;
                    mode_probs[2*16 +: 16]=16'd0;
                    mode_probs[4*16 +: 16]=16'd0;
                    mode_probs[5*16 +: 16]=16'd0;
                end
                2'd2: begin
                    mode_probs[3*16 +: 16]=16'd0;
                    mode_probs[4*16 +: 16]=16'd0;
                    mode_probs[5*16 +: 16]=16'd0;
                end
                default: begin
                    mode_probs[1*16 +: 16]=16'd0;
                    mode_probs[2*16 +: 16]=16'd0;
                    mode_probs[3*16 +: 16]=16'd0;
                    mode_probs[4*16 +: 16]=16'd0;
                    mode_probs[5*16 +: 16]=16'd0;
                end
            endcase
        end
    end
    assign backend_probs_comb = window_quiet_i ? 96'd0 : mode_probs;

    generate if(CURRENT_FIVE_CLASS_MODE) begin : g_current_five_softmax
        wire [79:0] five_probs;
        mn04_softmax_q16 #(.LUT_FILE(SOFTMAX_LUT_FILE),.N_CLASSES(5)) softmax(
            .clk(clk),.rst_n(rst_n),.logits_valid_i(core_logits_valid_i),
            .logits_i(core_logits_i[39:0]),.probs_valid_o(probs_valid),
            .probs_q16_o(five_probs),.busy_o(softmax_busy));
        // Preserve the display/event asset IDs: horn=5; dog=4 is unreachable.
        assign probs={five_probs[79:64],16'd0,five_probs[63:0]};
    end else begin : g_legacy_six_softmax
    mn04_softmax_q16 #(.LUT_FILE(SOFTMAX_LUT_FILE),.N_CLASSES(6)) softmax(
        .clk(clk),.rst_n(rst_n),.logits_valid_i(core_logits_valid_i),
        .logits_i(core_logits_i),.probs_valid_o(probs_valid),
        .probs_q16_o(probs),.busy_o(softmax_busy));
    end endgenerate

    mn04_dual_window_scheduler #(
        .SHORT_ONLY(1),.CONTINUE_WHILE_ALERT(CONTINUE_WHILE_ALERT)) scheduler(
        .clk(clk),.rst_n(rst_n),.short_ready_i(short_snapshot_ready_i),
        .short_mode_i(short_snapshot_mode_i),
        .long_ready_i(1'b0),.recognition_enable_i(recognition_enable_o),
        .alert_i(alert_accept),.confirmed_i(confirm_pulse),
        .core_busy_i(TEMPLATE_ONLY_MODE ? 1'b1 :
            (core_busy_i || (CPU_TASK_CONTROL && !cpu_job_authorized_i && core_start_op_o==0))),
        .core_done_i(TEMPLATE_ONLY_MODE ? 1'b0 : core_done_i),
        .core_start_o(sched_core_start),.core_start_op_o(core_start_op_o),
        .core_end_op_o(core_end_op_o),.core_short_window_o(core_short_window_o),
        .core_context_short_o(core_context_short_o),
        .core_short_mode_o(scheduler_window_mode),
        .short_result_valid_o(short_result_valid_o),.long_result_valid_o(),
        .alert_latched_o(),.short_snapshot_accept_o(scheduler_snapshot_accept),
        .long_snapshot_accept_o());

    v1_board_postcnn_top #(.SIX_CLASS_MODE(1),.ONE_SHOT_MODE(1),
        .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
        .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
        .EMERGENCY_VEHICLE_THRESHOLD_Q16(EMERGENCY_VEHICLE_THRESHOLD_Q16),
        .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
        .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16),
        .CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ),
        .RESET_CYCLES(RESET_CYCLES),.PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) backend(
        .clk(clk),.rst_n(rst_n),.work_key_n_i(work_key_n_i),
        .confirm_key_n_i(confirm_key_n_i),.uart_rx_i(uart_rx_i),
        .template_preview_i(template_preview_i),
        .template_preview_class_i(template_preview_class_i),
        .external_task_busy_i(external_task_busy_i),
        .probs_valid_i(CPU_TASK_CONTROL ? (cpu_event_valid_i && cpu_event_class_i<6) : backend_probs_valid),
        .probs_q16_i(CPU_TASK_CONTROL ? cpu_decided_probs : backend_probs),
        .template_result_valid_i(CPU_TASK_CONTROL ?
            (cpu_event_valid_i && cpu_event_class_i>=8 && cpu_event_class_i<=10) : template_result_valid_i),
        .template_result_class_i(CPU_TASK_CONTROL ? cpu_template_class : template_result_class_i),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .short_window_i(1'b1),.set_time_i(set_time_i),
        .set_hour_i(set_hour_i),.set_minute_i(set_minute_i),
        .set_second_i(set_second_i),.motor_o(motor_o),
        .recognition_enable_o(recognition_enable_o),.work_mode_o(work_mode_o),
        .alert_accept_o(alert_accept),.confirm_pulse_o(confirm_pulse),
        .panel_ready_o(panel_ready_o),.panel_busy_o(panel_busy_o),
        .tft_nrst_o(tft_nrst_o),.tft_backlight_o(tft_backlight_o),
        .tft_sclk_o(tft_sclk_o),.tft_mosi_o(tft_mosi_o),
        .tft_dc_o(tft_dc_o),.tft_cs_n_o(tft_cs_n_o));
endmodule
