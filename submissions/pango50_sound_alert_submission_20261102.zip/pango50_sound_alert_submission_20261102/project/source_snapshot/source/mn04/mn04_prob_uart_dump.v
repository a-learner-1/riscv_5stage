`timescale 1ns/1ps
// One ASCII line per CNN result: "P=hhhh,hhhh,hhhh,hhhh,hhhh" + CR/LF.
// The numbers come straight from the Softmax output registers, so the host
// sees exactly the probabilities the on-board decision uses.
module mn04_prob_uart_dump #(
    parameter integer CLOCK_HZ = 100_000_000,
    parameter integer BAUD = 115200
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        valid_i,
    input  wire [95:0] probs_q16_i,
    output reg         busy_o,
    output wire        tx_o
);
    localparam integer LEN = 29;   // 'P','=', 5 x (4 hex + ',') -> CR, LF

    reg [95:0] probs_r;
    reg [5:0]  idx_r;
    reg        send_r;
    reg  [7:0] char_r;
    wire       tx_ready;

    function [7:0] hex_char;
        input [3:0] n;
        begin
            hex_char = (n < 4'd10) ? (8'd48 + {4'd0, n}) : (8'd55 + {4'd0, n});
        end
    endfunction

    // Character at position idx for the latched vector.
    function [7:0] char_at;
        input [5:0] pos;
        input [95:0] p;
        integer k;
        reg [7:0] c;
        begin
            c = 8'h0D;
            if (pos == 6'd0) c = 8'h50;             // 'P'
            else if (pos == 6'd1) c = 8'h3D;        // '='
            else if (pos >= 6'd2 && pos < 6'd27) begin
                k = (pos - 6'd2) / 5;               // 0..4
                if (((pos - 6'd2) % 5) == 4) c = 8'h2C;   // ','
                else begin
                    case ((pos - 6'd2) % 5)
                        0: c = hex_char(p[k*16 + 15 -: 4]);
                        1: c = hex_char(p[k*16 + 11 -: 4]);
                        2: c = hex_char(p[k*16 + 7  -: 4]);
                        default: c = hex_char(p[k*16 + 3  -: 4]);
                    endcase
                end
            end else if (pos == 6'd27) c = 8'h0D;   // CR
            else c = 8'h0A;                          // LF
            char_at = c;
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            probs_r <= 96'd0;
            idx_r   <= 6'd0;
            send_r  <= 1'b0;
            char_r  <= 8'd0;
            busy_o  <= 1'b0;
        end else if (!send_r) begin
            if (valid_i) begin
                probs_r <= probs_q16_i;
                idx_r   <= 6'd0;
                char_r  <= 8'h50;
                send_r  <= 1'b1;
            end
            busy_o <= 1'b0;
        end else begin
            char_r <= char_at(idx_r, probs_r);
            if (tx_ready) begin
                if (idx_r == LEN - 1) begin
                    send_r <= 1'b0;
                    idx_r  <= 6'd0;
                end else begin
                    idx_r <= idx_r + 6'd1;
                end
            end
            busy_o <= 1'b1;
        end
    end

    uart_tx_8n1 #(.CLOCK_HZ(CLOCK_HZ), .BAUD(BAUD)) u_tx (
        .clk(clk), .rst_n(rst_n), .data_i(char_r),
        .valid_i(send_r), .ready_o(tx_ready), .tx_o(tx_o));
endmodule