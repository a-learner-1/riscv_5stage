`timescale 1ns/1ps
// Byte-write sink for the MN04 write FIFO. One accepted byte becomes one
// single-beat full-AXI4 write (256-bit data, one write strobe). Functional
// first bridge; transaction coalescing is a throughput optimization still to
// be measured.
//
// AXI4 side: this is a single-outstanding write master. It asserts awvalid and
// wvalid together (wlast=1, single beat), holds each until its ready, then
// waits for bvalid (bready is held high). The address is a 28-bit BYTE
// address; the byte's position inside the 256-bit beat is carried by wstrb
// (1<<byte_addr[4:0]) and wdata (byte<<8*byte_addr[4:0]).
module mn04_ddr_act_byte_writer (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         ddr_init_done_i,
    input  wire         byte_valid_i,
    input  wire [23:0]  byte_addr_i,
    input  wire [7:0]   byte_data_i,
    output wire         byte_ready_o,
    output reg  [27:0]  ddr_awaddr_o,
    output reg          ddr_awvalid_o,
    input  wire         ddr_awready_i,
    output reg  [255:0] ddr_wdata_o,
    output reg  [31:0]  ddr_wstrb_o,
    output reg          ddr_wvalid_o,
    output wire         ddr_wlast_o,
    input  wire         ddr_wready_i,
    input  wire [1:0]   ddr_bresp_i,
    input  wire         ddr_bvalid_i,
    output wire         ddr_bready_o,
    output wire         drained_o
);
    localparam IDLE=0, SEND=1, WAIT_B=2;
    reg [1:0] state_r;
    reg aw_done, w_done;
    assign byte_ready_o = (state_r == IDLE) && ddr_init_done_i;
    assign drained_o = (state_r == IDLE) && !byte_valid_i;
    assign ddr_wlast_o = 1'b1;   // single beat
    assign ddr_bready_o = 1'b1;  // single-outstanding: always accept response
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= IDLE;
            aw_done <= 0; w_done <= 0;
            ddr_awaddr_o <= 0; ddr_awvalid_o <= 0;
            ddr_wdata_o <= 0; ddr_wstrb_o <= 0; ddr_wvalid_o <= 0;
        end else begin
            case (state_r)
                IDLE: if (byte_valid_i && byte_ready_o) begin
                    ddr_awaddr_o <= {4'b0, byte_addr_i};
                    ddr_wdata_o <= {248'd0,byte_data_i} << (8*byte_addr_i[4:0]);
                    ddr_wstrb_o <= 32'd1 << byte_addr_i[4:0];
                    ddr_awvalid_o <= 1;
                    ddr_wvalid_o <= 1;
                    aw_done <= 0; w_done <= 0;
                    state_r <= SEND;
                end
                SEND: begin
                    if (ddr_awvalid_o && ddr_awready_i) begin
                        ddr_awvalid_o <= 0; aw_done <= 1;
                    end
                    if (ddr_wvalid_o && ddr_wready_i) begin
                        ddr_wvalid_o <= 0; w_done <= 1;
                    end
                    if (aw_done && w_done) state_r <= WAIT_B;
                end
                WAIT_B: if (ddr_bvalid_i) state_r <= IDLE;
                default: state_r <= IDLE;
            endcase
        end
    end
endmodule
