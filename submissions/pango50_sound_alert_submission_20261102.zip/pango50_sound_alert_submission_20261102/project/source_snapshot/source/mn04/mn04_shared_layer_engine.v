`timescale 1ns/1ps
// MN04 dot-product executor engine (GATE4 adaptation of
// senior_dbl_shared_layer_engine.v).  LANES=4 -> 4-lane mac (pw/fc),
// LANES=1 -> single-lane mac (depthwise / first conv).  Adds uact_i passed
// through to the MAC (unsigned activation mode for the V1 chain).
module mn04_shared_layer_engine #(
    parameter integer LANES = 4
)(
    input wire clk, input wire rst_n,
    input wire uact_i,
    input wire start_i, input wire [2:0] layer_id_i,
    input wire signed [31:0] bias_i, input wire [17:0] terms_i,
    output wire busy_o, output wire done_o, output wire signed [31:0] sum_o,
    output wire [2:0] active_layer_o, output wire [17:0] term_index_o,
    output wire [3:0] lane_mask_o,
    output wire pair_request_valid_o, input wire pair_request_ready_i,
    input wire pair_response_valid_i,
    input wire signed [9:0] a0_i, input wire signed [9:0] a1_i,
    input wire signed [9:0] a2_i, input wire signed [9:0] a3_i,
    input wire signed [7:0] w0_i, input wire signed [7:0] w1_i,
    input wire signed [7:0] w2_i, input wire signed [7:0] w3_i
);
    reg [2:0] active_layer_r;
    reg [17:0] term_index_r;
    reg launch_r;
    reg issue_d1, issue_d2, issue_d3;
    reg [3:0] mask_d1, mask_d2, mask_d3;
    wire mac_ready_w, mac_busy_w, mac_done_w;

    wire [17:0] rem = terms_i - term_index_r;
    wire [3:0] lane_mask;
    assign lane_mask[0] = rem > 18'd0;
    assign lane_mask[1] = rem > 18'd1;
    assign lane_mask[2] = rem > 18'd2;
    assign lane_mask[3] = rem > 18'd3;

    wire [3:0] effective_mask = (LANES == 1) ? 4'b0001 : lane_mask;
    wire [17:0] burst_size = (LANES == 1) ? 18'd1 :
        ({17'd0, lane_mask[0]} + {17'd0, lane_mask[1]} +
         {17'd0, lane_mask[2]} + {17'd0, lane_mask[3]});

    // A DDR row-cache miss may hold ready low BEFORE issue.  In that case
    // term_index and the fixed three-cycle weight/activation response pipeline
    // both stay aligned; already-issued pairs continue draining normally.
    wire request_valid = mac_ready_w && (rem != 18'd0);
    wire issue = request_valid && pair_request_ready_i;
    wire mac_pair_valid = issue_d3;
    wire [3:0] mac_lane_valid = mask_d3;

    generate if (LANES == 1) begin : single_lane
    mn04_shared_mac_single mac(
        .clk(clk),.rst_n(rst_n),.uact_i(uact_i),
        .start_i(launch_r),.bias_i(bias_i),.terms_i(terms_i),
        .activation_i(a0_i),.weight_i(w0_i),
        .pair_valid_i(mac_pair_valid),.pair_ready_o(mac_ready_w),
        .busy_o(mac_busy_w),.done_o(mac_done_w),.sum_o(sum_o));
    end else begin : four_lane
    mn04_shared_mac mac(
        .clk(clk),.rst_n(rst_n),.uact_i(uact_i),
        .start_i(launch_r),.bias_i(bias_i),.terms_i(terms_i),
        .act0_i(a0_i),.act1_i(a1_i),.act2_i(a2_i),.act3_i(a3_i),
        .w0_i(w0_i),.w1_i(w1_i),.w2_i(w2_i),.w3_i(w3_i),
        .lane_valid_i(mac_lane_valid),
        .pair_valid_i(mac_pair_valid),.pair_ready_o(mac_ready_w),
        .busy_o(mac_busy_w),.done_o(mac_done_w),.sum_o(sum_o));
    end endgenerate

    assign busy_o = mac_busy_w || launch_r;
    assign done_o = mac_done_w;
    assign active_layer_o = active_layer_r;
    assign term_index_o = term_index_r;
    assign lane_mask_o = effective_mask;
    assign pair_request_valid_o = request_valid;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            active_layer_r <= 0; term_index_r <= 0;
            launch_r <= 0; issue_d1 <= 0; issue_d2 <= 0; issue_d3 <= 0;
            mask_d1 <= 0; mask_d2 <= 0; mask_d3 <= 0;
        end else begin
            launch_r <= 0;
            if(start_i && !busy_o) begin
                active_layer_r <= layer_id_i;
                term_index_r <= 0; launch_r <= 1;
                issue_d1 <= 0; issue_d2 <= 0; issue_d3 <= 0;
                mask_d1 <= 0; mask_d2 <= 0; mask_d3 <= 0;
            end
            if(issue)
                term_index_r <= term_index_r + burst_size;
            issue_d1 <= issue; issue_d2 <= issue_d1; issue_d3 <= issue_d2;
            mask_d1 <= effective_mask; mask_d2 <= mask_d1; mask_d3 <= mask_d2;
        end
    end
endmodule
