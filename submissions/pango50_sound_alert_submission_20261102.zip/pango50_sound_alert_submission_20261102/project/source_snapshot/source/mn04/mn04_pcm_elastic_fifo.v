`timescale 1ns/1ps
// Decimator -> frontend rate matcher. The codec cannot be backpressured;
// frontend_framing_hann pauses PCM while processing a frame. At 50 MHz its
// measured frame processing budget is below the 10 ms hop, so this 128-sample
// FIFO absorbs the pause. Overflow is sticky and must inhibit an alert from
// a corrupted snapshot until a fresh window has been collected.
module mn04_pcm_elastic_fifo #(
    parameter integer ADDR_BITS = 7
)(
    input  wire clk,
    input  wire rst_n,
    input  wire signed [15:0] sample_i,
    input  wire sample_valid_i,
    output wire signed [15:0] sample_o,
    output wire sample_valid_o,
    input  wire sample_ready_i,
    output reg overflow_o
);
    localparam integer DEPTH = 1 << ADDR_BITS;
    reg signed [15:0] mem [0:DEPTH-1];
    reg [ADDR_BITS-1:0] wr_ptr, rd_ptr;
    reg [ADDR_BITS:0] count;
    wire pop = sample_valid_o && sample_ready_i;
    wire push = sample_valid_i && (count != DEPTH || pop);
    assign sample_valid_o = count != 0;
    assign sample_o = mem[rd_ptr];

    always @(posedge clk) if (push) mem[wr_ptr] <= sample_i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= 0;
            rd_ptr <= 0;
            count <= 0;
            overflow_o <= 0;
        end else begin
            if (push) wr_ptr <= wr_ptr + 1'b1;
            if (pop) rd_ptr <= rd_ptr + 1'b1;
            case ({push,pop})
                2'b10: count <= count + 1'b1;
                2'b01: count <= count - 1'b1;
                default: count <= count;
            endcase
            if (sample_valid_i && !push) overflow_o <= 1'b1;
        end
    end
endmodule
