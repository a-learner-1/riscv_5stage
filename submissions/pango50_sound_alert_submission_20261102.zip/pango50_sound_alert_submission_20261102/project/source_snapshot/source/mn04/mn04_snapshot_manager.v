`timescale 1ns/1ps
// Frame-count scheduler for one continuous 1000-frame x0 ring. Snapshot DMA
// freezes a 100-frame short window every 75 frames and a 1000-frame long
// window every 500 frames. Pending requests coalesce to the newest window.
// The inference scheduler's accept outputs prevent overwriting an arena
// while a job using it is active or pending.
module mn04_snapshot_manager #(
    parameter integer SHORT_HOP_FRAMES = 75,
    parameter integer ENABLE_LONG_WINDOW = 1
)(
    input  wire clk,
    input  wire rst_n,
    input  wire epoch_reset_i,
    input  wire recognition_enable_i,
    input  wire frame_done_i,
    input  wire [9:0] next_frame_slot_i,
    input  wire short_snapshot_accept_i,
    input  wire long_snapshot_accept_i,
    input  wire dma_busy_i,
    input  wire dma_done_short_i,
    input  wire dma_done_long_i,
    output reg dma_start_o,
    output reg dma_short_o,
    output reg [9:0] dma_next_frame_slot_o,
    output reg short_snapshot_ready_o,
    output reg long_snapshot_ready_o
);
    reg [9:0] short_left_r, long_left_r;
    reg short_pending_r, long_pending_r;
    reg [9:0] short_slot_r, long_slot_r;
    reg dma_owned_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            short_left_r <= 10'd100;
            long_left_r <= 10'd1000;
            short_pending_r <= 0;
            long_pending_r <= 0;
            short_slot_r <= 0;
            long_slot_r <= 0;
            dma_owned_r <= 0;
            dma_start_o <= 0;
            dma_short_o <= 0;
            dma_next_frame_slot_o <= 0;
            short_snapshot_ready_o <= 0;
            long_snapshot_ready_o <= 0;
        end else if (epoch_reset_i) begin
            short_left_r <= 10'd100;
            long_left_r <= 10'd1000;
            short_pending_r <= 0;
            long_pending_r <= 0;
            short_slot_r <= 0;
            long_slot_r <= 0;
            dma_owned_r <= 0;
            dma_start_o <= 0;
            dma_short_o <= 0;
            dma_next_frame_slot_o <= 0;
            short_snapshot_ready_o <= 0;
            long_snapshot_ready_o <= 0;
        end else begin
            dma_start_o <= 0;
            short_snapshot_ready_o <= 0;
            long_snapshot_ready_o <= 0;
            if (frame_done_i) begin
                if (short_left_r == 10'd1) begin
                    short_left_r <= SHORT_HOP_FRAMES;
                    if (recognition_enable_i) begin
                        short_pending_r <= 1;
                        short_slot_r <= next_frame_slot_i;
                    end
                end else short_left_r <= short_left_r - 1'b1;
                if (ENABLE_LONG_WINDOW && long_left_r == 10'd1) begin
                    long_left_r <= 10'd500;
                    if (recognition_enable_i) begin
                        long_pending_r <= 1;
                        long_slot_r <= next_frame_slot_i;
                    end
                end else if (ENABLE_LONG_WINDOW) long_left_r <= long_left_r - 1'b1;
            end
            if (!recognition_enable_i) begin
                short_pending_r <= 0;
                long_pending_r <= 0;
            end
            if (dma_done_short_i) begin
                dma_owned_r <= 0;
                if (recognition_enable_i) short_snapshot_ready_o <= 1;
            end
            if (dma_done_long_i) begin
                dma_owned_r <= 0;
                if (recognition_enable_i) long_snapshot_ready_o <= 1;
            end
            if (!dma_busy_i && !dma_owned_r && recognition_enable_i) begin
                if (short_pending_r && short_snapshot_accept_i) begin
                    dma_start_o <= 1;
                    dma_short_o <= 1;
                    dma_next_frame_slot_o <= short_slot_r;
                    short_pending_r <= 0;
                    dma_owned_r <= 1;
                end else if (long_pending_r && long_snapshot_accept_i) begin
                    dma_start_o <= 1;
                    dma_short_o <= 0;
                    dma_next_frame_slot_o <= long_slot_r;
                    long_pending_r <= 0;
                    dma_owned_r <= 1;
                end
            end
        end
    end
endmodule

// Three class-specific windows share the same 1000-frame ring and one
// activation arena. The manager waits for the inference controller to release
// that arena before starting DMA, then tags the completed snapshot with its
// window mode. Expired requests coalesce independently to the newest slot.
module mn04_class_window_snapshot_manager #(
    parameter integer UNIFORM_120_WINDOW = 0,
    // Frames to ignore after recognition is armed. The button click and its
    // room reverb land in the first window and look exactly like a knock, so
    // the first snapshot is taken after this warm-up gap.
    parameter integer WARMUP_FRAMES = 400
)(
    input  wire clk,
    input  wire rst_n,
    input  wire epoch_reset_i,
    input  wire recognition_enable_i,
    input  wire frame_done_i,
    input  wire [9:0] next_frame_slot_i,
    input  wire snapshot_accept_i,
    input  wire dma_busy_i,
    input  wire dma_done_i,
    output reg dma_start_o,
    output reg [1:0] dma_window_mode_o,
    output reg [9:0] dma_next_frame_slot_o,
    output reg snapshot_ready_o,
    output reg [1:0] snapshot_window_mode_o
);
    reg [9:0] left_100_r, left_120_r, left_150_r;
    reg [9:0] slot_100_r, slot_120_r, slot_150_r;
    reg [2:0] pending_r;
    reg dma_owned_r;
    reg [1:0] active_mode_r;
    reg [9:0] warm_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            left_100_r <= 10'd100;
            left_120_r <= 10'd120;
            left_150_r <= 10'd150;
            slot_100_r <= 0; slot_120_r <= 0; slot_150_r <= 0;
            pending_r <= 0; dma_owned_r <= 0;
            active_mode_r <= UNIFORM_120_WINDOW ? 2'd1 : 2'd0;
            warm_r <= WARMUP_FRAMES;
            dma_start_o <= 0;
            dma_window_mode_o <= UNIFORM_120_WINDOW ? 2'd1 : 2'd0;
            dma_next_frame_slot_o <= 0;
            snapshot_ready_o <= 0;
            snapshot_window_mode_o <= UNIFORM_120_WINDOW ? 2'd1 : 2'd0;
        end else if (epoch_reset_i) begin
            left_100_r <= 10'd100;
            left_120_r <= 10'd120;
            left_150_r <= 10'd150;
            slot_100_r <= 0; slot_120_r <= 0; slot_150_r <= 0;
            pending_r <= 0; dma_owned_r <= 0;
            active_mode_r <= UNIFORM_120_WINDOW ? 2'd1 : 2'd0;
            warm_r <= WARMUP_FRAMES;
            dma_start_o <= 0;
            dma_window_mode_o <= UNIFORM_120_WINDOW ? 2'd1 : 2'd0;
            dma_next_frame_slot_o <= 0;
            snapshot_ready_o <= 0;
            snapshot_window_mode_o <= UNIFORM_120_WINDOW ? 2'd1 : 2'd0;
        end else begin
            dma_start_o <= 0;
            snapshot_ready_o <= 0;

            if (!recognition_enable_i) begin
                left_100_r <= 10'd100;
                left_120_r <= 10'd120;
                left_150_r <= 10'd150;
                pending_r <= 0;
                warm_r <= WARMUP_FRAMES;
            end else begin
                // Start before recording expirations so a simultaneous new
                // window remains pending instead of being cleared by a launch.
                if (!dma_busy_i && !dma_owned_r && snapshot_accept_i) begin
                    if (UNIFORM_120_WINDOW && pending_r[1]) begin
                        dma_start_o <= 1;
                        dma_window_mode_o <= 1;
                        active_mode_r <= 1;
                        dma_next_frame_slot_o <= slot_120_r;
                        pending_r[1] <= 0;
                        dma_owned_r <= 1;
                    end else if (!UNIFORM_120_WINDOW) begin
                        if (pending_r[0]) begin
                            dma_start_o <= 1;
                            dma_window_mode_o <= 0;
                            active_mode_r <= 0;
                            dma_next_frame_slot_o <= slot_100_r;
                            pending_r[0] <= 0;
                            dma_owned_r <= 1;
                        end else if (pending_r[1]) begin
                            dma_start_o <= 1;
                            dma_window_mode_o <= 1;
                            active_mode_r <= 1;
                            dma_next_frame_slot_o <= slot_120_r;
                            pending_r[1] <= 0;
                            dma_owned_r <= 1;
                        end else if (pending_r[2]) begin
                            dma_start_o <= 1;
                            dma_window_mode_o <= 2;
                            active_mode_r <= 2;
                            dma_next_frame_slot_o <= slot_150_r;
                            pending_r[2] <= 0;
                            dma_owned_r <= 1;
                        end
                    end
                end

                if (frame_done_i) begin
                    if (warm_r != 10'd0) warm_r <= warm_r - 1'b1;
                    else if (UNIFORM_120_WINDOW) begin
                        if (left_120_r == 1) begin
                            left_120_r <= 10'd60;
                            slot_120_r <= next_frame_slot_i;
                            pending_r[1] <= 1;
                        end else left_120_r <= left_120_r - 1'b1;
                    end else begin
                        if (left_100_r == 1) begin
                            left_100_r <= 10'd50;
                            slot_100_r <= next_frame_slot_i;
                            pending_r[0] <= 1;
                        end else left_100_r <= left_100_r - 1'b1;
                        if (left_120_r == 1) begin
                            left_120_r <= 10'd60;
                            slot_120_r <= next_frame_slot_i;
                            pending_r[1] <= 1;
                        end else left_120_r <= left_120_r - 1'b1;
                        if (left_150_r == 1) begin
                            left_150_r <= 10'd75;
                            slot_150_r <= next_frame_slot_i;
                            pending_r[2] <= 1;
                        end else left_150_r <= left_150_r - 1'b1;
                    end
                end
            end

            if (dma_done_i && dma_owned_r) begin
                dma_owned_r <= 0;
                if (recognition_enable_i) begin
                    snapshot_ready_o <= 1;
                    snapshot_window_mode_o <= active_mode_r;
                end
            end
        end
    end
endmodule
