`timescale 1ns/1ps
// Streaming parser for the 8 KiB template selector journal at 0x670000.
//
// Each 64-byte record is validated exactly like the host contract in
// scripts/template_selector_journal.py: the commit word is checked first,
// then magic/version/flags, CRC-32, slot and length.  Selection keeps the
// highest generation with one committed content; a conflicting generation is
// skipped in favour of the previous selection, and a journal with no valid
// record falls back to fixed slot A.
//
// The caller supplies exactly RECORDS * 64 bytes in address order; ready_o
// drops while a record's CRC is evaluated so a parallel fast reader can be
// back-pressured.
module mn04_template_selector #(
    parameter integer RECORDS = 128,
    parameter integer MIN_CONTAINER_BYTES = 104961
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_i,
    input  wire [7:0]  byte_i,
    input  wire        valid_i,
    output wire        ready_o,
    output reg         done_o,
    output reg         active_valid_o,   // 0 => fixed fallback slot A
    output reg         slot_o,           // 0=A, 1=B
    output reg  [31:0] generation_o,
    output reg  [31:0] container_bytes_o,
    output reg  [17:0] first_erased_index_o,
    output reg         first_erased_valid_o,
    output reg  [7:0]  uncommitted_count_o,
    output reg  [7:0]  invalid_count_o,
    output reg  [7:0]  conflict_count_o
);
    localparam [7:0] MAGIC0 = 8'h50, MAGIC1 = 8'h35, MAGIC2 = 8'h30,
                     MAGIC3 = 8'h53, MAGIC4 = 8'h45, MAGIC5 = 8'h4C,
                     MAGIC6 = 8'h30, MAGIC7 = 8'h31;   // "P50SEL01"
    localparam [7:0] COMMIT0 = 8'h43, COMMIT1 = 8'h4D,
                     COMMIT2 = 8'h54, COMMIT3 = 8'h31; // "CMT1"

    reg [7:0]  rbuf [0:63];
    reg [5:0]  wi_r;                 // 0..63
    reg [6:0]  rec_no_r;             // 0..RECORDS-1
    reg        rec_all_ff_r;

    // CRC-32 / IEEE 802.3, LSB-first, initial 0xFFFFFFFF, final inversion.
    reg        crc_busy_r;
    reg        finalize_pending_r;
    reg [5:0]  crc_idx_r;            // byte 0..55
    reg [2:0]  crc_bit_r;
    reg [31:0] crc_r;

    reg best_valid_r, prev_valid_r, best_conflict_r;
    reg [31:0] best_gen_r, prev_gen_r;
    reg        best_slot_r, prev_slot_r;
    reg [17:0] best_len_r, prev_len_r;
    reg [255:0] best_sha_r, prev_sha_r;

    wire [7:0] crc_byte = rbuf[crc_idx_r];
    wire       crc_lsb = crc_r[0] ^ crc_byte[crc_bit_r];
    wire [31:0] crc_shift = {1'b0, crc_r[31:1]};
    wire [31:0] crc_next = crc_lsb ? (crc_shift ^ 32'hEDB88320) : crc_shift;
    wire [31:0] calc_crc = ~crc_next;   // valid on the final bit

    wire [31:0] rec_gen = {rbuf[15], rbuf[14], rbuf[13], rbuf[12]};
    wire        rec_slot = rbuf[16];
    wire [17:0] rec_len = {rbuf[22][1:0], rbuf[21], rbuf[20]};
    wire [255:0] rec_sha = {
        rbuf[24], rbuf[25], rbuf[26], rbuf[27], rbuf[28], rbuf[29], rbuf[30], rbuf[31],
        rbuf[32], rbuf[33], rbuf[34], rbuf[35], rbuf[36], rbuf[37], rbuf[38], rbuf[39],
        rbuf[40], rbuf[41], rbuf[42], rbuf[43], rbuf[44], rbuf[45], rbuf[46], rbuf[47],
        rbuf[48], rbuf[49], rbuf[50], rbuf[51], rbuf[52], rbuf[53], rbuf[54], rbuf[55]};
    wire [31:0] rec_crc = {rbuf[59], rbuf[58], rbuf[57], rbuf[56]};

    wire commit_ok = (rbuf[60] == COMMIT0) && (rbuf[61] == COMMIT1) &&
                     (rbuf[62] == COMMIT2) && (rbuf[63] == COMMIT3);
    wire fields_ok =
        (rbuf[0] == MAGIC0) && (rbuf[1] == MAGIC1) && (rbuf[2] == MAGIC2) &&
        (rbuf[3] == MAGIC3) && (rbuf[4] == MAGIC4) && (rbuf[5] == MAGIC5) &&
        (rbuf[6] == MAGIC6) && (rbuf[7] == MAGIC7) &&
        (rbuf[8] == 8'h01) && (rbuf[9] == 8'h00) &&
        (rbuf[10] == 8'h00) && (rbuf[11] == 8'h00) &&
        (rbuf[17] == 8'h00) && (rbuf[16] <= 8'h01) &&
        (rbuf[18] == 8'h00) && (rbuf[19] == 8'h00) &&
        (rbuf[22][7:2] == 6'd0) && (rbuf[23] == 8'h00) &&
        (rec_len >= MIN_CONTAINER_BYTES) && (rec_len <= 18'd196608);
    wire record_valid = commit_ok && fields_ok && (rec_crc == calc_crc);

    assign ready_o = !crc_busy_r && !done_o;

    task automatic promote_best;
        begin
            if (best_valid_r && !best_conflict_r) begin
                prev_valid_r <= 1'b1;
                prev_gen_r <= best_gen_r;
                prev_slot_r <= best_slot_r;
                prev_len_r <= best_len_r;
                prev_sha_r <= best_sha_r;
            end
            best_valid_r <= 1'b1;
            best_conflict_r <= 1'b0;
            best_gen_r <= rec_gen;
            best_slot_r <= rec_slot;
            best_len_r <= rec_len;
            best_sha_r <= rec_sha;
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wi_r <= 6'd0; rec_no_r <= 7'd0; rec_all_ff_r <= 1'b1;
            crc_busy_r <= 1'b0; crc_idx_r <= 6'd0; crc_bit_r <= 3'd0;
            crc_r <= 32'hFFFFFFFF;
            finalize_pending_r <= 1'b0;
            done_o <= 1'b0; active_valid_o <= 1'b0; slot_o <= 1'b0;
            generation_o <= 32'd0; container_bytes_o <= 32'd0;
            first_erased_index_o <= 18'd0; first_erased_valid_o <= 1'b0;
            uncommitted_count_o <= 8'd0; invalid_count_o <= 8'd0;
            conflict_count_o <= 8'd0;
            best_valid_r <= 0; prev_valid_r <= 0; best_conflict_r <= 0;
            best_gen_r <= 0; prev_gen_r <= 0;
            best_slot_r <= 0; prev_slot_r <= 0;
            best_len_r <= 0; prev_len_r <= 0;
            best_sha_r <= 256'd0; prev_sha_r <= 256'd0;
        end else if (start_i) begin
            wi_r <= 6'd0; rec_no_r <= 7'd0; rec_all_ff_r <= 1'b1;
            crc_busy_r <= 1'b0; crc_idx_r <= 6'd0; crc_bit_r <= 3'd0;
            crc_r <= 32'hFFFFFFFF;
            finalize_pending_r <= 1'b0;
            done_o <= 1'b0; active_valid_o <= 1'b0; slot_o <= 1'b0;
            generation_o <= 32'd0; container_bytes_o <= 32'd0;
            first_erased_index_o <= 18'd0; first_erased_valid_o <= 1'b0;
            uncommitted_count_o <= 8'd0; invalid_count_o <= 8'd0;
            conflict_count_o <= 8'd0;
            best_valid_r <= 0; prev_valid_r <= 0; best_conflict_r <= 0;
            best_gen_r <= 0; prev_gen_r <= 0;
            best_slot_r <= 0; prev_slot_r <= 0;
            best_len_r <= 0; prev_len_r <= 0;
            best_sha_r <= 256'd0; prev_sha_r <= 256'd0;
        end else if (valid_i && !crc_busy_r && !done_o) begin
            rbuf[wi_r] <= byte_i;
            rec_all_ff_r <= rec_all_ff_r && (byte_i == 8'hFF);
            if (wi_r == 6'd63) begin
                wi_r <= 6'd0;
                crc_busy_r <= 1'b1;
                crc_idx_r <= 6'd0;
                crc_bit_r <= 3'd0;
                crc_r <= 32'hFFFFFFFF;
            end else begin
                wi_r <= wi_r + 6'd1;
            end
        end else if (crc_busy_r) begin
            if (crc_idx_r == 6'd55 && crc_bit_r == 3'd7) begin
                crc_busy_r <= 1'b0;
                crc_r <= 32'hFFFFFFFF;
                // Classify the finished record.
                if (rec_all_ff_r) begin
                    if (!first_erased_valid_o) begin
                        first_erased_valid_o <= 1'b1;
                        first_erased_index_o <= {11'd0, rec_no_r};
                    end
                end else if (!commit_ok) begin
                    uncommitted_count_o <= uncommitted_count_o + 8'd1;
                end else if (!fields_ok || (rec_crc != calc_crc)) begin
                    invalid_count_o <= invalid_count_o + 8'd1;
                end else if (!best_valid_r || rec_gen > best_gen_r) begin
                    promote_best();
                end else if (rec_gen == best_gen_r) begin
                    if (rec_slot != best_slot_r || rec_len != best_len_r ||
                        rec_sha != best_sha_r) begin
                        best_conflict_r <= 1'b1;
                    end
                end
                if (rec_no_r == RECORDS - 1) begin
                    // Finalize on the next cycle so a valid/conflicting last
                    // record's nonblocking updates to best_* are visible.
                    finalize_pending_r <= 1'b1;
                end else begin
                    rec_no_r <= rec_no_r + 7'd1;
                    rec_all_ff_r <= 1'b1;
                end
            end else begin
                crc_r <= crc_next;
                if (crc_bit_r == 3'd7) begin
                    crc_bit_r <= 3'd0;
                    crc_idx_r <= crc_idx_r + 6'd1;
                end else begin
                    crc_bit_r <= crc_bit_r + 3'd1;
                end
            end
        end else if (finalize_pending_r && !done_o) begin
            finalize_pending_r <= 1'b0;
            done_o <= 1'b1;
            if (best_valid_r && !best_conflict_r) begin
                active_valid_o <= 1'b1;
                slot_o <= best_slot_r;
                generation_o <= best_gen_r;
                container_bytes_o <= {14'd0, best_len_r};
            end else if (prev_valid_r) begin
                active_valid_o <= 1'b1;
                slot_o <= prev_slot_r;
                generation_o <= prev_gen_r;
                container_bytes_o <= {14'd0, prev_len_r};
            end else begin
                active_valid_o <= 1'b0;
                slot_o <= 1'b0;
                generation_o <= 32'd0;
                container_bytes_o <= 32'd0;
            end
            if (best_conflict_r) conflict_count_o <= 8'd1;
        end
    end
endmodule
