`timescale 1ns/1ps
// Single-transaction SPI-NOR command engine used by the runtime template
// updater.  The orchestrator issues one transaction at a time and polls the
// status register itself, which keeps this block small and easy to verify.
//
// Transactions (mode 0, MSB first):
//   0 WREN   write enable                        (1 header byte)
//   1 SE     sector erase, 4 KiB                (0x20 + 24-bit address)
//   2 PP     page program, 1..256 bytes         (0x02 + address + data)
//   3 RDSR   read status register               (0x05 + 1 byte in)
module mn04_flash_programmer #(
    parameter integer SPI_DIV_HALF = 2
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       start_i,
    input  wire [1:0] txn_i,
    input  wire [23:0] addr_i,
    input  wire [8:0] len_i,          // 0 means 256 bytes
    input  wire       data_valid_i,
    input  wire [7:0] data_i,
    output wire       data_ready_o,
    output reg        busy_o,
    output reg        done_o,
    output reg        status_valid_o,
    output reg  [7:0] status_o,
    output reg        cs_o,
    output reg        sck_o,
    output reg        mosi_o,
    input  wire       miso_i
);
    localparam TXN_WREN = 2'd0, TXN_SE = 2'd1, TXN_PP = 2'd2, TXN_RDSR = 2'd3;
    localparam S_IDLE = 3'd0, S_HDR = 3'd1, S_WAIT_DATA = 3'd2,
               S_DATA = 3'd3, S_RX = 3'd4, S_END = 3'd5;

    reg [2:0]  state_r;
    reg [1:0]  txn_r;
    reg [23:0] addr_r;
    reg [8:0]  len_left_r;
    reg [2:0]  hdr_idx_r;
    reg [2:0]  hdr_total_r;
    reg [2:0]  bit_r;
    reg [4:0]  half_r;
    reg [7:0]  sh_out_r;
    reg [7:0]  sh_in_r;

    wire [2:0] hdr_total = (txn_r == TXN_WREN || txn_r == TXN_RDSR) ? 3'd1 : 3'd4;
    wire [2:0] hdr_next_idx = hdr_idx_r + 3'd1;
    wire [7:0] hdr_next_byte =
        (hdr_next_idx == 3'd0) ? ((txn_r == TXN_WREN) ? 8'h06 :
                                  (txn_r == TXN_SE)   ? 8'h20 :
                                  (txn_r == TXN_PP)   ? 8'h02 : 8'h05) :
        (hdr_next_idx == 3'd1) ? addr_r[23:16] :
        (hdr_next_idx == 3'd2) ? addr_r[15:8] : addr_r[7:0];

    assign data_ready_o = (state_r == S_WAIT_DATA);    // One byte is shifted out/in with SCK low then high for SPI_DIV_HALF
    // clocks each.  MISO is sampled as SCK rises, matching mode 0.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= S_IDLE;
            txn_r <= TXN_WREN;
            addr_r <= 24'd0;
            len_left_r <= 9'd0;
            hdr_idx_r <= 3'd0;
            hdr_total_r <= 3'd1;
            bit_r <= 3'd7;
            half_r <= 5'd0;
            sh_out_r <= 8'h00;
            sh_in_r <= 8'h00;
            cs_o <= 1'b1; sck_o <= 1'b0; mosi_o <= 1'b1;
            busy_o <= 1'b0; done_o <= 1'b0;
            status_valid_o <= 1'b0; status_o <= 8'h00;
        end else begin
            done_o <= 1'b0;
            status_valid_o <= 1'b0;
            case (state_r)
                S_IDLE: begin
                    if (start_i) begin
                        txn_r <= txn_i;
                        addr_r <= addr_i;
                        len_left_r <= (len_i == 9'd0) ? 9'd256 : len_i;
                        hdr_idx_r <= 3'd0;
                        hdr_total_r <= (txn_i == TXN_WREN || txn_i == TXN_RDSR) ?
                                       3'd1 : 3'd4;
                        sh_out_r <= (txn_i == TXN_WREN) ? 8'h06 :
                                    (txn_i == TXN_SE)   ? 8'h20 :
                                    (txn_i == TXN_PP)   ? 8'h02 : 8'h05;
                        bit_r <= 3'd7; half_r <= 5'd0;
                        sh_in_r <= 8'h00;
                        cs_o <= 1'b0; sck_o <= 1'b0;
                        busy_o <= 1'b1;
                        mosi_o <= ((txn_i == TXN_WREN) ? 8'h06 :
                                   (txn_i == TXN_SE)   ? 8'h20 :
                                   (txn_i == TXN_PP)   ? 8'h02 : 8'h05) >> 7;
                        state_r <= S_HDR;
                    end
                end
                S_HDR, S_DATA, S_RX: begin
                    if (half_r < SPI_DIV_HALF) begin
                        sck_o <= 1'b0;
                        if (half_r == 0) mosi_o <= sh_out_r[bit_r];
                        half_r <= half_r + 5'd1;
                    end else if (half_r < (2 * SPI_DIV_HALF - 1)) begin
                        sck_o <= 1'b1;
                        if (half_r == SPI_DIV_HALF && state_r == S_RX)
                            sh_in_r[bit_r] <= miso_i;
                        half_r <= half_r + 5'd1;
                    end else begin
                        sck_o <= 1'b1;
                        half_r <= 5'd0;
                        if (bit_r != 3'd0) begin
                            bit_r <= bit_r - 3'd1;
                        end else begin
                            bit_r <= 3'd7;
                            // Byte boundary.
                            case (state_r)
                                S_HDR: begin
                                    if (hdr_idx_r + 3'd1 >= hdr_total_r) begin
                                        if (txn_r == TXN_PP) begin
                                            state_r <= S_WAIT_DATA;
                                        end else if (txn_r == TXN_RDSR) begin
                                            sh_in_r <= 8'h00;
                                            state_r <= S_RX;
                                        end else begin
                                            state_r <= S_END;
                                        end
                                    end else begin
                                        hdr_idx_r <= hdr_idx_r + 3'd1;
                                        // MOSI changes at the next falling edge
                                        // (half == 0), not together with the
                                        // rising edge that samples the last bit.
                                        sh_out_r <= hdr_next_byte;
                                    end
                                end
                                S_DATA: begin
                                    if (len_left_r == 9'd1) begin
                                        state_r <= S_END;
                                    end else begin
                                        len_left_r <= len_left_r - 9'd1;
                                        state_r <= S_WAIT_DATA;
                                    end
                                end
                                S_RX: begin
                                    status_o <= sh_in_r;
                                    status_valid_o <= 1'b1;
                                    state_r <= S_END;
                                end
                                default: state_r <= S_END;
                            endcase
                        end
                    end
                end
                S_WAIT_DATA: begin
                    sck_o <= 1'b0;
                    if (data_valid_i) begin
                        sh_out_r <= data_i;
                        mosi_o <= data_i[7];
                        bit_r <= 3'd7;
                        half_r <= 5'd0;
                        state_r <= S_DATA;
                    end
                end
                S_END: begin
                    cs_o <= 1'b1;
                    sck_o <= 1'b0;
                    mosi_o <= 1'b1;
                    busy_o <= 1'b0;
                    done_o <= 1'b1;
                    state_r <= S_IDLE;
                end
                default: state_r <= S_IDLE;
            endcase
        end
    end
endmodule
