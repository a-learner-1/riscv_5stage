`timescale 1ns/1ps
// MN04 single-lane signed/unsigned int8 MAC (GATE4 adaptation of
// senior_dbl_shared_mac_single.v).  Used for depthwise / first-conv dot
// products (1 term per cycle).  uact_i: unsigned activation mode.
module mn04_shared_mac_single (
    input  wire        clk, input  wire rst_n,
    input  wire        uact_i,
    input  wire        start_i, input  wire signed [31:0] bias_i,
    input  wire [17:0] terms_i,
    input  wire signed [9:0] activation_i,
    input  wire signed [7:0] weight_i,
    input  wire        pair_valid_i, output wire pair_ready_o,
    output reg         busy_o, output reg done_o, output reg signed [31:0] sum_o
);
    reg [17:0] remaining_r;
    reg signed [17:0] p_r;
    reg        pair_pending_r;

    wire signed [17:0] prod = uact_i ? ($signed({2'b00, activation_i[7:0]}) * $signed(weight_i))
                                     : ($signed(activation_i) * $signed(weight_i));

    assign pair_ready_o = busy_o && (remaining_r != 0);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            remaining_r <= 0; busy_o <= 0; done_o <= 0; sum_o <= 0;
            p_r <= 0; pair_pending_r <= 0;
        end else begin
            done_o <= 0;
            if (start_i && !busy_o) begin
                sum_o <= bias_i;
                remaining_r <= terms_i;
                busy_o <= (terms_i != 0);
                pair_pending_r <= 0;
                if (terms_i == 0) done_o <= 1;
            end else if (pair_pending_r && (remaining_r == 0)) begin
                sum_o <= sum_o + p_r;
                pair_pending_r <= 0; busy_o <= 0; done_o <= 1;
            end else if (pair_valid_i && pair_ready_o) begin
                p_r <= prod;
                if (pair_pending_r) sum_o <= sum_o + p_r;
                pair_pending_r <= 1;
                remaining_r <= remaining_r - 18'd1;
            end
        end
    end
endmodule
