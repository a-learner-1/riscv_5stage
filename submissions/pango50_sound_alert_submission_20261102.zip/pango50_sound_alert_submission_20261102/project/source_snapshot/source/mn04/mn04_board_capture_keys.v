`timescale 1ns/1ps
// MES50HP active-low buttons for batched CNN training capture.
// KEY7 switches between CNN and preset-template capture. K4 advances the
// selected class in that family (and asks the capture engine to flush the
// previous batch), K5 starts a take, and K6 ends a take. Debouncing emits one
// action per physical press; holding a key never repeats an action.
module mn04_board_capture_keys #(
    parameter integer CLOCK_HZ=100000000
)(
    input wire clk,rst_n,
    input wire category_key_n_i,start_key_n_i,stop_key_n_i,mode_key_n_i,
    input wire recognition_enable_i,capture_busy_i,capture_recording_i,
    output reg category_advance_o,
    output reg template_mode_o,
    output reg preview_enable_o,
    output reg capture_start_o,
    output reg capture_stop_o
);
    wire tick_ms,category_press,start_press,stop_press,mode_press;
    v1_ms_tick #(.CLOCK_HZ(CLOCK_HZ)) ms_tick(
        .clk(clk),.rst_n(rst_n),.tick_ms_o(tick_ms));
    v1_key_debounce category_key(.clk(clk),.rst_n(rst_n),
        .tick_ms_i(tick_ms),.key_n_i(category_key_n_i),.press_o(category_press));
    v1_key_debounce start_key(.clk(clk),.rst_n(rst_n),
        .tick_ms_i(tick_ms),.key_n_i(start_key_n_i),.press_o(start_press));
    v1_key_debounce stop_key(.clk(clk),.rst_n(rst_n),
        .tick_ms_i(tick_ms),.key_n_i(stop_key_n_i),.press_o(stop_press));
    v1_key_debounce mode_key(.clk(clk),.rst_n(rst_n),
        .tick_ms_i(tick_ms),.key_n_i(mode_key_n_i),.press_o(mode_press));

    reg [12:0] preview_hold_ms;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            category_advance_o<=1'b0;
            template_mode_o<=1'b0;
            preview_enable_o<=1'b1;
            preview_hold_ms<=13'd4000;
            capture_start_o<=1'b0;
            capture_stop_o<=1'b0;
        end else begin
            category_advance_o<=1'b0;
            capture_start_o<=1'b0;
            capture_stop_o<=1'b0;

            // Show the armed class only briefly after the user changes it.
            // A permanently lit preview used the alarm renderer, so an idle
            // board looked like a class was detected all the time, and after
            // an acknowledgement the same picture came back a second later.
            if(tick_ms && preview_hold_ms!=13'd0)
                preview_hold_ms<=preview_hold_ms-1'b1;
            if(category_press || mode_press)
                preview_hold_ms<=13'd4000;
            if(recognition_enable_i || capture_busy_i || preview_hold_ms==13'd0)
                preview_enable_o<=1'b0;
            else
                preview_enable_o<=1'b1;

            if(!recognition_enable_i && !capture_busy_i && category_press)
                category_advance_o<=1'b1;
            if(!recognition_enable_i && !capture_busy_i && mode_press)
                template_mode_o<=!template_mode_o;
            if(!recognition_enable_i && !capture_busy_i && start_press)
                capture_start_o<=1'b1;
            if(!recognition_enable_i && capture_recording_i && stop_press)
                capture_stop_o<=1'b1;
        end
    end
endmodule
