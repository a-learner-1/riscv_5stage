`timescale 1ns/1ps
// MN04 SPI-NOR block reader (GATE4 copy of senior_dbl_qspi_block_reader.v)
// with a sim-acceleration parameter FAST_BYTES.  FAST_BYTES=0 reproduces the
// real SPI mode-0 transaction byte-for-byte (used by the qspi unit test);
// FAST_BYTES=1 keeps the same HDR/DATA/FIN FSM and ready/valid byte handshake
// but delivers DATA bytes at 1 per clock from the parallel flash port
// (flash_rd_addr_o/flash_rd_data_i), so 681 KB model-image loads finish in
// ~700K cycles instead of ~22M.
module mn04_qspi_block_reader #(
    parameter integer SPI_DIV_HALF = 2,
    parameter integer FAST_BYTES = 0
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_i,
    input  wire [23:0] addr_i,
    input  wire [15:0] count_i,
    output wire        busy_o,
    output reg         done_o,
    output reg  [7:0]  byte_o,
    output reg         byte_valid_o,
    input  wire        byte_ready_i,
    // parallel fast flash port (FAST_BYTES=1 only)
    output wire [23:0] flash_rd_addr_o,
    input  wire [7:0]  flash_rd_data_i,
    // SPI-NOR physical pins
    output reg         cs_o,
    output reg         sck_o,
    output reg         mosi_o,
    input  wire        miso_i
);
    localparam IDLE=2'd0, HDR=2'd1, DATA=2'd2, FIN=2'd3;

    reg [1:0]  st_r;
    reg [15:0] half_r;
    reg [7:0]  hdr_r;
    reg [1:0]  hdr_idx_r;
    reg [7:0]  bitbuf_r;
    reg [2:0]  bitidx_r;
    reg [15:0] rx_r;
    reg [23:0] addr_r;
    reg [15:0] count_r;

    wire [7:0] next_hdr = (hdr_idx_r == 2'd0) ? addr_r[23:16] :
                          (hdr_idx_r == 2'd1) ? addr_r[15:8]  : addr_r[7:0];

    assign busy_o = (st_r != IDLE);
    assign flash_rd_addr_o = addr_r + {8'd0, rx_r};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st_r <= IDLE; half_r <= 0;
            hdr_r <= 8'h00; hdr_idx_r <= 2'd0;
            bitbuf_r <= 8'h00; bitidx_r <= 3'd7; rx_r <= 16'd0;
            addr_r <= 24'd0; count_r <= 16'd0;
            cs_o <= 1'b1; sck_o <= 1'b0; mosi_o <= 1'b1;
            done_o <= 1'b0; byte_valid_o <= 1'b0; byte_o <= 8'h00;
        end else begin
            done_o <= 1'b0;
            case (st_r)
                IDLE: begin
                    byte_valid_o <= 1'b0;
                    if (start_i) begin
                        addr_r <= addr_i; count_r <= count_i;
                        cs_o <= 1'b0; half_r <= 16'd0;
                        st_r <= HDR; hdr_idx_r <= 2'd0; hdr_r <= 8'h03;
                        mosi_o <= 1'b1; bitidx_r <= 3'd7; rx_r <= 16'd0;
                    end
                end
                HDR: begin
                    if (half_r < SPI_DIV_HALF) begin
                        sck_o <= 1'b0;
                        if (half_r == 0) mosi_o <= hdr_r[bitidx_r];
                        half_r <= half_r + 1'b1;
                    end else if (half_r < (2*SPI_DIV_HALF - 1)) begin
                        sck_o <= 1'b1;
                        half_r <= half_r + 1'b1;
                    end else begin
                        sck_o <= 1'b1; half_r <= 16'd0;
                        if (bitidx_r != 3'd0) begin
                            bitidx_r <= bitidx_r - 3'd1;
                        end else if (hdr_idx_r == 2'd3) begin
                            st_r <= DATA; bitidx_r <= 3'd7; half_r <= 16'd0;
                        end else begin
                            hdr_idx_r <= hdr_idx_r + 2'd1;
                            hdr_r <= next_hdr;
                            // MOSI is driven on the next falling half so it is
                            // stable before the rising edge that samples the
                            // current byte's last bit.
                            bitidx_r <= 3'd7;
                        end
                    end
                end
                DATA: begin
                    if (FAST_BYTES) begin
                        // sim fast path: 1 byte per clock via parallel flash port
                        if (byte_valid_o) begin
                            if (byte_ready_i) begin
                                byte_valid_o <= 1'b0;
                                if (rx_r == (count_r - 1'b1)) begin
                                    cs_o <= 1'b1; st_r <= FIN; done_o <= 1'b1;
                                end else begin
                                    rx_r <= rx_r + 1'b1;
                                end
                            end
                        end else begin
                            byte_o <= flash_rd_data_i;
                            byte_valid_o <= 1'b1;
                        end
                    end else begin
                        if (byte_valid_o) begin
                            if (byte_ready_i) begin
                                byte_valid_o <= 1'b0;
                                if (rx_r == (count_r - 1'b1)) begin
                                    cs_o <= 1'b1; st_r <= FIN; done_o <= 1'b1;
                                end else begin
                                    rx_r <= rx_r + 1'b1;
                                    bitidx_r <= 3'd7; half_r <= 16'd0;
                                end
                            end
                        end else if (half_r < SPI_DIV_HALF) begin
                            sck_o <= 1'b0;
                            half_r <= half_r + 1'b1;
                        end else if (half_r < (2*SPI_DIV_HALF - 1)) begin
                            sck_o <= 1'b1;
                            if (half_r == SPI_DIV_HALF) bitbuf_r[bitidx_r] <= miso_i;
                            half_r <= half_r + 1'b1;
                        end else begin
                            sck_o <= 1'b1; half_r <= 16'd0;
                            if (bitidx_r != 3'd0) begin
                                bitidx_r <= bitidx_r - 3'd1;
                            end else begin
                                byte_o <= bitbuf_r; byte_valid_o <= 1'b1;
                            end
                        end
                    end
                end
                FIN: begin
                    cs_o <= 1'b1; sck_o <= 1'b0; byte_valid_o <= 1'b0;
                    if (!start_i) st_r <= IDLE;
                end
            endcase
        end
    end
endmodule
