`timescale 1ns/1ps
// mn04_frontend.v
// MN04 five-class audio frontend top: 32 kHz PCM -> x0 (int8).
// Chains the byte-exact V1 stages preemph -> framing(hann, streaming sliding
// window) -> fft1024 -> mel128 -> log/quant, matching tb_frontend.v wiring.
// x0 is emitted frame-major (128 mel bins per frame); the companion
// mn04_x0_writer transposes to the core's mel-major op0 layout.
//
// PCM input is a valid/ready streaming handshake: pcm_valid_i/pcm_data_i are
// held by the producer until pcm_ready_o is asserted (one sample per ready
// cycle).  done_o latches high after MAX_FRAMES*128 x0 bytes are emitted.
module mn04_frontend #(
    parameter integer MAX_FRAMES = 1000,     // long window (10 s @ 320 hop)
    parameter integer PCM_SAMPLES = 320000,
    parameter integer CONTINUOUS = 0
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        pcm_valid_i,          // 32 kHz PCM sample valid
    input  wire signed [15:0] pcm_data_i,
    output wire        pcm_ready_o,          // can accept the next sample
    output wire signed [7:0] x0_out,         // frame-major x0 byte
    output wire        x0_valid,
    output reg         done_o                // level: MAX_FRAMES*128 x0 bytes emitted
);

    // ---- stage 1: preemph (en gated by downstream ready) ----
    wire signed [16:0] p_out;
    wire p_valid;
    frontend_preemph u_pre (.clk(clk), .rst_n(rst_n),
                            .en(pcm_valid_i && pcm_ready_o),
                            .s_in(pcm_data_i), .p_out(p_out), .p_valid(p_valid));

    // ---- stage 2: framing + hann (streaming sliding window) ----
    wire signed [16:0] wnd_out;
    wire wnd_valid;
    wire f_done;
    wire [9:0] f_idx;
    wire x0_done;
    wire framing_ready;
    reg wait_chain_r;
    // The framing stage can finish its 1024 output samples before FFT/mel/log
    // finishes that frame. Hold incoming PCM until the whole chain drains so
    // no next frame can overwrite a busy downstream stage.
    assign pcm_ready_o = framing_ready && !wait_chain_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) wait_chain_r <= 1'b0;
        else if (x0_done) wait_chain_r <= 1'b0;
        else if (f_done) wait_chain_r <= 1'b1;
    end
    frontend_framing_hann #(.P_DEPTH(PCM_SAMPLES),
        .P_AW($clog2(PCM_SAMPLES+1)),
        .MAX_FRAMES(MAX_FRAMES), .CONTINUOUS(CONTINUOUS)) u_framing (
        .clk(clk), .rst_n(rst_n),
        .pcm_valid(p_valid), .pcm_in(p_out), .pcm_ready(framing_ready),
        .wnd_out(wnd_out), .wnd_valid(wnd_valid),
        .frame_idx_o(f_idx), .done(f_done));

    // ---- stage 3: FFT ----
    wire signed [42:0] power_out;
    wire power_valid;
    wire fft_done;
    frontend_fft1024 u_fft (.clk(clk), .rst_n(rst_n), .start(1'b0),
                            .wnd_in(wnd_out), .wnd_in_valid(wnd_valid),
                            .power_out(power_out), .power_valid(power_valid),
                            .done(fft_done));

    // ---- stage 4: mel ----
    wire signed [62:0] mel_out;
    wire mel_valid;
    wire mel_done;
    frontend_mel u_mel (.clk(clk), .rst_n(rst_n), .start(1'b0),
                        .power_in(power_out), .power_in_valid(power_valid),
                        .mel_out(mel_out), .mel_valid(mel_valid), .done(mel_done));

    // ---- stage 5: log/quant -> x0 ----
    wire signed [7:0] x0_out_w;
    wire x0_valid_w;
    frontend_log_quant u_log (.clk(clk), .rst_n(rst_n), .start(1'b0),
                              .E_in(mel_out), .E_valid(mel_valid),
                              .x0_out(x0_out_w), .x0_valid(x0_valid_w), .done(x0_done));

    assign x0_out  = x0_out_w;
    assign x0_valid = x0_valid_w;

    // ---- global done latch: MAX_FRAMES*128 x0 bytes ----
    localparam integer TOTAL = MAX_FRAMES * 128;
    reg [16:0] x0_cnt;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x0_cnt  <= 17'd0;
            done_o  <= 1'b0;
        end else if (x0_valid_w) begin
            if (x0_cnt == TOTAL - 1) begin
                done_o <= 1'b1;
                if (CONTINUOUS) x0_cnt <= 17'd0;
            end else x0_cnt <= x0_cnt + 1'b1;
        end
    end
endmodule
