`timescale 1ns/1ps
// Executes one erase-or-program request against a SPI-NOR part:
//   WREN -> sector erase / page program -> poll the status register
// A request only completes (ack) once the part reports not-busy, so callers
// can safely move to the next record or power step.
module mn04_flash_sequencer #(
    parameter integer SPI_DIV_HALF = 2,
    parameter integer POLL_GAP_CYCLES = 256,
    parameter integer POLL_LIMIT = 24'hFFFFFF
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        req_valid_i,
    input  wire [1:0]  req_op_i,        // 0 = erase 4 KiB, 1 = page program
    input  wire [23:0] req_addr_i,
    input  wire [8:0]  req_len_i,       // page program byte count (1..256)
    input  wire        buf_we_i,
    input  wire [7:0]  buf_addr_i,
    input  wire [7:0]  buf_data_i,
    output reg         ack_o,
    output wire        busy_o,
    output reg         error_o,
    output wire        cs_o,
    output wire        sck_o,
    output wire        mosi_o,
    input  wire        miso_i
);
    localparam TXN_WREN = 2'd0, TXN_SE = 2'd1, TXN_PP = 2'd2, TXN_RDSR = 2'd3;
    localparam [3:0] S_IDLE = 0, S_WREN_REQ = 1, S_WREN_WAIT = 2, S_GAP1 = 3,
                     S_OP_REQ = 4, S_OP_WAIT = 5, S_GAP2 = 6,
                     S_POLL_REQ = 7, S_POLL_WAIT = 8, S_POLL_GAP = 9,
                     S_FINISH = 10;

    reg [7:0] page_buf [0:255];
    reg [3:0] state_r;
    reg       op_r;
    reg [23:0] addr_r;
    reg [8:0] len_r;
    reg [8:0] idx_r;
    reg [15:0] gap_r;
    reg [23:0] poll_left_r;

    reg        pg_start_r;
    reg [1:0]  pg_txn_r;
    reg [23:0] pg_addr_r;
    reg [8:0]  pg_len_r;
    wire       pg_busy, pg_done, pg_data_ready, pg_status_valid;
    wire [7:0] pg_status;
    wire       pg_cs, pg_sck, pg_mosi;

    assign busy_o = (state_r != S_IDLE);
    assign cs_o = pg_cs;
    assign sck_o = pg_sck;
    assign mosi_o = pg_mosi;

    wire pg_data_valid = (state_r == S_OP_WAIT) && op_r && (idx_r < len_r);

    mn04_flash_programmer #(.SPI_DIV_HALF(SPI_DIV_HALF)) u_programmer (
        .clk(clk), .rst_n(rst_n),
        .start_i(pg_start_r), .txn_i(pg_txn_r),
        .addr_i(pg_addr_r), .len_i(pg_len_r),
        .data_valid_i(pg_data_valid),
        .data_i(page_buf[idx_r[7:0]]),
        .data_ready_o(pg_data_ready),
        .busy_o(pg_busy), .done_o(pg_done),
        .status_valid_o(pg_status_valid), .status_o(pg_status),
        .cs_o(pg_cs), .sck_o(pg_sck), .mosi_o(pg_mosi), .miso_i(miso_i));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= S_IDLE;
            op_r <= 1'b0; addr_r <= 24'd0; len_r <= 9'd1;
            idx_r <= 9'd0; gap_r <= 16'd0; poll_left_r <= POLL_LIMIT;
            pg_start_r <= 1'b0; pg_txn_r <= TXN_WREN;
            pg_addr_r <= 24'd0; pg_len_r <= 9'd1;
            ack_o <= 1'b0; error_o <= 1'b0;
        end else begin
            ack_o <= 1'b0;
            pg_start_r <= 1'b0;
            case (state_r)
                S_IDLE: begin
                    error_o <= 1'b0;
                    if (req_valid_i) begin
                        op_r <= req_op_i;
                        addr_r <= req_addr_i;
                        len_r <= (req_len_i == 9'd0) ? 9'd256 : req_len_i;
                        idx_r <= 9'd0;
                        poll_left_r <= POLL_LIMIT;
                        state_r <= S_WREN_REQ;
                    end
                end
                S_WREN_REQ: begin
                    pg_txn_r <= TXN_WREN;
                    pg_addr_r <= 24'd0;
                    pg_len_r <= 9'd1;
                    pg_start_r <= 1'b1;
                    state_r <= S_WREN_WAIT;
                end
                S_WREN_WAIT: begin
                    if (pg_done) begin
                        gap_r <= 16'd16;
                        state_r <= S_GAP1;
                    end
                end
                S_GAP1: begin
                    if (gap_r == 16'd0) state_r <= S_OP_REQ;
                    else gap_r <= gap_r - 16'd1;
                end
                S_OP_REQ: begin
                    pg_txn_r <= op_r ? TXN_PP : TXN_SE;
                    pg_addr_r <= addr_r;
                    pg_len_r <= op_r ? len_r : 9'd1;
                    pg_start_r <= 1'b1;
                    state_r <= S_OP_WAIT;
                end
                S_OP_WAIT: begin
                    if (pg_data_valid && pg_data_ready) idx_r <= idx_r + 9'd1;
                    if (pg_done) begin
                        gap_r <= 16'd16;
                        state_r <= S_GAP2;
                    end
                end
                S_GAP2: begin
                    if (gap_r == 16'd0) state_r <= S_POLL_REQ;
                    else gap_r <= gap_r - 16'd1;
                end
                S_POLL_REQ: begin
                    pg_txn_r <= TXN_RDSR;
                    pg_addr_r <= 24'd0;
                    pg_len_r <= 9'd1;
                    pg_start_r <= 1'b1;
                    state_r <= S_POLL_WAIT;
                end
                S_POLL_WAIT: begin
                    if (pg_status_valid) begin
                        if (!pg_status[0]) begin
                            state_r <= S_FINISH;
                        end else if (poll_left_r == 24'd0) begin
                            error_o <= 1'b1;
                            state_r <= S_FINISH;
                        end else begin
                            poll_left_r <= poll_left_r - 24'd1;
                            gap_r <= POLL_GAP_CYCLES;
                            state_r <= S_POLL_GAP;
                        end
                    end
                end
                S_POLL_GAP: begin
                    if (gap_r == 16'd0) state_r <= S_POLL_REQ;
                    else gap_r <= gap_r - 16'd1;
                end
                S_FINISH: begin
                    ack_o <= 1'b1;
                    state_r <= S_IDLE;
                end
                default: state_r <= S_IDLE;
            endcase
        end
    end

    always @(posedge clk) begin
        if (buf_we_i) page_buf[buf_addr_i] <= buf_data_i;
    end
endmodule
