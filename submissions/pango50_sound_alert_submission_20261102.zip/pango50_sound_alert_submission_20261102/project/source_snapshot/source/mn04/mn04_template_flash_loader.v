`timescale 1ns/1ps
// Load the fixed-capacity Q7 template map section from QSPI into the matcher's
// existing block-RAM bank before inference is enabled.  The host-side package
// places the maps immediately after the 128-byte template-container header.
module mn04_template_flash_loader #(
    parameter [23:0] TEMPLATE_BASE = 24'h610080,
    parameter integer TEMPLATE_BYTES = 102400,
    parameter [15:0] CHUNK_BYTES = 16'd65535,
    parameter integer FAST_BYTES = 0
)(
    input wire clk,
    input wire rst_n,
    input wire start_i,
    input wire [23:0] base_i,       // runtime-selected slot + header offset
    input wire use_base_i,          // 0 => legacy fixed TEMPLATE_BASE
    output wire busy_o,
    output reg done_o,
    output wire [23:0] flash_rd_addr_o,
    input wire [7:0] flash_rd_data_i,
    output wire cs_o,
    output wire sck_o,
    output wire mosi_o,
    input wire miso_i,
    output wire load_we_o,
    output wire [17:0] load_addr_o,
    output wire [7:0] load_data_o
);
    localparam [1:0] S_WAIT=2'd0, S_START=2'd1, S_READ=2'd2, S_DONE=2'd3;
    reg [1:0] state_r;
    reg [23:0] chunk_base_r;
    reg [15:0] chunk_len_r;
    reg [17:0] total_count_r;
    reg qr_start_r;
    wire qr_busy,qr_done,qr_valid;
    wire [7:0] qr_byte;

    assign busy_o = (state_r == S_START) || (state_r == S_READ);
    assign load_we_o = (state_r == S_READ) && qr_valid;
    assign load_addr_o = total_count_r;
    assign load_data_o = qr_byte;

    wire [23:0] active_base = use_base_i ? base_i : TEMPLATE_BASE;

    mn04_qspi_block_reader #(.FAST_BYTES(FAST_BYTES)) u_reader (
        .clk(clk),.rst_n(rst_n),.start_i(qr_start_r),
        .addr_i(active_base + chunk_base_r),.count_i(chunk_len_r),
        .busy_o(qr_busy),.done_o(qr_done),
        .byte_o(qr_byte),.byte_valid_o(qr_valid),.byte_ready_i(1'b1),
        .flash_rd_addr_o(flash_rd_addr_o),.flash_rd_data_i(flash_rd_data_i),
        .cs_o(cs_o),.sck_o(sck_o),.mosi_o(mosi_o),.miso_i(miso_i));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= S_WAIT;
            chunk_base_r <= 24'd0;
            chunk_len_r <= 16'd0;
            total_count_r <= 18'd0;
            qr_start_r <= 1'b0;
            done_o <= 1'b0;
        end else begin
            qr_start_r <= 1'b0;
            case (state_r)
                S_WAIT: if (start_i) begin
                    chunk_base_r <= 24'd0;
                    chunk_len_r <= (TEMPLATE_BYTES > CHUNK_BYTES) ?
                                   CHUNK_BYTES : TEMPLATE_BYTES[15:0];
                    total_count_r <= 18'd0;
                    done_o <= 1'b0;
                    state_r <= S_START;
                end
                S_START: begin
                    qr_start_r <= 1'b1;
                    state_r <= S_READ;
                end
                S_READ: begin
                    if (qr_valid) total_count_r <= total_count_r + 1'b1;
                    if (qr_done) begin
                        if (total_count_r >= TEMPLATE_BYTES) begin
                            done_o <= 1'b1;
                            state_r <= S_DONE;
                        end else begin
                            chunk_base_r <= chunk_base_r + {8'd0,chunk_len_r};
                            chunk_len_r <= ((TEMPLATE_BYTES - total_count_r) > CHUNK_BYTES) ?
                                           CHUNK_BYTES : (TEMPLATE_BYTES - total_count_r);
                            state_r <= S_START;
                        end
                    end
                end
                S_DONE: begin
                    done_o <= 1'b1;
                    if (!start_i) state_r <= S_WAIT;
                end
                default: state_r <= S_WAIT;
            endcase
        end
    end
endmodule
