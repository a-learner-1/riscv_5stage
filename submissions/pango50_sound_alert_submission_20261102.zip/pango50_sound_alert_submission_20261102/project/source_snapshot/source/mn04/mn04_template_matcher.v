`timescale 1ns/1ps
// One-second, 128-bin feature-map matcher for three user-enrolled sounds.
// Templates may be offline Q7 vectors or raw int8 maps from local enrollment.
// Center and normalize BOTH vectors on chip; a fixed template norm of 127
// incorrectly saturates raw enrolled maps and can turn unrelated sounds into
// full-score doorbell alerts. A pipelined MAC
// scans one feature every three compute cycles.  A small input FIFO preserves
// frame-major features while the matcher is busy.  The Pango 50 board build
// caps the three classes at two maps each. Template bytes can be initialized from a
// build-time ROM or loaded from QSPI into the same RAM before recognition.
// Enrollment persistence is owned by the runtime updater and boot selector.
module mn04_template_matcher #(
    parameter INITIAL_TEMPLATE_FILE = "",
    parameter integer DOORBELL_MAPS = 0,
    parameter integer SMOKE_ALARM_MAPS = 0,
    parameter integer GAS_CO_ALARM_MAPS = 0,
    parameter integer MAX_MAPS_PER_CLASS = 2,
    parameter integer EXTERNAL_TEMPLATE_MEMORY = 0,
    parameter integer INPUT_FIFO_DEPTH = EXTERNAL_TEMPLATE_MEMORY ? 2048 : 256,
    parameter integer USE_TEMPLATE_VALID_MASK = 0,
    parameter [15:0] THRESHOLD_Q15 = 16'd26214,
    // Fraction of the window mean removed before the cosine, Q4 (0..16).
    // 16 removes the whole mean and keeps only the fine spectral shape; two
    // replays of the same sound then drift far apart because the spectral
    // level is gone.  8 keeps half of the level and separates same-sound
    // replays from unrelated sounds far better on board captures.
    parameter integer CENTER_ALPHA_Q4 = 16,
    // Sum of squared deviations below which a window counts as "no sound".
    // 32768 over 12800 samples is a standard deviation of about 1.6 LSB.
    parameter integer MIN_VAR_SUM = 32768,
    // Bytes to discard after enabling so the button click that started the
    // session never becomes part of the first query window.
    parameter integer WARMUP_FRAMES = 400
)(
    input wire clk,
    input wire rst_n,
    input wire enable_i,
    input wire signed [7:0] x0_i,
    input wire x0_valid_i,
    input wire template_load_we_i,
    input wire [17:0] template_load_addr_i,
    input wire signed [7:0] template_load_data_i,
    // A second logical client uses the existing synchronous template-RAM read
    // port while recognition is paused (SD boot restore / enrollment save).
    input wire template_external_rd_en_i,
    input wire [17:0] template_external_rd_addr_i,
    output wire signed [7:0] template_external_rd_data_o,
    input wire [3*MAX_MAPS_PER_CLASS-1:0] template_valid_mask_i,
    output wire template_ddr_rd_req_o,
    output wire [17:0] template_ddr_rd_addr_o,
    input wire template_ddr_rd_valid_i,
    input wire signed [7:0] template_ddr_rd_data_i,
    output reg result_valid_o,
    output reg [1:0] result_class_o, // 0=unknown, 1=doorbell, 2=smoke, 3=gas/CO
    output reg [15:0] result_score_q15_o,
    output wire busy_o
);
    localparam integer MEL_BINS = 128;
    localparam integer WINDOW_FRAMES = 100;
    localparam integer WINDOW_SIZE = MEL_BINS * WINDOW_FRAMES;
    localparam integer TOTAL_MAPS = DOORBELL_MAPS + SMOKE_ALARM_MAPS + GAS_CO_ALARM_MAPS;
    localparam integer MAX_TOTAL_MAPS = 3 * MAX_MAPS_PER_CLASS;
    localparam integer INPUT_FIFO_PTR_BITS = $clog2(INPUT_FIFO_DEPTH);
    localparam [4:0] S_CAPTURE=0, S_MEAN_READ=1, S_MEAN_ACC=2,
                     S_MEAN_DIV=3, S_NORM_READ=4, S_NORM_MUL=5,
                     S_NORM_ACC=6, S_SQRT=7, S_DOT_READ=8,
                     S_DOT_MUL=9, S_DOT_ACC=10, S_DIV=11,
                     S_FINISH=12, S_TEMPLATE_MEAN=13,
                     S_TEMPLATE_NORM=14, S_TEMPLATE_SQRT=15,
                     S_QUERY_CENTER=16, S_TEMPLATE_ABS=17, S_MEAN_ABS=18,
                     S_TEMPLATE_NORM_FINISH=19, S_TEMPLATE_DDR_WAIT=20;

    reg [4:0] state_r;
    reg signed [7:0] query_mem [0:WINDOW_SIZE-1];
    reg signed [7:0] template_mem [0:MAX_TOTAL_MAPS*WINDOW_SIZE-1];
    reg signed [7:0] input_fifo [0:INPUT_FIFO_DEPTH-1];
    reg [INPUT_FIFO_PTR_BITS-1:0] input_wr_ptr_r,input_rd_ptr_r;
    reg [INPUT_FIFO_PTR_BITS:0] input_fifo_count_r;
    reg input_fifo_overflow_r;
    reg signed [7:0] query_d_r,template_d_r;
    reg [6:0] mel_slot_r,write_frame_r,window_base_r;
    reg [6:0] frames_seen_r,hop_frames_r;
    reg [15:0] warm_bytes_r;
    reg [13:0] sample_r;
    // A signed int8 feature summed over 12,800 bins is bounded by
    // +/-1,638,400, so 22 signed bits are sufficient.  Keeping the
    // accumulators at this width shortens the template-read critical path.
    reg signed [21:0] sum_r;
    reg signed [31:0] mean_r;
    // Registered version of the mean after CENTER_ALPHA_Q4 scaling.  Both stay
    // nine bits wide so the dot/norm multipliers keep their original width.
    reg signed [8:0] query_mean_eff_r;
    reg signed [8:0] template_mean_eff_r;
    reg query_flat_r;
    reg template_flat_r;
    reg [31:0] query_flat_margin_r;
    reg [31:0] template_flat_margin_r;
    reg [31:0] query_mean_sq_r;
    reg [31:0] template_mean_sq_r;
    reg [21:0] mean_div_rem_r;
    reg [7:0] mean_div_quot_r;
    reg mean_div_negative_r;
    reg [29:0] norm_sum_r;
    reg [17:0] norm_term_r;
    reg [31:0] sqrt_x_r,sqrt_res_r,sqrt_bit_r;
    reg [15:0] sqrt_root_r;
    reg [4:0] sqrt_iter_r;
    reg signed [30:0] dot_sum_r;
    reg signed [16:0] dot_product_r;
    reg signed [21:0] template_sum_r;
    reg [31:0] template_square_sum_r;
    reg [15:0] template_square_r;
    reg signed [8:0] template_mean_r;
    reg signed [31:0] centered_dot_r;
    // Register the wide template-centering products before the final add/sub
    // stage. This keeps the mean-product path out of the same cycle as the
    // 32-bit norm correction and is important on the PGL50H DDR clock domain.
    reg signed [31:0] template_mean_sum_r;
    reg signed [31:0] template_mean_square_scaled_r;
    reg signed [31:0] template_dot_correction_r;
    reg [4:0] map_r;
    reg [15:0] best_score_r;
    reg [1:0] best_class_r;
    reg [47:0] div_num_r,div_quot_r;
    reg [31:0] div_rem_r,div_den_r;
    reg [5:0] div_bits_r;

    wire template_read_en;
    wire [17:0] template_read_addr;
    generate if(!EXTERNAL_TEMPLATE_MEMORY) begin:g_internal_template_ram
        initial if(INITIAL_TEMPLATE_FILE!="") $readmemh(INITIAL_TEMPLATE_FILE,template_mem);
        always @(posedge clk) begin
            if(template_load_we_i && template_load_addr_i<MAX_TOTAL_MAPS*WINDOW_SIZE)
                template_mem[template_load_addr_i]<=template_load_data_i;
            if(template_read_en) template_d_r<=template_mem[template_read_addr];
        end
    end else begin:g_external_template_data
        always @(posedge clk) if(template_ddr_rd_valid_i) template_d_r<=template_ddr_rd_data_i;
    end endgenerate

    assign busy_o = state_r != S_CAPTURE;
    assign template_external_rd_data_o = template_d_r;
    wire [6:0] logical_frame = sample_r[13:7];
    wire [7:0] query_frame_sum = {1'b0,window_base_r} + {1'b0,logical_frame};
    wire [6:0] query_frame_addr = (query_frame_sum >= WINDOW_FRAMES) ?
                                   query_frame_sum - WINDOW_FRAMES : query_frame_sum[6:0];
    wire [13:0] query_addr = {query_frame_addr, sample_r[6:0]};
    // CENTER_ALPHA_Q4 scales how much of the window mean is removed.  With
    // alpha=16 this is exactly the old zero-mean cosine; with alpha=8 half of
    // the spectral level survives, which is what keeps two replays of the same
    // sound close together after local enrollment.
    // The scaled means are registered next to the raw means so the multiply
    // below keeps its original register-to-register depth.
    localparam signed [31:0] ALPHA_Q4 = CENTER_ALPHA_Q4;
    wire signed [31:0] query_mean_next = mean_div_negative_r ?
        -$signed({24'd0,mean_div_quot_r}) : $signed({24'd0,mean_div_quot_r});
    wire signed [31:0] template_mean_next = mean_div_negative_r ?
        -$signed({1'b0,mean_div_quot_r}) : $signed({1'b0,mean_div_quot_r});
    wire signed [8:0] query_mean_eff = query_mean_eff_r;
    wire signed [8:0] template_mean_eff = template_mean_eff_r;
    wire signed [8:0] centered_query = $signed(query_d_r) - $signed(query_mean_eff[8:0]);
    wire signed [16:0] dot_product = centered_query * $signed(template_d_r);
    wire signed [17:0] norm_term = centered_query * centered_query;
    wire [29:0] norm_sum_next = norm_sum_r + norm_term_r;
    wire signed [21:0] mean_total_next = sum_r + $signed(query_d_r);
    wire signed [21:0] template_sum_next = template_sum_r + $signed(template_d_r);
    wire [31:0] template_square_sum_next = template_square_sum_r + template_square_r;
    wire signed [15:0] template_square = template_d_r * template_d_r;
    // Keep the integer mean convention identical for the two vectors.
    // Query mean times the window size, registered in the mean-divide cycle so
    // the template step only needs one multiplier in its path.
    reg signed [31:0] query_centered_sum_r;
    wire signed [31:0] template_mean_sum = template_mean_eff * template_sum_r;
    wire signed [17:0] template_mean_square = template_mean_eff * template_mean_eff;
    // A near-constant window (digital silence, a stuck channel, or an empty
    // enrollment take) carries no spectral shape.  Without this guard it
    // scores ~1.0 against any other near-constant window, so a silent template
    // would alarm forever.  Variance is recovered from sums already collected:
    //   sum((x-a*mean)^2) = sum((x-mean)^2) + N*mean^2*(1-a)^2
    localparam signed [31:0] FLAT_COEF =
        50 * (16 - CENTER_ALPHA_Q4) * (16 - CENTER_ALPHA_Q4);
    // Both variance comparisons are reduced to a single subtract: the
    // mean-square term is precomputed next to the mean and registered, so no
    // multiplier sits in the compare path.
    wire [31:0] query_flat_limit = MIN_VAR_SUM + query_flat_margin_r;
    wire query_flat_next = {2'b00,norm_sum_next} < query_flat_limit;
    wire template_flat = template_flat_r;

    wire [31:0] sqrt_trial = sqrt_res_r + sqrt_bit_r;
    wire sqrt_take = sqrt_x_r >= sqrt_trial;
    wire [31:0] sqrt_x_next = sqrt_take ? sqrt_x_r - sqrt_trial : sqrt_x_r;
    wire [31:0] sqrt_res_next = sqrt_take ? (sqrt_res_r >> 1) + sqrt_bit_r :
                                            (sqrt_res_r >> 1);
    wire [31:0] div_trial = {div_rem_r[30:0],div_num_r[47]};
    wire div_take = div_trial >= div_den_r;
    wire [31:0] div_rem_next = div_take ? div_trial - div_den_r : div_trial;
    wire [47:0] div_quot_next = {div_quot_r[46:0],div_take};
    wire signed [30:0] dot_sum_next = dot_sum_r + dot_product_r;
    wire [15:0] score_next = (div_quot_next > 48'd32767) ? 16'h7fff :
                                                               div_quot_next[15:0];
    // Matching a full second takes several milliseconds.  Keep accepting x0
    // bytes during that work and replay them in order afterward, so a feature
    // burst cannot be lost or shift the 128-bin frame alignment.
    wire input_pop = enable_i && (state_r == S_CAPTURE) &&
                     (input_fifo_count_r != 0);
    wire input_direct = enable_i && !input_fifo_overflow_r &&
                        (state_r == S_CAPTURE) &&
                        (input_fifo_count_r == 0) && x0_valid_i;
    wire input_push_request = enable_i && !input_fifo_overflow_r &&
                              x0_valid_i && !input_direct;
    wire input_push = input_push_request &&
                      ((input_fifo_count_r < INPUT_FIFO_DEPTH) || input_pop);
    wire capture_valid = input_pop || input_direct;
    wire signed [7:0] capture_data = input_pop ? input_fifo[input_rd_ptr_r] : x0_i;

    // Enrollment/SD restore and online matching are serialized by the fabric.
    // Select the address before the RAM read so synthesis can infer one shared
    // synchronous read port instead of duplicating the complete template bank.
    wire template_external_read = template_external_rd_en_i &&
        (template_external_rd_addr_i < MAX_TOTAL_MAPS*WINDOW_SIZE);
    wire template_internal_read = !template_external_read &&
        (state_r == S_DOT_READ);
    assign template_read_en = template_external_read || template_internal_read;
    assign template_read_addr = template_external_read ?
        template_external_rd_addr_i : (map_r*WINDOW_SIZE + sample_r);
    assign template_ddr_rd_req_o=EXTERNAL_TEMPLATE_MEMORY && state_r==S_DOT_READ &&
        (!USE_TEMPLATE_VALID_MASK || template_valid_mask_i[map_r]);
    assign template_ddr_rd_addr_o=map_r*WINDOW_SIZE+sample_r;

    // Synchronous reads keep both arrays eligible for block RAM inference.
    always @(posedge clk) begin
        if (rst_n && input_push) input_fifo[input_wr_ptr_r] <= x0_i;
        if (state_r == S_MEAN_READ || state_r == S_NORM_READ ||
            state_r == S_DOT_READ)
            query_d_r <= query_mem[query_addr];
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= S_CAPTURE;
            result_valid_o <= 1'b0;
            result_class_o <= 2'd0;
            result_score_q15_o <= 16'd0;
            mel_slot_r <= 0;
            write_frame_r <= 0;
            window_base_r <= 0;
            frames_seen_r <= 0;
            warm_bytes_r <= 16'd0;
            hop_frames_r <= 0;
            sample_r <= 0;
            sum_r <= 0;
            mean_r <= 0;
            query_mean_eff_r <= 0;
            template_mean_eff_r <= 0;
            query_flat_r <= 1'b0;
            template_flat_r <= 1'b0;
            query_flat_margin_r <= 0;
            template_flat_margin_r <= 0;
            query_mean_sq_r <= 0;
            template_mean_sq_r <= 0;
            query_centered_sum_r <= 0;
            mean_div_rem_r <= 0;
            mean_div_quot_r <= 0;
            mean_div_negative_r <= 0;
            norm_sum_r <= 0;
            norm_term_r <= 0;
            sqrt_x_r <= 0;
            sqrt_res_r <= 0;
            sqrt_bit_r <= 0;
            sqrt_root_r <= 0;
            sqrt_iter_r <= 0;
            dot_sum_r <= 0;
            dot_product_r <= 0;
            template_sum_r <= 0;
            template_square_sum_r <= 0;
            template_square_r <= 0;
            template_mean_r <= 0;
            centered_dot_r <= 0;
            template_mean_sum_r <= 0;
            template_mean_square_scaled_r <= 0;
            template_dot_correction_r <= 0;
            input_wr_ptr_r <= 0;
            input_rd_ptr_r <= 0;
            input_fifo_count_r <= 0;
            input_fifo_overflow_r <= 0;
            map_r <= 0;
            best_score_r <= 0;
            best_class_r <= 0;
            div_num_r <= 0;
            div_quot_r <= 0;
            div_rem_r <= 0;
            div_den_r <= 0;
            div_bits_r <= 0;
        end else begin
            result_valid_o <= 1'b0;
            if (!enable_i) begin
                state_r <= S_CAPTURE;
                mel_slot_r <= 0;
                write_frame_r <= 0;
                warm_bytes_r <= WARMUP_FRAMES * MEL_BINS;
                window_base_r <= 0;
                frames_seen_r <= 0;
                hop_frames_r <= 0;
                sample_r <= 0;
                sum_r <= 0;
                mean_div_rem_r <= 0;
                mean_div_quot_r <= 0;
                mean_div_negative_r <= 0;
                norm_sum_r <= 0;
                norm_term_r <= 0;
                dot_sum_r <= 0;
                template_sum_r <= 0;
                template_square_sum_r <= 0;
                input_wr_ptr_r <= 0;
                input_rd_ptr_r <= 0;
                input_fifo_count_r <= 0;
                input_fifo_overflow_r <= 0;
                dot_product_r <= 0;
                map_r <= 0;
                best_score_r <= 0;
                best_class_r <= 0;
                result_class_o <= 0;
                result_score_q15_o <= 0;
            end else begin
                if (input_push) input_wr_ptr_r <= input_wr_ptr_r + 1'b1;
                if (input_pop) input_rd_ptr_r <= input_rd_ptr_r + 1'b1;
                case ({input_push,input_pop})
                    2'b10: input_fifo_count_r <= input_fifo_count_r + 1'b1;
                    2'b01: input_fifo_count_r <= input_fifo_count_r - 1'b1;
                    default: input_fifo_count_r <= input_fifo_count_r;
                endcase
                if (input_push_request && !input_push)
                    input_fifo_overflow_r <= 1'b1;
                case (state_r)
                    S_CAPTURE: if (warm_bytes_r != 16'd0 && capture_valid) begin
                        warm_bytes_r <= warm_bytes_r - 1'b1;
                    end else if (capture_valid) begin
                        query_mem[write_frame_r*MEL_BINS + mel_slot_r] <= capture_data;
                        if (mel_slot_r == MEL_BINS-1) begin
                            mel_slot_r <= 0;
                            if (write_frame_r == WINDOW_FRAMES-1) write_frame_r <= 0;
                            else write_frame_r <= write_frame_r + 1'b1;
                            if (frames_seen_r < WINDOW_FRAMES) begin
                                frames_seen_r <= frames_seen_r + 1'b1;
                                if (frames_seen_r == WINDOW_FRAMES-1 && TOTAL_MAPS > 0) begin
                                    window_base_r <= (write_frame_r == WINDOW_FRAMES-1) ? 0 :
                                                     write_frame_r + 1'b1;
                                    sample_r <= 0;
                                    sum_r <= 0;
                                    best_score_r <= 0;
                                    best_class_r <= 0;
                                    state_r <= S_MEAN_READ;
                                end
                            end else if (hop_frames_r == 49 && TOTAL_MAPS > 0) begin
                                hop_frames_r <= 0;
                                window_base_r <= (write_frame_r == WINDOW_FRAMES-1) ? 0 :
                                                 write_frame_r + 1'b1;
                                sample_r <= 0;
                                sum_r <= 0;
                                best_score_r <= 0;
                                best_class_r <= 0;
                                state_r <= S_MEAN_READ;
                            end else if (frames_seen_r >= WINDOW_FRAMES) begin
                                hop_frames_r <= hop_frames_r + 1'b1;
                            end
                        end else mel_slot_r <= mel_slot_r + 1'b1;
                    end
                    S_MEAN_READ: state_r <= S_MEAN_ACC;
                    S_MEAN_ACC: begin
                        sum_r <= sum_r + $signed(query_d_r);
                        if (sample_r == WINDOW_SIZE-1) begin
                            sum_r <= mean_total_next;
                            state_r <= S_MEAN_ABS;
                        end else begin
                            sample_r <= sample_r + 1'b1;
                            state_r <= S_MEAN_READ;
                        end
                    end
                    S_MEAN_ABS: begin
                        // Separate the final RAM-read/add from absolute-value
                        // conversion so the 100 MHz path does not cross two
                        // long carry chains in one cycle.
                        mean_div_negative_r <= (sum_r < 0);
                        mean_div_rem_r <= (sum_r < 0) ? -sum_r : sum_r;
                        mean_div_quot_r <= 0;
                        state_r <= S_MEAN_DIV;
                    end
                    S_MEAN_DIV: begin
                        // The mean is bounded by the signed int8 input range.
                        // Repeated subtraction avoids spending a scarce APM on
                        // an approximate reciprocal multiply.
                        if (mean_div_rem_r >= 22'd12800) begin
                            mean_div_rem_r <= mean_div_rem_r - 22'd12800;
                            mean_div_quot_r <= mean_div_quot_r + 1'b1;
                        end else begin
                            mean_r <= query_mean_next;
                            query_mean_eff_r <= (query_mean_next * ALPHA_Q4) >>> 4;
                            // Squared magnitude only: the sign is irrelevant
                            // for a variance threshold, and taking it from the
                            // unsigned quotient keeps the negation out of the
                            // multiplier input path.
                            query_mean_sq_r <=
                                mean_div_quot_r * mean_div_quot_r;
                            sample_r <= 0;
                            norm_sum_r <= 0;
                            state_r <= S_QUERY_CENTER;
                        end
                    end
                    S_QUERY_CENTER: begin
                        // Separate signed mean scaling from sum correction.
                        // This removes the negation/scaling/multiply/subtract
                        // chain from a single 100-MHz register interval.
                        query_centered_sum_r <= sum_r -
                            ($signed(query_mean_eff_r) * 32'sd12800);
                        state_r <= S_NORM_READ;
                    end
                    S_NORM_READ: begin
                        // One cycle of slack before the norm pass turns the
                        // squared mean into the variance threshold margin.
                        query_flat_margin_r <= query_mean_sq_r * FLAT_COEF;
                        state_r <= S_NORM_MUL;
                    end
                    S_NORM_MUL: begin
                        norm_term_r <= norm_term;
                        state_r <= S_NORM_ACC;
                    end
                    S_NORM_ACC: begin
                        norm_sum_r <= norm_sum_next;
                        if (sample_r == WINDOW_SIZE-1) begin
                            query_flat_r <= query_flat_next;
                            sqrt_x_r <= {2'b00,norm_sum_next};
                            sqrt_res_r <= 0;
                            sqrt_bit_r <= 32'h40000000;
                            sqrt_iter_r <= 0;
                            state_r <= S_SQRT;
                        end else begin
                            sample_r <= sample_r + 1'b1;
                            state_r <= S_NORM_READ;
                        end
                    end
                    S_SQRT: begin
                        sqrt_x_r <= sqrt_x_next;
                        sqrt_res_r <= sqrt_res_next;
                        sqrt_bit_r <= sqrt_bit_r >> 2;
                        if (sqrt_iter_r == 15) begin
                            sqrt_root_r <= sqrt_res_next[15:0];
                            sample_r <= 0;
                            map_r <= 0;
                            dot_sum_r <= 0;
                            template_sum_r <= 0;
                            template_square_sum_r <= 0;
                            state_r <= S_DOT_READ;
                        end else sqrt_iter_r <= sqrt_iter_r + 1'b1;
                    end
                    S_DOT_READ: begin
                        if (USE_TEMPLATE_VALID_MASK && !template_valid_mask_i[map_r]) begin
                            if (map_r == TOTAL_MAPS-1) state_r <= S_FINISH;
                            else begin
                                map_r <= map_r + 1'b1;
                                dot_sum_r <= 0;
                                template_sum_r <= 0;
                                template_square_sum_r <= 0;
                                sample_r <= 0;
                                state_r <= S_DOT_READ;
                            end
                        end else state_r <= EXTERNAL_TEMPLATE_MEMORY ? S_TEMPLATE_DDR_WAIT : S_DOT_MUL;
                    end
                    S_TEMPLATE_DDR_WAIT: if(template_ddr_rd_valid_i) state_r<=S_DOT_MUL;
                    S_DOT_MUL: begin
                        dot_product_r <= dot_product;
                        template_square_r <= template_square;
                        state_r <= S_DOT_ACC;
                    end
                    S_DOT_ACC: begin
                        dot_sum_r <= dot_sum_next;
                        template_sum_r <= template_sum_next;
                        template_square_sum_r <= template_square_sum_next;
                        if (sample_r == WINDOW_SIZE-1) begin
                            sample_r <= 0;
                            template_sum_r <= template_sum_next;
                            state_r <= S_TEMPLATE_ABS;
                        end else begin
                            sample_r <= sample_r + 1'b1;
                            state_r <= S_DOT_READ;
                        end
                    end
                    S_TEMPLATE_ABS: begin
                        mean_div_negative_r <= (template_sum_r < 0);
                        mean_div_rem_r <= (template_sum_r < 0) ?
                            -template_sum_r : template_sum_r;
                        mean_div_quot_r <= 0;
                        state_r <= S_TEMPLATE_MEAN;
                    end
                    S_TEMPLATE_MEAN: begin
                        if (mean_div_rem_r >= 22'd12800) begin
                            mean_div_rem_r <= mean_div_rem_r - 22'd12800;
                            mean_div_quot_r <= mean_div_quot_r + 1'b1;
                        end else begin
                            template_mean_r <= template_mean_next;
                            template_mean_eff_r <= (template_mean_next * ALPHA_Q4) >>> 4;
                            template_mean_sq_r <=
                                mean_div_quot_r * mean_div_quot_r;
                            state_r <= S_TEMPLATE_NORM;
                        end
                    end
                    S_TEMPLATE_NORM: begin
                        template_flat_margin_r <= template_mean_sq_r * 32'd12800;
                        template_mean_sum_r <= template_mean_sum;
                        template_mean_square_scaled_r <=
                            template_mean_square * 32'd12800;
                        template_dot_correction_r <=
                            template_mean_eff * query_centered_sum_r;
                        state_r <= S_TEMPLATE_NORM_FINISH;
                    end
                    S_TEMPLATE_NORM_FINISH: begin
                        centered_dot_r <= $signed(dot_sum_r) -
                            template_dot_correction_r;
                        sqrt_x_r <= template_square_sum_r -
                            (template_mean_sum_r <<< 1) +
                            template_mean_square_scaled_r;
                        sqrt_res_r <= 0;
                        sqrt_bit_r <= 32'h40000000;
                        sqrt_iter_r <= 0;
                        state_r <= S_TEMPLATE_SQRT;
                    end
                    S_TEMPLATE_SQRT: begin
                        // Decide once, in the first cycle, whether this map
                        // carries any spectral shape at all.
                        if (sqrt_iter_r == 0)
                            template_flat_r <= template_square_sum_r <
                                (MIN_VAR_SUM + template_flat_margin_r);
                        sqrt_x_r <= sqrt_x_next;
                        sqrt_res_r <= sqrt_res_next;
                        sqrt_bit_r <= sqrt_bit_r >> 2;
                        if (sqrt_iter_r == 15) begin
                            div_quot_r <= 0;
                            div_rem_r <= 0;
                            div_bits_r <= 48;
                            if (sqrt_root_r == 0 || sqrt_res_next == 0 ||
                                centered_dot_r <= 0 ||
                                query_flat_r || template_flat) begin
                                div_num_r <= 0;
                                div_den_r <= 1;
                            end else begin
                                div_num_r <= {1'b0,centered_dot_r,15'd0};
                                div_den_r <= sqrt_root_r * sqrt_res_next[15:0];
                            end
                            state_r <= S_DIV;
                        end else sqrt_iter_r <= sqrt_iter_r + 1'b1;
                    end
                    S_DIV: begin
                        div_num_r <= {div_num_r[46:0],1'b0};
                        div_quot_r <= div_quot_next;
                        div_rem_r <= div_rem_next;
                        div_bits_r <= div_bits_r - 1'b1;
                        if (div_bits_r == 1) begin
                            if (score_next > best_score_r) begin
                                best_score_r <= score_next;
                                if (map_r < DOORBELL_MAPS)
                                    best_class_r <= 2'd1;
                                else if (map_r < DOORBELL_MAPS + SMOKE_ALARM_MAPS)
                                    best_class_r <= 2'd2;
                                else
                                    best_class_r <= 2'd3;
                            end
                            if (map_r == TOTAL_MAPS-1) state_r <= S_FINISH;
                            else begin
                                map_r <= map_r + 1'b1;
                                dot_sum_r <= 0;
                                template_sum_r <= 0;
                                template_square_sum_r <= 0;
                                sample_r <= 0;
                                state_r <= S_DOT_READ;
                            end
                        end
                    end
                    S_FINISH: begin
                        result_valid_o <= 1'b1;
                        result_score_q15_o <= best_score_r;
                        result_class_o <= (!input_fifo_overflow_r &&
                                           best_score_r >= THRESHOLD_Q15) ? best_class_r : 2'd0;
                        if (input_fifo_overflow_r) begin
                            // Do not resume with a feature-frame offset after
                            // an impossible-to-recover FIFO overflow.  The
                            // controller sees an unknown result; a new session
                            // clears the matcher and starts on a clean stream.
                            mel_slot_r <= 0;
                            write_frame_r <= 0;
                            window_base_r <= 0;
                            frames_seen_r <= 0;
                            hop_frames_r <= 0;
                            input_wr_ptr_r <= 0;
                            input_rd_ptr_r <= 0;
                            input_fifo_count_r <= 0;
                        end
                        state_r <= S_CAPTURE;
                    end
                    default: state_r <= S_CAPTURE;
                endcase
            end
        end
    end
endmodule
