`timescale 1ns/1ps
// MN04 write-merge FIFO bridge between the CNN core and a DDR3 write port.
//
// The core produces one byte-write per requant result (wr_en_o is a one-cycle
// pulse with no internal ready).  Directly tying that to a real DDR write
// queue would drop writes whenever the queue is full.  This bridge buffers
// writes in a FIFO and exposes a backpressure handshake:
//
//   core -> wr_en_i/wr_addr_i/wr_data_i -> FIFO -> mem_wr_en_o/... -> DDR
//   wr_ready_o   = (fill < STALL_THRESHOLD)   (to core: may start another write)
//   mem_wr_ready_i                            (from DDR: accepts one more byte)
//
// Backpressure contract with mn04_core.v:
//   * The core gates EVERY requant-start on wr_ready_i, so it never starts a
//     requant once the bridge is near-full.  Because at most RQ_DEPTH (=8)
//     requants are in flight at once, a write presented to the bridge always
//     finds a free slot as long as STALL_THRESHOLD + RQ_DEPTH <= DEPTH.
//     Defaults (DEPTH=16, STALL_THRESHOLD=8) satisfy that: a requant's write
//     fires with fill <= (THRESHOLD-1) + (RQ_DEPTH-1) = 14 < 16 = DEPTH.
//   * The FIFO preserves write order (FIFO), so the committed DDR image is
//     byte-identical to a no-backpressure run -- no reorder, no loss.
//
// DEPTH/STALL_THRESHOLD are tunable per DDR worst-case stall; the tb proves
// correctness under a bounded-backpressure write model.
module mn04_wmerge_bridge #(
    parameter integer DEPTH = 16,
    parameter integer STALL_THRESHOLD = 8
)(
    input  wire        clk,
    input  wire        rst_n,
    // core side
    input  wire        wr_en_i,
    input  wire [23:0] wr_addr_i,
    input  wire [7:0]  wr_data_i,
    output wire        wr_ready_o,
    output wire        empty_o,
    // DDR side
    output wire        mem_wr_en_o,
    output wire [23:0] mem_wr_addr_o,
    output wire [7:0]  mem_wr_data_o,
    input  wire        mem_wr_ready_i
);
    localparam AW = $clog2(DEPTH);  // FIFO pointers wrap at DEPTH (power of two)

    reg [23:0] fifo_addr [0:DEPTH-1];
    reg [7:0]  fifo_data [0:DEPTH-1];
    reg [AW-1:0] head_r, tail_r;
    reg [AW:0]  fill_r;  // 0..DEPTH

    integer i;
    initial begin
        for (i = 0; i < DEPTH; i = i + 1) begin
            fifo_addr[i] = 24'd0;
            fifo_data[i] = 8'd0;
        end
    end

    wire push    = wr_en_i && wr_ready_o;
    wire pop     = (fill_r != 0) && mem_wr_ready_i;
    wire mem_en  = pop;

    assign wr_ready_o   = (fill_r < STALL_THRESHOLD);
    assign empty_o = fill_r==0;
    assign mem_wr_en_o  = mem_en;
    assign mem_wr_addr_o= fifo_addr[head_r];
    assign mem_wr_data_o= fifo_data[head_r];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            head_r <= 0; tail_r <= 0; fill_r <= 0;
        end else begin
            if (push) begin
                fifo_addr[tail_r] <= wr_addr_i;
                fifo_data[tail_r] <= wr_data_i;
                tail_r <= tail_r + 1'b1;
            end
            if (mem_en)
                head_r <= head_r + 1'b1;
            // net-zero fill update handled below (single always: no collision)
            if (push && mem_en)
                fill_r <= fill_r;
            else if (push)
                fill_r <= fill_r + 1'b1;
            else if (mem_en)
                fill_r <= fill_r - 1'b1;
        end
    end

    // Guard: a write must never be dropped.  If the core presents a byte when
    // the bridge cannot accept it, that is a design/flow-control bug and must
    // fail the simulation loudly rather than silently lose data.
    always @(posedge clk) begin
        if (wr_en_i && !wr_ready_o)
            $display("MN04_WMERGE OVERFLOW: core write at %0d rejected (fill=%0d), addr=%h data=%0d",
                     $time, fill_r, wr_addr_i, $signed(wr_data_i));
    end
endmodule
