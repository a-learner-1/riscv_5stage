`timescale 1ns/1ps
// Board PCM path. The I2S receiver and 3:2 resampler cannot be paused, so a
// bounded FIFO absorbs the frontend's per-frame processing pause. One shared
// frontend emits 128 x0 bytes per 10 ms frame for both recognition windows.
module mn04_audio_capture_frontend (
    input  wire clk,
    input  wire rst_n,
    input  wire es8311_bclk_i,
    input  wire es8311_lrck_i,
    input  wire es8311_dout_i,
    output wire signed [7:0] x0_o,
    output wire x0_valid_o,
    output wire pcm_overflow_o,
    output wire signed [15:0] pcm_debug_o,
    output wire pcm_debug_valid_o
);
    wire signed [15:0] pcm48, pcm32, pcm_queued;
    wire pcm48_valid, pcm32_valid, pcm_queued_valid, pcm_queued_ready;
    assign pcm_debug_o=pcm48;
    assign pcm_debug_valid_o=pcm48_valid;
    es8311_i2s_receiver u_i2s (
        .clk(clk), .rst_n(rst_n), .bclk_i(es8311_bclk_i),
        .lrck_i(es8311_lrck_i), .dout_i(es8311_dout_i),
        .sample_o(pcm48), .sample_valid_o(pcm48_valid));
    pcm_decimator_48k_to_32k u_resample (
        .clk(clk), .rst_n(rst_n), .sample_i(pcm48),
        .sample_valid_i(pcm48_valid), .sample_o(pcm32),
        .sample_valid_o(pcm32_valid));
    mn04_pcm_elastic_fifo #(.ADDR_BITS(7)) u_pcm_fifo (
        .clk(clk), .rst_n(rst_n), .sample_i(pcm32),
        .sample_valid_i(pcm32_valid), .sample_o(pcm_queued),
        .sample_valid_o(pcm_queued_valid), .sample_ready_i(pcm_queued_ready),
        .overflow_o(pcm_overflow_o));
    mn04_frontend #(.MAX_FRAMES(1000), .PCM_SAMPLES(320000),
        .CONTINUOUS(1)) u_frontend (
        .clk(clk), .rst_n(rst_n), .pcm_valid_i(pcm_queued_valid),
        .pcm_data_i(pcm_queued), .pcm_ready_o(pcm_queued_ready),
        .x0_out(x0_o), .x0_valid(x0_valid_o), .done_o());
endmodule
