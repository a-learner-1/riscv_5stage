`timescale 1ns/1ps
// Runtime template update controller.
//
// Host protocol (binary, little-endian fields):
//   host -> 0xA5, 0x01, len[4], sha256[32], header_crc32[4]
//   board: scan selector journal, erase the inactive slot, then answer 'R'
//   host -> container[len] in chunks of at most 256 bytes; board answers 'A'
//          after each page has finished programming; then host -> CRC32[4]
//   board: program the container, append a selector record body, then write the
//          4-byte commit word last, and answer 'C', slot, generation[4]
//   any failure: 'E', code    (1 header/len, 2 busy, 3 crc, 4 journal,
//                               5 flash, 6 generation exhausted)
//
// The journal record matches scripts/template_selector_journal.py byte for
// byte.  A power cut before the commit word leaves the record uncommitted and
// the previous slot selected; the top-level boot selector reads the same
// journal, so no host-side rewrite is needed after an update.
module mn04_template_update #(
    parameter [23:0] JOURNAL_BASE = 24'h670000,
    parameter integer JOURNAL_BYTES = 8192,
    parameter [23:0] SLOT_A_BASE = 24'h610000,
    parameter [23:0] SLOT_B_BASE = 24'h640000,
    parameter integer SLOT_BYTES = 196608,
    parameter integer MIN_CONTAINER_BYTES = 104961,
    parameter integer SECTOR_BYTES = 4096,
    parameter integer SPI_DIV_HALF = 2
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        idle_ok_i,
    input  wire        host_valid_i,
    input  wire [7:0]  host_data_i,
    output wire        host_ready_o,
    output wire        msg_valid_o,
    output wire [7:0]  msg_data_o,
    input  wire        msg_ready_i,
    output wire        qspi_cs_o,
    output wire        qspi_sck_o,
    output wire        qspi_mosi_o,
    input  wire        qspi_miso_i,
    output wire        busy_o,
    output reg         active_valid_o,
    output reg         active_slot_o,
    output reg  [31:0] active_generation_o
);
    localparam [4:0] S_IDLE = 0, S_CMD = 1, S_LEN_START = 2, S_LEN = 3,
                     S_SHA = 4, S_HCRC = 5, S_HCRC_WAIT = 6,
                     S_SCAN_START = 7, S_SCAN = 8,
                     S_ERASE_REQ = 9, S_ERASE_WAIT = 10,
                     S_READY_MSG = 11, S_DATA_START = 12, S_DATA = 13,
                     S_PAGE_REQ = 14, S_PAGE_WAIT = 15,
                     S_DCRC = 16, S_DCRC_WAIT = 17,
                     S_JCRC_START = 18, S_JCRC_FEED = 19, S_JCRC_WAIT = 20,
                     S_JBUF_FILL = 21, S_JBODY_REQ = 22, S_JBODY_WAIT = 23,
                     S_JCOMMIT_FILL = 24, S_JCOMMIT_REQ = 25,
                     S_JCOMMIT_WAIT = 26, S_MSG = 27,
                     S_LEN_PRE = 28, S_DATA_PRE = 29, S_JCRC_PRE = 30,
                     S_BUSY_DRAIN = 31;

    reg [4:0] st;
    reg [31:0] hdr_len_r;
    reg [5:0] busy_drain_count_r;
    reg [1:0] len_idx_r;
    reg [4:0] sha_idx_r;
    reg [1:0] hcrc_idx_r, dcrc_idx_r;
    reg [31:0] hcrc_rx_r, dcrc_rx_r;
    reg [255:0] sha_r;
    reg [17:0] len_r;
    reg target_slot_r;
    reg [23:0] target_base_r;
    reg [31:0] target_gen_r;
    reg [23:0] record_addr_r;
    reg [6:0] sector_count_r, erase_idx_r;
    reg [17:0] rx_count_r, page_offset_r;
    reg [63:0] template_magic_r;
    reg [15:0] template_version_r, template_header_bytes_r;
    reg [31:0] template_map_bytes_r, template_metadata_bytes_r;
    reg [31:0] template_display_bytes_r;
    reg [31:0] template_counts_word_r;
    reg [8:0] page_count_r, page_len_r;
    reg last_page_r;
    reg [7:0] msg_buf [0:7];
    reg [3:0] msg_len_r, msg_idx_r;
    reg [4:0] msg_next_r;
    reg [5:0] jcrc_idx_r, jfill_idx_r;
    reg [31:0] jcrc_val_r;
    reg rd_done_seen_r;

    reg rd_start_r, sel_start_r;
    wire rd_busy, rd_done, rd_valid, rd_ready;
    wire [7:0] rd_byte;
    wire rd_cs, rd_sck, rd_mosi;
    wire sel_ready, sel_done;
    wire sel_active_valid, sel_slot;
    wire [31:0] sel_generation;
    wire [17:0] sel_first_erased;
    wire sel_first_erased_valid, sel_ready_w;

    wire fs_ack, fs_busy, fs_err;
    reg  fs_req_r;
    reg  [1:0] fs_op_r;
    reg  [23:0] fs_addr_r;
    reg  [8:0]  fs_len_r;
    reg  buf_we_r;
    reg  [7:0] buf_addr_r, buf_data_r;
    wire fs_cs, fs_sck, fs_mosi;

    reg crc_start_r;
    wire crc_ready, crc_busy;
    wire [31:0] crc_out;

    // ------------------------------------------------------------------
    // Journal byte generator for the record body (0..59).
    // ------------------------------------------------------------------
    function [7:0] journal_byte(input [5:0] idx);
        reg [5:0] j;
        begin
            j = idx - 6'd24;
            case (idx)
                6'd0: journal_byte = 8'h50; // P
                6'd1: journal_byte = 8'h35; // 5
                6'd2: journal_byte = 8'h30; // 0
                6'd3: journal_byte = 8'h53; // S
                6'd4: journal_byte = 8'h45; // E
                6'd5: journal_byte = 8'h4C; // L
                6'd6: journal_byte = 8'h30; // 0
                6'd7: journal_byte = 8'h31; // 1
                6'd8: journal_byte = 8'h01;
                6'd9, 6'd10, 6'd11: journal_byte = 8'h00;
                6'd12: journal_byte = target_gen_r[7:0];
                6'd13: journal_byte = target_gen_r[15:8];
                6'd14: journal_byte = target_gen_r[23:16];
                6'd15: journal_byte = target_gen_r[31:24];
                6'd16: journal_byte = {7'd0, target_slot_r};
                6'd17: journal_byte = 8'h00;
                6'd18, 6'd19: journal_byte = 8'h00;
                6'd20: journal_byte = len_r[7:0];
                6'd21: journal_byte = len_r[15:8];
                6'd22: journal_byte = {6'd0, len_r[17:16]};
                6'd23: journal_byte = 8'h00;
                default: journal_byte = sha_r[(31 - j) * 8 +: 8];
            endcase
        end
    endfunction

    wire [7:0] journal_fill_byte =
        (jfill_idx_r < 6'd56) ? journal_byte(jfill_idx_r) :
        (jfill_idx_r == 6'd56) ? jcrc_val_r[7:0] :
        (jfill_idx_r == 6'd57) ? jcrc_val_r[15:8] :
        (jfill_idx_r == 6'd58) ? jcrc_val_r[23:16] : jcrc_val_r[31:24];

    wire [7:0] commit_byte =
        (jfill_idx_r == 6'd0) ? 8'h43 :  // C
        (jfill_idx_r == 6'd1) ? 8'h4D :  // M
        (jfill_idx_r == 6'd2) ? 8'h54 :  // T
                                8'h31;   // 1

    // Host-side acceptance.
    assign host_ready_o =
        (st == S_IDLE) ? 1'b1 :
        (st == S_CMD) ? 1'b1 :
        (st == S_BUSY_DRAIN) ? 1'b1 :
        (st == S_LEN) ? crc_ready :
        (st == S_SHA) ? crc_ready :
        (st == S_HCRC) ? 1'b1 :
        (st == S_DATA) ? crc_ready :
        (st == S_DCRC) ? 1'b1 : 1'b0;

    wire host_take = host_valid_i && host_ready_o;

    assign msg_valid_o = (st == S_MSG) && (msg_idx_r < msg_len_r);
    assign msg_data_o = msg_buf[msg_idx_r[2:0]];

    assign busy_o = (st != S_IDLE);

    // Only one owner of the QSPI pins at a time.
    assign qspi_cs_o = (st == S_SCAN || st == S_SCAN_START) ? rd_cs : fs_cs;
    assign qspi_sck_o = (st == S_SCAN || st == S_SCAN_START) ? rd_sck : fs_sck;
    assign qspi_mosi_o = (st == S_SCAN || st == S_SCAN_START) ? rd_mosi : fs_mosi;

    // CRC feed: header bytes, container bytes, or journal body bytes.
    wire crc_feed_valid = ((st == S_LEN || st == S_SHA || st == S_DATA) && host_take) ||
                          (st == S_JCRC_FEED && crc_ready);
    wire [7:0] crc_feed_data = (st == S_JCRC_FEED) ? journal_byte(jcrc_idx_r) : host_data_i;

    always @(*) begin
        fs_req_r = (st == S_ERASE_REQ) || (st == S_PAGE_REQ) ||
                   (st == S_JBODY_REQ) || (st == S_JCOMMIT_REQ);
        fs_op_r = ((st == S_PAGE_REQ) || (st == S_JBODY_REQ) ||
                   (st == S_JCOMMIT_REQ)) ? 2'd1 : 2'd0;
        if (st == S_ERASE_REQ) begin
            fs_addr_r = target_base_r + ({11'd0, erase_idx_r[6:0]} << 12);
            fs_len_r = 9'd1;
        end else if (st == S_PAGE_REQ) begin
            fs_addr_r = target_base_r + {6'd0, page_offset_r};
            fs_len_r = page_len_r;
        end else if (st == S_JBODY_REQ) begin
            fs_addr_r = record_addr_r;
            fs_len_r = 9'd60;
        end else if (st == S_JCOMMIT_REQ) begin
            fs_addr_r = record_addr_r + 24'd60;
            fs_len_r = 9'd4;
        end else begin
            fs_addr_r = 24'd0;
            fs_len_r = 9'd1;
        end
        buf_we_r = (st == S_DATA && host_take) ||
                   (st == S_JBUF_FILL) || (st == S_JCOMMIT_FILL);
        if (st == S_DATA) begin
            buf_addr_r = page_count_r[7:0];
            buf_data_r = host_data_i;
        end else if (st == S_JBUF_FILL) begin
            buf_addr_r = {2'd0, jfill_idx_r};
            buf_data_r = journal_fill_byte;
        end else begin
            buf_addr_r = {6'd0, jfill_idx_r[1:0]};
            buf_data_r = commit_byte;
        end
    end

    mn04_crc32_stream u_crc (
        .clk(clk), .rst_n(rst_n), .start_i(crc_start_r),
        .data_i(crc_feed_data), .valid_i(crc_feed_valid),
        .ready_o(crc_ready), .busy_o(crc_busy), .crc_o(crc_out));

    mn04_qspi_block_reader u_reader (
        .clk(clk), .rst_n(rst_n), .start_i(rd_start_r),
        .addr_i(JOURNAL_BASE), .count_i(JOURNAL_BYTES[15:0]),
        .busy_o(rd_busy), .done_o(rd_done),
        .byte_o(rd_byte), .byte_valid_o(rd_valid),
        .byte_ready_i(rd_ready), .flash_rd_addr_o(), .flash_rd_data_i(8'h00),
        .cs_o(rd_cs), .sck_o(rd_sck), .mosi_o(rd_mosi), .miso_i(qspi_miso_i));

    assign rd_ready = (st == S_SCAN) ? sel_ready : 1'b1;

    mn04_template_selector #(.RECORDS(JOURNAL_BYTES / 64)) u_selector (
        .clk(clk), .rst_n(rst_n), .start_i(sel_start_r),
        .byte_i(rd_byte), .valid_i(rd_valid && (st == S_SCAN)),
        .ready_o(sel_ready), .done_o(sel_done),
        .active_valid_o(sel_active_valid), .slot_o(sel_slot),
        .generation_o(sel_generation), .container_bytes_o(),
        .first_erased_index_o(sel_first_erased),
        .first_erased_valid_o(sel_first_erased_valid),
        .uncommitted_count_o(), .invalid_count_o(), .conflict_count_o());

    mn04_flash_sequencer #(.SPI_DIV_HALF(SPI_DIV_HALF)) u_flash (
        .clk(clk), .rst_n(rst_n),
        .req_valid_i(fs_req_r), .req_op_i(fs_op_r),
        .req_addr_i(fs_addr_r), .req_len_i(fs_len_r),
        .buf_we_i(buf_we_r), .buf_addr_i(buf_addr_r), .buf_data_i(buf_data_r),
        .ack_o(fs_ack), .busy_o(fs_busy), .error_o(fs_err),
        .cs_o(fs_cs), .sck_o(fs_sck), .mosi_o(fs_mosi), .miso_i(qspi_miso_i));

    // ------------------------------------------------------------------
    // Main control.
    // ------------------------------------------------------------------
    task automatic set_error(input [7:0] code);
        begin
            msg_buf[0] <= 8'h45;   // 'E'
            msg_buf[1] <= code;
            msg_len_r <= 4'd2;
            msg_idx_r <= 4'd0;
            msg_next_r <= S_IDLE;
            st <= S_MSG;
        end
    endtask

    task automatic begin_msg(input [4:0] next_state);
        begin
            msg_idx_r <= 4'd0;
            msg_next_r <= next_state;
            st <= S_MSG;
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE;
            hdr_len_r <= 32'd0; len_idx_r <= 2'd0; sha_idx_r <= 5'd0;
            busy_drain_count_r <= 6'd0;
            hcrc_idx_r <= 2'd0; dcrc_idx_r <= 2'd0;
            hcrc_rx_r <= 32'd0; dcrc_rx_r <= 32'd0; sha_r <= 256'd0;
            len_r <= 18'd0; target_slot_r <= 1'b0; target_base_r <= 24'd0;
            target_gen_r <= 32'd0; record_addr_r <= 24'd0;
            sector_count_r <= 7'd0; erase_idx_r <= 7'd0;
            rx_count_r <= 18'd0; page_offset_r <= 18'd0;
            template_magic_r <= 64'd0;
            template_version_r <= 16'd0; template_header_bytes_r <= 16'd0;
            template_map_bytes_r <= 32'd0; template_metadata_bytes_r <= 32'd0;
            template_display_bytes_r <= 32'd0;
            template_counts_word_r <= 32'd0;
            page_count_r <= 9'd0; page_len_r <= 9'd1; last_page_r <= 1'b0;
            msg_len_r <= 4'd0; msg_idx_r <= 4'd0; msg_next_r <= S_IDLE;
            jcrc_idx_r <= 6'd0; jfill_idx_r <= 6'd0; jcrc_val_r <= 32'd0;
            rd_start_r <= 1'b0; sel_start_r <= 1'b0; rd_done_seen_r <= 1'b0;
            crc_start_r <= 1'b0;
            active_valid_o <= 1'b0; active_slot_o <= 1'b0;
            active_generation_o <= 32'd0;
        end else begin
            rd_start_r <= 1'b0;
            sel_start_r <= 1'b0;
            crc_start_r <= 1'b0;
            
            case (st)
                S_IDLE: begin
                    if (host_valid_i && host_data_i == 8'hA5) begin
                        if (!idle_ok_i) begin
                            // Consume the rest of the fixed-size header before
                            // reporting busy so a later retry cannot be
                            // desynchronized by leftover header bytes.
                            busy_drain_count_r <= 6'd0;
                            st <= S_BUSY_DRAIN;
                        end
                        else st <= S_CMD;
                    end
                end
                S_BUSY_DRAIN: begin
                    if (host_valid_i) begin
                        if (busy_drain_count_r == 6'd40) set_error(8'd2);
                        else busy_drain_count_r <= busy_drain_count_r + 6'd1;
                    end
                end
                S_CMD: begin
                    if (host_valid_i) begin
                        if (host_data_i == 8'h01) begin
                            len_idx_r <= 2'd0;
                            st <= S_LEN_START;
                        end else set_error(8'd1);
                    end
                end
                S_LEN_START: begin
                    crc_start_r <= 1'b1;
                    st <= S_LEN_PRE;
                end
                S_LEN_PRE: begin
                    st <= S_LEN;
                end
                S_LEN: begin
                    if (host_take) begin
                        hdr_len_r[{len_idx_r, 3'd0} +: 8] <= host_data_i;
                        if (len_idx_r == 2'd3) st <= S_SHA;
                        else len_idx_r <= len_idx_r + 2'd1;
                    end
                end
                S_SHA: begin
                    if (host_take) begin
                        sha_r[(31 - sha_idx_r) * 8 +: 8] <= host_data_i;
                        if (sha_idx_r == 5'd31) begin
                            sha_idx_r <= 5'd0;
                            hcrc_idx_r <= 2'd0;
                            st <= S_HCRC;
                        end else sha_idx_r <= sha_idx_r + 5'd1;
                    end
                end
                S_HCRC: begin
                    if (host_valid_i) begin
                        hcrc_rx_r[{hcrc_idx_r, 3'd0} +: 8] <= host_data_i;
                        if (hcrc_idx_r == 2'd3) st <= S_HCRC_WAIT;
                        else hcrc_idx_r <= hcrc_idx_r + 2'd1;
                    end
                end
                S_HCRC_WAIT: begin
                    if (!crc_busy) begin
                        if (crc_out != hcrc_rx_r) set_error(8'd1);
                        else if (hdr_len_r < MIN_CONTAINER_BYTES ||
                                 hdr_len_r > SLOT_BYTES ||
                                 hdr_len_r[31:18] != 14'd0) set_error(8'd1);
                        else begin
                            len_r <= hdr_len_r[17:0];
                            sector_count_r <= (hdr_len_r[17:0] + SECTOR_BYTES - 1) >> 12;
                            erase_idx_r <= 7'd0;
                            rd_done_seen_r <= 1'b0;
                            st <= S_SCAN_START;
                        end
                    end
                end
                S_SCAN_START: begin
                    sel_start_r <= 1'b1;
                    rd_start_r <= 1'b1;
                    st <= S_SCAN;
                end
                S_SCAN: begin
                    if (rd_done) rd_done_seen_r <= 1'b1;
                    if (sel_done && (rd_done || rd_done_seen_r)) begin
                        if (!sel_first_erased_valid) set_error(8'd4);
                        else if (sel_active_valid && sel_generation == 32'hFFFFFFFF)
                            set_error(8'd6);
                        else begin
                            target_slot_r <= sel_active_valid ? ~sel_slot : 1'b1;
                            target_base_r <= sel_active_valid ?
                                             (sel_slot ? SLOT_A_BASE : SLOT_B_BASE) :
                                             SLOT_B_BASE;
                            target_gen_r <= sel_active_valid ?
                                            (sel_generation + 32'd1) : 32'd1;
                            record_addr_r <= JOURNAL_BASE + {sel_first_erased, 6'd0};
                            st <= S_ERASE_REQ;
                        end
                    end
                end
                S_ERASE_REQ: begin
                    if (fs_busy) st <= S_ERASE_WAIT;
                end
                S_ERASE_WAIT: begin
                    if (fs_ack) begin
                        if (fs_err) set_error(8'd5);
                        else if (erase_idx_r + 7'd1 >= sector_count_r) begin
                            msg_buf[0] <= 8'h52;  // 'R'
                            msg_len_r <= 4'd1;
                            begin_msg(S_DATA_START);
                        end else begin
                            erase_idx_r <= erase_idx_r + 7'd1;
                            st <= S_ERASE_REQ;
                        end
                    end
                end
                S_DATA_START: begin
                    crc_start_r <= 1'b1;
                    rx_count_r <= 18'd0;
                    page_offset_r <= 18'd0;
                    page_count_r <= 9'd0;
                    template_magic_r <= 64'd0;
                    template_version_r <= 16'd0;
                    template_header_bytes_r <= 16'd0;
                    template_map_bytes_r <= 32'd0;
                    template_metadata_bytes_r <= 32'd0;
                    template_display_bytes_r <= 32'd0;
                    template_counts_word_r <= 32'd0;
                    st <= S_DATA_PRE;
                end
                S_DATA_PRE: begin
                    st <= S_DATA;
                end
                S_DATA: begin
                    if (host_take) begin
                        // The current bitstream builds a fixed 2+2+2 matcher.
                        // Validate the container header's packed counts before
                        // committing this slot, so a mismatched package cannot
                        // become the boot-selected template bank. Also validate
                        // all fixed v3 section sizes and the variable metadata
                        // length against the transferred byte count.
                        case (rx_count_r)
                            18'd0: template_magic_r[7:0] <= host_data_i;
                            18'd1: template_magic_r[15:8] <= host_data_i;
                            18'd2: template_magic_r[23:16] <= host_data_i;
                            18'd3: template_magic_r[31:24] <= host_data_i;
                            18'd4: template_magic_r[39:32] <= host_data_i;
                            18'd5: template_magic_r[47:40] <= host_data_i;
                            18'd6: template_magic_r[55:48] <= host_data_i;
                            18'd7: template_magic_r[63:56] <= host_data_i;
                            18'd8: template_version_r[7:0] <= host_data_i;
                            18'd9: template_version_r[15:8] <= host_data_i;
                            18'd10: template_header_bytes_r[7:0] <= host_data_i;
                            18'd11: template_header_bytes_r[15:8] <= host_data_i;
                            18'd12: template_map_bytes_r[7:0] <= host_data_i;
                            18'd13: template_map_bytes_r[15:8] <= host_data_i;
                            18'd14: template_map_bytes_r[23:16] <= host_data_i;
                            18'd15: template_map_bytes_r[31:24] <= host_data_i;
                            18'd16: template_metadata_bytes_r[7:0] <= host_data_i;
                            18'd17: template_metadata_bytes_r[15:8] <= host_data_i;
                            18'd18: template_metadata_bytes_r[23:16] <= host_data_i;
                            18'd19: template_metadata_bytes_r[31:24] <= host_data_i;
                            18'd20: template_display_bytes_r[7:0] <= host_data_i;
                            18'd21: template_display_bytes_r[15:8] <= host_data_i;
                            18'd22: template_display_bytes_r[23:16] <= host_data_i;
                            18'd23: template_display_bytes_r[31:24] <= host_data_i;
                            18'd24: template_counts_word_r[7:0] <= host_data_i;
                            18'd25: template_counts_word_r[15:8] <= host_data_i;
                            18'd26: template_counts_word_r[23:16] <= host_data_i;
                            18'd27: template_counts_word_r[31:24] <= host_data_i;
                            default: ;
                        endcase
                        if (rx_count_r + 18'd1 == len_r) begin
                            page_len_r <= page_count_r + 9'd1;
                            last_page_r <= 1'b1;
                            st <= S_PAGE_REQ;
                        end else if (page_count_r == 9'd255) begin
                            page_len_r <= 9'd256;
                            last_page_r <= 1'b0;
                            st <= S_PAGE_REQ;
                        end else begin
                            rx_count_r <= rx_count_r + 18'd1;
                            page_count_r <= page_count_r + 9'd1;
                        end
                    end
                end
                S_PAGE_REQ: begin
                    if (fs_busy) st <= S_PAGE_WAIT;
                end
                S_PAGE_WAIT: begin
                    if (fs_ack) begin
                        if (fs_err) set_error(8'd5);
                        else begin
                            page_offset_r <= page_offset_r + {9'd0, page_len_r};
                            rx_count_r <= rx_count_r + 18'd1;
                            if (last_page_r) begin
                                dcrc_idx_r <= 2'd0;
                                dcrc_rx_r <= 32'd0;
                                msg_buf[0] <= 8'h41;  // 'A': final page programmed
                                msg_len_r <= 4'd1;
                                begin_msg(S_DCRC);
                            end else begin
                                page_count_r <= 9'd0;
                                msg_buf[0] <= 8'h41;  // 'A': page programmed
                                msg_len_r <= 4'd1;
                                begin_msg(S_DATA);
                            end
                        end
                    end
                end
                S_DCRC: begin
                    if (host_valid_i) begin
                        dcrc_rx_r[{dcrc_idx_r, 3'd0} +: 8] <= host_data_i;
                        if (dcrc_idx_r == 2'd3) st <= S_DCRC_WAIT;
                        else dcrc_idx_r <= dcrc_idx_r + 2'd1;
                    end
                end
                S_DCRC_WAIT: begin
                    if (!crc_busy) begin
                        if (crc_out != dcrc_rx_r) set_error(8'd3);
                        else if (template_magic_r != 64'h3330424D54303550 ||
                                 template_version_r != 16'd3 ||
                                 template_header_bytes_r != 16'd128 ||
                                 template_map_bytes_r != 32'd76800 ||
                                 template_metadata_bytes_r == 32'd0 ||
                                 template_display_bytes_r != 32'd28032 ||
                                 len_r != (18'd128 + 18'd76800 +
                                           template_metadata_bytes_r + 18'd28032) ||
                                 template_counts_word_r != 32'h00020202)
                            set_error(8'd1);
                        else begin
                            jcrc_idx_r <= 6'd0;
                            st <= S_JCRC_START;
                        end
                    end
                end
                S_JCRC_START: begin
                    crc_start_r <= 1'b1;
                    st <= S_JCRC_PRE;
                end
                S_JCRC_PRE: begin
                    st <= S_JCRC_FEED;
                end
                S_JCRC_FEED: begin
                    if (crc_ready) begin
                        if (jcrc_idx_r == 6'd55) st <= S_JCRC_WAIT;
                        else jcrc_idx_r <= jcrc_idx_r + 6'd1;
                    end
                end
                S_JCRC_WAIT: begin
                    if (!crc_busy) begin
                        jcrc_val_r <= crc_out;
                        jfill_idx_r <= 6'd0;
                        st <= S_JBUF_FILL;
                    end
                end
                S_JBUF_FILL: begin
                    if (jfill_idx_r == 6'd59) begin
                        jfill_idx_r <= 6'd0;
                        st <= S_JBODY_REQ;
                    end else jfill_idx_r <= jfill_idx_r + 6'd1;
                end
                S_JBODY_REQ: begin
                    if (fs_busy) st <= S_JBODY_WAIT;
                end
                S_JBODY_WAIT: begin
                    if (fs_ack) begin
                        if (fs_err) set_error(8'd5);
                        else begin
                            jfill_idx_r <= 6'd0;
                            st <= S_JCOMMIT_FILL;
                        end
                    end
                end
                S_JCOMMIT_FILL: begin
                    if (jfill_idx_r == 6'd3) begin
                        jfill_idx_r <= 6'd0;
                        st <= S_JCOMMIT_REQ;
                    end else jfill_idx_r <= jfill_idx_r + 6'd1;
                end
                S_JCOMMIT_REQ: begin
                    if (fs_busy) st <= S_JCOMMIT_WAIT;
                end
                S_JCOMMIT_WAIT: begin
                    if (fs_ack) begin
                        if (fs_err) set_error(8'd5);
                        else begin
                            active_valid_o <= 1'b1;
                            active_slot_o <= target_slot_r;
                            active_generation_o <= target_gen_r;
                            msg_buf[0] <= 8'h43;  // 'C'
                            msg_buf[1] <= {7'd0, target_slot_r};
                            msg_buf[2] <= target_gen_r[7:0];
                            msg_buf[3] <= target_gen_r[15:8];
                            msg_buf[4] <= target_gen_r[23:16];
                            msg_buf[5] <= target_gen_r[31:24];
                            msg_len_r <= 4'd6;
                            begin_msg(S_IDLE);
                        end
                    end
                end
                S_MSG: begin
                    if (msg_valid_o && msg_ready_i) begin
                        if (msg_idx_r + 4'd1 == msg_len_r) st <= msg_next_r;
                        else msg_idx_r <= msg_idx_r + 4'd1;
                    end
                end
                default: st <= S_IDLE;
            endcase
        end
    end
endmodule
