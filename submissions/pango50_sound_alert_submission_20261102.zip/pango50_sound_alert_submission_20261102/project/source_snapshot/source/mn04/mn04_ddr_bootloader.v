`timescale 1ns/1ps
// MN04 boot-time DDR image loader (GATE: QSPI -> DDR + checksum).
//
// Reads the packed five-class runtime image (op descriptors + weights + LUTs)
// out of SPI-NOR in <=64 KiB chunks and writes it into the single shared DDR
// at word DDR_BASE_WORD (byte DDR_BASE_WORD*4), accumulating a 32-bit additive
// checksum over the bytes as read.  Asserts ddr_init_done_o only after the
// whole image is written AND the checksum matches; the inference core gates
// its DDR weight feeder on that signal.
//
// QSPI ownership: this loader drives the SPI bus first and releases it
// (cs deasserted, busy_o low) before ddr_init_done_o goes high, so the board
// mux can then hand the bus to the core's descriptor/LUT reader.
//
// The mn04_qspi_block_reader count port is 16-bit, so IMAGE_BYTES is split
// into CHUNK_BYTES (<= 65535) chunks.  The byte writer is reused as-is:
// one accepted byte becomes one single-strobe 256-bit DDR beat (functional;
// coalescing 32 bytes/beat is a boot-time throughput optimization, not a
// correctness requirement — 811890 single-beat writes at 50 MHz is ~50 ms).
module mn04_ddr_bootloader #(
    parameter integer SPI_DIV_HALF = 2,
    parameter integer FAST_BYTES   = 1,
    parameter [23:0] FLASH_BASE       = 24'h0,         // image byte base in SPI-NOR
    parameter [23:0] IMAGE_BYTES      = 24'd811890,    // total image size in bytes
    parameter [15:0] CHUNK_BYTES      = 16'd65535,     // <= 65535 (reader count width)
    parameter [27:0] DDR_BASE_WORD    = 28'h100000,    // DDR word base of the image
    parameter [31:0] CHECKSUM_EXPECTED = 32'h053e2a11  // sum of image bytes mod 2^32
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start_i,          // pulse; held-high handled in VERIFY
    output wire        busy_o,
    output reg         done_o,           // 1-cycle pulse at completion
    output reg         ddr_init_done_o,  // level: high iff copy done + checksum OK
    output reg         checksum_ok_o,    // level, same value as ddr_init_done_o
    // SPI-NOR (parallel fast port for sim; physical pins otherwise)
    output wire [23:0] flash_rd_addr_o,
    input  wire [7:0]  flash_rd_data_i,
    output wire        cs_o,
    output wire        sck_o,
    output wire        mosi_o,
    input  wire        miso_i,
    // DDR write master (arbiter m3, full AXI4)
    output wire [27:0] ddr_awaddr_o,
    output wire        ddr_awvalid_o,
    input  wire        ddr_awready_i,
    output wire [255:0] ddr_wdata_o,
    output wire [31:0]  ddr_wstrb_o,
    output wire        ddr_wvalid_o,
    output wire        ddr_wlast_o,
    input  wire        ddr_wready_i,
    input  wire [1:0]  ddr_bresp_i,
    input  wire        ddr_bvalid_i,
    output wire        ddr_bready_o
);
    localparam IDLE=3'd0, CHUNK_START=3'd1, COPY=3'd2, VERIFY=3'd3;

    reg  [2:0]  st_r;
    reg  [23:0] chunk_base_r;    // flash byte base of the current chunk
    reg  [15:0] chunk_len_r;     // bytes in the current chunk
    reg  [23:0] global_idx_r;    // bytes accepted overall (0..IMAGE_BYTES)
    reg  [16:0] chunk_idx_r;     // bytes accepted in this chunk (17-bit to hold 65535+)
    reg  [31:0] csum_r;
    reg         qr_start_r;

    wire [7:0]  qr_byte;
    wire        qr_byte_valid;
    wire        wr_byte_ready, wr_drained;

    assign busy_o = (st_r != IDLE);

    // a byte is accepted when the reader presents it and the writer can take it
    wire byte_acc = qr_byte_valid && wr_byte_ready;
    // DDR byte address of the byte currently being accepted
    wire [23:0] wr_byte_addr = (DDR_BASE_WORD << 2) + global_idx_r;

    // next chunk length: remaining = IMAGE_BYTES - chunk_base_r
    wire [23:0] remaining = IMAGE_BYTES - chunk_base_r;
    wire [15:0] next_len = (remaining > {8'd0, CHUNK_BYTES})
                           ? CHUNK_BYTES : remaining[15:0];

    mn04_qspi_block_reader #(.SPI_DIV_HALF(SPI_DIV_HALF), .FAST_BYTES(FAST_BYTES)) qr (
        .clk(clk), .rst_n(rst_n),
        .start_i(qr_start_r),
        .addr_i(FLASH_BASE + chunk_base_r),
        .count_i(chunk_len_r),
        .busy_o(), .done_o(),
        .byte_o(qr_byte), .byte_valid_o(qr_byte_valid), .byte_ready_i(wr_byte_ready),
        .flash_rd_addr_o(flash_rd_addr_o), .flash_rd_data_i(flash_rd_data_i),
        .cs_o(cs_o), .sck_o(sck_o), .mosi_o(mosi_o), .miso_i(miso_i)
    );

    mn04_ddr_act_byte_writer writer (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(1'b1),
        .byte_valid_i(qr_byte_valid), .byte_addr_i(wr_byte_addr),
        .byte_data_i(qr_byte), .byte_ready_o(wr_byte_ready),
        .ddr_awaddr_o(ddr_awaddr_o), .ddr_awvalid_o(ddr_awvalid_o),
        .ddr_awready_i(ddr_awready_i), .ddr_wdata_o(ddr_wdata_o),
        .ddr_wstrb_o(ddr_wstrb_o),
        .ddr_wvalid_o(ddr_wvalid_o), .ddr_wlast_o(ddr_wlast_o),
        .ddr_wready_i(ddr_wready_i),
        .ddr_bresp_i(ddr_bresp_i), .ddr_bvalid_i(ddr_bvalid_i),
        .ddr_bready_o(ddr_bready_o),
        .drained_o(wr_drained)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st_r <= IDLE;
            chunk_base_r <= 24'd0; chunk_len_r <= 16'd0;
            global_idx_r <= 24'd0; chunk_idx_r <= 17'd0;
            csum_r <= 32'd0; qr_start_r <= 1'b0;
            done_o <= 1'b0; ddr_init_done_o <= 1'b0; checksum_ok_o <= 1'b0;
        end else begin
            done_o <= 1'b0;
            qr_start_r <= 1'b0;
            case (st_r)
                IDLE: begin
                    if (start_i) begin
                        chunk_base_r <= 24'd0;
                        global_idx_r <= 24'd0;
                        csum_r <= 32'd0;
                        st_r <= CHUNK_START;
                    end
                end
                CHUNK_START: begin
                    chunk_len_r <= next_len;
                    chunk_idx_r <= 17'd0;
                    qr_start_r <= 1'b1;
                    st_r <= COPY;
                end
                COPY: begin
                    if (byte_acc) begin
                        csum_r <= csum_r + {24'd0, qr_byte};
                        global_idx_r <= global_idx_r + 1'b1;
                        chunk_idx_r <= chunk_idx_r + 1'b1;
                    end
                    // chunk complete: every byte accepted and the writer drained
                    if (chunk_idx_r == {1'b0, chunk_len_r} && wr_drained) begin
                        if (global_idx_r == IMAGE_BYTES) begin
                            ddr_init_done_o <= (csum_r == CHECKSUM_EXPECTED);
                            checksum_ok_o   <= (csum_r == CHECKSUM_EXPECTED);
                            st_r <= VERIFY;
                        end else begin
                            chunk_base_r <= chunk_base_r + {8'd0, chunk_len_r};
                            st_r <= CHUNK_START;
                        end
                    end
                end
                VERIFY: begin
                    done_o <= 1'b1;
                    if (!start_i) st_r <= IDLE;  // held-high start_i must not restart
                end
            endcase
        end
    end
endmodule
