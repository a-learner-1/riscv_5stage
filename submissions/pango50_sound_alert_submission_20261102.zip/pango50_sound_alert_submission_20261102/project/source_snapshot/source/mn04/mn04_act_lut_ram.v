`timescale 1ns/1ps
// MN04 activation LUT RAM (256 x 8).  Loaded from the runtime image LUT table
// via the qspi byte stream; applied with index = signed_byte + 128 (golden
// lut_apply contract: y = lut[q + 128], q in [-128,127]).  Combinational read.
module mn04_act_lut_ram (
    input  wire        clk,
    input  wire        rst_n,
    // load port (qspi byte stream, 256 bytes)
    input  wire        ld_en_i,
    input  wire [7:0]  ld_addr_i,
    input  wire [7:0]  ld_data_i,
    // read port
    input  wire [7:0]  rd_idx_i,      // q + 128
    output wire [7:0]  rd_data_o
);
    reg [7:0] lut [0:255];
    integer i;
    initial for (i = 0; i < 256; i = i + 1) lut[i] = 8'd0;
    always @(posedge clk) begin
        if (ld_en_i) lut[ld_addr_i] <= ld_data_i;
    end
    assign rd_data_o = lut[rd_idx_i];
endmodule
