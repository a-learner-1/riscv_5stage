`timescale 1ns/1ps
// CPU5 control replacement for mn04_rv32im_control.
// The sound/CNN/template datapaths and their register contract are unchanged.
// CPU5 fetches from a synchronous ROM, keeps its stack/BSS in D0 BRAM, and
// reaches the existing control registers through a single AXI4-Lite master.
module mn04_cpu5_control #(
    parameter integer CLOCK_HZ=50000000,
    parameter FIRMWARE_FILE="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_replacement_20261028/control_cpu5.mem",
    parameter DATA_FILE="C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_replacement_20261028/control_cpu5_data.mem",
    parameter [15:0] BABY_THRESHOLD=59637,KNOCK_THRESHOLD=47841,
    parameter [15:0] SIREN_THRESHOLD=49152,CAR_THRESHOLD=29491,
    parameter [15:0] TEMPLATE_THRESHOLD=26214
)(
    input wire clk,rst_n,
    input wire [5:0] key_n_i,
    input wire boot_ready_i,codec_ready_i,recognition_i,capture_busy_i,recording_i,alert_i,
    input wire snapshot_ready_i,job_done_i,
    input wire cnn_valid_i,
    input wire [95:0] cnn_probabilities_i,
    input wire template_valid_i,
    input wire [1:0] template_class_i,
    input wire [15:0] template_score_i,
    input wire [3:0] capture_category_i,
    input wire [14:0] template_slot_mask_i,
    input wire template_commit_i,
    output wire [5:0] command_key_n_o,
    output reg job_authorized_o,
    output reg [3:0] template_slot_o,
    output reg event_valid_o,
    output reg [3:0] event_class_o,
    output reg [31:0] firmware_signature_o,command_count_o,irq_count_o,
    output reg [31:0] isa_selftest_o
);
    wire tick_ms;
    wire [5:0] press;
    reg [5:0] pending_keys;
    reg [5:0] hold_ms[0:5];
    reg [31:0] milliseconds;
    v1_ms_tick #(.CLOCK_HZ(CLOCK_HZ)) timer(.clk(clk),.rst_n(rst_n),.tick_ms_o(tick_ms));
    genvar k;
    generate for(k=0;k<6;k=k+1) begin:g_keys
        v1_key_debounce key(.clk(clk),.rst_n(rst_n),.tick_ms_i(tick_ms),.key_n_i(key_n_i[k]),.press_o(press[k]));
        assign command_key_n_o[k]=(hold_ms[k]==0);
    end endgenerate

    // AXI4-Lite control-register endpoint. AW and W are accepted separately;
    // one response is retained until CPU5 consumes it.
    wire [31:0] awaddr,araddr,wdata,rdata;
    wire [3:0] wstrb;
    wire [2:0] awprot,arprot;
    wire awvalid,awready,wvalid,wready,arvalid,arready;
    wire bready,rready;
    reg awheld,wheld,bvalid,rvalid;
    reg [31:0] awaddr_r,wdata_r,rdata_r;
    reg [3:0] wstrb_r;
    assign awready=!awheld && !bvalid;
    assign wready=!wheld && !bvalid;
    assign arready=!rvalid;
    wire write_accept=awheld && wheld && !bvalid;
    wire [7:0] offset=awaddr_r[7:0];
    wire word_write=write_accept && wstrb_r==4'hf;
    wire [5:0] irq_clear=word_write && offset==8'h24 ? wdata_r[5:0] : 6'd0;
    wire [5:0] key_clear=word_write && offset==8'h08 ? wdata_r[5:0] : 6'd0;
    wire [5:0] irq_force=word_write && offset==8'h2c ? wdata_r[5:0] : 6'd0;
    wire [5:0] sources={template_commit_i,job_done_i,template_valid_i,
                         cnn_valid_i,snapshot_ready_i,|press};
    reg [5:0] irq_pending,irq_mask;
    reg [95:0] cnn_mailbox;
    reg [31:0] template_mailbox;
    reg [15:0] threshold[0:5];
    reg [15:0] template_threshold;
    reg [31:0] required_windows,max_gap_ms,overrun_count;
    wire interrupt_request=|(irq_pending & irq_mask);
    wire command_active=command_key_n_o!=6'h3f;
    integer n;
    assign rdata=rdata_r;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            awheld<=0;wheld<=0;bvalid<=0;rvalid<=0;
            awaddr_r<=0;wdata_r<=0;wstrb_r<=0;rdata_r<=0;
            pending_keys<=0;irq_pending<=0;irq_mask<=0;milliseconds<=0;
            cnn_mailbox<=0;template_mailbox<=0;overrun_count<=0;
            firmware_signature_o<=0;command_count_o<=0;irq_count_o<=0;isa_selftest_o<=0;
            job_authorized_o<=0;template_slot_o<=0;event_valid_o<=0;event_class_o<=0;
            required_windows<=1;max_gap_ms<=2000;template_threshold<=TEMPLATE_THRESHOLD;
            threshold[0]<=65535;threshold[1]<=BABY_THRESHOLD;threshold[2]<=KNOCK_THRESHOLD;
            threshold[3]<=SIREN_THRESHOLD;threshold[4]<=65535;threshold[5]<=CAR_THRESHOLD;
            for(n=0;n<6;n=n+1) hold_ms[n]<=0;
        end else begin
            if(tick_ms) milliseconds<=milliseconds+1'b1;
            pending_keys<=(pending_keys & ~key_clear)|press;
            irq_pending<=(irq_pending & ~irq_clear)|sources|irq_force;
            if(cnn_valid_i) begin
                if(!irq_pending[2] || irq_clear[2]) cnn_mailbox<=cnn_probabilities_i;
                else overrun_count<=overrun_count+1'b1;
            end
            if(template_valid_i) begin
                if(!irq_pending[3] || irq_clear[3]) template_mailbox<={template_score_i,14'd0,template_class_i};
                else overrun_count<=overrun_count+1'b1;
            end
            if(job_done_i || !recognition_i || alert_i) job_authorized_o<=0;
            event_valid_o<=0;
            for(n=0;n<6;n=n+1) if(tick_ms && hold_ms[n]!=0) hold_ms[n]<=hold_ms[n]-1'b1;

            if(awvalid && awready) begin awheld<=1;awaddr_r<=awaddr;end
            if(wvalid && wready) begin wheld<=1;wdata_r<=wdata;wstrb_r<=wstrb;end
            if(bvalid && bready) bvalid<=0;
            if(rvalid && rready) rvalid<=0;
            if(write_accept) begin
                awheld<=0;wheld<=0;bvalid<=1;
                if(word_write) case(offset)
                    8'h0c: begin
                        for(n=0;n<6;n=n+1) if(wdata_r[n]) hold_ms[n]<=40;
                        command_count_o<=command_count_o+1'b1;
                    end
                    8'h14:firmware_signature_o<=wdata_r;
                    8'h24:irq_count_o<=irq_count_o+1'b1;
                    8'h28:irq_mask<=wdata_r[5:0];
                    8'h34:if(boot_ready_i && recognition_i && !alert_i) job_authorized_o<=wdata_r[0];
                    8'h40:begin event_valid_o<=1;event_class_o<=wdata_r[3:0];end
                    8'h4c:template_slot_o<=wdata_r[3:0];
                    8'h50:template_threshold<=wdata_r[15:0];
                    8'h54:required_windows<=wdata_r;
                    8'h58:max_gap_ms<=wdata_r;
                    8'h5c:isa_selftest_o<=wdata_r;
                    8'h80,8'h84,8'h88,8'h8c,8'h90,8'h94:threshold[(offset-8'h80)>>2]<=wdata_r[15:0];
                endcase
            end
            if(arvalid && arready) begin
                rvalid<=1;rdata_r<=0;
                case(araddr[7:0])
                    8'h00:rdata_r<={26'd0,pending_keys};
                    8'h04:rdata_r<={25'd0,command_active,alert_i,recording_i,capture_busy_i,recognition_i,codec_ready_i,boot_ready_i};
                    8'h10:rdata_r<=command_count_o;
                    8'h14:rdata_r<=firmware_signature_o;
                    8'h20:rdata_r<={26'd0,irq_pending};
                    8'h28:rdata_r<={26'd0,irq_mask};
                    8'h30:rdata_r<=irq_count_o;
                    8'h34:rdata_r<={31'd0,job_authorized_o};
                    8'h38:rdata_r<=milliseconds;
                    8'h3c:rdata_r<=template_mailbox;
                    8'h44:rdata_r<={28'd0,capture_category_i};
                    8'h48:rdata_r<={17'd0,template_slot_mask_i};
                    8'h4c:rdata_r<={28'd0,template_slot_o};
                    8'h50:rdata_r<={16'd0,template_threshold};
                    8'h54:rdata_r<=required_windows;
                    8'h58:rdata_r<=max_gap_ms;
                    8'h5c:rdata_r<=isa_selftest_o;
                    8'h60,8'h64,8'h68,8'h6c,8'h70,8'h74:rdata_r<={16'd0,cnn_mailbox[((araddr[7:0]-8'h60)>>2)*16+:16]};
                    8'h78:rdata_r<=overrun_count;
                    8'h80,8'h84,8'h88,8'h8c,8'h90,8'h94:rdata_r<={16'd0,threshold[(araddr[7:0]-8'h80)>>2]};
                endcase
            end
        end
    end

    // CPU5 has a native synchronous instruction request/response port.
    wire imem_req_valid,imem_req_ready,imem_rsp_valid,imem_rsp_ready,imem_rsp_error;
    wire [31:0] imem_req_addr,imem_rsp_rdata;
    wire imem_fault,dmem_fault;
    soc_instr_mem #(.WORDS(8192),.INIT_FILE(FIRMWARE_FILE)) u_imem(
        .clk(clk),.rst_n(rst_n),.req_valid(imem_req_valid),.req_ready(imem_req_ready),
        .req_addr(imem_req_addr),.rsp_valid(imem_rsp_valid),.rsp_ready(imem_rsp_ready),
        .rsp_rdata(imem_rsp_rdata),.rsp_error(imem_rsp_error));

    wire [31:0] m_axi_awaddr,m_axi_wdata,m_axi_araddr,m_axi_rdata;
    wire [3:0] m_axi_wstrb;
    wire [2:0] m_axi_awprot,m_axi_arprot;
    wire m_axi_awvalid,m_axi_awready,m_axi_wvalid,m_axi_wready;
    wire m_axi_bvalid,m_axi_bready,m_axi_arvalid,m_axi_arready,m_axi_rvalid,m_axi_rready;
    wire [1:0] m_axi_bresp,m_axi_rresp;
    assign m_axi_bresp=2'b00;
    assign m_axi_rresp=2'b00;
    assign m_axi_awready=awready;
    assign m_axi_wready=wready;
    assign m_axi_bvalid=bvalid;
    assign m_axi_arready=arready;
    assign m_axi_rvalid=rvalid;
    assign m_axi_rdata=rdata;
    assign awaddr=m_axi_awaddr;
    assign awprot=m_axi_awprot;
    assign awvalid=m_axi_awvalid;
    assign wdata=m_axi_wdata;
    assign wstrb=m_axi_wstrb;
    assign wvalid=m_axi_wvalid;
    assign bready=m_axi_bready;
    assign araddr=m_axi_araddr;
    assign arprot=m_axi_arprot;
    assign arvalid=m_axi_arvalid;
    assign rready=m_axi_rready;

    cpu5_d0_axi_lite_top #(
        .PROGRAM_FILE(FIRMWARE_FILE),.DATA_FILE(DATA_FILE),
        .IMEM_WORDS(8192),.DMEM_WORDS(4096),.DMEM_BASE_ADDR(32'h00010000),
        .EXTERNAL_DMEM(1),.EXTERNAL_IMEM(1),.ENABLE_TRAPS(1),.ENABLE_EXTERNAL_IRQ(1),
        .ENABLE_TIMER_IRQ(0),.ENABLE_SOFTWARE_IRQ(0),.ENABLE_M(1),
        .SKELETON_ONLY(0),.ENABLE_FORWARDING(1),.ENABLE_CONTROL_FLOW(1),.ENABLE_RAM(1),
        .ENABLE_SYNC_TRAPS(1),.ENABLE_CSR(1),.ENABLE_RV32M(1),.ENABLE_MMIO(1),.ENABLE_FENCE(1),
        .ENABLE_TIMER_DEVICE(0),.ENABLE_SOFTWARE_DEVICE(0),
        .ENABLE_ICACHE(1),.ICACHE_SETS(64),.ICACHE_LINE_WORDS(4),
        .ENABLE_DCACHE(1),.DCACHE_SETS(64),.DCACHE_LINE_WORDS(4),
        .ENABLE_D0_BRAM(1),.ENABLE_BRANCH_PRED(1),.BTB_ENTRIES(64),
        .BRANCH_RESOLVE_IN_ID(0),.UART_CLOCK_HZ(CLOCK_HZ),.UART_BAUD(115200),
        .UART_RX_FIFO_DEPTH(16),.SIM_CONSOLE_ECHO(0),.TRAP_VECTOR(32'h00000100)
    ) cpu5(
        .clk(clk),.rst_n(rst_n),.uart_rx(1'b1),.gpio_in(8'd0),.uart_tx(),.gpio_out(),.gpio_oe(),
        .pc_x(),.instr_x(),.valid_x(),.wb_pc(),.wb_rd(),.wb_data(),.wb_we(),.retire_valid(),
        .cycle_count(),.instret_count(),.dmem_fault(dmem_fault),
        .imem_req_valid(imem_req_valid),.imem_req_ready(imem_req_ready),.imem_req_addr(imem_req_addr),
        .imem_rsp_valid(imem_rsp_valid),.imem_rsp_ready(imem_rsp_ready),
        .imem_rsp_rdata(imem_rsp_rdata),.imem_rsp_error(imem_rsp_error),
        .imem_fault(imem_fault),.imem_fault_pc(),.trap_valid(),.trap_pc(),.trap_cause(),.trap_tval(),
        .bp_lookup_count(),.bp_hit_count(),.bp_taken_count(),.bp_resolved_count(),.bp_mispredict_count(),
        .bp_direction_error_count(),.bp_target_error_count(),.irq_external(interrupt_request),
        .irq_software(1'b0),.irq_timer(1'b0),.perf_cycle_events(),
        .icache_access_count(),.icache_hit_count(),.icache_miss_count(),.icache_refill_word_count(),.icache_error_count(),
        .dcache_access_count(),.dcache_hit_count(),.dcache_miss_count(),.dcache_refill_word_count(),
        .dcache_error_count(),.dcache_write_count(),.dcache_bypass_count(),
        .m_axi_awaddr(m_axi_awaddr),.m_axi_awprot(m_axi_awprot),.m_axi_awvalid(m_axi_awvalid),.m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata),.m_axi_wstrb(m_axi_wstrb),.m_axi_wvalid(m_axi_wvalid),.m_axi_wready(m_axi_wready),
        .m_axi_bresp(m_axi_bresp),.m_axi_bvalid(m_axi_bvalid),.m_axi_bready(m_axi_bready),
        .m_axi_araddr(m_axi_araddr),.m_axi_arprot(m_axi_arprot),.m_axi_arvalid(m_axi_arvalid),.m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata),.m_axi_rresp(m_axi_rresp),.m_axi_rvalid(m_axi_rvalid),.m_axi_rready(m_axi_rready));
endmodule
