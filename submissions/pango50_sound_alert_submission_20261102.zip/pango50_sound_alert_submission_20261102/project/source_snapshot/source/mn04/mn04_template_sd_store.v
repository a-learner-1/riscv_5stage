`timescale 1ns/1ps
// Raw-sector persistence for the six locally enrolled 128x100 int8 maps.
// Sector 0 is a compact versioned header; sectors 1..150 contain maps 0..5,
// 25 sectors per map.  A map becomes valid only after its payload CRC is
// written and the header sector commits the new CRC/mask.
module mn04_template_sd_store #(
    parameter integer CLK_HZ = 100_000_000,
    parameter integer BASE_LBA = 1,
    parameter integer MAP_BYTES = 12800,
    parameter integer BLOCK_BYTES = 512,
    parameter integer MAP_COUNT = 6,
    parameter integer ASYNC_TEMPLATE_READ = 0,
    parameter [26:0] WAIT_LIMIT = 27'd100_000_000
)(
    input wire clk,
    input wire rst_n,
    input wire boot_start_i,
    input wire card_detect_n_i, // MES50HP detect is low when a card is seated
    input wire enrollment_commit_i,
    input wire [$clog2(MAP_COUNT)-1:0] enrollment_map_i,
    output reg [MAP_COUNT-1:0] valid_mask_o,
    output reg boot_done_o,
    output wire busy_o,
    output reg template_rd_en_o,
    output reg [17:0] template_rd_addr_o,
    input wire signed [7:0] template_rd_data_i,
    input wire template_rd_valid_i,
    output reg template_load_we_o,
    output reg [17:0] template_load_addr_o,
    output reg signed [7:0] template_load_data_o,
    output wire sd_clk_o,
    output wire sd_cs_n_o,
    output wire sd_mosi_o,
    input wire sd_miso_i
);
    localparam integer BLOCKS_PER_MAP = MAP_BYTES / BLOCK_BYTES;
    localparam integer HEADER_PAYLOAD_BYTES = 8 + 4*MAP_COUNT;
    localparam [7:0] HEADER_MAGIC_LAST = MAP_COUNT==6 ? 8'h31 : 8'h32;
    localparam [7:0] HEADER_VERSION = MAP_COUNT==6 ? 8'd1 : 8'd2;
    wire [15:0] valid_mask_extended=valid_mask_o;
    localparam [4:0]
        ST_WAIT_BOOT=0, ST_INIT_WAIT=1, ST_HEADER_START=2, ST_HEADER_RX=3,
        ST_HEADER_CHECK=4, ST_MAP_PICK=5, ST_MAP_START=6, ST_MAP_RX=7,
        ST_MAP_CHECK=8, ST_READY=9, ST_WRITE_MAP_START=10,
        ST_WRITE_MAP_DATA=11, ST_WRITE_MAP_WAIT=12, ST_HEADER_PREP=13,
        ST_WRITE_HEADER_START=14, ST_WRITE_HEADER_DATA=15,
        ST_WRITE_HEADER_WAIT=16, ST_OFFLINE=17;

    reg [4:0] state_r;
    // Give up on a card that never answers instead of stalling the boot chain.
    reg [26:0] wait_r;
    reg [4:0]  prev_state_r;
    reg sd_init_pulse_r, sd_start_pulse_r;
    reg sd_write_r;
    reg [31:0] sd_lba_r;
    reg [7:0] sd_wdata_r;
    reg sd_wvalid_r;
    wire [7:0] sd_rdata;
    wire sd_rvalid,sd_wready,sd_busy,sd_done,sd_error,sd_ready;
    reg boot_seen_r, card_ok_r;

    reg [9:0] header_rx_count_r, header_tx_count_r;
    reg [7:0] header_valid_mask_r;
    reg [31:0] header_crc_work_r,header_crc_saved_r,header_crc_final_r;
    reg [31:0] map_crc_r [0:MAP_COUNT-1];
    reg [31:0] map_crc_work_r;
    reg [MAP_COUNT-1:0] candidate_mask_r;
    reg [$clog2(MAP_COUNT)-1:0] boot_map_r,write_map_r;
    reg [5:0] block_r;
    reg [8:0] block_byte_r;
    reg [13:0] map_byte_r;
    reg [1:0] prefetch_stage_r;
    reg data_valid_r;
    reg [9:0] header_crc_index_r;
    integer i;

    function [31:0] crc32_byte;
        input [31:0] crc_in;
        input [7:0] data_in;
        integer b;
        reg [31:0] c;
        begin
            c = crc_in ^ {24'd0,data_in};
            for (b=0;b<8;b=b+1)
                c = c[0] ? ((c >> 1) ^ 32'hedb88320) : (c >> 1);
            crc32_byte = c;
        end
    endfunction

    function [7:0] header_payload_byte;
        input [9:0] byte_index;
        reg [$clog2(MAP_COUNT)-1:0] map_index;
        reg [1:0] byte_lane;
        begin
            case (byte_index)
                0: header_payload_byte=8'h4d; // M
                1: header_payload_byte=8'h4e; // N
                2: header_payload_byte=8'h54; // T
                3: header_payload_byte=HEADER_MAGIC_LAST;
                4: header_payload_byte=HEADER_VERSION;
                5: header_payload_byte=valid_mask_extended[7:0];
                6: header_payload_byte=MAP_COUNT;
                7: header_payload_byte=valid_mask_extended[15:8];
                default: begin
                    if (byte_index >= 8 && byte_index < HEADER_PAYLOAD_BYTES) begin
                        map_index=(byte_index-8)>>2;
                        byte_lane=(byte_index-8)&3;
                        header_payload_byte=(map_crc_r[map_index] >> (byte_lane*8));
                    end else header_payload_byte=8'hff;
                end
            endcase
        end
    endfunction

    function [7:0] header_write_byte;
        input [9:0] byte_index;
        reg [1:0] byte_lane;
        begin
            if (byte_index < HEADER_PAYLOAD_BYTES)
                header_write_byte=header_payload_byte(byte_index);
            else if (byte_index >= HEADER_PAYLOAD_BYTES && byte_index < HEADER_PAYLOAD_BYTES+4) begin
                byte_lane=byte_index-HEADER_PAYLOAD_BYTES;
                header_write_byte=header_crc_final_r >> (byte_lane*8);
            end else header_write_byte=8'hff;
        end
    endfunction

    wire [7:0] header_crc_input_byte = header_payload_byte(header_crc_index_r);
    wire [31:0] header_crc_next = crc32_byte(header_crc_work_r,header_crc_input_byte);
    wire [31:0] map_write_lba = BASE_LBA + write_map_r*BLOCKS_PER_MAP + block_r;
    wire [31:0] map_read_lba  = BASE_LBA + boot_map_r*BLOCKS_PER_MAP + block_r;

    assign busy_o = (state_r != ST_WAIT_BOOT) && (state_r != ST_READY) &&
                    (state_r != ST_OFFLINE);

    sd_card_spi #(.CLK_HZ(CLK_HZ)) u_sd_card (
        .clk(clk),.rst_n(rst_n),.init_i(sd_init_pulse_r),
        .start_i(sd_start_pulse_r),.write_i(sd_write_r),.lba_i(sd_lba_r),
        .wdata_i(sd_wdata_r),.wvalid_i(sd_wvalid_r),.rdata_o(sd_rdata),
        .rvalid_o(sd_rvalid),.wready_o(sd_wready),.busy_o(sd_busy),
        .done_o(sd_done),.error_o(sd_error),.ready_o(sd_ready),
        .sd_clk_o(sd_clk_o),.sd_cs_n_o(sd_cs_n_o),.sd_mosi_o(sd_mosi_o),
        .sd_miso_i(sd_miso_i),.card_present_i(card_ok_r));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r<=ST_WAIT_BOOT;
            sd_init_pulse_r<=0; sd_start_pulse_r<=0; sd_write_r<=0;
            sd_lba_r<=0; sd_wdata_r<=8'hff; sd_wvalid_r<=0;
            boot_seen_r<=0; card_ok_r<=0; boot_done_o<=0;
            wait_r<=0;prev_state_r<=ST_WAIT_BOOT;
            valid_mask_o<=0; candidate_mask_r<=0;
            header_rx_count_r<=0; header_tx_count_r<=0;
            header_crc_work_r<=32'hffffffff; header_crc_saved_r<=0;
            header_crc_final_r<=0; header_crc_index_r<=0;
            boot_map_r<=0; write_map_r<=0; block_r<=0; block_byte_r<=0;
            map_byte_r<=0; map_crc_work_r<=32'hffffffff;
            prefetch_stage_r<=0; data_valid_r<=0;
            template_rd_en_o<=0; template_rd_addr_o<=0;
            template_load_we_o<=0; template_load_addr_o<=0;
            template_load_data_o<=0;
            for (i=0;i<MAP_COUNT;i=i+1) map_crc_r[i]<=0;
        end else begin
            sd_init_pulse_r<=0;
            sd_start_pulse_r<=0;
            template_rd_en_o<=0;
            template_load_we_o<=0;

            case (state_r)
            ST_WAIT_BOOT: begin
                if (boot_start_i && !boot_seen_r) begin
                    boot_seen_r<=1;
                    card_ok_r<=!card_detect_n_i;
                    if (card_detect_n_i) begin
                        // A missing card never prevents local/template or CNN use.
                        boot_done_o<=1;
                        state_r<=ST_OFFLINE;
                    end else begin
                        sd_init_pulse_r<=1;
                        state_r<=ST_INIT_WAIT;
                    end
                end
            end
            ST_INIT_WAIT: if (sd_done) begin
                if (sd_error || !sd_ready) begin
                    card_ok_r<=0; boot_done_o<=1; state_r<=ST_OFFLINE;
                end else begin
                    header_rx_count_r<=0;
                    header_crc_work_r<=32'hffffffff;
                    header_crc_saved_r<=0;
                    sd_lba_r<=0; sd_write_r<=0; sd_start_pulse_r<=1;
                    state_r<=ST_HEADER_RX;
                end
            end
            ST_HEADER_RX: begin
                if (sd_rvalid) begin
                    if (header_rx_count_r < HEADER_PAYLOAD_BYTES)
                        header_crc_work_r<=crc32_byte(header_crc_work_r,sd_rdata);
                    if (header_rx_count_r == 5)
                        candidate_mask_r<=sd_rdata;
                    if (header_rx_count_r == 7)
                        candidate_mask_r<=candidate_mask_r | ({8'd0,sd_rdata}<<8);
                    if (header_rx_count_r >= 8 && header_rx_count_r < HEADER_PAYLOAD_BYTES) begin
                        map_crc_r[(header_rx_count_r-8)>>2] <=
                            (map_crc_r[(header_rx_count_r-8)>>2] &
                             ~(32'h000000ff << (((header_rx_count_r-8)&3)*8))) |
                            ({24'd0,sd_rdata} << (((header_rx_count_r-8)&3)*8));
                    end
                    if (header_rx_count_r >= HEADER_PAYLOAD_BYTES && header_rx_count_r < HEADER_PAYLOAD_BYTES+4)
                        header_crc_saved_r <=
                            (header_crc_saved_r &
                             ~(32'h000000ff << ((header_rx_count_r-HEADER_PAYLOAD_BYTES)*8))) |
                            ({24'd0,sd_rdata} << ((header_rx_count_r-HEADER_PAYLOAD_BYTES)*8));
                    if (header_rx_count_r < 512)
                        header_rx_count_r<=header_rx_count_r+1'b1;
                end
                if (sd_done) state_r<=ST_HEADER_CHECK;
            end
            ST_HEADER_CHECK: begin
                if (!sd_error && header_crc_saved_r == (header_crc_work_r ^ 32'hffffffff) &&
                    header_valid_mask_r == 8'h00) begin
                    // Header bytes 0..4 are checked separately below via the
                    // magic/version latch; keep only well-formed maps live.
                    valid_mask_o<=candidate_mask_r;
                    boot_map_r<=0;
                    state_r<=ST_MAP_PICK;
                end else begin
                    valid_mask_o<=0;
                    boot_done_o<=1;
                    state_r<=ST_READY;
                end
            end
            ST_MAP_PICK: begin
                if (boot_map_r >= MAP_COUNT) begin
                    boot_done_o<=1;
                    state_r<=ST_READY;
                end else if (candidate_mask_r[boot_map_r]) begin
                    block_r<=0; map_byte_r<=0; map_crc_work_r<=32'hffffffff;
                    // block_r is reset by this same edge. Do not use the
                    // previous map's final block (24) to address block zero.
                    sd_lba_r<=BASE_LBA+boot_map_r*BLOCKS_PER_MAP;
                    sd_write_r<=0; sd_start_pulse_r<=1;
                    state_r<=ST_MAP_RX;
                end else boot_map_r<=boot_map_r+1'b1;
            end
            ST_MAP_RX: begin
                if (sd_rvalid && map_byte_r < MAP_BYTES) begin
                    template_load_we_o<=1;
                    template_load_addr_o<=boot_map_r*MAP_BYTES+map_byte_r;
                    template_load_data_o<=sd_rdata;
                    map_crc_work_r<=crc32_byte(map_crc_work_r,sd_rdata);
                    map_byte_r<=map_byte_r+1'b1;
                end
                if (sd_done) begin
                    if (sd_error) begin
                        valid_mask_o[boot_map_r]<=0;
                        boot_map_r<=boot_map_r+1'b1;
                        state_r<=ST_MAP_PICK;
                    end else if (block_r == BLOCKS_PER_MAP-1) begin
                        state_r<=ST_MAP_CHECK;
                    end else begin
                        block_r<=block_r+1'b1;
                        sd_lba_r<=BASE_LBA+boot_map_r*BLOCKS_PER_MAP+block_r+1'b1;
                        sd_write_r<=0; sd_start_pulse_r<=1;
                    end
                end
            end
            ST_MAP_CHECK: begin
                if ((map_crc_work_r ^ 32'hffffffff) == map_crc_r[boot_map_r])
                    valid_mask_o[boot_map_r]<=1;
                else valid_mask_o[boot_map_r]<=0;
                boot_map_r<=boot_map_r+1'b1;
                state_r<=ST_MAP_PICK;
            end
            ST_READY: begin
                if (enrollment_commit_i && enrollment_map_i < MAP_COUNT && card_ok_r) begin
                    write_map_r<=enrollment_map_i;
                    block_r<=0; block_byte_r<=0; map_byte_r<=0;
                    map_crc_work_r<=32'hffffffff;
                    prefetch_stage_r<=0; data_valid_r<=0;
                    state_r<=ST_WRITE_MAP_START;
                end
            end
            ST_WRITE_MAP_START: begin
                sd_lba_r<=map_write_lba; sd_write_r<=1; sd_start_pulse_r<=1;
                block_byte_r<=0; data_valid_r<=0; prefetch_stage_r<=0;
                state_r<=ST_WRITE_MAP_DATA;
            end
            ST_WRITE_MAP_DATA: begin
                // CMD24 may fail before the card ever requests payload bytes
                // (e.g. write protection or removal). Waiting only in the
                // post-payload state would strand this state with wready=0.
                if (sd_done && sd_error) begin
                    sd_wvalid_r<=0; data_valid_r<=0; prefetch_stage_r<=0;
                    valid_mask_o[write_map_r]<=0;
                    card_ok_r<=0; boot_done_o<=1;
                    state_r<=ST_OFFLINE;
                end else begin
                // Template RAM is synchronously read through the matcher's
                // existing port.  Two wait phases align its registered data
                // with the byte-stream handshake without a second RAM copy.
                if (!data_valid_r && prefetch_stage_r==0 && sd_wready) begin
                    template_rd_en_o<=1;
                    template_rd_addr_o<=write_map_r*MAP_BYTES+map_byte_r;
                    prefetch_stage_r<=1;
                end else if (!data_valid_r && prefetch_stage_r==1 && ASYNC_TEMPLATE_READ && template_rd_valid_i) begin
                    sd_wdata_r<=template_rd_data_i;
                    sd_wvalid_r<=1;data_valid_r<=1;prefetch_stage_r<=0;
                end else if (!data_valid_r && prefetch_stage_r==1 && !ASYNC_TEMPLATE_READ) begin
                    prefetch_stage_r<=2;
                end else if (!data_valid_r && prefetch_stage_r==2) begin
                    sd_wdata_r<=template_rd_data_i;
                    sd_wvalid_r<=1;
                    data_valid_r<=1;
                    prefetch_stage_r<=0;
                end
                if (data_valid_r && sd_wready) begin
                    sd_wvalid_r<=0;
                    data_valid_r<=0;
                    map_crc_work_r<=crc32_byte(map_crc_work_r,sd_wdata_r);
                    map_byte_r<=map_byte_r+1'b1;
                    if (block_byte_r == BLOCK_BYTES-1) begin
                        block_byte_r<=0;
                        state_r<=ST_WRITE_MAP_WAIT;
                    end else block_byte_r<=block_byte_r+1'b1;
                end
                end
            end
            ST_WRITE_MAP_WAIT: if (sd_done) begin
                if (sd_error) begin
                    boot_done_o<=1;
                    state_r<=ST_OFFLINE;
                end else if (block_r == BLOCKS_PER_MAP-1) begin
                    map_crc_r[write_map_r]<=map_crc_work_r ^ 32'hffffffff;
                    valid_mask_o[write_map_r]<=1;
                    header_crc_index_r<=0;
                    header_crc_work_r<=32'hffffffff;
                    state_r<=ST_HEADER_PREP;
                end else begin
                    block_r<=block_r+1'b1;
                    state_r<=ST_WRITE_MAP_START;
                end
            end
            ST_HEADER_PREP: begin
                header_crc_work_r<=header_crc_next;
                if (header_crc_index_r == HEADER_PAYLOAD_BYTES-1) begin
                    header_crc_final_r<=header_crc_next ^ 32'hffffffff;
                    state_r<=ST_WRITE_HEADER_START;
                end else header_crc_index_r<=header_crc_index_r+1'b1;
            end
            ST_WRITE_HEADER_START: begin
                header_tx_count_r<=0;
                sd_lba_r<=0; sd_write_r<=1; sd_start_pulse_r<=1;
                sd_wvalid_r<=0; data_valid_r<=0;
                state_r<=ST_WRITE_HEADER_DATA;
            end
            ST_WRITE_HEADER_DATA: begin
                if (sd_done && sd_error) begin
                    sd_wvalid_r<=0; data_valid_r<=0;
                    valid_mask_o[write_map_r]<=0;
                    card_ok_r<=0; boot_done_o<=1;
                    state_r<=ST_OFFLINE;
                end else begin
                if (!data_valid_r && sd_wready) begin
                    sd_wdata_r<=header_write_byte(header_tx_count_r);
                    sd_wvalid_r<=1;
                    data_valid_r<=1;
                end
                if (data_valid_r && sd_wready) begin
                    sd_wvalid_r<=0;
                    data_valid_r<=0;
                    if (header_tx_count_r == 511) begin
                        state_r<=ST_WRITE_HEADER_WAIT;
                    end else header_tx_count_r<=header_tx_count_r+1'b1;
                end
                end
            end
            ST_WRITE_HEADER_WAIT: if (sd_done) begin
                if (sd_error) state_r<=ST_OFFLINE;
                else state_r<=ST_READY;
            end
            ST_OFFLINE: begin
                // Deliberately leave on-chip templates usable without a card.
                if (!card_detect_n_i && !boot_done_o) begin
                    card_ok_r<=1;
                    sd_init_pulse_r<=1;
                    state_r<=ST_INIT_WAIT;
                end
            end
            default: state_r<=ST_WAIT_BOOT;
            endcase
            // Idle time is not transaction time. In particular, a recording
            // can leave ST_READY idle for seconds before committing a map.
            // Never carry that saturated idle counter into the new write.
            if (state_r == ST_WAIT_BOOT || state_r == ST_READY ||
                state_r == ST_OFFLINE || state_r != prev_state_r) wait_r <= 27'd0;
            else if (wait_r != WAIT_LIMIT) wait_r <= wait_r + 1'b1;
            prev_state_r <= state_r;
            if (state_r != ST_WAIT_BOOT && state_r != ST_READY &&
                state_r != ST_OFFLINE && state_r == prev_state_r && wait_r >= WAIT_LIMIT) begin
                card_ok_r <= 1'b0;
                boot_done_o <= 1'b1;
                state_r <= ST_OFFLINE;
            end
        end
    end

    // Latch the header signature/version while parsing its first sector.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) header_valid_mask_r<=8'hff;
        else if (state_r==ST_HEADER_RX && sd_rvalid) begin
            if ((header_rx_count_r==0 && sd_rdata!=8'h4d) ||
                (header_rx_count_r==1 && sd_rdata!=8'h4e) ||
                (header_rx_count_r==2 && sd_rdata!=8'h54) ||
                (header_rx_count_r==3 && sd_rdata!=HEADER_MAGIC_LAST) ||
                (header_rx_count_r==4 && sd_rdata!=HEADER_VERSION) ||
                (header_rx_count_r==6 && sd_rdata!=MAP_COUNT))
                header_valid_mask_r<=8'h01;
            else if (header_rx_count_r==0) header_valid_mask_r<=8'h00;
        end
    end
endmodule
