`timescale 1ns/1ps
// MN04 DDR weight feeder.
//
// Streams a contiguous byte range out of DDR3 (256-bit, single-beat reads) with
// the SAME ready/valid byte handshake as mn04_qspi_block_reader, so it drops in
// as the weight block cache's source without touching mn04_weight_block_cache.
// byte 0 of beat N is rdata[7:0] (little-endian, contiguous packed image), i.e.
// the exact byte order the QSPI path delivers.
//
// Read side: one outstanding single-beat read at a time (arlen=0), re-filling a
// small beat FIFO (FIFO_DEPTH beats = 32*FIFO_DEPTH bytes) so DDR read latency
// and arbiter grants never stall the 1-byte/cycle consumer.  The DDR port is the
// same simplified 256-bit user port as ddr3_host_top / senior_dbl_ddr3_tile and
// drops straight onto senior_dbl_ddr3_user_arbiter as an extra master.
//
// addr_i may start at any byte (MN04 layer weights are not always 32-byte
// aligned). Read from the containing DDR beat, skip its leading bytes, and
// fetch enough beats to cover count_i bytes. The final partial beat is safe
// because done_o is derived from bytes_out, not beats issued.
module mn04_ddr_weight_feeder #(
    parameter integer FIFO_DEPTH     = 4,       // beats of 256-bit buffering
    parameter [27:0] WEIGHT_BASE_WORD = 28'd0   // DDR word-address base of image
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        ddr_init_done_i,
    // ---- byte-stream source (mirrors mn04_qspi_block_reader) ----
    input  wire        start_i,
    input  wire [23:0] addr_i,     // image byte offset (arbitrary alignment)
    input  wire [15:0] count_i,    // bytes to fetch
    output reg         busy_o,
    output reg         done_o,
    output wire [7:0]  byte_o,
    output wire        byte_valid_o,
    input  wire        byte_ready_i,
    // ---- DDR user AXI read master (single-beat, 256-bit, full AXI4) ----
    output reg  [27:0] araddr_o,
    output reg         arvalid_o,
    input  wire        arready_i,
    input  wire [255:0] rdata_i,
    input  wire [1:0]  rresp_i,
    input  wire        rvalid_i,
    output wire        rready_o
);
    localparam IR_IDLE=0, IR_AR=1, IR_RW=2;
    localparam FAW = (FIFO_DEPTH <= 2) ? 1 : $clog2(FIFO_DEPTH);

    reg [1:0]   ir_state;
    reg [15:0]  beats_total_r;   // ceil(count_i/32)
    reg [15:0]  beats_issued_r;  // beats whose arvalid has been accepted
    reg [15:0]  bytes_out_r;     // bytes streamed to the consumer (done_o)
    reg [23:0]  addr_r;          // captured addr_i (byte offset)
    reg [15:0]  count_r;         // captured count_i

    // ---- beat FIFO (256-bit words) ----
    reg [255:0]  fifo_mem [0:FIFO_DEPTH-1];
    reg [FAW-1:0] fifo_wp, fifo_rp;
    reg [FAW:0]   fifo_cnt;

    // ---- byte position within the head beat (0..31) ----
    reg [4:0] byte_pos_r;

    assign rready_o = 1'b1;   // single-outstanding read: always accept a beat

    wire fifo_full  = (fifo_cnt == FIFO_DEPTH[FAW:0]);
    wire fifo_empty = (fifo_cnt == 0);
    wire fifo_push  = (ir_state == IR_RW) && rvalid_i;               // beat arrived
    wire fifo_pop   = byte_valid_o && byte_ready_i && (byte_pos_r == 5'd31);

    // The consumer sees byte_valid high exactly while a beat is buffered.
    // A partial final beat can remain buffered after count_r bytes have been
    // delivered. Do not expose those stale bytes to the next cache load while
    // its one-cycle start pulse is crossing into this feeder.
    assign byte_valid_o = busy_o && !fifo_empty;
    assign byte_o       = fifo_mem[fifo_rp][byte_pos_r*8 +: 8];

    // Issue the next read when there is room and beats remain.
    wire want_issue = busy_o && ddr_init_done_i &&
                      (beats_issued_r < beats_total_r) &&
                      !fifo_full && (ir_state == IR_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy_o <= 1'b0; done_o <= 1'b0;
            ir_state <= IR_IDLE;
            beats_total_r <= 16'd0; beats_issued_r <= 16'd0;
            bytes_out_r <= 16'd0; addr_r <= 24'd0; count_r <= 16'd0;
            fifo_wp <= 0; fifo_rp <= 0; fifo_cnt <= 0;
            byte_pos_r <= 5'd0;
            araddr_o <= 28'd0; arvalid_o <= 1'b0;
        end else begin
            done_o <= 1'b0;

            // ---- byte streaming (drain the head beat) ----
            // The FIFO is emptied by the normal pop bookkeeping below; the done
            // branch must not force-reset the pointers (they are the same
            // signals the FIFO bookkeeping drives, and a final-beat rvalid can
            // coincide with the last-byte consume).
            if (byte_valid_o && byte_ready_i) begin
                if (bytes_out_r == (count_r - 1'b1)) begin
                    // last byte of this load just transferred
                    bytes_out_r <= 16'd0;
                    busy_o <= 1'b0;
                    done_o <= 1'b1;
                    byte_pos_r <= 5'd0;
                end else begin
                    bytes_out_r <= bytes_out_r + 1'b1;
                    if (byte_pos_r == 5'd31) byte_pos_r <= 5'd0;
                    else                      byte_pos_r <= byte_pos_r + 1'b1;
                end
            end

            // ---- read-issue state machine (independent of streaming) ----
            arvalid_o <= 1'b0;
            case (ir_state)
                IR_IDLE: begin
                    if (start_i && !busy_o) begin
                        addr_r <= addr_i;
                        count_r <= count_i;
                        beats_total_r <= ({1'b0,count_i} +
                                          {12'd0,addr_i[4:0]} + 17'd31) >> 5;
                        beats_issued_r <= 16'd0;
                        bytes_out_r <= 16'd0;
                        byte_pos_r <= addr_i[4:0];
                        fifo_wp <= 0; fifo_rp <= 0; fifo_cnt <= 0;
                        busy_o <= 1'b1;
                    end else if (want_issue) begin
                        araddr_o <= {WEIGHT_BASE_WORD[25:0], 2'b00} +
                                    {addr_r[23:5], 5'b000} +
                                    {beats_issued_r[12:0], 5'b000};
                        arvalid_o <= 1'b1;
                        ir_state <= IR_AR;
                    end
                end
                IR_AR: begin
                    // hold arvalid/araddr until the arbiter/host accepts
                    arvalid_o <= 1'b1;
                    if (arready_i) begin
                        beats_issued_r <= beats_issued_r + 1'b1;
                        ir_state <= IR_RW;
                    end
                end
                IR_RW: begin
                    if (rvalid_i) begin
                        fifo_mem[fifo_wp] <= rdata_i;
                        fifo_wp <= fifo_wp + 1'b1;
                        ir_state <= IR_IDLE;
                    end
                end
                default: ir_state <= IR_IDLE;
            endcase

            // ---- FIFO bookkeeping (single driver) ----
            if (fifo_push && fifo_pop)      fifo_cnt <= fifo_cnt;
            else if (fifo_push)             fifo_cnt <= fifo_cnt + 1'b1;
            else if (fifo_pop)              fifo_cnt <= fifo_cnt - 1'b1;
            if (fifo_pop)                   fifo_rp  <= fifo_rp + 1'b1;
        end
    end
endmodule
