`timescale 1ns/1ps
// One MN04 core, two activation contexts.  Inputs are one-cycle pulses after
// each x0 snapshot has been written to its own DDR arena.  Repeated pulses are
// coalesced.  The short job preempts the long job only between complete ops.
module mn04_dual_window_scheduler #(
    parameter N_OPS = 91,
    parameter SHORT_ONLY = 0,
    // A one-shot reminder may remain latched while a board capture/UART task
    // is still active. In that interval the caller keeps recognition_enable_i
    // asserted, so continue classifying new windows without clearing the
    // latched reminder. Once the caller drops enable, scheduling stops.
    parameter CONTINUE_WHILE_ALERT = 0
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire       short_ready_i,
    input  wire [1:0] short_mode_i,
    input  wire       long_ready_i,
    input  wire       recognition_enable_i,
    input  wire       alert_i,
    input  wire       confirmed_i,
    input  wire       core_busy_i,
    input  wire       core_done_i,
    output wire       core_start_o,
    output wire [8:0] core_start_op_o,
    output wire [8:0] core_end_op_o,
    output wire       core_short_window_o,
    // Stable through the in-flight operation; use for DDR arena translation.
    output wire       core_context_short_o,
    output wire [1:0] core_short_mode_o,
    output reg        short_result_valid_o,
    output reg        long_result_valid_o,
    output reg        alert_latched_o,
    output wire       short_snapshot_accept_o,
    output wire       long_snapshot_accept_o
);
    localparam IDLE = 1'b0, WAIT_OP = 1'b1;
    reg state_r;
    // An already launched op cannot be cancelled mid-operation. Drain it and
    // discard its completion whenever an alert/confirmation flushes jobs.
    reg draining_r;
    reg short_pending_r, long_pending_r;
    reg short_active_r, long_active_r;
    reg [8:0] short_op_r, long_op_r;
    reg running_short_r;
    reg [1:0] short_pending_mode_r, short_active_mode_r, running_short_mode_r;

    wire can_schedule = recognition_enable_i && state_r == IDLE &&
                        !core_busy_i && !core_done_i &&
                        (CONTINUE_WHILE_ALERT || !alert_latched_o) &&
                        !alert_i && !confirmed_i &&
                        !draining_r && !short_result_valid_o &&
                        !long_result_valid_o;
    wire choose_short = short_active_r || short_pending_r || short_ready_i;
    wire choose_long = !SHORT_ONLY && (long_active_r || long_pending_r || long_ready_i);
    assign core_start_o = can_schedule && (choose_short || choose_long);
    assign core_short_window_o = choose_short;
    assign core_context_short_o = (state_r == WAIT_OP) ? running_short_r : choose_short;
    assign core_short_mode_o = (state_r == WAIT_OP) ? running_short_mode_r :
                               short_active_r ? short_active_mode_r :
                               short_pending_r ? short_pending_mode_r : short_mode_i;
    assign core_start_op_o = choose_short ? short_op_r : long_op_r;
    assign core_end_op_o = core_start_op_o;  // one op = safe preemption point
    assign short_snapshot_accept_o = recognition_enable_i &&
                                     !short_active_r && !short_pending_r &&
                                     (CONTINUE_WHILE_ALERT || !alert_latched_o) &&
                                     !confirmed_i && !draining_r;
    assign long_snapshot_accept_o = !SHORT_ONLY && recognition_enable_i &&
                                    !long_active_r && !long_pending_r &&
                                    (CONTINUE_WHILE_ALERT || !alert_latched_o) &&
                                    !confirmed_i && !draining_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= IDLE;
            draining_r <= 0;
            short_pending_r <= 0; long_pending_r <= 0;
            short_active_r <= 0; long_active_r <= 0;
            short_op_r <= 0; long_op_r <= 0;
            running_short_r <= 0;
            short_pending_mode_r <= 0; short_active_mode_r <= 0;
            running_short_mode_r <= 0;
            short_result_valid_o <= 0; long_result_valid_o <= 0;
            alert_latched_o <= 0;
        end else begin
            short_result_valid_o <= 0;
            long_result_valid_o <= 0;
            if (confirmed_i) begin
                alert_latched_o <= 0;
                short_pending_r <= 0; long_pending_r <= 0;
                short_active_r <= 0; long_active_r <= 0;
                short_op_r <= 0; long_op_r <= 0;
                short_pending_mode_r <= 0; short_active_mode_r <= 0;
                if (state_r == WAIT_OP) begin
                    draining_r <= !core_done_i;
                    if (core_done_i) state_r <= IDLE;
                end
            end else if (alert_i) begin
                alert_latched_o <= 1;
                short_pending_r <= 0; long_pending_r <= 0;
                short_active_r <= 0; long_active_r <= 0;
                short_op_r <= 0; long_op_r <= 0;
                short_pending_mode_r <= 0; short_active_mode_r <= 0;
                if (state_r == WAIT_OP) begin
                    draining_r <= !core_done_i;
                    if (core_done_i) state_r <= IDLE;
                end
            end else if (draining_r) begin
                if (core_done_i) begin
                    state_r <= IDLE;
                    draining_r <= 0;
                end
            end else begin
                if (short_ready_i && short_snapshot_accept_o) begin
                    short_pending_r <= 1;
                    short_pending_mode_r <= short_mode_i;
                end
                if (long_ready_i && long_snapshot_accept_o) long_pending_r <= 1;
                if (state_r == IDLE) begin
                    if (core_start_o) begin
                        state_r <= WAIT_OP;
                        running_short_r <= choose_short;
                        if (choose_short) begin
                            short_active_r <= 1;
                            if (short_active_r) begin
                                running_short_mode_r <= short_active_mode_r;
                            end else if (short_pending_r) begin
                                short_active_mode_r <= short_pending_mode_r;
                                running_short_mode_r <= short_pending_mode_r;
                            end else begin
                                short_active_mode_r <= short_mode_i;
                                running_short_mode_r <= short_mode_i;
                            end
                            short_pending_r <= 0;
                        end else begin
                            long_active_r <= 1;
                            long_pending_r <= 0;
                        end
                    end
                end else if (core_done_i) begin
                    state_r <= IDLE;
                    if (running_short_r) begin
                        if (short_op_r == N_OPS-1) begin
                            short_op_r <= 0;
                            short_active_r <= 0;
                            short_result_valid_o <= 1;
                        end else short_op_r <= short_op_r + 1'b1;
                    end else begin
                        if (long_op_r == N_OPS-1) begin
                            long_op_r <= 0;
                            long_active_r <= 0;
                            long_result_valid_o <= 1;
                        end else long_op_r <= long_op_r + 1'b1;
                    end
                end
            end
        end
    end
endmodule
