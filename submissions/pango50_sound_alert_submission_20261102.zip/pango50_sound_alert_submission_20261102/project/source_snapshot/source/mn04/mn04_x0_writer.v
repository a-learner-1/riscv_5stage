`timescale 1ns/1ps
// mn04_x0_writer.v
// Frontend x0 -> activation DDR writer with frame-major -> mel-major transpose
// and a small elastic input FIFO.
//
// The frontend (frontend_log_quant) emits x0 frame-major with NO backpressure:
// a burst of 128 mel bins per frame, back-to-back.  The MN04 core consumes the
// op0 input as NHWC C=1, H=128 (mel), W=N_FRAMES (time), i.e.
// act_mem[mel*N_FRAMES + frame], and mn04_ddr_act_byte_writer drains one
// single-strobe 256-bit beat every 3 cycles.  This module (a) absorbs the
// frame burst in a FIFO (max ~86 bytes/frame; the frontend frame period is
// >1024 cycles while 128 bytes drain in ~384, so a 256-deep FIFO never fills),
// and (b) folds the transpose into the byte-address computation on the FIFO
// pop counter: pop n -> frame = n/128, mel = n%128,
// byte_addr = X0_BASE + mel*N_FRAMES + frame.  No transpose buffer is needed.
module mn04_x0_writer #(
    parameter [23:0] X0_BASE_BYTE = 24'h000000, // activation arena base (byte)
    parameter integer MEL_BINS  = 128,
    parameter integer N_FRAMES  = 1000,          // long window (10 s)
    parameter integer CONTINUOUS = 0,
    parameter integer MEL_AW    = 7,             // ceil(log2(MEL_BINS))
    parameter integer FRAME_AW  = 10,            // ceil(log2(N_FRAMES))
    parameter integer FIFO_DEPTH = 256,
    parameter integer FIFO_AW    = 8             // ceil(log2(FIFO_DEPTH))
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        ddr_init_done_i,
    input  wire        overflow_clear_i,
    input  wire        x0_valid_i,      // frame-major x0 byte valid (bursty)
    input  wire [7:0]  x0_data_i,
    input  wire [23:0] x0_base_byte_i,  // selected DDR ring bank base
    output wire        x0_ready_o,      // = !full (frontend may push)
    output reg         done_o,          // level: all MEL_BINS*N_FRAMES bytes popped
    output reg         frame_done_o,    // pulse after each frame's last DDR write
    output wire [FRAME_AW-1:0] next_frame_slot_o,
    output reg         overflow_o,
    // DDR write master (single-beat byte writes)
    output wire [27:0] ddr_awaddr_o,
    output wire        ddr_awvalid_o,
    input  wire        ddr_awready_i,
    output wire [255:0] ddr_wdata_o,
    output wire [31:0] ddr_wstrb_o,
    output wire        ddr_wvalid_o,
    output wire        ddr_wlast_o,
    input  wire        ddr_wready_i,
    input  wire [1:0]  ddr_bresp_i,
    input  wire        ddr_bvalid_i,
    output wire        ddr_bready_o,
    output wire        drained_o
);
    localparam integer TOTAL = MEL_BINS * N_FRAMES;   // 128000 (fits 17 bits)

    // ---- elastic FIFO (sync write, async read) ----
    reg [7:0] fifo [0:FIFO_DEPTH-1];
    reg [FIFO_AW-1:0] wptr_r, rptr_r;
    reg [FIFO_AW:0]   n_in_fifo;      // occupancy 0..FIFO_DEPTH
    wire full  = (n_in_fifo == FIFO_DEPTH[FIFO_AW:0]);
    wire empty = (n_in_fifo == 0);
    assign x0_ready_o = !full;

    wire push = x0_valid_i && !full;
    wire byte_ready;
    wire pop  = !empty && byte_ready;

    reg [16:0] pop_cnt;               // total bytes popped (= address index)
    reg frame_pending_r;
    assign next_frame_slot_o = pop_cnt >> MEL_AW;

    always @(posedge clk) begin
        if (push) fifo[wptr_r] <= x0_data_i;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wptr_r <= 0; rptr_r <= 0; n_in_fifo <= 0; pop_cnt <= 17'd0;
            done_o <= 1'b0;
            frame_done_o <= 1'b0;
            frame_pending_r <= 1'b0;
            overflow_o <= 1'b0;
        end else begin
            frame_done_o <= 1'b0;
            if (overflow_clear_i) overflow_o <= 1'b0;
            if (x0_valid_i && full) overflow_o <= 1'b1;
            if (frame_pending_r && drained_o) begin
                frame_done_o <= 1'b1;
                frame_pending_r <= 1'b0;
            end
            if (push) wptr_r <= wptr_r + 1'b1;
            if (pop)  rptr_r <= rptr_r + 1'b1;
            case ({push, pop})
                2'b10: n_in_fifo <= n_in_fifo + 1'b1;
                2'b01: n_in_fifo <= n_in_fifo - 1'b1;
                default: n_in_fifo <= n_in_fifo;   // 00 or 11 (net zero)
            endcase
            if (pop) begin
                if (pop_cnt[MEL_AW-1:0] == MEL_BINS - 1)
                    frame_pending_r <= 1'b1;
                if (pop_cnt == TOTAL - 1) begin
                    done_o <= 1'b1;
                    if (CONTINUOUS) pop_cnt <= 17'd0;
                end else pop_cnt <= pop_cnt + 1'b1;
            end
        end
    end

    // transpose address from the pop counter
    wire [FRAME_AW-1:0] frame = pop_cnt[FRAME_AW+MEL_AW-1 : MEL_AW];
    wire [MEL_AW-1:0]   mel   = pop_cnt[MEL_AW-1:0];
    wire [23:0] byte_addr = x0_base_byte_i + (mel * N_FRAMES) + frame;
    wire [7:0]  fifo_out  = fifo[rptr_r];

    mn04_ddr_act_byte_writer u_writer (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done_i),
        .byte_valid_i(pop), .byte_addr_i(byte_addr), .byte_data_i(fifo_out),
        .byte_ready_o(byte_ready),
        .ddr_awaddr_o(ddr_awaddr_o), .ddr_awvalid_o(ddr_awvalid_o),
        .ddr_awready_i(ddr_awready_i), .ddr_wdata_o(ddr_wdata_o),
        .ddr_wstrb_o(ddr_wstrb_o),
        .ddr_wvalid_o(ddr_wvalid_o), .ddr_wlast_o(ddr_wlast_o),
        .ddr_wready_i(ddr_wready_i),
        .ddr_bresp_i(ddr_bresp_i), .ddr_bvalid_i(ddr_bvalid_i),
        .ddr_bready_o(ddr_bready_o),
        .drained_o(drained_o)
    );
endmodule
