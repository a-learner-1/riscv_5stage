`timescale 1ns/1ps
// Behavioral DDR3 model for the 256-bit user port (SIMULATION ONLY).
//
// Backs a byte-addressable memory and models the simplified user port used by
// ddr3_host_top / senior_dbl_ddr3_tile: no WVALID/RREADY/B channel, writes are
// pulled beat-by-beat via WREADY, reads are pushed via RVALID (single-beat,
// arlen/awlen = 0).  Reads and writes are serialized to ONE outstanding
// transaction at a time, which faithfully matches senior_dbl_ddr3_user_arbiter
// (it locks the port until the response) and the feeder's one-outstanding read.
//
// Addresses are 32-bit WORD addresses: byte address = araddr << 2, and byte 0
// of a beat is the lowest byte (rdata[7:0]).
//
// RD_LATENCY = cycles from the arready accept to rvalid (>=0).  Writes commit
// one cycle after the awvalid accept.  arready drops low while a transaction
// is in flight, injecting the backpressure the feeder must tolerate.
module mn04_ddr_behav #(
    parameter integer MEM_BYTES  = 24'h100000,  // byte-addressable depth (1 MB)
    parameter integer RD_LATENCY = 4
)(
    input  wire        clk,
    input  wire        rst_n,
    // ---- write port ----
    input  wire [27:0] awaddr_i,
    input  wire [3:0]  awlen_i,
    input  wire        awvalid_i,
    output reg         awready_o,
    input  wire [255:0] wdata_i,
    input  wire [31:0]  wstrb_i,
    output reg          wready_o,
    // ---- read port ----
    input  wire [27:0] araddr_i,
    input  wire [3:0]  arlen_i,
    input  wire        arvalid_i,
    output reg         arready_o,
    output reg  [255:0] rdata_o,
    output reg          rlast_o,
    output reg          rvalid_o
);
    reg [7:0] mem [0:MEM_BYTES-1];
    integer i;
    initial for (i = 0; i < MEM_BYTES; i = i + 1) mem[i] = 8'd0;

    // ---- combinational 256-bit beat read (byte 0 = lowest address) ----
    reg [255:0] rdata_c;
    integer b;
    always @(*) begin
        rdata_c = 256'd0;
        for (b = 0; b < 32; b = b + 1)
            rdata_c[8*b +: 8] = mem[({araddr_i, 2'b00}) + b[31:0]];
    end

    // ---- single-outstanding transaction state ----
    reg         pending;        // a read or write is in flight
    reg         is_wr;
    reg [7:0]   lat_cnt;
    reg [255:0] pend_data;
    reg [31:0]  pend_strb;
    reg [27:0]  pend_addr;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pending <= 1'b0; is_wr <= 1'b0; lat_cnt <= 8'd0;
            pend_data <= 256'd0; pend_strb <= 32'd0; pend_addr <= 28'd0;
            arready_o <= 1'b0; awready_o <= 1'b0; wready_o <= 1'b0;
            rvalid_o <= 1'b0; rdata_o <= 256'd0; rlast_o <= 1'b0;
        end else begin
            arready_o <= !pending;
            awready_o <= !pending;
            wready_o  <= is_wr && pending;
            rvalid_o  <= 1'b0;

            if (!pending) begin
                // prioritize reads over writes (matches the tile's read-heavy use)
                if (arvalid_i) begin
                    pending   <= 1'b1;
                    is_wr     <= 1'b0;
                    pend_addr <= araddr_i;
                    pend_data <= rdata_c;
                    lat_cnt   <= RD_LATENCY[7:0];
                end else if (awvalid_i) begin
                    pending   <= 1'b1;
                    is_wr     <= 1'b1;
                    pend_addr <= awaddr_i;
                    pend_data <= wdata_i;
                    pend_strb <= wstrb_i;
                    lat_cnt   <= 8'd0;
                end
            end else begin
                if (is_wr) begin
                    // wready_o is high this cycle; commit the strobed bytes
                    for (b = 0; b < 32; b = b + 1)
                        if (pend_strb[b])
                            mem[({pend_addr, 2'b00}) + b[31:0]] <= pend_data[8*b +: 8];
                    pending <= 1'b0;
                end else begin
                    if (lat_cnt == 8'd0) begin
                        rvalid_o <= 1'b1;
                        rdata_o  <= pend_data;
                        rlast_o  <= 1'b1;
                        pending  <= 1'b0;
                    end else begin
                        lat_cnt <= lat_cnt - 8'd1;
                    end
                end
            end
        end
    end
endmodule
