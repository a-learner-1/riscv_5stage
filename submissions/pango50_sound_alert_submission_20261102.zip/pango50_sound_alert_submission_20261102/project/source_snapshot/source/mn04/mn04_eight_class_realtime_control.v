`timescale 1ns/1ps
// Eight-class controller for the MN04 CNN head. Class-specific windows are
// scheduled at 50/60/75-frame hops; each completed window carries eight logits.
module mn04_eight_class_realtime_control #(
    parameter SOFTMAX_LUT_FILE="softmax_exp_q24_eight_class.mem",
    parameter integer CONTINUE_WHILE_ALERT=1,
    parameter integer CLASS_WINDOW_MODE=0,
    parameter [15:0] BABY_THRESHOLD_Q16=16'd5470,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'd29986,
    parameter [15:0] SIREN_THRESHOLD_Q16=16'd61298,
    parameter [15:0] FIRE_TRUCK_THRESHOLD_Q16=16'd23360,
    parameter [15:0] AMBULANCE_THRESHOLD_Q16=16'd16262,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'd54522,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'd51738,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,
    input wire short_snapshot_ready_i,
    input wire [1:0] short_snapshot_mode_i,
    input wire core_busy_i,core_done_i,
    input wire core_logits_valid_i,
    input wire [63:0] core_logits_i,
    input wire window_quiet_i,
    input wire template_result_valid_i,
    input wire [1:0] template_result_class_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire work_key_n_i,confirm_key_n_i,uart_rx_i,
    input wire template_preview_i,
    input wire [3:0] template_preview_class_i,
    input wire external_task_busy_i,
    input wire set_time_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    output wire core_start_o,
    output wire [8:0] core_start_op_o,core_end_op_o,
    output wire core_short_window_o,core_context_short_o,
    output wire [1:0] core_class_window_mode_o,
    output wire short_snapshot_accept_o,
    output wire short_result_valid_o,
    output wire motor_o,recognition_enable_o,work_mode_o,
    output wire panel_ready_o,panel_busy_o,
    output wire tft_nrst_o,tft_backlight_o,
    output wire tft_sclk_o,tft_mosi_o,tft_dc_o,tft_cs_n_o
);
    wire [127:0] probs,backend_probs,backend_probs_comb;
    wire probs_valid,backend_probs_valid,softmax_busy,alert_accept,confirm_pulse;
    reg [127:0] backend_probs_r;
    reg backend_probs_valid_r;
    reg result_short_r;
    reg [1:0] result_mode_r;
    wire [1:0] scheduler_window_mode;
    wire scheduler_snapshot_accept;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) result_short_r<=1'b1;
        else if(core_logits_valid_i) result_short_r<=1'b1;
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) result_mode_r<=2'd0;
        else if(core_start_o && core_start_op_o==9'd0)
            result_mode_r<=scheduler_window_mode;
    end
    // Register the mode-masked softmax result before the display/alert path.
    // Besides aligning mode and data, this cuts the class-mode-to-alert timing
    // path while adding only one 50 MHz control cycle of decision latency.
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            backend_probs_r<=128'd0;
            backend_probs_valid_r<=1'b0;
        end else begin
            backend_probs_valid_r<=probs_valid;
            if(probs_valid) backend_probs_r<=backend_probs_comb;
        end
    end
    assign backend_probs=backend_probs_r;
    assign backend_probs_valid=backend_probs_valid_r;
    assign core_class_window_mode_o = CLASS_WINDOW_MODE ?
                                      scheduler_window_mode : 2'd0;
    assign short_snapshot_accept_o = scheduler_snapshot_accept &&
        !short_snapshot_ready_i && !core_busy_i && !softmax_busy &&
        !short_result_valid_o;
    generate if(CLASS_WINDOW_MODE) begin : g_class_window_filter
        v1_eight_class_window_filter u_filter(
            .probs_q16_i(probs),.window_mode_i(result_mode_r),
            .probs_q16_o(backend_probs_comb));
    end else begin : g_unfiltered_classes
        assign backend_probs_comb=probs;
    end endgenerate
    mn04_softmax_q16 #(.LUT_FILE(SOFTMAX_LUT_FILE),.N_CLASSES(8)) softmax(
        .clk(clk),.rst_n(rst_n),.logits_valid_i(core_logits_valid_i),
        .logits_i(core_logits_i),.probs_valid_o(probs_valid),
        .probs_q16_o(probs),.busy_o(softmax_busy));
    mn04_dual_window_scheduler #(
        .SHORT_ONLY(1),.CONTINUE_WHILE_ALERT(CONTINUE_WHILE_ALERT)) scheduler(
        .clk(clk),.rst_n(rst_n),.short_ready_i(short_snapshot_ready_i),
        .short_mode_i(short_snapshot_mode_i),
        .long_ready_i(1'b0),.recognition_enable_i(recognition_enable_o),
        .alert_i(alert_accept),.confirmed_i(confirm_pulse),
        .core_busy_i(core_busy_i),.core_done_i(core_done_i),
        .core_start_o(core_start_o),.core_start_op_o(core_start_op_o),
        .core_end_op_o(core_end_op_o),.core_short_window_o(core_short_window_o),
        .core_context_short_o(core_context_short_o),
        .core_short_mode_o(scheduler_window_mode),
        .short_result_valid_o(short_result_valid_o),.long_result_valid_o(),
        .alert_latched_o(),.short_snapshot_accept_o(scheduler_snapshot_accept),
        .long_snapshot_accept_o());
    v1_board_postcnn_top #(.EIGHT_CLASS_MODE(1),.ONE_SHOT_MODE(1),
        .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
        .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
        .SIREN_THRESHOLD_Q16(SIREN_THRESHOLD_Q16),
        .FIRE_TRUCK_THRESHOLD_Q16(FIRE_TRUCK_THRESHOLD_Q16),
        .AMBULANCE_THRESHOLD_Q16(AMBULANCE_THRESHOLD_Q16),
        .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
        .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16),.CLOCK_HZ(CLOCK_HZ),
        .SPI_HZ(SPI_HZ),.RESET_CYCLES(RESET_CYCLES),
        .PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) backend(
        .clk(clk),.rst_n(rst_n),.work_key_n_i(work_key_n_i),
        .confirm_key_n_i(confirm_key_n_i),.uart_rx_i(uart_rx_i),
        .template_preview_i(template_preview_i),
        .template_preview_class_i(template_preview_class_i),
        .external_task_busy_i(external_task_busy_i),
        .probs_valid_i(backend_probs_valid),.probs_q16_i(backend_probs),
        .template_result_valid_i(template_result_valid_i),
        .template_result_class_i(template_result_class_i),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .short_window_i(result_short_r),.set_time_i(set_time_i),
        .set_hour_i(set_hour_i),.set_minute_i(set_minute_i),
        .set_second_i(set_second_i),.motor_o(motor_o),
        .recognition_enable_o(recognition_enable_o),.work_mode_o(work_mode_o),
        .alert_accept_o(alert_accept),.confirm_pulse_o(confirm_pulse),
        .panel_ready_o(panel_ready_o),.panel_busy_o(panel_busy_o),
        .tft_nrst_o(tft_nrst_o),.tft_backlight_o(tft_backlight_o),
        .tft_sclk_o(tft_sclk_o),.tft_mosi_o(tft_mosi_o),
        .tft_dc_o(tft_dc_o),.tft_cs_n_o(tft_cs_n_o));
endmodule
