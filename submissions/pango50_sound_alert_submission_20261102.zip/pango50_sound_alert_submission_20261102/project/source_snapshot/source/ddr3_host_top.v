`timescale 1ns/1ps
// Wrapper around the Pango DDR3 controller IP (ddr3_test) for the infant-cry
// SoC. The IP user AXI ports are clocked by the half-rate controller clock
// ddrphy_clkin (exposed as core_clk_o); ref_clk is only the 50 MHz PLL
// reference. The bridge must run its DDR side in the core_clk_o domain.
//
// Addresses are in 32-bit words; each 256-bit beat covers 8 words, so within
// a burst the word address increments by 8. There is no WVALID/RREADY/B
// channel: write data is pulled beat-by-beat via WREADY, read data is pushed
// beat-by-beat with RVALID and must be accepted.
module ddr3_host_top(
    input  wire        ref_clk,        // 50 MHz board oscillator
    input  wire        resetn,
    output wire        core_clk_o,     // = ddrphy_clkin, controller/user clock
    output wire        init_done_o,
    output wire        pll_lock_o,

    // user AXI (core_clk_o domain), driven by the bridge
    input  wire [27:0] awaddr_i,
    input  wire [3:0]  awlen_i,
    output wire        awready_o,
    input  wire        awvalid_i,
    input  wire [255:0] wdata_i,
    input  wire [31:0] wstrb_i,
    output wire        wready_o,
    input  wire [27:0] araddr_i,
    input  wire [3:0]  arlen_i,
    output wire        arready_o,
    input  wire        arvalid_i,
    output wire [255:0] rdata_o,
    output wire        rlast_o,
    output wire        rvalid_o,

    // physical DDR3 pins
    output wire mem_rst_n, mem_ck, mem_ck_n, mem_cke, mem_cs_n,
    output wire mem_ras_n, mem_cas_n, mem_we_n, mem_odt,
    output wire [14:0] mem_a,
    output wire [2:0]  mem_ba,
    inout  wire [3:0]  mem_dqs, mem_dqs_n,
    inout  wire [31:0] mem_dq,
    output wire [3:0]  mem_dm
);
    wire ddrphy_clkin;
    assign core_clk_o = ddrphy_clkin;

    ddr3_test u_ddr3_ip(
        .ref_clk(ref_clk), .resetn(resetn),
        .ddr_init_done(init_done_o),
        .ddrphy_clkin(ddrphy_clkin),
        .pll_lock(pll_lock_o),

        .axi_awaddr(awaddr_i), .axi_awuser_ap(1'b0), .axi_awuser_id(4'd0),
        .axi_awlen(awlen_i), .axi_awready(awready_o), .axi_awvalid(awvalid_i),
        .axi_wdata(wdata_i), .axi_wstrb(wstrb_i), .axi_wready(wready_o),
        .axi_wusero_id(), .axi_wusero_last(),

        .axi_araddr(araddr_i), .axi_aruser_ap(1'b0), .axi_aruser_id(4'd0),
        .axi_arlen(arlen_i), .axi_arready(arready_o), .axi_arvalid(arvalid_i),
        .axi_rdata(rdata_o), .axi_rid(), .axi_rlast(rlast_o), .axi_rvalid(rvalid_o),

        .apb_clk(1'b0), .apb_rst_n(1'b0), .apb_sel(1'b0), .apb_enable(1'b0),
        .apb_addr(8'd0), .apb_write(1'b0), .apb_ready(), .apb_wdata(16'd0),
        .apb_rdata(), .apb_int(),
        .debug_data(), .debug_slice_state(), .debug_calib_ctrl(),
        .ck_dly_set_bin(), .force_ck_dly_en(1'b0), .force_ck_dly_set_bin(8'd0),
        .dll_step(), .dll_lock(),
        .init_read_clk_ctrl(2'd0), .init_slip_step(4'd0), .force_read_clk_ctrl(1'b0),
        .ddrphy_gate_update_en(1'b0), .update_com_val_err_flag(), .rd_fake_stop(1'b0),

        .mem_rst_n(mem_rst_n), .mem_ck(mem_ck), .mem_ck_n(mem_ck_n),
        .mem_cke(mem_cke), .mem_cs_n(mem_cs_n),
        .mem_ras_n(mem_ras_n), .mem_cas_n(mem_cas_n), .mem_we_n(mem_we_n),
        .mem_odt(mem_odt), .mem_a(mem_a), .mem_ba(mem_ba),
        .mem_dqs(mem_dqs), .mem_dqs_n(mem_dqs_n),
        .mem_dq(mem_dq), .mem_dm(mem_dm)
    );
endmodule
