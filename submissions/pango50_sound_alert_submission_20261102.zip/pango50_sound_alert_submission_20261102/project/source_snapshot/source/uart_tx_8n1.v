`timescale 1ns/1ps
// Transmit-only 8-N-1 UART with a valid/ready byte handshake.  ready_o is
// high when idle; a byte is accepted on the clock edge where valid_i && ready_o.
module uart_tx_8n1 #(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer BAUD = 115200
)(
    input wire clk, rst_n,
    input wire [7:0] data_i,
    input wire valid_i,
    output wire ready_o,
    output wire tx_o
);
    localparam integer BIT_CYCLES = CLOCK_HZ / BAUD;
    reg [9:0] frame;          // {stop, data[7:0], start}; tx_o = frame[0]
    reg [3:0] bits_left;      // bit periods remaining in the frame
    reg [15:0] count;         // bit-period timer
    reg busy;
    assign ready_o = !busy;
    assign tx_o = frame[0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame <= 10'h3ff; bits_left <= 4'd0; count <= 16'd0; busy <= 1'b0;
        end else if (busy) begin
            if (count == BIT_CYCLES - 1) begin
                count <= 16'd0;
                if (bits_left == 4'd1) begin
                    busy <= 1'b0;
                    frame <= 10'h3ff;      // idle: tx high
                end else begin
                    frame <= {1'b1, frame[9:1]};
                    bits_left <= bits_left - 4'd1;
                end
            end else count <= count + 16'd1;
        end else if (valid_i) begin
            frame <= {1'b1, data_i, 1'b0};
            bits_left <= 4'd10;
            count <= 16'd0;
            busy <= 1'b1;
        end
    end
endmodule
