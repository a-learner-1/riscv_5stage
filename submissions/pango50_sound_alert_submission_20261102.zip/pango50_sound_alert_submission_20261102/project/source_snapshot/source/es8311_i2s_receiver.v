`timescale 1ns/1ps
// ES8311 ADC I2S receive front end.
//
// The codec is configured externally for standard I2S, 16-bit stereo.  BCLK,
// LRCK and DOUT are asynchronous pins, so they are synchronized before being
// decoded in the FPGA system-clock domain.  LRCK=0 denotes the left channel;
// only that channel is emitted because the on-board microphone is mono.
//
// This module deliberately produces PCM, not CNN features.  The deployed
// six-class model consumes 40 x 256 Log-Mel features, which are calculated
// by the senior_dbl audio frontend from a PCM window.
module es8311_i2s_receiver #(
    parameter integer SAMPLE_BITS = 16
)(
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    bclk_i,
    input  wire                    lrck_i,
    input  wire                    dout_i,//dout = data out，数据输出
    output reg signed [15:0]       sample_o,//采样数据输出
    output reg                     sample_valid_o//采样有效标志，高电平表示 sample_o 上的数据有效，可以读取
);
    reg [1:0] bclk_sync, lrck_sync, dout_sync;/*sync是同步的意思，2 级寄存器打拍，把来自音频域异步信号同步到
     FPGA 系统clk域，解决亚稳态。xxx_sync[1]是同步后的稳定信号。*/
    reg       bclk_q;//上一拍的同步后 bclk，用来检测上升沿：!bclk_q && bclk_sync[1] ，（bclk 从 0 变 1）
    reg       lrck_q;//上一拍同步 lrck，用来检测lrck 跳变（声道切换）
    reg       capture_left;//标记当前帧是不是左声道；capture_left <= ~lrck_sync[1]
    reg       skip_first_bit;//把 1 位标志信号skip_first_bit置高，跳过第一个 bit（比如串行接收时舍弃起始位）。
    reg [5:0] bit_count;//接收 bit 计数器
    reg [15:0] shift_reg;//移位寄存器，缓存串行 bit

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bclk_sync      <= 2'b00;
            lrck_sync      <= 2'b00;
            dout_sync      <= 2'b00;

            bclk_q         <= 1'b0;
            lrck_q         <= 1'b0;
            capture_left   <= 1'b0;
            skip_first_bit <= 1'b0;
            bit_count      <= 6'd0;
            shift_reg      <= 16'd0;
            sample_o       <= 16'sd0;
            sample_valid_o <= 1'b0;
        end else begin
            bclk_sync <= {bclk_sync[0], bclk_i};
            lrck_sync <= {lrck_sync[0], lrck_i};
            dout_sync <= {dout_sync[0], dout_i};
            bclk_q    <= bclk_sync[1];
            lrck_q    <= lrck_sync[1];
            sample_valid_o <= 1'b0;

            // I2S changes LRCK one bit-clock before the channel MSB.  Reset
            // the serial counter at the channel boundary, then capture the
            // following SAMPLE_BITS BCLK rising edges.
            if (lrck_q != lrck_sync[1]) begin
                capture_left <= ~lrck_sync[1];//取反就是为了：LRCK 低代表左声道，capture_left 拉高表示当前是左声道
                skip_first_bit <= 1'b1;
                bit_count    <= 6'd0;//6 位计数器，清零。最多可以计数 0~63，用来统计已经移位的 bit 个数
                shift_reg    <= 16'd0;

            end else if (!bclk_q && bclk_sync[1]) begin    //bclk上升沿驱动
                // Standard I2S places the MSB on the second rising BCLK
                // after LRCK changes.  The first clock is a one-bit delay.
                if (skip_first_bit) begin
                    skip_first_bit <= 1'b0;
                end else if (bit_count < SAMPLE_BITS) begin
                    shift_reg <= {shift_reg[14:0], dout_sync[1]};
                    if (bit_count == SAMPLE_BITS - 1) begin
                        if (capture_left) begin
                            sample_o       <= {shift_reg[14:0], dout_sync[1]};
                            sample_valid_o <= 1'b1;
                        end
                    end
                    bit_count <= bit_count + 1'b1;
                end
            end
        end
    end
endmodule
