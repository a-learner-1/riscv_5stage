`timescale 1ns/1ps
// SPI-mode SD card controller for the MES50HP MicroSD socket.
// Board pins (manual 3.4.4): CLK=C4, CMD/MOSI=A4, DAT0/MISO=D5,
// DAT3/CS=E5, DETECT=G9.
//
// One transaction at a time.  The caller drives a 512-byte block read or
// write; initialisation runs CMD0, CMD8, CMD55+ACMD41, CMD58, CMD16.
module sd_card_spi #(
    parameter integer CLK_HZ   = 100_000_000,
    parameter integer INIT_DIV = (CLK_HZ / 400_000 + 1) / 2,      // ~400 kHz
    parameter integer RUN_DIV  = (CLK_HZ / 12_500_000 + 1) / 2    // ~12.5 MHz
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        init_i,
    input  wire        start_i,
    input  wire        write_i,
    input  wire [31:0] lba_i,
    input  wire [7:0]  wdata_i,
    input  wire        wvalid_i,
    output reg  [7:0]  rdata_o,
    output reg         rvalid_o,
    output wire        wready_o,
    output reg         busy_o,
    output reg         done_o,
    output reg         error_o,
    output reg         ready_o,
    output reg         sd_clk_o,
    output reg         sd_cs_n_o,
    output reg         sd_mosi_o,
    input  wire        sd_miso_i,
    input  wire        card_present_i   // 1 = card seated
);
    // ---------------------------------------------------------------- SPI byte engine
    reg        spi_go;
    reg  [7:0] spi_tx;
    reg  [15:0] div_r;
    reg  [15:0] div_target;
    reg         sclk_r;
    reg  [7:0]  tx_shift, rx_shift;
    reg  [3:0]  bit_cnt;
    reg         spi_busy;
    reg  [7:0]  spi_in;
    reg         spi_done;
    reg         last_rise;

    // Keep the existing registered board output (one system clock of setup
    // between MOSI changes and the external falling edge).  The byte engine
    // now explicitly clocks the final falling edge before raising spi_done,
    // so the old idle-high gap is removed without changing pin timing.

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_r <= 0; sclk_r <= 0; tx_shift <= 8'hff; rx_shift <= 0;
            bit_cnt <= 0; spi_busy <= 0; spi_in <= 0; spi_done <= 0;
            last_rise <= 1'b0; sd_clk_o <= 1'b0; sd_mosi_o <= 1'b1;
        end else begin
            spi_done <= 1'b0;
            if (!spi_busy) begin
                if (spi_go) begin
                    // Mode 0: MOSI is valid before the first rising edge.
                    spi_busy <= 1'b1; tx_shift <= spi_tx; bit_cnt <= 8;
                    last_rise <= 1'b0;
                    sd_mosi_o <= spi_tx[7];
                    div_r <= 0; sclk_r <= 1'b0;
                end
            end else if (div_r >= div_target) begin
                div_r <= 0;
                sclk_r <= ~sclk_r;
                if (!sclk_r) begin
                    // rising edge: the card samples MOSI, we sample MISO
                    rx_shift <= {rx_shift[6:0],sd_miso_i};
                    if (bit_cnt > 0) bit_cnt <= bit_cnt - 1'b1;
                    if (bit_cnt == 1) begin
                        spi_in   <= {rx_shift[6:0],sd_miso_i};
                        // Keep the byte active until its final falling edge.
                        // That returns SCLK to idle-low before the next byte.
                        last_rise <= 1'b1;
                    end
                end else begin
                    // falling edge: present the next MOSI bit
                    if (last_rise) begin
                        spi_busy <= 1'b0;
                        spi_done <= 1'b1;
                        last_rise <= 1'b0;
                    end else begin
                        sd_mosi_o <= tx_shift[6];
                        tx_shift <= {tx_shift[6:0],1'b0};
                    end
                end
            end else div_r <= div_r + 1'b1;
            sd_clk_o <= sclk_r;
        end
    end
    // ---------------------------------------------------------------- transaction FSM
    localparam [4:0]
        S_IDLE       = 5'd0,
        S_POWER      = 5'd1,
        S_SEND       = 5'd2,
        S_R1         = 5'd3,
        S_EXTRA      = 5'd4,
        S_INIT_GAP   = 5'd5,
        S_TOKEN      = 5'd6,
        S_DATA       = 5'd7,
        S_TAIL       = 5'd8,
        S_WR_RESP    = 5'd9,
        S_WR_BUSY    = 5'd10,
        S_FINISH     = 5'd11,
        S_CS_GAP     = 5'd12;

    reg [4:0]  state;
    reg [7:0]  cmd_buf [0:5];
    reg [2:0]  cmd_idx;
    reg [8:0]  data_cnt;
    reg [15:0] poll_cnt;
    reg [15:0] crc16;
    reg [7:0]  cmd_now;
    reg        write_now;
    reg        sdhc_r;       // OCR.CCS: sector-addressed high-capacity card
    reg        tail_hi;       // which CRC byte goes next on a write
    reg [2:0]  extra_left;
    reg [31:0] gap_cnt;

    assign wready_o = (state == S_DATA) && write_now && !spi_busy && !spi_go;

    function [15:0] crc16_next;
        input [15:0] c_in;
        input [7:0]  d;
        integer i;
        reg [15:0] c;
        begin
            c = c_in ^ {d,8'h00};
            for (i=0;i<8;i=i+1) c = c[15] ? ((c<<1) ^ 16'h1021) : (c<<1);
            crc16_next = c;
        end
    endfunction

    function [6:0] crc7_of;
        input [39:0] frame;
        integer i;
        reg [39:0] w;
        reg [6:0]  c;
        begin
            c = 7'd0; w = frame;
            for (i=0;i<40;i=i+1) begin
                c = c << 1;
                if (w[39]) c = c ^ 7'h09;
                w = w << 1;
            end
            crc7_of = c;
        end
    endfunction

    task load_command(input [7:0] index, input [31:0] arg);
        reg [39:0] frame;
        reg [6:0]  c7;
        begin
            frame = {2'b01, index[5:0], arg};
            c7    = crc7_of(frame);
            cmd_buf[0] <= frame[39:32];
            cmd_buf[1] <= frame[31:24];
            cmd_buf[2] <= frame[23:16];
            cmd_buf[3] <= frame[15:8];
            cmd_buf[4] <= frame[7:0];
            cmd_buf[5] <= {c7,1'b1};
        end
    endtask

    task begin_command(input [7:0] index, input [31:0] arg);
        begin
            cmd_now  <= index;
            load_command(index, arg);
            cmd_idx  <= 0;
            state    <= S_SEND;
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE; cmd_idx <= 0; data_cnt <= 0; poll_cnt <= 0;
            crc16 <= 0; cmd_now <= 0; write_now <= 0; tail_hi <= 0;
            extra_left <= 0; gap_cnt <= 0; busy_o <= 0; done_o <= 0;
            sdhc_r <= 1'b0;
            error_o <= 0; ready_o <= 0; sd_cs_n_o <= 1; rdata_o <= 0;
            rvalid_o <= 0; spi_go <= 0; spi_tx <= 8'hff;
            div_target <= INIT_DIV;
        end else begin
            spi_go <= 1'b0;
            done_o <= 1'b0;
            rvalid_o <= 1'b0;

            case (state)
            S_IDLE: begin
                busy_o <= 1'b0;
                sd_cs_n_o <= 1'b1;
                if (init_i) begin
                    busy_o <= 1'b1; ready_o <= 1'b0; error_o <= 1'b0;
                    sdhc_r <= 1'b0;
                    sd_cs_n_o <= 1'b1;
                    div_target <= INIT_DIV;
                    poll_cnt <= 0;
                    state <= S_POWER;
                end else if (start_i && ready_o) begin
                    if (!card_present_i) begin
                        error_o <= 1'b1; done_o <= 1'b1;
                    end else begin
                        busy_o <= 1'b1; error_o <= 1'b0;
                        write_now <= write_i;
                        sd_cs_n_o <= 1'b0;
                        // SDHC/SDXC commands take a 512-byte sector number;
                        // SDSC uses a byte address.
                        begin_command(write_i ? 8'd24 : 8'd17,
                                      sdhc_r ? lba_i : (lba_i << 9));
                    end
                end
            end
            // 74 clocks with CS high, then CMD0.
            S_POWER: begin
                if (!spi_busy && !spi_go) begin
                    if (poll_cnt < 9) begin
                        spi_tx <= 8'hff; spi_go <= 1'b1;
                        poll_cnt <= poll_cnt + 1'b1;
                    end else begin
                        // One 0xFF byte with CS low aligns the card's byte
                        // framing before the first command frame.
                        sd_cs_n_o <= 1'b0;
                        spi_tx <= 8'hff; spi_go <= 1'b1;
                        state <= S_CS_GAP;
                    end
                end
            end
            S_CS_GAP: begin
                if (spi_done) begin_command(8'd0, 32'd0);
            end
            S_SEND: begin
                if (!spi_busy && !spi_go) begin
                    spi_tx <= cmd_buf[cmd_idx];
                    spi_go <= 1'b1;
                    if (cmd_idx == 5) begin
                        cmd_idx <= 0; poll_cnt <= 0;
                        state <= S_R1;
                    end else cmd_idx <= cmd_idx + 1'b1;
                end
            end
            // Poll for a response byte with bit7 clear.
            S_R1: begin
                if (spi_done) begin
                    if (!spi_in[7]) begin
                        poll_cnt <= 0;
                        case (cmd_now)
                        8'd0:  begin
                            if (spi_in != 8'h01) begin error_o <= 1'b1; state <= S_FINISH; end
                            else begin_command(8'd8, 32'h0000_01AA);   // CMD8
                        end
                        8'd8:  begin extra_left <= 3'd4; state <= S_EXTRA; end
                        8'd55: begin_command(8'd41, 32'h4000_0000);   // ACMD41
                        8'd41: begin
                            if (spi_in == 8'h00) begin_command(8'd58, 32'd0);
                            else begin
                                begin_command(8'd55, 32'd0);           // retry
                                gap_cnt <= 0; state <= S_INIT_GAP;
                                cmd_now <= 8'h00;                      // make S_R1 ignore
                            end
                        end
                        8'd58: begin extra_left <= 3'd4; state <= S_EXTRA; end
                        8'd16: begin
                            if (spi_in != 8'h00) begin error_o <= 1'b1; state <= S_FINISH; end
                            else begin ready_o <= 1'b1; div_target <= RUN_DIV; state <= S_FINISH; end
                        end
                        default: begin                        // CMD17 / CMD24
                            if (spi_in != 8'h00) begin error_o <= 1'b1; state <= S_FINISH; end
                            else begin
                                poll_cnt <= 0;
                                data_cnt <= 0;
                                crc16 <= 0;
                                state <= S_TOKEN;
                            end
                        end
                        endcase
                    end else if (poll_cnt >= 16'd8) begin
                        error_o <= 1'b1; state <= S_FINISH;
                    end else begin
                        poll_cnt <= poll_cnt + 1'b1;
                        spi_tx <= 8'hff; spi_go <= 1'b1;
                    end
                end else if (!spi_busy && !spi_go) begin
                    spi_tx <= 8'hff; spi_go <= 1'b1;
                end
            end
            S_EXTRA: begin
                if (spi_done) begin
                    // CMD58 returns OCR[31:24] first; CCS is OCR[30].
                    if (cmd_now == 8'd58 && extra_left == 3'd4)
                        sdhc_r <= spi_in[6];
                    if (extra_left == 3'd1) begin
                        if (cmd_now == 8'd8) begin_command(8'd55, 32'd0);
                        else if (sdhc_r) begin
                            // CMD16 is not required (and is commonly rejected)
                            // for SDHC/SDXC cards, whose blocks are fixed at 512 B.
                            ready_o <= 1'b1;
                            div_target <= RUN_DIV;
                            state <= S_FINISH;
                        end else begin_command(8'd16, 32'd512);
                    end else extra_left <= extra_left - 1'b1;
                end else if (!spi_busy && !spi_go) begin
                    spi_tx <= 8'hff; spi_go <= 1'b1;
                end
            end
            S_INIT_GAP: begin
                if (gap_cnt >= 32'd100_000) begin
                    gap_cnt <= 0;
                    state <= S_SEND;              // re-send the staged CMD55
                end else gap_cnt <= gap_cnt + 1'b1;
            end
            S_TOKEN: begin
                if (write_now) begin
                    // A block write is opened by the host: send the 0xFE
                    // start token, then the payload follows.
                    if (!spi_busy && !spi_go) begin
                        spi_tx <= 8'hfe; spi_go <= 1'b1;
                        state <= S_DATA;
                    end
                end else if (spi_done) begin
                    if (spi_in == 8'hfe) begin
                        data_cnt <= 0;
                        state <= S_DATA;
                    end else if (poll_cnt >= 16'd512) begin
                        error_o <= 1'b1; state <= S_FINISH;
                    end else poll_cnt <= poll_cnt + 1'b1;
                end else if (!spi_busy && !spi_go) begin
                    spi_tx <= 8'hff; spi_go <= 1'b1;
                end
            end
            S_DATA: begin
                if (write_now) begin
                    if (!spi_busy && !spi_go && wvalid_i) begin
                        spi_tx <= wdata_i; spi_go <= 1'b1;
                        crc16 <= crc16_next(crc16, wdata_i);
                        if (data_cnt == 9'd511) begin
                            data_cnt <= 0; tail_hi <= 1'b1; state <= S_TAIL;
                        end else data_cnt <= data_cnt + 1'b1;
                    end
                end else begin
                    if (spi_done) begin
                        rdata_o <= spi_in; rvalid_o <= 1'b1;
                        if (data_cnt == 9'd511) begin
                            data_cnt <= 0; state <= S_TAIL;
                        end else data_cnt <= data_cnt + 1'b1;
                    end else if (!spi_busy && !spi_go) begin
                        spi_tx <= 8'hff; spi_go <= 1'b1;
                    end
                end
            end
            S_TAIL: begin
                if (!spi_busy && !spi_go) begin
                    if (write_now) begin
                        spi_tx <= tail_hi ? crc16[15:8] : crc16[7:0];
                        spi_go <= 1'b1;
                        if (tail_hi) tail_hi <= 1'b0;
                        else state <= S_WR_RESP;
                    end else begin
                        spi_tx <= 8'hff; spi_go <= 1'b1;
                        if (data_cnt == 9'd1) state <= S_FINISH;
                        else data_cnt <= data_cnt + 1'b1;
                    end
                end
            end
            S_WR_RESP: begin
                if (spi_done) begin
                    if (spi_in == 8'hff) begin
                        // still in the latency gap
                        state <= S_WR_RESP;
                    end else begin
                        error_o <= (spi_in[4:0] != 5'h05);
                        state <= S_WR_BUSY;
                    end
                end else if (!spi_busy && !spi_go) begin
                    spi_tx <= 8'hff; spi_go <= 1'b1;
                end
            end
            S_WR_BUSY: begin
                if (spi_done && spi_in == 8'hff) state <= S_FINISH;
                else if (!spi_busy && !spi_go) begin
                    spi_tx <= 8'hff; spi_go <= 1'b1;
                end
            end
            // The read tail schedules the second CRC byte and enters this
            // state in the same cycle. Keep CS asserted until that byte has
            // actually finished. Otherwise a back-to-back CMD17 can begin
            // halfway through the trailing clocks, shifting its R1 response.
            S_FINISH: if (!spi_busy && !spi_go) begin
                sd_cs_n_o <= 1'b1;
                busy_o <= 1'b0;
                done_o <= 1'b1;
                state <= S_IDLE;
            end
            default: state <= S_IDLE;
            endcase
        end
    end
endmodule
