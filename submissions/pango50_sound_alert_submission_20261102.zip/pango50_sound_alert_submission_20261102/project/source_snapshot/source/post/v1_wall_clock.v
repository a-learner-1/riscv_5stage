`timescale 1ns/1ps
// Wall clock without battery backup. A UART parser must drive set_i and BCD
// fields after validating the complete TIME command. tick_1s_o is a pulse.
module v1_wall_clock #(
    parameter integer CLOCK_HZ=50000000
)(
    input wire clk,rst_n,
    input wire set_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    output reg valid_o,
    output reg [7:0] hour_o,minute_o,second_o,
    output reg tick_1s_o,
    output wire [31:0] seconds_since_midnight_o
);
    reg [31:0] divider;
    assign seconds_since_midnight_o = hour_o*32'd3600 + minute_o*32'd60 + second_o;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            divider<=0;valid_o<=0;hour_o<=0;minute_o<=0;second_o<=0;tick_1s_o<=0;
        end else begin
            tick_1s_o<=0;
            if(set_i && set_hour_i<24 && set_minute_i<60 && set_second_i<60) begin
                hour_o<=set_hour_i;minute_o<=set_minute_i;second_o<=set_second_i;
                valid_o<=1;divider<=0;
            end else if(divider==CLOCK_HZ-1) begin
                divider<=0;tick_1s_o<=1;
                if(valid_o) begin
                    if(second_o==59) begin
                        second_o<=0;
                        if(minute_o==59) begin
                            minute_o<=0;
                            if(hour_o==23) hour_o<=0;
                            else hour_o<=hour_o+1'b1;
                        end else minute_o<=minute_o+1'b1;
                    end else second_o<=second_o+1'b1;
                end
            end else divider<=divider+1'b1;
        end
    end
endmodule
