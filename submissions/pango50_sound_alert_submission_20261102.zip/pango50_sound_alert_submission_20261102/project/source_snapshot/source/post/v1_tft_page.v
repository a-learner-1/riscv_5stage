`timescale 1ns/1ps
// Post-init page rasterizer. The caller starts a full or partial rectangle;
// source pixel coordinates are the panel coordinates, so the clock and icon
// can be refreshed independently without a DDR framebuffer.
module v1_tft_page #(
    parameter integer FULLSCREEN_IMAGES=0,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer SHOW_ALERT_LABELS=0
)(
    input wire clk,rst_n,start_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire [7:0] x0_i,x1_i,
    input wire [8:0] y0_i,y1_i,
    input wire [3:0] display_class_i,
    input wire alert_visible_i,clock_valid_i,
    input wire [7:0] hour_i,minute_i,second_i,
    output wire busy_o,done_o,
    output wire sclk_o,mosi_o,dc_o,cs_n_o
);
    wire [7:0] pixel_x;
    wire [8:0] pixel_y;
    wire [15:0] pixel;
    reg [3:0] frame_class;
    reg [7:0] frame_label_x0,frame_label_x1;
    reg frame_alert_visible,frame_clock_valid;
    reg [7:0] frame_hour,frame_minute,frame_second;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_class<=0;
            frame_label_x0<=120;frame_label_x1<=120;
            frame_alert_visible<=0;
            frame_clock_valid<=0;
            frame_hour<=0;
            frame_minute<=0;
            frame_second<=0;
        end else if (start_i && !busy_o) begin
            frame_class<=display_class_i;
            if (SHOW_ALERT_LABELS) begin
                case (display_class_i)
                    4'd1,4'd5: begin frame_label_x0<=72; frame_label_x1<=168; end
                    4'd2: begin frame_label_x0<=84; frame_label_x1<=156; end
                    4'd3: begin frame_label_x0<=24; frame_label_x1<=216; end
                    4'd4: begin frame_label_x0<=96; frame_label_x1<=144; end
                    4'd8,4'd9,4'd10: begin frame_label_x0<=24; frame_label_x1<=216; end
                    default: begin frame_label_x0<=120; frame_label_x1<=120; end
                endcase
            end else begin
                frame_label_x0<=120;
                frame_label_x1<=120;
            end
            frame_alert_visible<=alert_visible_i;
            frame_clock_valid<=clock_valid_i;
            frame_hour<=hour_i;
            frame_minute<=minute_i;
            frame_second<=second_i;
        end
    end
    generate if(FULLSCREEN_IMAGES) begin:g_fullscreen
        v1_fullscreen_image_pixel screen(.clk(clk),.rst_n(rst_n),
            .x_i(pixel_x),.y_i(pixel_y),.class_i(frame_class),
            .visible_i(frame_alert_visible),.pixel_o(pixel));
    end else begin:g_composite
    v1_screen_pixel screen(.clk(clk),.rst_n(rst_n),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .x_i(pixel_x),.y_i(pixel_y),
        .class_i(frame_class),.label_x0_i(frame_label_x0),
        .label_x1_i(frame_label_x1),.alert_visible_i(frame_alert_visible),
        .clock_valid_i(frame_clock_valid),.hour_i(frame_hour),
        .minute_i(frame_minute),.second_i(frame_second),.pixel_o(pixel));
    end endgenerate
    // The screen's pixel_o is already registered (three-stage rasterizer), so no
    // extra output register is needed here; the SPI window writer waits two
    // cycles after each coordinate advance to keep pixels aligned.
    v1_tft_spi_window #(.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ)) writer(
        .clk(clk),.rst_n(rst_n),.start_i(start_i),
        .x0_i(x0_i),.x1_i(x1_i),.y0_i(y0_i),.y1_i(y1_i),
        .pixel_rgb565_i(pixel),.pixel_x_o(pixel_x),.pixel_y_o(pixel_y),
        .busy_o(busy_o),.done_o(done_o),
        .sclk_o(sclk_o),.mosi_o(mosi_o),.dc_o(dc_o),.cs_n_o(cs_n_o));
endmodule
