`timescale 1ns/1ps
// Five-class MN04 decision adapter. Class order is background, baby cry,
// car horn, doorbell/knock, fire alarm. The short window keeps the horn fast
// path (direct horn score) and also evaluates baby/door/fire by global
// argmax, so every class is reachable from the 1 s short window; the long
// window remains as a slower fallback. Short-window thresholds are fit on
// 100-frame windows at zero validation false alarms (a fast + confident path
// that must not add false alarms on top of the long window); long-window
// thresholds are the original experimental operating points.
module v1_five_class_selector #(
    parameter [15:0] HORN_THRESHOLD_Q16       = 16'd39293,
    parameter [15:0] BABY_SHORT_THRESHOLD_Q16 = 16'd57953,
    parameter [15:0] DOOR_SHORT_THRESHOLD_Q16 = 16'd0,
    parameter [15:0] FIRE_SHORT_THRESHOLD_Q16 = 16'd45081,
    parameter [15:0] BABY_LONG_THRESHOLD_Q16  = 16'd0,
    parameter [15:0] DOOR_LONG_THRESHOLD_Q16  = 16'd32072,
    parameter [15:0] FIRE_LONG_THRESHOLD_Q16  = 16'd63465
)(
    input wire [79:0] probs_q16_i,
    input wire short_window_i,
    output reg [2:0] target_class_o,
    output reg [15:0] target_score_o,
    output reg alert_o
);
    integer c;
    reg [2:0] best_class;
    reg [15:0] best_score;
    reg [15:0] score;
    always @* begin
        best_class = 3'd0;
        best_score = probs_q16_i[15:0];
        score = 16'd0;
        for (c=1; c<5; c=c+1) begin
            score = probs_q16_i[c*16 +: 16];
            if (score > best_score) begin
                best_score = score;
                best_class = c[2:0];
            end
        end

        target_class_o = 3'd0;
        target_score_o = 16'd0;
        alert_o = 1'b0;
        if (short_window_i) begin
            target_score_o = probs_q16_i[47:32];
            if (target_score_o >= HORN_THRESHOLD_Q16) begin
                target_class_o = 3'd2;
                alert_o = 1'b1;
            end else begin
                target_score_o = best_score;
                case (best_class)
                    3'd1: if (best_score >= BABY_SHORT_THRESHOLD_Q16) begin
                        target_class_o = 3'd1;
                        alert_o = 1'b1;
                    end
                    3'd3: if (best_score >= DOOR_SHORT_THRESHOLD_Q16) begin
                        target_class_o = 3'd3;
                        alert_o = 1'b1;
                    end
                    3'd4: if (best_score >= FIRE_SHORT_THRESHOLD_Q16) begin
                        target_class_o = 3'd4;
                        alert_o = 1'b1;
                    end
                    default: begin end
                endcase
            end
        end else begin
            target_score_o = best_score;
            case (best_class)
                3'd1: if (best_score >= BABY_LONG_THRESHOLD_Q16) begin
                    target_class_o = 3'd1;
                    alert_o = 1'b1;
                end
                3'd3: if (best_score >= DOOR_LONG_THRESHOLD_Q16) begin
                    target_class_o = 3'd3;
                    alert_o = 1'b1;
                end
                3'd4: if (best_score >= FIRE_LONG_THRESHOLD_Q16) begin
                    target_class_o = 3'd4;
                    alert_o = 1'b1;
                end
                default: begin end // background and long-window horn
            endcase
        end
    end
endmodule
