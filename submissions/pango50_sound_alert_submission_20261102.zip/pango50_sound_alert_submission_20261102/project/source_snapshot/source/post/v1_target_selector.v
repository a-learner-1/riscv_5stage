`timescale 1ns/1ps
// Mirrors compare_fitting_models.clip_records for one inference window:
// choose the largest of target classes 1..7, then compare to the threshold.
// Inputs are unsigned Q0.16 probabilities; class 0 is background.
module v1_target_selector #(
    parameter [15:0] THRESHOLD_Q16 = 16'd42640
)(
    input wire [127:0] probs_q16_i,
    output reg [2:0] target_class_o,
    output reg [15:0] target_score_o,
    output wire alert_o
);
    integer c;
    reg [15:0] score;
    always @* begin
        target_class_o = 3'd1;
        target_score_o = probs_q16_i[31:16];
        score = 0;
        for(c=2;c<=7;c=c+1) begin
            score = probs_q16_i[c*16 +: 16];
            if(score>target_score_o) begin
                target_score_o=score;
                target_class_o=c[2:0];
            end
        end
    end
    assign alert_o=(target_score_o>=THRESHOLD_Q16);
endmodule
