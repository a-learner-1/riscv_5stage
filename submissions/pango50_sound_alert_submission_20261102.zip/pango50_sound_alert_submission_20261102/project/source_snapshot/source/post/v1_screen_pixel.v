`timescale 1ns/1ps
// Full 240x320 portrait RGB565 page: top clock, 128x128 image, Chinese label.
// Intended to feed an ST7789V2 SPI window writer. No DDR framebuffer needed.
//
// GATE6 timing: coordinate decoding, glyph-base selection, row-byte arithmetic,
// async glyph ROM read, and region priority mux are pipelined across three
// stages. Stage 1 decodes coordinates and selects glyph bases; stage 2 adds
// row/byte offsets; stage 3 reads the asynchronous ROM and registers pixel_o.
// The SPI window writer waits two cycles after advancing the raster coordinate.
module v1_screen_pixel(
    input wire clk,
    input wire rst_n,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire [7:0] x_i,
    input wire [8:0] y_i,
    input wire [3:0] class_i,
    input wire [7:0] label_x0_i,label_x1_i,
    input wire alert_visible_i,
    input wire clock_valid_i,
    input wire [7:0] hour_i,minute_i,second_i,
    output reg [15:0] pixel_o
);
    reg [7:0] glyph_rom [0:5543];
    reg [7:0] template_glyph_rom [0:3455];
    reg template_glyph_loaded_r;
    wire [6:0] icon_x = x_i-8'd56;
    wire [6:0] icon_y = y_i-9'd64;
    wire [15:0] icon_pixel;
    // stage-1 combinational terms
    reg [11:0] glyph_base_c,template_glyph_base_c;
    reg [6:0] glyph_row_byte_c;
    reg [2:0]  bit_index_c;
    reg        line40_c,clock_region_c,time_on_c,icon_region_c,glyph_region_c;
    reg        glyph_second_line_c,template_glyph_region_c;
    reg [15:0] icon_pixel_c;
    // stage-1 registers
    reg [11:0] glyph_base_r,template_glyph_base_r;
    reg [6:0] glyph_row_byte_r;
    reg [2:0] bit_index_stage1_r;
    reg line40_stage1_r,clock_region_stage1_r,time_on_stage1_r;
    reg icon_region_stage1_r,glyph_region_stage1_r;
    reg template_glyph_region_stage1_r;
    reg [15:0] icon_pixel_stage1_r;
    // stage-2 registers hold completed addresses and delayed pixel controls
    reg [11:0] offset_r;
    reg [2:0]  bit_index_r;
    reg        line40_r,clock_region_r,time_on_r,icon_region_r,glyph_region_r;
    reg        template_glyph_region_r;
    reg [11:0] template_glyph_offset_r;
    reg [15:0] icon_pixel_r;
    // stage-2 combinational
    reg        glyph_on;
    reg [15:0] pixel_c;
    // stage-1 temporaries
    reg [7:0] coord;
    reg [2:0] char_pos,time_pos,digit_col,digit_row;
    reg [4:0] local_x,local_y;
    reg [3:0] digit_value;
    reg [4:0] digit_bits;
    reg [11:0] glyph_offset;

    initial $readmemh("v1_run/display_assets/glyphs_u1.hex",glyph_rom);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) template_glyph_loaded_r<=1'b0;
        else if ((display_asset_we_i === 1'b1) &&
                 (display_asset_addr_i == 15'd28031))
            template_glyph_loaded_r<=1'b1;
    end
    always @(posedge clk) begin
        if ((display_asset_we_i === 1'b1) && (display_asset_addr_i >= 15'd24576) &&
            (display_asset_addr_i < 15'd28032))
            template_glyph_rom[display_asset_addr_i - 15'd24576] <= display_asset_data_i;
    end
    v1_icon_pixel icon(.clk(clk),
        .display_asset_we_i(display_asset_we_i &&
                             (display_asset_addr_i < 15'd24576)),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .class_i(class_i),.x_i(icon_x),.y_i(icon_y),.pixel_o(icon_pixel));

    function [11:0] glyph_for;
        input [3:0] cls;
        input [2:0] pos;
        input       second_line;
        begin
            glyph_for=0;
            case(cls)
                3'd1: if(pos<4) glyph_for=pos*72;
                3'd2: if(pos<3) glyph_for=(4+pos)*72;
                3'd3: if(pos<8) glyph_for=(7+(second_line ? 8 : 0)+pos)*72;
                3'd4: if(pos<2) glyph_for=(23+pos)*72;
                3'd5: if(pos<4) glyph_for=(25+pos)*72;
                4'd8: if(pos<8) glyph_for=(29+(second_line ? 8 : 0)+pos)*72;
                4'd9: if(pos<8) glyph_for=(45+(second_line ? 8 : 0)+pos)*72;
                4'd10: if(pos<8) glyph_for=(61+(second_line ? 8 : 0)+pos)*72;
            endcase
        end
    endfunction
    function [4:0] digit_row_bits;
        input [3:0] digit;
        input [2:0] row;
        reg [34:0] bits;
        begin
            case(digit)
                0:bits=35'b01110100011001110101100111000101110;
                1:bits=35'b00100011000010000100001000010001110;
                2:bits=35'b01110100010000100010001000100011111;
                3:bits=35'b11110000010000101110000010000111110;
                4:bits=35'b00010001100101010010111110001000010;
                5:bits=35'b11111100001111000001000011000101110;
                6:bits=35'b00110010001000011110100011000101110;
                7:bits=35'b11111000010001000100010000100001000;
                8:bits=35'b01110100011000101110100011000101110;
                9:bits=35'b01110100011000101111000010001001100;
                default:bits=0;
            endcase
            digit_row_bits=(bits >> ((6-row)*5)) & 5'b11111;
        end
    endfunction

    function [2:0] tens10;
        input [7:0] value;
        begin
            if(value>=50) tens10=5;
            else if(value>=40) tens10=4;
            else if(value>=30) tens10=3;
            else if(value>=20) tens10=2;
            else if(value>=10) tens10=1;
            else tens10=0;
        end
    endfunction
    function [3:0] ones10;
        input [7:0] value;
        reg [2:0] tens;
        begin tens=tens10(value);ones10=value-tens*10;end
    endfunction

    // ---- stage 1: coordinate/address arithmetic and every non-glyph term ----
    always @* begin
        glyph_base_c=0;template_glyph_base_c=0;glyph_row_byte_c=0;bit_index_c=0;
        line40_c=0;clock_region_c=0;time_on_c=0;icon_region_c=0;glyph_region_c=0;
        glyph_second_line_c=0;template_glyph_region_c=0;
        icon_pixel_c=icon_pixel;
        coord=0;char_pos=0;local_x=0;local_y=0;
        time_pos=0;digit_col=0;digit_row=0;digit_value=0;digit_bits=0;glyph_offset=0;

        if(y_i==9'd40) line40_c=1;
        if(clock_valid_i && y_i>=10 && y_i<31 && x_i>=30 && x_i<222) begin
            clock_region_c=1;
            coord=x_i-30;
            if (coord<24) begin time_pos=0;local_x=coord;end
            else if (coord<48) begin time_pos=1;local_x=coord-24;end
            else if (coord<72) begin time_pos=2;local_x=coord-48;end
            else if (coord<96) begin time_pos=3;local_x=coord-72;end
            else if (coord<120) begin time_pos=4;local_x=coord-96;end
            else if (coord<144) begin time_pos=5;local_x=coord-120;end
            else if (coord<168) begin time_pos=6;local_x=coord-144;end
            else begin time_pos=7;local_x=coord-168;end
            if(local_x<3) digit_col=0;
            else if(local_x<6) digit_col=1;
            else if(local_x<9) digit_col=2;
            else if(local_x<12) digit_col=3;
            else if(local_x<15) digit_col=4;
            else if(local_x<18) digit_col=5;
            else if(local_x<21) digit_col=6;
            else digit_col=7;
            if(y_i<13) digit_row=0;
            else if(y_i<16) digit_row=1;
            else if(y_i<19) digit_row=2;
            else if(y_i<22) digit_row=3;
            else if(y_i<25) digit_row=4;
            else if(y_i<28) digit_row=5;
            else digit_row=6;
            case(time_pos)
                0:digit_value=tens10(hour_i);
                1:digit_value=ones10(hour_i);
                3:digit_value=tens10(minute_i);
                4:digit_value=ones10(minute_i);
                6:digit_value=tens10(second_i);
                7:digit_value=ones10(second_i);
                default:digit_value=0;
            endcase
            if(time_pos==2 || time_pos==5)
                time_on_c=(digit_col==2 && (digit_row==2 || digit_row==4));
            else if(digit_col<5 && digit_row<7) begin
                digit_bits=digit_row_bits(digit_value[3:0],digit_row[2:0]);
                time_on_c=digit_bits[4-digit_col];
            end
        end

        if(alert_visible_i && class_i>=1 && class_i<=11) begin
            if(x_i>=56 && x_i<184 && y_i>=64 && y_i<192)
                icon_region_c=1;
            if(((y_i>=220 && y_i<244) ||
                (((class_i==3 || (class_i>=8 && class_i<=10))) &&
                 y_i>=250 && y_i<274)) &&
               x_i >= label_x0_i && x_i < label_x1_i) begin
                glyph_region_c=1;
                glyph_second_line_c=(y_i>=250);
                template_glyph_region_c=(class_i>=8 && class_i<=10);
                coord=x_i-label_x0_i;
                if (coord<24) begin char_pos=0;local_x=coord;end
                else if (coord<48) begin char_pos=1;local_x=coord-24;end
                else if (coord<72) begin char_pos=2;local_x=coord-48;end
                else if (coord<96) begin char_pos=3;local_x=coord-72;end
                else if(coord<120) begin char_pos=4;local_x=coord-96;end
                else if(coord<144) begin char_pos=5;local_x=coord-120;end
                else if(coord<168) begin char_pos=6;local_x=coord-144;end
                else begin char_pos=7;local_x=coord-168;end
                local_y=glyph_second_line_c ? y_i-250 : y_i-220;
                glyph_offset=glyph_for(class_i,char_pos[2:0],glyph_second_line_c);
                glyph_base_c=glyph_offset;
                template_glyph_base_c=
                    ((class_i-8)*16 + (glyph_second_line_c ? 8 : 0) +
                     char_pos[2:0]) * 72;
                glyph_row_byte_c=local_y*3+(local_x>>3);
                bit_index_c=7-(local_x&7);
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            glyph_base_r<=0;template_glyph_base_r<=0;glyph_row_byte_r<=0;
            bit_index_stage1_r<=0;
            line40_stage1_r<=0;clock_region_stage1_r<=0;time_on_stage1_r<=0;
            icon_region_stage1_r<=0;glyph_region_stage1_r<=0;
            template_glyph_region_stage1_r<=0;icon_pixel_stage1_r<=0;
        end else begin
            glyph_base_r<=glyph_base_c;
            template_glyph_base_r<=template_glyph_base_c;
            glyph_row_byte_r<=glyph_row_byte_c;
            bit_index_stage1_r<=bit_index_c;
            line40_stage1_r<=line40_c;clock_region_stage1_r<=clock_region_c;
            time_on_stage1_r<=time_on_c;icon_region_stage1_r<=icon_region_c;
            glyph_region_stage1_r<=glyph_region_c;
            template_glyph_region_stage1_r<=template_glyph_region_c;
            icon_pixel_stage1_r<=icon_pixel_c;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            offset_r<=0;template_glyph_offset_r<=0;bit_index_r<=0;
            line40_r<=0;clock_region_r<=0;time_on_r<=0;
            icon_region_r<=0;glyph_region_r<=0;icon_pixel_r<=0;
            template_glyph_region_r<=0;
        end else begin
            offset_r<=glyph_base_r+glyph_row_byte_r;
            template_glyph_offset_r<=template_glyph_base_r+glyph_row_byte_r;
            bit_index_r<=bit_index_stage1_r;
            line40_r<=line40_stage1_r;clock_region_r<=clock_region_stage1_r;
            time_on_r<=time_on_stage1_r;icon_region_r<=icon_region_stage1_r;
            glyph_region_r<=glyph_region_stage1_r;
            icon_pixel_r<=icon_pixel_stage1_r;
            template_glyph_region_r<=template_glyph_region_stage1_r;
        end
    end

    // ---- stage 2: async glyph read + final region priority mux ----
    always @* begin
        glyph_on=(template_glyph_region_r && template_glyph_loaded_r) ?
                 template_glyph_rom[template_glyph_offset_r][bit_index_r] :
                 glyph_rom[offset_r][bit_index_r];
        pixel_c=16'h08E3;
        if(line40_r) pixel_c=16'h8410;
        else if(clock_region_r) pixel_c=time_on_r ? 16'hFFFF : 16'h08E3;
        else if(icon_region_r) pixel_c=icon_pixel_r;
        else if(glyph_region_r) pixel_c=glyph_on ? 16'hFFFF : 16'h08E3;
    end

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) pixel_o<=16'h08E3;
        else pixel_o<=pixel_c;
    end
endmodule
