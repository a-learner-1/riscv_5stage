`timescale 1ns/1ps
// Legacy eight-output head selector: class 0 is background; classes 1..7 are
// baby cry, knock, siren, fire truck, ambulance, dog bark, car horn.
module v1_eight_class_selector #(
    parameter [15:0] BABY_THRESHOLD_Q16=16'hffff,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] SIREN_THRESHOLD_Q16=16'hffff,
    parameter [15:0] FIRE_TRUCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] AMBULANCE_THRESHOLD_Q16=16'hffff,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'hffff
)(
    input wire [127:0] probs_q16_i,
    output reg [2:0] target_class_o,
    output reg [15:0] target_score_o,
    output reg alert_o
);
    integer c;
    reg [15:0] best_score,threshold;
    always @* begin
        target_class_o=3'd1;
        best_score=probs_q16_i[31:16];
        for(c=2;c<=7;c=c+1) begin
            if(probs_q16_i[c*16 +: 16]>best_score) begin
                target_class_o=c[2:0];
                best_score=probs_q16_i[c*16 +: 16];
            end
        end
        target_score_o=best_score;
        case(target_class_o)
            3'd1: threshold=BABY_THRESHOLD_Q16;
            3'd2: threshold=KNOCK_THRESHOLD_Q16;
            3'd3: threshold=SIREN_THRESHOLD_Q16;
            3'd4: threshold=FIRE_TRUCK_THRESHOLD_Q16;
            3'd5: threshold=AMBULANCE_THRESHOLD_Q16;
            3'd6: threshold=DOG_BARK_THRESHOLD_Q16;
            default: threshold=CAR_HORN_THRESHOLD_Q16;
        endcase
        alert_o=(best_score>=threshold);
    end
endmodule
