`timescale 1ns/1ps
// ST7789V2 reset/init sequence adapted from the reference driver. Every
// parameter byte explicitly drives DC=1; command bytes drive DC=0.
module v1_st7789_init #(
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,
    output reg ready_o,
    output reg nrst_o,
    output wire backlight_o,
    output wire sclk_o,mosi_o,dc_o,cs_n_o
);
    localparam ST_RESET=0,ST_LAUNCH=1,ST_WAIT=2,ST_DELAY=3,ST_READY=4;
    reg [2:0] state;
    reg [31:0] count,delay_target;
    reg [6:0] index;
    reg tx_start;
    reg [7:0] tx_data;
    reg tx_dc;
    wire tx_busy,tx_done;
    assign backlight_o=ready_o;
    tft_spi_byte #(.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ)) spi(
        .clk(clk),.rst_n(rst_n),.start_i(tx_start),.data_i(tx_data),.dc_i(tx_dc),
        .busy_o(tx_busy),.done_o(tx_done),.sclk_o(sclk_o),.mosi_o(mosi_o),
        .dc_o(dc_o),.cs_n_o(cs_n_o));
    always @* begin
        tx_data=0;tx_dc=1;
        case(index)
            0:begin tx_data=8'h01;tx_dc=0;end // SWRESET
            1:begin tx_data=8'h11;tx_dc=0;end // SLPOUT
            2:begin tx_data=8'h36;tx_dc=0;end // MADCTL
            3:tx_data=8'h00;
            4:begin tx_data=8'h3A;tx_dc=0;end // COLMOD
            5:tx_data=8'h05; // RGB565
            6:begin tx_data=8'hB2;tx_dc=0;end
            7:tx_data=8'h0C;8:tx_data=8'h0C;9:tx_data=8'h00;
            10:tx_data=8'h33;11:tx_data=8'h33;
            12:begin tx_data=8'hB7;tx_dc=0;end
            13:tx_data=8'h35;
            14:begin tx_data=8'hBB;tx_dc=0;end
            15:tx_data=8'h19;
            16:begin tx_data=8'hC0;tx_dc=0;end
            17:tx_data=8'h2C;
            18:begin tx_data=8'hC2;tx_dc=0;end
            19:tx_data=8'h01;
            20:begin tx_data=8'hC3;tx_dc=0;end
            21:tx_data=8'h12;
            22:begin tx_data=8'hC4;tx_dc=0;end
            23:tx_data=8'h20;
            24:begin tx_data=8'hC6;tx_dc=0;end
            25:tx_data=8'h0F;
            26:begin tx_data=8'hD0;tx_dc=0;end
            27:tx_data=8'hA4;28:tx_data=8'hA1;
            29:begin tx_data=8'hE0;tx_dc=0;end
            30:tx_data=8'hD0;31:tx_data=8'h04;32:tx_data=8'h0D;33:tx_data=8'h11;
            34:tx_data=8'h13;35:tx_data=8'h2B;36:tx_data=8'h3F;37:tx_data=8'h54;
            38:tx_data=8'h4C;39:tx_data=8'h18;40:tx_data=8'h0D;41:tx_data=8'h0B;
            42:tx_data=8'h1F;43:tx_data=8'h23;
            44:begin tx_data=8'hE1;tx_dc=0;end
            45:tx_data=8'hD0;46:tx_data=8'h04;47:tx_data=8'h0C;48:tx_data=8'h11;
            49:tx_data=8'h13;50:tx_data=8'h2C;51:tx_data=8'h3F;52:tx_data=8'h44;
            53:tx_data=8'h51;54:tx_data=8'h2F;55:tx_data=8'h1F;56:tx_data=8'h1F;
            57:tx_data=8'h20;58:tx_data=8'h23;
            59:begin tx_data=8'h21;tx_dc=0;end // INVON
            60:begin tx_data=8'h29;tx_dc=0;end // DISPON
        endcase
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=ST_RESET;count<=0;delay_target<=0;index<=0;
            tx_start<=0;ready_o<=0;nrst_o<=0;
        end else begin
            tx_start<=0;
            case(state)
                ST_RESET:begin
                    if(count==RESET_CYCLES-1) begin
                        nrst_o<=1;count<=0;state<=ST_LAUNCH;
                    end else count<=count+1'b1;
                end
                ST_LAUNCH:if(!tx_busy) begin tx_start<=1;state<=ST_WAIT;end
                ST_WAIT:if(tx_done) begin
                    if(index==60) begin
                        count<=0;delay_target<=DISPLAY_DELAY_CYCLES;state<=ST_DELAY;
                    end else begin
                        index<=index+1'b1;
                        if(index==0 || index==1) begin
                            count<=0;delay_target<=PWR_DELAY_CYCLES;state<=ST_DELAY;
                        end else state<=ST_LAUNCH;
                    end
                end
                ST_DELAY:if(count==delay_target-1) begin
                    count<=0;
                    if(index==60) begin ready_o<=1;state<=ST_READY;end
                    else state<=ST_LAUNCH;
                end else count<=count+1'b1;
                ST_READY:ready_o<=1;
            endcase
        end
    end
endmodule
