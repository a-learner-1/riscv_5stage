`timescale 1ns/1ps
// Selector for the eight-output model (background plus seven targets). The
// three modes are 100f, 120f, and 150f; background is eligible in every mode.
// Outputs are zero-based model indices. The display layer should add one.
module v1_eight_target_window_selector #(
    parameter [15:0] BABY_THRESHOLD_Q16=16'hffff,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] SIREN_THRESHOLD_Q16=16'hffff,
    parameter [15:0] FIRE_TRUCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] AMBULANCE_THRESHOLD_Q16=16'hffff,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'hffff
)(
    input wire [127:0] probs_q16_i,
    input wire [1:0] window_mode_i,
    output reg [2:0] target_class_o,
    output reg [15:0] target_score_o,
    output reg alert_o
);
    reg [15:0] threshold;
    always @* begin
        target_class_o=3'd0;
        target_score_o=probs_q16_i[0 +: 16];
        threshold=16'hffff;
        case(window_mode_i)
            2'd0: begin // 100 frames: siren, dog bark, car horn
                target_class_o=3'd0;
                target_score_o=probs_q16_i[0 +: 16];
                if(probs_q16_i[3*16 +: 16]>target_score_o) begin
                    target_class_o=3'd3; target_score_o=probs_q16_i[3*16 +: 16];
                end
                if(probs_q16_i[6*16 +: 16]>target_score_o) begin
                    target_class_o=3'd6; target_score_o=probs_q16_i[6*16 +: 16];
                end
                if(probs_q16_i[7*16 +: 16]>target_score_o) begin
                    target_class_o=3'd7; target_score_o=probs_q16_i[7*16 +: 16];
                end
            end
            2'd1: begin // 120 frames: fire truck, ambulance
                target_class_o=3'd0;
                target_score_o=probs_q16_i[0 +: 16];
                if(probs_q16_i[4*16 +: 16]>target_score_o) begin
                    target_class_o=3'd4; target_score_o=probs_q16_i[4*16 +: 16];
                end
                if(probs_q16_i[5*16 +: 16]>target_score_o) begin
                    target_class_o=3'd5; target_score_o=probs_q16_i[5*16 +: 16];
                end
            end
            2'd2: begin // 150 frames: baby cry, knock
                target_class_o=3'd0;
                target_score_o=probs_q16_i[0 +: 16];
                if(probs_q16_i[1*16 +: 16]>target_score_o) begin
                    target_class_o=3'd1; target_score_o=probs_q16_i[1*16 +: 16];
                end
                if(probs_q16_i[2*16 +: 16]>target_score_o) begin
                    target_class_o=3'd2; target_score_o=probs_q16_i[2*16 +: 16];
                end
            end
            default: begin end
        endcase
        case(target_class_o)
            3'd0: threshold=16'hffff;
            3'd1: threshold=BABY_THRESHOLD_Q16;
            3'd2: threshold=KNOCK_THRESHOLD_Q16;
            3'd3: threshold=SIREN_THRESHOLD_Q16;
            3'd4: threshold=FIRE_TRUCK_THRESHOLD_Q16;
            3'd5: threshold=AMBULANCE_THRESHOLD_Q16;
            3'd6: threshold=DOG_BARK_THRESHOLD_Q16;
            default: threshold=CAR_HORN_THRESHOLD_Q16;
        endcase
        alert_o=(window_mode_i<=2'd2) && (target_class_o!=3'd0) &&
                (target_score_o>=threshold);
    end
endmodule

// Retain only the target classes trained for the selected class-specific
// window. Background remains available in every mode for decision telemetry.
module v1_eight_class_window_filter(
    input wire [127:0] probs_q16_i,
    input wire [1:0] window_mode_i,
    output reg [127:0] probs_q16_o
);
    always @* begin
        probs_q16_o=probs_q16_i;
        case(window_mode_i)
            2'd0: begin // 100 frames: siren, dog bark, car horn
                probs_q16_o[1*16 +: 16]=0; probs_q16_o[2*16 +: 16]=0;
                probs_q16_o[4*16 +: 16]=0; probs_q16_o[5*16 +: 16]=0;
            end
            2'd1: begin // 120 frames: fire truck, ambulance
                probs_q16_o[1*16 +: 16]=0; probs_q16_o[2*16 +: 16]=0;
                probs_q16_o[3*16 +: 16]=0; probs_q16_o[6*16 +: 16]=0;
                probs_q16_o[7*16 +: 16]=0;
            end
            2'd2: begin // 150 frames: baby cry, knock
                probs_q16_o[3*16 +: 16]=0; probs_q16_o[4*16 +: 16]=0;
                probs_q16_o[5*16 +: 16]=0; probs_q16_o[6*16 +: 16]=0;
                probs_q16_o[7*16 +: 16]=0;
            end
            default: begin
                probs_q16_o[1*16 +: 16]=0; probs_q16_o[2*16 +: 16]=0;
                probs_q16_o[3*16 +: 16]=0; probs_q16_o[4*16 +: 16]=0;
                probs_q16_o[5*16 +: 16]=0; probs_q16_o[6*16 +: 16]=0;
                probs_q16_o[7*16 +: 16]=0;
            end
        endcase
    end
endmodule
