`timescale 1ns/1ps
// Display side of the alert path. Inference/controller/clock provide state;
// this module initializes the ST7789V2 and refreshes only changed regions.
module v1_tft_auto_display #(
    parameter integer FULLSCREEN_IMAGES=1,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,
    input wire [3:0] display_class_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire alert_visible_i,clock_valid_i,
    input wire [7:0] hour_i,minute_i,second_i,
    output wire panel_ready_o,panel_busy_o,
    output wire nrst_o,backlight_o,
    output wire sclk_o,mosi_o,dc_o,cs_n_o
);
    wire start,done;
    wire [7:0] x0,x1;
    wire [8:0] y0,y1;
    v1_screen_refresh_scheduler #(.FULLSCREEN_IMAGES(FULLSCREEN_IMAGES)) scheduler(
        .clk(clk),.rst_n(rst_n),.panel_ready_i(panel_ready_o),
        .panel_busy_i(panel_busy_o),.panel_done_i(done),
        .display_class_i(display_class_i),.alert_visible_i(alert_visible_i),
        .clock_valid_i(clock_valid_i),.hour_i(hour_i),.minute_i(minute_i),
        .second_i(second_i),.start_o(start),
        .x0_o(x0),.x1_o(x1),.y0_o(y0),.y1_o(y1));
    v1_tft_panel #(.FULLSCREEN_IMAGES(FULLSCREEN_IMAGES),.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ),
        .RESET_CYCLES(RESET_CYCLES),.PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) panel(
        .clk(clk),.rst_n(rst_n),.start_i(start),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .x0_i(x0),.x1_i(x1),.y0_i(y0),.y1_i(y1),
        .display_class_i(display_class_i),.alert_visible_i(alert_visible_i),
        .clock_valid_i(clock_valid_i),.hour_i(hour_i),.minute_i(minute_i),
        .second_i(second_i),.ready_o(panel_ready_o),.busy_o(panel_busy_o),
        .done_o(done),.nrst_o(nrst_o),.backlight_o(backlight_o),
        .sclk_o(sclk_o),.mosi_o(mosi_o),.dc_o(dc_o),.cs_n_o(cs_n_o));
endmodule
