`timescale 1ns/1ps
// Active-low key. Two-flop synchronizer; one press pulse after stable low.
// A new pulse requires stable high release. Long holds do not repeat.
module v1_key_debounce #(
    parameter integer DEBOUNCE_MS=20
)(
    input wire clk,rst_n,tick_ms_i,key_n_i,
    output reg press_o
);
    reg key_meta,key_sync,pressed;
    reg [15:0] stable_ms;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            key_meta<=1;key_sync<=1;pressed<=0;stable_ms<=0;press_o<=0;
        end else begin
            key_meta<=key_n_i;
            key_sync<=key_meta;
            press_o<=0;
            if(tick_ms_i) begin
                if(key_sync==!pressed) stable_ms<=0;
                else if(stable_ms==DEBOUNCE_MS-1) begin
                    stable_ms<=0;
                    pressed<=!pressed;
                    if(!key_sync) press_o<=1;
                end else stable_ms<=stable_ms+1'b1;
            end
        end
    end
endmodule
