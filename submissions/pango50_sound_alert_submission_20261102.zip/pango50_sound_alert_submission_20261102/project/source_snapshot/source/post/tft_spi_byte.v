`timescale 1ns/1ps
// tft_spi_byte — 8-bit SPI byte transmitter for the ST7789 panel chain.
// Referenced by v1_st7789_init and v1_tft_spi_window but NOT shipped in the
// unpacked backend (GATE6: implemented locally).  SPI mode 0 (CPOL=0, CPHA=0):
// sclk idles low, mosi changes while sclk is low, the slave samples on the
// rising edge.  cs_n is low for the whole byte; dc_o follows dc_i.
module tft_spi_byte #(
    parameter integer CLOCK_HZ = 50000000,
    parameter integer SPI_HZ   = 5000000
)(
    input  wire clk, rst_n,
    input  wire start_i,
    input  wire [7:0] data_i,
    input  wire dc_i,
    output wire busy_o,
    output reg  done_o,
    output reg  sclk_o,
    output reg  mosi_o,
    output reg  dc_o,
    output reg  cs_n_o
);
    localparam integer DIV    = CLOCK_HZ / SPI_HZ;   // 10
    localparam integer HALF   = DIV / 2;             // 5

    reg busy;
    reg [3:0] bitcnt;
    reg [7:0] shift;
    reg [15:0] cnt;

    assign busy_o = busy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy <= 0; done_o <= 0; sclk_o <= 0; mosi_o <= 0; dc_o <= 0;
            cs_n_o <= 1; bitcnt <= 0; shift <= 0; cnt <= 0;
        end else begin
            done_o <= 0;
            if (!busy) begin
                if (start_i) begin
                    busy <= 1; cs_n_o <= 0; dc_o <= dc_i;
                    shift <= data_i; bitcnt <= 0; cnt <= 0; sclk_o <= 0;
                    mosi_o <= data_i[7];
                end
            end else begin
                // one bit = DIV clocks: [0,HALF) sclk low, [HALF,DIV) sclk high
                if (cnt < HALF) begin
                    sclk_o <= 0;
                    cnt <= cnt + 1'b1;
                end else if (cnt < DIV-1) begin
                    sclk_o <= 1;
                    cnt <= cnt + 1'b1;
                end else begin
                    // bit done
                    if (bitcnt == 4'd7) begin
                        busy <= 0; cs_n_o <= 1; sclk_o <= 0;
                        done_o <= 1;
                    end else begin
                        bitcnt <= bitcnt + 1'b1;
                        shift <= {shift[6:0], 1'b0};
                        mosi_o <= shift[6];
                        cnt <= 0; sclk_o <= 0;
                    end
                end
            end
        end
    end
endmodule
