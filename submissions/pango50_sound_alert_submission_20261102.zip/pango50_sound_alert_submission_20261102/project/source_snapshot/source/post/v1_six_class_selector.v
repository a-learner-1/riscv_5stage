`timescale 1ns/1ps
// Six model outputs: background, baby cry, knock, emergency vehicle,
// dog bark and car horn. Output IDs stay aligned with the model and icon ROM.
module v1_six_class_selector #(
    parameter [15:0] BABY_THRESHOLD_Q16=16'hffff,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] EMERGENCY_VEHICLE_THRESHOLD_Q16=16'hffff,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'hffff
)(
    input wire [95:0] probs_q16_i,
    output reg [2:0] target_class_o,
    output reg [15:0] target_score_o,
    output reg alert_o
);
    integer c;
    reg [15:0] best_score, threshold;
    always @* begin
        target_class_o=3'd0;
        best_score=probs_q16_i[15:0];
        for(c=1;c<6;c=c+1) begin
            if(probs_q16_i[c*16 +: 16]>best_score) begin
                target_class_o=c[2:0];
                best_score=probs_q16_i[c*16 +: 16];
            end
        end
        target_score_o=best_score;
        case(target_class_o)
            3'd1: threshold=BABY_THRESHOLD_Q16;
            3'd2: threshold=KNOCK_THRESHOLD_Q16;
            3'd3: threshold=EMERGENCY_VEHICLE_THRESHOLD_Q16;
            3'd4: threshold=DOG_BARK_THRESHOLD_Q16;
            3'd5: threshold=CAR_HORN_THRESHOLD_Q16;
            default: threshold=16'hffff;
        endcase
        alert_o=(target_class_o!=3'd0) && (best_score>=threshold);
    end
endmodule
