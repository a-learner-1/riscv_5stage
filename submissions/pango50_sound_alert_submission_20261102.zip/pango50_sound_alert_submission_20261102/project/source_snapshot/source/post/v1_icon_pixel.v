`timescale 1ns/1ps
// Combinational 128x128 RGB565 icon area. CNN icons are 64x64 1bpp and
// template-bound images are 64x64 RGB565; both are scaled 2x. Class 0 returns
// background. Text and SPI are separate stages.
module v1_icon_pixel(
    input wire clk,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire [3:0] class_i,
    input wire [6:0] x_i,y_i,
    output reg [15:0] pixel_o
);
    reg [7:0] icon_rom [0:2559];
    reg [15:0] template_rgb565_rom [0:12287];
    integer address, template_address, bit_index;
    reg [15:0] color;
    reg [7:0] template_rgb565_hi_r;
    initial $readmemh("v1_run/display_assets/icons_u1.hex", icon_rom);
    initial $readmemh("v1_run/display_assets/template_rgb565.hex", template_rgb565_rom);
    always @(posedge clk) begin
        // The caller gates this write-enable to the three-image RGB565 section.
        if (display_asset_we_i === 1'b1) begin
            if (!display_asset_addr_i[0])
                template_rgb565_hi_r <= display_asset_data_i;
            else
                template_rgb565_rom[display_asset_addr_i[14:1]] <=
                    {template_rgb565_hi_r, display_asset_data_i};
        end
    end
    always @* begin
        color=16'hFFFF;
        case(class_i)
            4'd1: color=16'hE966;
            4'd2: color=16'hE500;
            4'd3: color=16'hE966;
            4'd4: color=16'h8ADE;
            4'd5: color=16'hE966;
            4'd8: color=16'h8ADE;
            4'd9: color=16'hE966;
            default: color=16'hFFFF;
        endcase
        pixel_o=16'h08E3; // solid dark green background, generated in logic
        address=0;
        template_address=0;
        bit_index=0;
        if(class_i>=8 && class_i<=10) begin
            template_address=(class_i-8)*4096 + (y_i >> 1)*64 + (x_i >> 1);
            pixel_o=template_rgb565_rom[template_address];
        end else if(class_i>=1 && class_i<=5) begin
            address=(class_i-1)*512 + (y_i >> 1)*8 + (x_i >> 4);
            bit_index=7-((x_i >> 1) & 7);
            if(icon_rom[address][bit_index]) pixel_o=color;
        end
    end
endmodule
