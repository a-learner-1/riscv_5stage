`timescale 1ns/1ps
// ST7789V2 window writer after panel initialization. Sends CASET, RASET,
// RAMWR then RGB565 pixels high byte first. Upstream supplies a pixel for
// pixel_x_o/pixel_y_o. Does not allocate a framebuffer or use DDR.
module v1_tft_spi_window #(
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000
)(
    input wire clk,rst_n,start_i,
    input wire [7:0] x0_i,x1_i,
    input wire [8:0] y0_i,y1_i,
    input wire [15:0] pixel_rgb565_i,
    output reg [7:0] pixel_x_o,
    output reg [8:0] pixel_y_o,
    output wire busy_o,
    output reg done_o,
    output wire sclk_o,mosi_o,dc_o,cs_n_o
);
    localparam ST_IDLE=0,ST_LAUNCH=1,ST_WAIT=2;
    reg [1:0] state;
    reg [3:0] header_index;
    reg pixel_phase,low_byte;
    reg [7:0] x0,x1;
    reg [8:0] y0,y1;
    reg tx_start,tx_dc;
    reg [7:0] tx_data;
    // The three-stage v1_screen_pixel rasterizer needs two clocks after a
    // coordinate advance before its pixel is valid. Hold ST_LAUNCH for two
    // cycles before raising tx_start so the RGB565 byte stays aligned.
    reg [1:0] launch_hold;
    wire tx_busy,tx_done;
    assign busy_o=(state!=ST_IDLE);
    tft_spi_byte #(.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ)) spi(
        .clk(clk),.rst_n(rst_n),.start_i(tx_start),.data_i(tx_data),.dc_i(tx_dc),
        .busy_o(tx_busy),.done_o(tx_done),.sclk_o(sclk_o),.mosi_o(mosi_o),
        .dc_o(dc_o),.cs_n_o(cs_n_o));
    always @* begin
        tx_data=0;tx_dc=0;
        if(!pixel_phase) begin
            case(header_index)
                0:tx_data=8'h2A; // CASET
                1:begin tx_data=0;tx_dc=1;end
                2:begin tx_data=x0;tx_dc=1;end
                3:begin tx_data=0;tx_dc=1;end
                4:begin tx_data=x1;tx_dc=1;end
                5:tx_data=8'h2B; // RASET
                6:begin tx_data=y0[8]?8'h01:8'h00;tx_dc=1;end
                7:begin tx_data=y0[7:0];tx_dc=1;end
                8:begin tx_data=y1[8]?8'h01:8'h00;tx_dc=1;end
                9:begin tx_data=y1[7:0];tx_dc=1;end
                default:tx_data=8'h2C; // RAMWR
            endcase
        end else begin
            tx_data=low_byte ? pixel_rgb565_i[7:0] : pixel_rgb565_i[15:8];
            tx_dc=1;
        end
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=ST_IDLE;tx_start<=0;header_index<=0;pixel_phase<=0;low_byte<=0;
            x0<=0;x1<=0;y0<=0;y1<=0;pixel_x_o<=0;pixel_y_o<=0;done_o<=0;
            launch_hold<=0;
        end else begin
            tx_start<=0;done_o<=0;
            case(state)
                ST_IDLE: if(start_i && x0_i<=x1_i && y0_i<=y1_i) begin
                    x0<=x0_i;x1<=x1_i;y0<=y0_i;y1<=y1_i;
                    pixel_x_o<=x0_i;pixel_y_o<=y0_i;
                    header_index<=0;pixel_phase<=0;low_byte<=0;
                    state<=ST_LAUNCH;
                end
                ST_LAUNCH: if(!tx_busy) begin
                    if(launch_hold==2) begin
                        tx_start<=1;state<=ST_WAIT;launch_hold<=0;
                    end else begin
                        launch_hold<=launch_hold+1'b1;
                    end
                end
                ST_WAIT: if(tx_done) begin
                    if(!pixel_phase) begin
                        if(header_index==10) begin pixel_phase<=1;low_byte<=0;end
                        else header_index<=header_index+1'b1;
                        state<=ST_LAUNCH;
                    end else if(!low_byte) begin
                        low_byte<=1;state<=ST_LAUNCH;
                    end else begin
                        low_byte<=0;
                        if(pixel_x_o==x1) begin
                            pixel_x_o<=x0;
                            if(pixel_y_o==y1) begin
                                state<=ST_IDLE;done_o<=1;
                            end else begin
                                pixel_y_o<=pixel_y_o+1'b1;state<=ST_LAUNCH;
                            end
                        end else begin
                            pixel_x_o<=pixel_x_o+1'b1;state<=ST_LAUNCH;
                        end
                    end
                end
            endcase
        end
    end
endmodule
