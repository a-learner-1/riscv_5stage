`timescale 1ns/1ps
// Complete reset/init + rectangle stream for the portrait ST7789V2.
// A page scheduler should request the clock region each second and the
// alert region when its state changes; requests are accepted only when idle.
module v1_tft_panel #(
    parameter integer FULLSCREEN_IMAGES=0,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,start_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire [7:0] x0_i,x1_i,
    input wire [8:0] y0_i,y1_i,
    input wire [3:0] display_class_i,
    input wire alert_visible_i,clock_valid_i,
    input wire [7:0] hour_i,minute_i,second_i,
    output wire ready_o,busy_o,done_o,
    output wire nrst_o,backlight_o,
    output wire sclk_o,mosi_o,dc_o,cs_n_o
);
    wire init_sclk,init_mosi,init_dc,init_cs;
    wire page_sclk,page_mosi,page_dc,page_cs;
    wire page_busy;
    v1_st7789_init #(.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ),
        .RESET_CYCLES(RESET_CYCLES),.PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) init(
        .clk(clk),.rst_n(rst_n),.ready_o(ready_o),.nrst_o(nrst_o),
        .backlight_o(backlight_o),.sclk_o(init_sclk),.mosi_o(init_mosi),
        .dc_o(init_dc),.cs_n_o(init_cs));
    v1_tft_page #(.FULLSCREEN_IMAGES(FULLSCREEN_IMAGES),.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ)) page(
        .clk(clk),.rst_n(rst_n),.start_i(start_i && ready_o && !page_busy),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .x0_i(x0_i),.x1_i(x1_i),.y0_i(y0_i),.y1_i(y1_i),
        .display_class_i(display_class_i),.alert_visible_i(alert_visible_i),
        .clock_valid_i(clock_valid_i),.hour_i(hour_i),.minute_i(minute_i),
        .second_i(second_i),.busy_o(page_busy),.done_o(done_o),
        .sclk_o(page_sclk),.mosi_o(page_mosi),.dc_o(page_dc),.cs_n_o(page_cs));
    assign busy_o=!ready_o || page_busy;
    assign sclk_o=ready_o ? page_sclk : init_sclk;
    assign mosi_o=ready_o ? page_mosi : init_mosi;
    assign dc_o=ready_o ? page_dc : init_dc;
    assign cs_n_o=ready_o ? page_cs : init_cs;
endmodule
