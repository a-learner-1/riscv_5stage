`timescale 1ns/1ps
// Board-facing V1 backend. UART: R/r starts work mode, C/c acknowledges.
// Both local keys are active low. Recognition enable must gate the upstream
// inference scheduler; results arriving during an alert are ignored here.
module v1_board_postcnn_top #(
    parameter FIVE_CLASS_MODE=0,
    parameter EIGHT_CLASS_MODE=0,
    parameter SIX_CLASS_MODE=0,
    parameter ONE_SHOT_MODE=0,
    parameter [15:0] BABY_THRESHOLD_Q16=16'hffff,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] SIREN_THRESHOLD_Q16=16'hffff,
    parameter [15:0] FIRE_TRUCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] AMBULANCE_THRESHOLD_Q16=16'hffff,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'hffff,
    parameter [15:0] EMERGENCY_VEHICLE_THRESHOLD_Q16=16'hffff,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,work_key_n_i,confirm_key_n_i,uart_rx_i,
    input wire template_preview_i,
    input wire [3:0] template_preview_class_i,
    input wire external_task_busy_i,
    input wire probs_valid_i,
    input wire [16*(SIX_CLASS_MODE ? 6 : (EIGHT_CLASS_MODE ? 8 : 7))-1:0] probs_q16_i,
    input wire template_result_valid_i,
    input wire [1:0] template_result_class_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire short_window_i,
    input wire set_time_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    output wire motor_o,recognition_enable_o,work_mode_o,
    output wire alert_accept_o,confirm_pulse_o,
    output wire panel_ready_o,panel_busy_o,
    output wire tft_nrst_o,tft_backlight_o,
    output wire tft_sclk_o,tft_mosi_o,tft_dc_o,tft_cs_n_o
);
    wire [127:0] probs_q16_wide = SIX_CLASS_MODE ? {32'd0,probs_q16_i} :
                                    (EIGHT_CLASS_MODE ? probs_q16_i : {16'd0,probs_q16_i});
    wire tick_ms,work_press,confirm_press,uart_valid;
    wire [7:0] uart_data;
    wire uart_start=uart_valid && (uart_data=="R" || uart_data=="r");
    wire uart_confirm=uart_valid && (uart_data=="C" || uart_data=="c");
    assign confirm_pulse_o=confirm_press|uart_confirm;
    v1_ms_tick #(.CLOCK_HZ(CLOCK_HZ)) ms_tick(
        .clk(clk),.rst_n(rst_n),.tick_ms_o(tick_ms));
    v1_key_debounce work_key(.clk(clk),.rst_n(rst_n),
        .tick_ms_i(tick_ms),.key_n_i(work_key_n_i),.press_o(work_press));
    v1_key_debounce confirm_key(.clk(clk),.rst_n(rst_n),
        .tick_ms_i(tick_ms),.key_n_i(confirm_key_n_i),.press_o(confirm_press));
    uart_rx_8n1 #(.CLOCK_HZ(CLOCK_HZ),.BAUD(115200)) uart_rx(
        .clk(clk),.rst_n(rst_n),.rx_i(uart_rx_i),
        .data_o(uart_data),.valid_o(uart_valid));
    v1_alert_display_top #(.FIVE_CLASS_MODE(FIVE_CLASS_MODE),
        .EIGHT_CLASS_MODE(EIGHT_CLASS_MODE),
        .SIX_CLASS_MODE(SIX_CLASS_MODE),
        .ONE_SHOT_MODE(ONE_SHOT_MODE),
        .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
        .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
        .SIREN_THRESHOLD_Q16(SIREN_THRESHOLD_Q16),
        .FIRE_TRUCK_THRESHOLD_Q16(FIRE_TRUCK_THRESHOLD_Q16),
        .AMBULANCE_THRESHOLD_Q16(AMBULANCE_THRESHOLD_Q16),
        .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
        .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16),
        .EMERGENCY_VEHICLE_THRESHOLD_Q16(EMERGENCY_VEHICLE_THRESHOLD_Q16),
        .CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ),
        .RESET_CYCLES(RESET_CYCLES),.PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) path(
        .clk(clk),.rst_n(rst_n),
        .template_preview_i(template_preview_i),
        .template_preview_class_i(template_preview_class_i),
        .probs_valid_i(probs_valid_i),.probs_q16_i(probs_q16_wide),
        .template_result_valid_i(template_result_valid_i),
        .template_result_class_i(template_result_class_i),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .short_window_i(short_window_i),
        .external_task_busy_i(external_task_busy_i),
        .start_i(work_press|uart_start),.ack_i(confirm_pulse_o),
        .set_time_i(set_time_i),.set_hour_i(set_hour_i),
        .set_minute_i(set_minute_i),.set_second_i(set_second_i),
        .recognition_enable_o(recognition_enable_o),.work_mode_o(work_mode_o),
        .alert_accept_o(alert_accept_o),
        .motor_o(motor_o),.panel_ready_o(panel_ready_o),
        .panel_busy_o(panel_busy_o),.tft_nrst_o(tft_nrst_o),
        .tft_backlight_o(tft_backlight_o),.tft_sclk_o(tft_sclk_o),
        .tft_mosi_o(tft_mosi_o),.tft_dc_o(tft_dc_o),
        .tft_cs_n_o(tft_cs_n_o));
endmodule
