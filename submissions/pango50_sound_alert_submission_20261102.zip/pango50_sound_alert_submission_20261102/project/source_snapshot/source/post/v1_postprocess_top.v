`timescale 1ns/1ps
// RTL post-processing integration point. probs_valid_i is a completed V1
// inference pulse; start/ack pulses are decoded by the board wrapper.
module v1_postprocess_top #(
    parameter integer CLOCK_HZ=50000000
)(
    input wire clk,rst_n,
    input wire probs_valid_i,
    input wire [111:0] probs_q16_i,
    input wire start_i,ack_i,
    input wire set_time_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    input wire [6:0] icon_x_i,icon_y_i,
    input wire [7:0] screen_x_i,
    input wire [8:0] screen_y_i,
    output wire motor_o,
    output wire recognition_enable_o,work_mode_o,
    output wire [3:0] display_class_o,
    output wire display_valid_o,
    output wire [15:0] icon_rgb565_o,
    output wire [15:0] screen_rgb565_o,
    output wire clock_valid_o,
    output wire [7:0] hour_o,minute_o,second_o
);
    wire [2:0] target_class;
    wire [15:0] target_score;
    wire alert;
    wire tick_1s;
    wire [31:0] seconds_since_midnight;
    v1_target_selector selector(.probs_q16_i(probs_q16_i),
        .target_class_o(target_class),.target_score_o(target_score),.alert_o(alert));
    v1_wall_clock #(.CLOCK_HZ(CLOCK_HZ)) wall_clock(
        .clk(clk),.rst_n(rst_n),.set_i(set_time_i),.set_hour_i(set_hour_i),
        .set_minute_i(set_minute_i),.set_second_i(set_second_i),
        .valid_o(clock_valid_o),.hour_o(hour_o),.minute_o(minute_o),
        .second_o(second_o),.tick_1s_o(tick_1s),
        .seconds_since_midnight_o(seconds_since_midnight));
    v1_alert_controller alerts(
        .clk(clk),.rst_n(rst_n),.start_i(start_i),.ack_i(ack_i),
        .external_task_busy_i(1'b0),
        .class_valid_i(probs_valid_i),.class_id_i(target_class),
        .class_score_pass_i(alert),.recognition_enable_o(recognition_enable_o),
        .work_mode_o(work_mode_o),.motor_o(motor_o),
        .display_class_o(display_class_o),.display_valid_o(display_valid_o));
    v1_icon_pixel icon(.class_i(display_valid_o ? display_class_o : 4'd0),
        .x_i(icon_x_i),.y_i(icon_y_i),.pixel_o(icon_rgb565_o));
    reg [7:0] label_x0,label_x1;
    always @* begin
        case (display_class_o)
            4'd1,4'd4: begin label_x0=72; label_x1=168; end
            4'd3,4'd5: begin label_x0=60; label_x1=180; end
            4'd2,4'd6: begin label_x0=96; label_x1=144; end
            4'd8,4'd9: begin label_x0=24; label_x1=216; end
            default: begin label_x0=120; label_x1=120; end
        endcase
    end
    v1_screen_pixel screen(.clk(clk),.rst_n(rst_n),
        .x_i(screen_x_i),.y_i(screen_y_i),
        .label_x0_i(label_x0),.label_x1_i(label_x1),
        .class_i(display_class_o),.alert_visible_i(display_valid_o),
        .clock_valid_i(clock_valid_o),.hour_i(hour_o),
        .minute_i(minute_o),.second_i(second_o),.pixel_o(screen_rgb565_o));
endmodule
