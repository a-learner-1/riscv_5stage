`timescale 1ns/1ps
module v1_ms_tick #(
    parameter integer CLOCK_HZ=50000000
)(
    input wire clk,rst_n,
    output reg tick_ms_o
);
    localparam integer CYCLES_PER_MS=CLOCK_HZ/1000;
    reg [31:0] divider;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin divider<=0;tick_ms_o<=0;end
        else begin
            tick_ms_o<=0;
            if(divider==CYCLES_PER_MS-1) begin
                divider<=0;tick_ms_o<=1;
            end else divider<=divider+1'b1;
        end
    end
endmodule
