`timescale 1ns/1ps
// Single-event alert policy. Start arms recognition; one accepted result
// latches the motor and display until an explicit acknowledgement.
module v1_alert_controller #(
    parameter ONE_SHOT = 0
)(
    input wire clk,rst_n,
    input wire start_i,ack_i,external_task_busy_i,
    input wire class_valid_i,
    input wire [3:0] class_id_i,
    input wire class_score_pass_i,
    output wire recognition_enable_o,
    output wire work_mode_o,
    output reg motor_o,
    output reg [3:0] display_class_o,
    output reg display_valid_o
);
    localparam [1:0] OFF=2'd0, LISTEN=2'd1, ALERT=2'd2, DONE=2'd3;
    reg [1:0] state;
    reg capture_seen_r;
    wire accepted = class_valid_i && class_score_pass_i &&
                    class_id_i>=4'd1 && class_id_i<=4'd10;

    assign recognition_enable_o = (state==LISTEN) ||
                                  (ONE_SHOT && state==ALERT &&
                                   capture_seen_r && external_task_busy_i);
    assign work_mode_o = (state!=OFF);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=OFF;
            motor_o<=0;
            display_class_o<=0;
            display_valid_o<=0;
            capture_seen_r<=0;
        end else begin
            case(state)
                OFF: if(start_i) begin
                    state<=LISTEN;
                    capture_seen_r<=external_task_busy_i;
                end
                // A classification result is not a completed listening
                // session. Background and scores below threshold must leave
                // the microphone and both recognition paths running.
                LISTEN: if(ack_i && ONE_SHOT) begin
                    state<=DONE;
                    motor_o<=0;
                    display_class_o<=0;
                    display_valid_o<=0;
                    capture_seen_r<=0;
                end else if(accepted) begin
                    state<=ALERT;
                    motor_o<=1'b1;
                    display_class_o<=class_id_i;
                    display_valid_o<=1'b1;
                    if (external_task_busy_i) capture_seen_r<=1'b1;
                end else if(external_task_busy_i) begin
                    // UART capture runs beside live recognition.  Remember
                    // that a capture began and stop listening only after its
                    // final UART byte has drained (busy returns low).
                    capture_seen_r<=1'b1;
                end else if(capture_seen_r && !ONE_SHOT) begin
                    // A template take must never end the recognition session.
                    // In ONE_SHOT mode the session is finished only by the
                    // user's acknowledgement; otherwise one button take would
                    // silently switch recognition off and leave a preview
                    // screen that looks like a stuck alarm.
                    state<=DONE;
                    capture_seen_r<=1'b0;
                end
                ALERT: if(ack_i) begin
                    // One shot: acknowledging always parks the session in DONE.
                    // Returning to LISTEN here re-armed the matcher before its
                    // first 1 s window, so an alert reappeared about a second
                    // after the user cleared it.
                    state<=(ONE_SHOT) ? DONE : LISTEN;
                    motor_o<=0;
                    display_class_o<=0;
                    display_valid_o<=0;
                    if (ONE_SHOT)
                        capture_seen_r<=1'b0;
                end
                DONE: if(start_i) state<=LISTEN;
                default: state<=OFF;
            endcase
        end
    end
endmodule
