`timescale 1ns/1ps
// Post-inference path. Recognition is armed explicitly and suspended during
// an alert; a single acknowledgement clears the latched motor and display.
module v1_alert_display_top #(
    parameter FIVE_CLASS_MODE=0,
    parameter EIGHT_CLASS_MODE=0,
    parameter SIX_CLASS_MODE=0,
    parameter ONE_SHOT_MODE=0,
    parameter [15:0] BABY_THRESHOLD_Q16=16'hffff,
    parameter [15:0] KNOCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] SIREN_THRESHOLD_Q16=16'hffff,
    parameter [15:0] FIRE_TRUCK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] AMBULANCE_THRESHOLD_Q16=16'hffff,
    parameter [15:0] DOG_BARK_THRESHOLD_Q16=16'hffff,
    parameter [15:0] CAR_HORN_THRESHOLD_Q16=16'hffff,
    parameter [15:0] EMERGENCY_VEHICLE_THRESHOLD_Q16=16'hffff,
    parameter integer CLOCK_HZ=50000000,
    parameter integer SPI_HZ=5000000,
    parameter integer RESET_CYCLES=500000,
    parameter integer PWR_DELAY_CYCLES=6000000,
    parameter integer DISPLAY_DELAY_CYCLES=1000000
)(
    input wire clk,rst_n,
    input wire template_preview_i,
    input wire [3:0] template_preview_class_i,
    input wire probs_valid_i,
    input wire [127:0] probs_q16_i,
    input wire template_result_valid_i,
    input wire [1:0] template_result_class_i,
    input wire display_asset_we_i,
    input wire [14:0] display_asset_addr_i,
    input wire [7:0] display_asset_data_i,
    input wire short_window_i,
    input wire start_i,ack_i,external_task_busy_i,
    input wire set_time_i,
    input wire [7:0] set_hour_i,set_minute_i,set_second_i,
    output wire recognition_enable_o,work_mode_o,
    output wire alert_accept_o,
    output wire motor_o,
    output wire panel_ready_o,panel_busy_o,
    output wire tft_nrst_o,tft_backlight_o,
    output wire tft_sclk_o,tft_mosi_o,tft_dc_o,tft_cs_n_o
);
    wire [3:0] target_class,display_class;
    wire [2:0] cnn_target_class;
    wire [15:0] target_score;
    wire alert,display_valid,clock_valid,tick_1s;
    wire [7:0] hour,minute,second;
    wire [31:0] seconds_since_midnight;
    wire template_preview_valid = template_preview_i &&
                                  (template_preview_class_i>=4'd1) &&
                                  (template_preview_class_i<=4'd11);
    wire [3:0] screen_class = (template_preview_valid && !display_valid) ?
                               template_preview_class_i : display_class;
    wire screen_visible = display_valid || template_preview_valid;
    generate if (FIVE_CLASS_MODE) begin : five_class_decision
        v1_five_class_selector selector(.probs_q16_i(probs_q16_i[79:0]),
        .short_window_i(short_window_i),.target_class_o(cnn_target_class),
            .target_score_o(target_score),.alert_o(alert));
    end else if (SIX_CLASS_MODE) begin : six_class_decision
        v1_six_class_selector #(
            .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
            .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
            .EMERGENCY_VEHICLE_THRESHOLD_Q16(EMERGENCY_VEHICLE_THRESHOLD_Q16),
            .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
            .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16)) selector(
            .probs_q16_i(probs_q16_i[95:0]),
            .target_class_o(cnn_target_class),.target_score_o(target_score),.alert_o(alert));
    end else if (EIGHT_CLASS_MODE) begin : eight_class_decision
        v1_eight_class_selector #(
            .BABY_THRESHOLD_Q16(BABY_THRESHOLD_Q16),
            .KNOCK_THRESHOLD_Q16(KNOCK_THRESHOLD_Q16),
            .SIREN_THRESHOLD_Q16(SIREN_THRESHOLD_Q16),
            .FIRE_TRUCK_THRESHOLD_Q16(FIRE_TRUCK_THRESHOLD_Q16),
            .AMBULANCE_THRESHOLD_Q16(AMBULANCE_THRESHOLD_Q16),
            .DOG_BARK_THRESHOLD_Q16(DOG_BARK_THRESHOLD_Q16),
            .CAR_HORN_THRESHOLD_Q16(CAR_HORN_THRESHOLD_Q16)) selector(
            .probs_q16_i(probs_q16_i),
            .target_class_o(cnn_target_class),.target_score_o(target_score),.alert_o(alert));
    end else begin : legacy_decision
        v1_target_selector selector(.probs_q16_i(probs_q16_i),
            .target_class_o(cnn_target_class),.target_score_o(target_score),.alert_o(alert));
    end endgenerate
    wire template_match = (template_result_valid_i === 1'b1) &&
                          (template_result_class_i >= 2'd1 && template_result_class_i <= 2'd3);
    wire event_valid = probs_valid_i || template_match;
    wire [3:0] event_class = template_match ? (4'd7 + {2'b00,template_result_class_i}) :
                                              {1'b0,cnn_target_class};
    wire event_score_pass = template_match || alert;
    // Register the alert-accept pulse so the combinational softmax->argmax
    // decision (12 logic levels in v1_five_class_selector) and its threshold
    // compares are NOT in the same 100 MHz period as the scheduler's
    // core_start -> mn04_core op_act_r clock-enable.  alert is latched by the
    // scheduler on the next edge, and the next snapshot is ~180 ms away, so a
    // one-cycle delay is functionally transparent.
    reg alert_accept_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) alert_accept_r <= 1'b0;
        else alert_accept_r <= event_valid && event_score_pass && recognition_enable_o &&
                               (!ONE_SHOT_MODE || !display_valid);
    end
    assign alert_accept_o = alert_accept_r;
    v1_wall_clock #(.CLOCK_HZ(CLOCK_HZ)) wall_clock(
        .clk(clk),.rst_n(rst_n),.set_i(set_time_i),
        .set_hour_i(set_hour_i),.set_minute_i(set_minute_i),
        .set_second_i(set_second_i),.valid_o(clock_valid),
        .hour_o(hour),.minute_o(minute),.second_o(second),
        .tick_1s_o(tick_1s),.seconds_since_midnight_o(seconds_since_midnight));
    v1_alert_controller #(.ONE_SHOT(ONE_SHOT_MODE)) alerts(
        .clk(clk),.rst_n(rst_n),.start_i(start_i),.ack_i(ack_i),
        .external_task_busy_i(external_task_busy_i),
        .class_valid_i(event_valid),.class_id_i(event_class),
        .class_score_pass_i(event_score_pass),.recognition_enable_o(recognition_enable_o),
        .work_mode_o(work_mode_o),.motor_o(motor_o),
        .display_class_o(display_class),.display_valid_o(display_valid));
    v1_tft_auto_display #(.CLOCK_HZ(CLOCK_HZ),.SPI_HZ(SPI_HZ),
        .RESET_CYCLES(RESET_CYCLES),.PWR_DELAY_CYCLES(PWR_DELAY_CYCLES),
        .DISPLAY_DELAY_CYCLES(DISPLAY_DELAY_CYCLES)) display(
        .clk(clk),.rst_n(rst_n),.display_class_i(screen_class),
        .display_asset_we_i(display_asset_we_i),
        .display_asset_addr_i(display_asset_addr_i),
        .display_asset_data_i(display_asset_data_i),
        .alert_visible_i(screen_visible),.clock_valid_i(clock_valid),
        .hour_i(hour),.minute_i(minute),.second_i(second),
        .panel_ready_o(panel_ready_o),.panel_busy_o(panel_busy_o),
        .nrst_o(tft_nrst_o),.backlight_o(tft_backlight_o),
        .sclk_o(tft_sclk_o),.mosi_o(tft_mosi_o),
        .dc_o(tft_dc_o),.cs_n_o(tft_cs_n_o));
endmodule
