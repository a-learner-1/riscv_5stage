`timescale 1ns/1ps
// Request full screen once, then only the changed alert or clock region.
// The page writer snapshots its input state when it accepts start_o.
module v1_screen_refresh_scheduler #(
    parameter integer FULLSCREEN_IMAGES=0
)(
    input wire clk,rst_n,
    input wire panel_ready_i,panel_busy_i,panel_done_i,
    input wire [3:0] display_class_i,
    input wire alert_visible_i,clock_valid_i,
    input wire [7:0] hour_i,minute_i,second_i,
    output reg start_o,
    output reg [7:0] x0_o,x1_o,
    output reg [8:0] y0_o,y1_o
);
    reg initialized,request_inflight;
    reg [3:0] sent_class;
    reg sent_alert_visible,sent_clock_valid;
    reg [7:0] sent_hour,sent_minute,sent_second;
    wire alert_changed=(display_class_i!=sent_class) ||
                       (alert_visible_i!=sent_alert_visible);
    wire clock_changed=(clock_valid_i!=sent_clock_valid) ||
                       (hour_i!=sent_hour) || (minute_i!=sent_minute) ||
                       (second_i!=sent_second);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            start_o<=0;
            x0_o<=0;x1_o<=239;y0_o<=0;y1_o<=319;
            initialized<=0;request_inflight<=0;
            sent_class<=0;sent_alert_visible<=0;sent_clock_valid<=0;
            sent_hour<=0;sent_minute<=0;sent_second<=0;
        end else begin
            start_o<=0;
            if(panel_done_i) request_inflight<=0;
            if(panel_ready_i && !panel_busy_i && !request_inflight) begin
                if(!initialized || alert_changed || (!FULLSCREEN_IMAGES && clock_changed)) begin
                    start_o<=1;
                    request_inflight<=1;
                    x0_o<=0;x1_o<=239;
                    if(!initialized || FULLSCREEN_IMAGES) begin y0_o<=0;y1_o<=319;end
                    else if(alert_changed) begin y0_o<=41;y1_o<=319;end
                    else begin y0_o<=0;y1_o<=40;end
                    initialized<=1;
                    sent_class<=display_class_i;
                    sent_alert_visible<=alert_visible_i;
                    sent_clock_valid<=clock_valid_i;
                    sent_hour<=hour_i;
                    sent_minute<=minute_i;
                    sent_second<=second_i;
                end
            end
        end
    end
endmodule
