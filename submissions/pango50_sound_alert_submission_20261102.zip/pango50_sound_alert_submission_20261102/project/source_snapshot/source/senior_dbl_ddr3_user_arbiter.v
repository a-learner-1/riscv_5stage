`timescale 1ns/1ps
// Round-robin arbiter muxing five single-beat DDR3 user-port masters onto the
// one ddr3_host_top port, all in the ddr_core_clk domain:
//   master 0 = CPU window bridge (ddr3_axi_bridge)
//   master 1..4 = the shared CNN core's four conv tiles
//
// Every master performs one transaction at a time and HOLDS awvalid/arvalid
// until awready/arready (ddr3_axi_bridge already did this; senior_dbl_ddr3_tile
// was changed to match).  The arbiter grants a master, forwards its address and
// write beat to the host, returns the host's responses to that master only, and
// releases the grant once the transaction completes:
//   write = address handshake (awvalid&awready), then data pull (wready)
//   read  = address handshake (arvalid&arready), then data push (rvalid)
// Separating the address and data phases means a level-high WREADY (the Pango
// controller keeps the user port ready) cannot falsely complete a write before
// the master has entered its data phase.
module senior_dbl_ddr3_user_arbiter (
    input  wire clk, rst_n,
    // ---- master 0: CPU bridge ----
    input  wire [27:0] m0_awaddr, m0_araddr,
    input  wire [3:0]  m0_awlen,  m0_arlen,
    input  wire        m0_awvalid, m0_arvalid,
    output wire        m0_awready, m0_arready,
    input  wire [255:0] m0_wdata,
    input  wire [31:0]  m0_wstrb,
    output wire        m0_wready,
    output wire [255:0] m0_rdata,
    output wire        m0_rlast, m0_rvalid,
    // ---- master 1 ----
    input  wire [27:0] m1_awaddr, m1_araddr,
    input  wire [3:0]  m1_awlen,  m1_arlen,
    input  wire        m1_awvalid, m1_arvalid,
    output wire        m1_awready, m1_arready,
    input  wire [255:0] m1_wdata,
    input  wire [31:0]  m1_wstrb,
    output wire        m1_wready,
    output wire [255:0] m1_rdata,
    output wire        m1_rlast, m1_rvalid,
    // ---- master 2 ----
    input  wire [27:0] m2_awaddr, m2_araddr,
    input  wire [3:0]  m2_awlen,  m2_arlen,
    input  wire        m2_awvalid, m2_arvalid,
    output wire        m2_awready, m2_arready,
    input  wire [255:0] m2_wdata,
    input  wire [31:0]  m2_wstrb,
    output wire        m2_wready,
    output wire [255:0] m2_rdata,
    output wire        m2_rlast, m2_rvalid,
    // ---- master 3 ----
    input  wire [27:0] m3_awaddr, m3_araddr,
    input  wire [3:0]  m3_awlen,  m3_arlen,
    input  wire        m3_awvalid, m3_arvalid,
    output wire        m3_awready, m3_arready,
    input  wire [255:0] m3_wdata,
    input  wire [31:0]  m3_wstrb,
    output wire        m3_wready,
    output wire [255:0] m3_rdata,
    output wire        m3_rlast, m3_rvalid,
    // ---- master 4 ----
    input  wire [27:0] m4_awaddr, m4_araddr,
    input  wire [3:0]  m4_awlen,  m4_arlen,
    input  wire        m4_awvalid, m4_arvalid,
    output wire        m4_awready, m4_arready,
    input  wire [255:0] m4_wdata,
    input  wire [31:0]  m4_wstrb,
    output wire        m4_wready,
    output wire [255:0] m4_rdata,
    output wire        m4_rlast, m4_rvalid,
    // ---- slave: ddr3_host_top user port ----
    output wire [27:0] s_awaddr, s_araddr,
    output wire [3:0]  s_awlen,  s_arlen,
    output wire        s_awvalid, s_arvalid,
    input  wire        s_awready, s_arready,
    output wire [255:0] s_wdata,
    output wire [31:0]  s_wstrb,
    input  wire        s_wready,
    input  wire [255:0] s_rdata,
    input  wire        s_rlast, s_rvalid
);
    // ---- packed master-side arrays ----
    wire [27:0] m_awaddr [0:4];
    wire [27:0] m_araddr [0:4];
    wire [3:0]  m_awlen  [0:4];
    wire [3:0]  m_arlen  [0:4];
    wire        m_awvalid[0:4];
    wire        m_arvalid[0:4];
    wire [255:0] m_wdata [0:4];
    wire [31:0]  m_wstrb [0:4];
    wire        m_awready[0:4];
    wire        m_arready[0:4];
    wire        m_wready [0:4];
    wire [255:0] m_rdata [0:4];
    wire        m_rlast  [0:4];
    wire        m_rvalid [0:4];

    assign m_awaddr[0] = m0_awaddr; assign m_awaddr[1] = m1_awaddr;
    assign m_awaddr[2] = m2_awaddr; assign m_awaddr[3] = m3_awaddr;
    assign m_awaddr[4] = m4_awaddr;
    assign m_araddr[0] = m0_araddr; assign m_araddr[1] = m1_araddr;
    assign m_araddr[2] = m2_araddr; assign m_araddr[3] = m3_araddr;
    assign m_araddr[4] = m4_araddr;
    assign m_awlen[0] = m0_awlen; assign m_awlen[1] = m1_awlen;
    assign m_awlen[2] = m2_awlen; assign m_awlen[3] = m3_awlen;
    assign m_awlen[4] = m4_awlen;
    assign m_arlen[0] = m0_arlen; assign m_arlen[1] = m1_arlen;
    assign m_arlen[2] = m2_arlen; assign m_arlen[3] = m3_arlen;
    assign m_arlen[4] = m4_arlen;
    assign m_awvalid[0] = m0_awvalid; assign m_awvalid[1] = m1_awvalid;
    assign m_awvalid[2] = m2_awvalid; assign m_awvalid[3] = m3_awvalid;
    assign m_awvalid[4] = m4_awvalid;
    assign m_arvalid[0] = m0_arvalid; assign m_arvalid[1] = m1_arvalid;
    assign m_arvalid[2] = m2_arvalid; assign m_arvalid[3] = m3_arvalid;
    assign m_arvalid[4] = m4_arvalid;
    assign m_wdata[0] = m0_wdata; assign m_wdata[1] = m1_wdata;
    assign m_wdata[2] = m2_wdata; assign m_wdata[3] = m3_wdata;
    assign m_wdata[4] = m4_wdata;
    assign m_wstrb[0] = m0_wstrb; assign m_wstrb[1] = m1_wstrb;
    assign m_wstrb[2] = m2_wstrb; assign m_wstrb[3] = m3_wstrb;
    assign m_wstrb[4] = m4_wstrb;

    assign m0_awready = m_awready[0]; assign m1_awready = m_awready[1];
    assign m2_awready = m_awready[2]; assign m3_awready = m_awready[3];
    assign m4_awready = m_awready[4];
    assign m0_arready = m_arready[0]; assign m1_arready = m_arready[1];
    assign m2_arready = m_arready[2]; assign m3_arready = m_arready[3];
    assign m4_arready = m_arready[4];
    assign m0_wready = m_wready[0]; assign m1_wready = m_wready[1];
    assign m2_wready = m_wready[2]; assign m3_wready = m_wready[3];
    assign m4_wready = m_wready[4];
    assign m0_rdata = m_rdata[0]; assign m1_rdata = m_rdata[1];
    assign m2_rdata = m_rdata[2]; assign m3_rdata = m_rdata[3];
    assign m4_rdata = m_rdata[4];
    assign m0_rlast = m_rlast[0]; assign m1_rlast = m_rlast[1];
    assign m2_rlast = m_rlast[2]; assign m3_rlast = m_rlast[3];
    assign m4_rlast = m_rlast[4];
    assign m0_rvalid = m_rvalid[0]; assign m1_rvalid = m_rvalid[1];
    assign m2_rvalid = m_rvalid[2]; assign m3_rvalid = m_rvalid[3];
    assign m4_rvalid = m_rvalid[4];

    // ---- request vector + round-robin grant ----
    wire [4:0] req;
    assign req = { m_awvalid[4] | m_arvalid[4],
                   m_awvalid[3] | m_arvalid[3],
                   m_awvalid[2] | m_arvalid[2],
                   m_awvalid[1] | m_arvalid[1],
                   m_awvalid[0] | m_arvalid[0] };

    reg [2:0] gnt;
    reg [2:0] gnt_nxt;
    reg       found;
    integer   k;
    always @(*) begin
        gnt_nxt = gnt;
        found   = 1'b0;
        for (k = 1; k <= 5 && !found; k = k + 1) begin
            if (req[(gnt + k) % 5]) begin
                gnt_nxt = (gnt + k) % 5;
                found   = 1'b1;
            end
        end
    end

    // ---- transaction lock ----
    reg       busy;
    reg       is_wr;      // 1 = write (aw channel), 0 = read (ar channel)
    reg       aw_done;    // address handshake observed
    reg       ar_done;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gnt     <= 3'd0;
            busy    <= 1'b0;
            is_wr   <= 1'b0;
            aw_done <= 1'b0;
            ar_done <= 1'b0;
        end else if (!busy) begin
            aw_done <= 1'b0;
            ar_done <= 1'b0;
            if (|req) begin
                gnt   <= gnt_nxt;
                is_wr <= m_awvalid[gnt_nxt];
                busy  <= 1'b1;
            end
        end else begin
            if (is_wr) begin
                if (!aw_done)
                    aw_done <= s_awvalid && s_awready;
                else if (s_wready)
                    busy <= 1'b0;
            end else begin
                if (!ar_done)
                    ar_done <= s_arvalid && s_arready;
                else if (s_rvalid)
                    busy <= 1'b0;
            end
        end
    end

    // ---- forward the granted master to the host ----
    assign s_awvalid = busy && is_wr && !aw_done && m_awvalid[gnt];
    assign s_arvalid = busy && !is_wr && !ar_done && m_arvalid[gnt];
    assign s_awaddr  = m_awaddr[gnt];
    assign s_awlen   = m_awlen[gnt];
    assign s_araddr  = m_araddr[gnt];
    assign s_arlen   = m_arlen[gnt];
    assign s_wdata   = m_wdata[gnt];
    assign s_wstrb   = m_wstrb[gnt];

    // ---- return the host's responses to the granted master only ----
    genvar i;
    generate
        for (i = 0; i < 5; i = i + 1) begin : gen_m
            assign m_awready[i] = (busy && is_wr && !aw_done && gnt == i) ? s_awready : 1'b0;
            assign m_arready[i] = (busy && !is_wr && !ar_done && gnt == i) ? s_arready : 1'b0;
            assign m_wready[i]  = (busy && is_wr && aw_done && gnt == i) ? s_wready : 1'b0;
            assign m_rvalid[i]  = (busy && !is_wr && ar_done && gnt == i) ? s_rvalid : 1'b0;
            assign m_rlast[i]   = (busy && !is_wr && ar_done && gnt == i) ? s_rlast : 1'b0;
            assign m_rdata[i]   = s_rdata;
        end
    endgenerate
endmodule
