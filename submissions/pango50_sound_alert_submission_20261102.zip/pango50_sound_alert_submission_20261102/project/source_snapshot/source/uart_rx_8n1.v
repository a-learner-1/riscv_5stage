`timescale 1ns/1ps
// Receive-only 8-N-1 UART.  It emits one valid pulse for every received byte.
module uart_rx_8n1 #(
    parameter integer CLOCK_HZ=50000000,
    parameter integer BAUD=115200
)(
    input wire clk,rst_n,rx_i,
    output reg [7:0] data_o,
    output reg valid_o
);
    localparam integer BIT_CYCLES=CLOCK_HZ/BAUD;
    reg [1:0] rx_sync;
    reg [1:0] state;
    reg [31:0] count;
    reg [2:0] bit_index;
    reg [7:0] shift;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin rx_sync<=2'b11;state<=0;count<=0;bit_index<=0;shift<=0;data_o<=0;valid_o<=0;end
        else begin
            rx_sync<={rx_sync[0],rx_i};valid_o<=0;
            case(state)
                0:if(!rx_sync[1]) begin state<=1;count<=0;end
                1:if(count==(BIT_CYCLES/2)-1) begin
                    count<=0;
                    if(!rx_sync[1]) begin state<=2;bit_index<=0;end else state<=0;
                end else count<=count+1'b1;
                2:if(count==BIT_CYCLES-1) begin
                    count<=0;shift[bit_index]<=rx_sync[1];
                    if(bit_index==7) state<=3; else bit_index<=bit_index+1'b1;
                end else count<=count+1'b1;
                default:if(count==BIT_CYCLES-1) begin
                    count<=0;state<=0;
                    if(rx_sync[1]) begin data_o<=shift;valid_o<=1;end
                end else count<=count+1'b1;
            endcase
        end
    end
endmodule
