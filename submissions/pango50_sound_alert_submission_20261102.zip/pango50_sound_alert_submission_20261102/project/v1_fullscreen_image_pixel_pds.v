`timescale 1ns/1ps
// Eight complete stored pages, including any text baked into the image.
// 108x144, 16 colours per page. Nine 4-bit pixels share one 36-bit ROM word.
// The entire 240x320 raster is filled; there are no live UI overlays.
module v1_fullscreen_image_pixel(
    input wire clk,rst_n,
    input wire [7:0] x_i,
    input wire [8:0] y_i,
    input wire [3:0] class_i,
    input wire visible_i,
    output reg [15:0] pixel_o
);
    reg [15:0] palette_rom[0:127];
    reg [7:0] x_rom[0:255],y_rom[0:511];
    initial begin
        $readmemh("C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_palette.hex",palette_rom);
        $readmemh("C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_x.hex",x_rom);
        $readmemh("C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_y.hex",y_rom);
    end
    reg [2:0] page;
    reg valid;
    always @* begin
        page=0;valid=visible_i;
        case(class_i)
            1:page=0; 2:page=1; 3:page=2; 4:page=3; 5:page=4;
            8:page=5; 9:page=6; 10:page=7;
            default:valid=0;
        endcase
    end
    reg [13:0] address_r;
    reg [3:0] lane_r,lane2_r;
    reg [2:0] page_r,page2_r;
    reg valid_r,valid2_r;
    wire [503:0] bank_words;
    reg [3:0] bank_r;
    wire [35:0] word_r=bank_words[bank_r*36+:36];
    wire [7:0] source_x=x_rom[x_i];
    wire [7:0] source_y=y_rom[y_i];
    wire [3:0] index=(word_r >> {lane2_r,2'b00});
    // Small synchronous banks avoid the PDS large initialized-ROM mod-gen crash.
    genvar b;
    generate for(b=0;b<14;b=b+1) begin:g_banks
        v1_fullscreen_image_bank #(.BANK(b)) bank(.clk(clk),
            .address_i(address_r[9:0]),.word_o(bank_words[b*36+:36]));
    end endgenerate
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            address_r<=0;lane_r<=0;lane2_r<=0;page_r<=0;page2_r<=0;
            valid_r<=0;valid2_r<=0;bank_r<=0;pixel_o<=16'h08e3;
        end else begin
            address_r<=page*14'd1728+source_y*14'd12+source_x[7:4];
            lane_r<=source_x[3:0];page_r<=page;valid_r<=valid;
            lane2_r<=lane_r;page2_r<=page_r;valid2_r<=valid_r;
            bank_r<=address_r[13:10];
            pixel_o<=valid2_r ? palette_rom[{page2_r,index}] : 16'h08e3;
        end
    end
endmodule

module v1_fullscreen_image_bank #(parameter integer BANK=0)(
    input wire clk,input wire [9:0] address_i,output reg [35:0] word_o
);
    localparam FILE_LO = BANK==0?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b00_0.hex":
        BANK==1?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b01_0.hex":
        BANK==2?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b02_0.hex":
        BANK==3?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b03_0.hex":
        BANK==4?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b04_0.hex":
        BANK==5?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b05_0.hex":
        BANK==6?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b06_0.hex":
        BANK==7?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b07_0.hex":
        BANK==8?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b08_0.hex":
        BANK==9?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b09_0.hex":
        BANK==10?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b10_0.hex":
        BANK==11?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b11_0.hex":
        BANK==12?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b12_0.hex":
                 "C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b13_0.hex";
    localparam FILE_HI = BANK==0?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b00_1.hex":
        BANK==1?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b01_1.hex":
        BANK==2?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b02_1.hex":
        BANK==3?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b03_1.hex":
        BANK==4?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b04_1.hex":
        BANK==5?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b05_1.hex":
        BANK==6?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b06_1.hex":
        BANK==7?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b07_1.hex":
        BANK==8?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b08_1.hex":
        BANK==9?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b09_1.hex":
        BANK==10?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b10_1.hex":
        BANK==11?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b11_1.hex":
        BANK==12?"C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b12_1.hex":
                 "C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030/fullscreen_roms/fullscreen_b13_1.hex";
    reg [17:0] lo[0:1023],hi[0:1023];
    initial $readmemh(FILE_LO,lo);
    initial $readmemh(FILE_HI,hi);
    always @(posedge clk) word_o<={hi[address_i],lo[address_i]};
endmodule
