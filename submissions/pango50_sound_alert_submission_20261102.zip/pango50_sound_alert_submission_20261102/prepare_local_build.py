#!/usr/bin/env python3
"""Prepare a relocation-only PDS build copy; original RTL is never edited."""
from pathlib import Path
import argparse, hashlib, json, re, shutil

PACKAGE = Path(__file__).resolve().parent
ORIGINAL = 'C:/Studying_file/pango50_sound_alert_v1/build/pds/mn04_cpu5_template_baby45_20261030'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=PACKAGE / 'build_work',
                        help='new empty directory for generated PDS work')
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise SystemExit(f'Output already exists; choose another directory: {output}')
    original = PACKAGE / 'project'
    assets = json.loads((PACKAGE / 'external_assets_map.json').read_text(encoding='utf-8'))
    for source, target in assets.items():
        if not (PACKAGE / target).is_file():
            raise SystemExit(f'Missing copied external asset: {target} (original {source})')
    shutil.copytree(original, output)
    replacements = {source: (PACKAGE / target).resolve().as_posix() for source, target in assets.items()}
    replacements[ORIGINAL] = output.as_posix()
    changes = []
    for path in output.rglob('*'):
        if not path.is_file() or path.suffix.lower() not in ('.v', '.vp', '.fdc', '.pds', '.tcl'):
            continue
        data = path.read_bytes()
        modified = data
        for old, new in sorted(replacements.items(), key=lambda item: len(item[0]), reverse=True):
            modified = modified.replace(old.encode('utf-8'), new.encode('utf-8'))
        if modified != data:
            path.write_bytes(modified)
            changes.append(path.relative_to(output).as_posix())
    script = output / 'build_romfix.tcl'
    inputs = re.findall(r'add_design\s+"([^"]+)"', script.read_text(encoding='utf-8'))
    missing = [name for name in inputs if not Path(name).is_file()]
    if missing:
        raise SystemExit('Missing PDS design inputs: ' + json.dumps(missing, ensure_ascii=False))
    report = {'source_project': str(original), 'generated_project': str(output),
              'pds_design_inputs': len(inputs), 'missing_design_inputs': missing,
              'relocation_only_files': changes,
              'original_board_bitstream_sha256': hashlib.sha256((original/'mn04_sound_alert_soc_with_model.sfc').read_bytes()).hexdigest(),
              'status': 'paths and design input existence checked; synthesis and board operation not checked'}
    (output / 'relocation_check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print('Run PDS with build_romfix.tcl in the generated directory; this has not been built or board-tested.')

if __name__ == '__main__':
    main()
