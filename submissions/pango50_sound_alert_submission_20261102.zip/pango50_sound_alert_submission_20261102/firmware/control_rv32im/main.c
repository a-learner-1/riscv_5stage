/* Control only: no FFT, CNN MACs, pixel copying, or template dot products.
 * AXI-Lite mailboxes latch accelerator completions until an ISR consumes them.
 * Score order uses stable screen IDs 0,1,2,3,4,5; dog slot 4 is disabled.
 */
typedef unsigned int u32;
#define R(n) (*(volatile u32 *)(0x80000000u+(n)))
enum { KEY=1,SNAPSHOT=2,CNN=4,TEMPLATE=8,DONE=16,SLOT=32 };
enum { WORK=1,CONFIRM=2,NEXT=4,RECORD=8,STOP=16,FAMILY=32 };
enum { BOOT=1,CODEC=2,LISTEN=4,BUSY=8,RECORDING=16,ALERT=32 };
static u32 previous_class,previous_time,consecutive;

static void keys(void) {
    u32 events=R(0),s=R(4),command=0;
    if(s&64) return; /* command stretched for downstream debounce */
    R(8)=events;
    if((s&(BOOT|CODEC))!=(BOOT|CODEC)) return;
    if(events&CONFIRM) { command|=CONFIRM;previous_class=0;consecutive=0; }
    if((events&STOP)&&(s&RECORDING)) command|=STOP;
    if(!(s&(LISTEN|BUSY|ALERT))) {
        if(events&WORK) command|=WORK;
        else if(events&RECORD) {
            /* CPU chooses an empty slot in the selected pure-template class.
             * The datapath must reject RECORD when every slot is occupied. */
            u32 cls=R(0x44),valid=R(0x48),slot;
            if(cls>=5 && cls<8) {
                u32 base=(cls-5)*5;
                for(slot=0;slot<5;slot++) if(!(valid&(1u<<(base+slot)))) break;
                if(slot==5) return;
                R(0x4c)=base+slot;
            }
            command|=RECORD;
        } else command|=events&(NEXT|FAMILY);
    }
    if(command) R(12)=command;
}

static void classify(void) {
    u32 cls=0,best=R(0x60),i,now=R(0x38),minimum=R(0x54),limit=R(0x58);
    for(i=1;i<6;i++) { u32 p=R(0x60+i*4); if(i!=4 && p>best) {best=p;cls=i;} }
    if(!cls || best<R(0x80+cls*4)) { previous_class=0;consecutive=0;R(0x40)=0;return; }
    if(cls==previous_class && now-previous_time<=limit) consecutive++;
    else consecutive=1;
    previous_class=cls;previous_time=now;
    if(consecutive>=(minimum?minimum:1)) R(0x40)=cls;
    else R(0x40)=0;
}

void __attribute__((interrupt("machine"),aligned(4))) irq_handler(void) {
    u32 pending=R(0x20),template_claim=0;
    /* Pure template identity has priority over the CNN out-of-set guess. */
    if(pending&TEMPLATE) {
        u32 match=R(0x3c),cls=match&3,score=match>>16;
        if(cls && score>=R(0x50) && (R(4)&LISTEN)) { R(0x40)=cls+7;template_claim=1; }
    }
    if(pending&CNN) { if(!template_claim && (R(4)&LISTEN)) classify(); }
    if(pending&SNAPSHOT) { if((R(4)&LISTEN) && !(R(4)&(ALERT|BUSY))) R(0x34)=1; }
    if(pending&KEY) keys();
    R(0x24)=pending;
}

int main(void) {
    volatile int a=37,b=9;
    int product,quotient,remainder;
    /* Exercise the actual M instructions; never infer ISA support from a name. */
    __asm__ volatile("mul %0,%3,%4\n\tdiv %1,%3,%4\n\trem %2,%3,%4"
        :"=&r"(product),"=&r"(quotient),"=&r"(remainder):"r"(a),"r"(b));
    if(product!=333 || quotient!=4 || remainder!=1) { R(20)=0xbad00001;for(;;); }
    R(0x5c)=0x4d554c44; /* MULD self-test complete */
    R(0x54)=1; /* user can later calibrate repeat-window rule */
    R(0x58)=2000;
    R(0x28)=KEY|SNAPSHOT|CNN|TEMPLATE|DONE|SLOT;
    __asm__ volatile("csrw mtvec,%0\n\tli t0,1\n\tcsrw 0xbc0,t0\n\tli t0,2048\n\tcsrw mie,t0\n\tcsrsi mstatus,8"::"r"(irq_handler):"t0","memory");
    R(20)=0x56584d32; /* VXM2: firmware initialized, interrupts enabled */
    for(;;) {
        /* A pending key may outlive the previous stretched command. Re-arm
         * its IRQ after the command settles, without re-reading a held key. */
        if(R(0) && !(R(4)&64)) R(0x2c)=KEY;
        __asm__ volatile("nop");
    }
}
