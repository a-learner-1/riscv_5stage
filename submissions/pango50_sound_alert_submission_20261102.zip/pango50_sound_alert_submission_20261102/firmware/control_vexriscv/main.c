/* VexRiscv board supervisor. No OS or host link is required.
 * Hardware owns sample timing, DMA and per-layer accelerator scheduling.
 * Firmware owns admission of user commands and recognition/capture mode. */
typedef unsigned int u32;
#define REG(offset) (*(volatile u32 *)(0x80000000u+(offset)))
enum { WORK=1, CONFIRM=2, NEXT=4, RECORD=8, STOP=16, FAMILY=32 };
enum { BOOT=1, CODEC=2, LISTEN=4, BUSY=8, RECORDING=16, ALERT=32 };
int main(void) {
    REG(20)=0x56583531; /* VX51: firmware reached main */
    for (;;) {
        u32 events=REG(0), status=REG(4), commands=0;
        if (!events) continue;
        if (status&64) continue; /* prior command is still crossing the key debounce */
        REG(8)=events; /* acknowledge only the observed sticky key events */
        if ((status&(BOOT|CODEC)) != (BOOT|CODEC)) continue;
        if (events&CONFIRM) commands|=CONFIRM;
        if ((events&STOP) && (status&RECORDING)) commands|=STOP;
        if (!(status&(LISTEN|BUSY|ALERT))) {
            /* Work and capture are mutually exclusive, including simultaneous keys. */
            if (events&WORK) commands|=WORK;
            else if (events&RECORD) commands|=RECORD;
            else commands|=events&(NEXT|FAMILY);
        }
        if (commands) REG(12)=commands;
    }
}
