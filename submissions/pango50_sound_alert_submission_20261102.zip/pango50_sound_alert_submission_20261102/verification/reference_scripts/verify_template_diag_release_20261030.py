from pathlib import Path
import json,hashlib,argparse
parser=argparse.ArgumentParser()
parser.add_argument('--build-dir',type=Path,default=Path(__file__).resolve().parents[1]/'build/pds/mn04_cpu5_template_diag_20261030')
args=parser.parse_args()
b=args.build_dir.resolve()
s=(b/'mn04_sound_alert_soc_with_model.sfc').read_bytes()
bit=(b/'prj_tasks/pnr_1/generate_bitstream/mn04_sound_alert_soc.sbit').read_bytes()
dif=[i for i,(x,y) in enumerate(zip(bit,s)) if x!=y]
assert dif==[2102,2103],dif[:30]
parts=[];end=len(bit)
for name,addr in [('model_mn04_six_class_windows.bin',0x400000),('icons_sector_0x600000.bin',0x600000)]:
    d=(b/name).read_bytes()
    assert s[addr:addr+len(d)]==d
    assert all(v==255 for v in s[end:addr])
    end=addr+len(d);parts.append(name)
assert len(s)==end
assert 'Design Summary : All Constraints Met.' in (b/'prj_tasks/pnr_1/report_timing/mn04_sound_alert_soc.rtr').read_text()
r=dict(status='PASS',sfc_sha256=hashlib.sha256(s).hexdigest(),sfc_bytes=len(s),configuration_differences=dif,partitions=parts,timing_constraints_met=True,physical_programmed=False)
(b/'release_verification_20261030.json').write_text(json.dumps(r,indent=2))
(b/'BUILD_STATUS.txt').write_text('PDS compile/synthesis/map/place/route/bitstream PASS. All Constraints Met. SFC partitions verified. Template UART telemetry and new baby/knock/horn pages included. Not physically programmed; board recognition verification pending.\n')
print(json.dumps(r,indent=2))
