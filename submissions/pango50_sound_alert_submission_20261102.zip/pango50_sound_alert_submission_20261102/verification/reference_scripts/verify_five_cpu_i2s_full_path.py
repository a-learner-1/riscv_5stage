"""Five-class released image: I2S/frontend/DDR/91 ops/CPU IRQ/event outputs.

One fixture is a consistency regression, never a board accuracy estimate.
"""
import argparse,hashlib,json,re,shutil,subprocess,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import verify_six_class_audio_rtl as model_ref
from short_head_quantization import q16_softmax
sys.path.insert(0,str(ROOT/'sim/frontend/gen'));import ref_model as frontend_ref
MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--build-dir',type=Path,required=True);ap.add_argument('--out-dir',type=Path,required=True)
    ap.add_argument('--pcm32-file',type=Path);ap.add_argument('--silence',action='store_true')
    ap.add_argument('--fixture-offset',type=int,default=0,help='circular offset in 48 kHz fixture samples; never changes production warmup')
    ap.add_argument('--with-sd-card',action='store_true',help='enable the actual 15-slot DDR/SD boot path with a blank modeled card')
    ap.add_argument('--reference-only',action='store_true')
    ap.add_argument('--verify-existing',action='store_true',help='validate saved RTL artifacts without restarting simulation')
    ap.add_argument('--warmup-frames',type=int,default=400)
    ap.add_argument('--i2s-half-cycles',type=int,default=4)
    args=ap.parse_args();build=args.build_dir.resolve();out=args.out_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((build/'six_class_build_manifest.json').read_text())
    assert manifest['current_five_class_mode'] and manifest['cpu_control']['task_control']
    package=ROOT/'training/output/pc_five_class_fixed120_deployment_20261024'
    image=(build/'model_mn04_six_class_windows.bin').read_bytes()
    assert hashlib.sha256(image).hexdigest()==manifest['model_sha256']=='db0530e019db7fb0c413e3649bd756003dfe81414c1bfcf33dd1dcf596b3c306'
    (out/'image.hex').write_text(''.join(f'{x:02x}\n' for x in image))
    if args.silence:base=np.zeros(32000,dtype=np.int16)
    elif args.pcm32_file:base=np.frombuffer(args.pcm32_file.read_bytes(),dtype='<i2')
    else:base=np.frombuffer((ROOT/'sim/frontend/golden/car_horn_car_horn_001.pcm_s16le.bin').read_bytes(),dtype='<i2')
    pairs=base[:len(base)//2*2].reshape(-1,2)
    original=np.column_stack((pairs[:,0],pairs[:,1],pairs[:,1])).reshape(-1)
    original=np.roll(original,-args.fixture_offset)
    if args.warmup_frames<0 or args.i2s_half_cycles<4:raise ValueError('negative warmup or overflowing accelerated I2S timing')
    n_frames=args.warmup_frames+120
    pcm=np.resize(original,(n_frames+4)*480)
    (out/'pcm48.hex').write_text(''.join(f'{int(x)&65535:04x}\n' for x in pcm))
    groups=pcm.astype(np.int32).reshape(-1,3);sums=groups[:,1]+groups[:,2]
    pcm32=np.column_stack((groups[:,0],np.where(sums>=0,(sums+1)>>1,sums>>1))).reshape(-1)
    pre=frontend_ref.preemph(pcm32);frames=[]
    for frame in range(n_frames):
        wnd=[0]*1024
        for m in range(112,912):
            sample=abs(frame*320-512+m);wnd[m]=frontend_ref.rnd(pre[sample+1]*frontend_ref.HANN[m-112],15)
        frames.append(frontend_ref.to_x0(frontend_ref.mel_bands(frontend_ref.fft1024_power(wnd))))
    reference_frontend=np.asarray(frames,dtype=np.int8);x0=reference_frontend[args.warmup_frames:n_frames].T.copy()
    (out/'x0.hex').write_text(''.join(f'{int(x)&255:02x}\n' for x in x0.flat))
    bb,layers,fixed,meta,scales=model_ref.current.build_chain()
    ops=json.loads((package/'op_desc_120f_six_class.json').read_text());golden=out/'golden';golden.mkdir(exist_ok=True)
    *_,embedding,dumps=model_ref.forward_hardware_reference(x0.reshape(1,1,128,120),bb,layers,model_ref.current.load_head(),fixed,meta,scales,ops,golden)
    with np.load(package/'head_quant.npz',allow_pickle=False) as z:
        q0=tuple(z[k] for k in ('h0_weight','h0_mult','h0_shift','h0_bias'));q1=tuple(z[k] for k in ('h1_weight','h1_mult','h1_shift','h1_bias'))
    expected=model_ref.quant_head(np.asarray(embedding,dtype=np.int8).reshape(384),q0,q1)
    lut=np.array([int(x,16) for x in (package/'softmax_exp_q24_six_class.mem').read_text().split()]);probs=q16_softmax(expected,lut)
    winner=int(np.argmax(probs));label=manifest['class_order'][winner]
    accepted=winner!=0 and int(probs[winner])>=manifest['thresholds_q16'][label]
    event=(5 if winner==4 else winner) if accepted else 0
    initial={'expected_logits':np.asarray(expected).tolist(),'probabilities_q16':probs.tolist(),'expected_event':event,'warmup_frames':args.warmup_frames,'fixture_offset_48k':args.fixture_offset}
    (out/'reference.json').write_text(json.dumps(initial,indent=2));print(json.dumps(initial),flush=True)
    if args.reference_only:return
    for folder in ('rom','v1_run'):shutil.copytree(build/folder,out/folder,dirs_exist_ok=True)
    def run(command,name):
        with (out/name).open('w') as f:r=subprocess.run([str(x) for x in command],cwd=out,stdout=f,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError(str(out/name))
    lib='work_five_cpu_i2s'
    if not args.verify_existing and not (out/lib).exists():run([MS/'vlib.exe',lib],'vlib.log')
    sources=list((ROOT/'source/mn04').glob('*.v'))+[p for p in (ROOT/'source/post').glob('*.v') if p.name!='v1_fullscreen_image_pixel.v']+list((ROOT/'source/frontend').glob('*.v'))
    sources+=[ROOT/'source'/name for name in ('es8311_i2s_receiver.v','pcm_decimator_48k_to_32k.v','senior_dbl_ddr3_user_arbiter.v','uart_rx_8n1.v','uart_tx_8n1.v','sd/sd_card_spi.v')]
    sources+=[ROOT/'third_party/pythondata_cpu_vexriscv/pythondata_cpu_vexriscv/verilog/VexRiscv_Lite.v',ROOT/'sim/sd/sd_card_model.v',build/'v1_fullscreen_image_pixel_pds.v',ROOT/'sim/mn04/tb_mn04_runtime_fabric_short.v']
    if not args.verify_existing:run([MS/'vlog.exe','-quiet','+define+USE_DDR_WEIGHTS','-work',lib,*sources],'compile.log')
    if not args.verify_existing:(out/'rtl_inputs_sha256.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2))
    params=dict(OP_FILE=build/'op_desc_120f_six_class.mem',IMAGE_HEX=out/'image.hex',X0_HEX=out/'x0.hex',F0_HEX=golden/'f0_out.hex',PCM_FILE=out/'pcm48.hex',SOFTMAX_LUT_FILE=build/'softmax_exp_q24_six_class.mem',I2S_INPUT=1,I2S_HALF_CYCLES=args.i2s_half_cycles,SIX_CLASS_MODE=1,CLASS_WINDOW_MODE=1,UNIFORM_120_WINDOW=1,CURRENT_FIVE_CLASS=1,CPU_TASK_CONTROL=1,TEMPLATE_DDR_STORAGE=1,TEMPLATE_MAPS_PER_CLASS=5,N_FRAMES=120,PCM_SAMPLES=len(pcm),MODEL_CHECKSUM="32'h"+manifest['model_sum32'],EXPECTED_DISPLAY_CLASS=event,EXPECT_NO_ALERT=int(event==0),EXPECTED_WARMUP_FRAMES=args.warmup_frames,CPU_FIRMWARE_FILE=build/'control.mem')
    for key,label in [('BABY','baby_cry'),('KNOCK','knock'),('SIREN','emergency_vehicle_siren'),('CAR','car_horn')]:params[f'FUSED_{key}_THRESHOLD_Q16']=manifest['thresholds_q16'][label]
    params['SD_ENABLED']=int(args.with_sd_card)
    if not args.verify_existing:run([MS/'vsim.exe','-c',lib+'.tb_mn04_runtime_fabric_short',*[f'-g{k}={v}' for k,v in params.items()],'-do','run -all; quit -f'],'sim.log')
    log=(out/'sim.log').read_text(errors='replace')
    if 'UNIFORM120_I2S_FULL_PATH_PASS' not in log or '** Fatal' in log:raise RuntimeError(str(out/'sim.log'))
    def read_mem(path):
        # Older harnesses saved only 512 frames. Preserve that explicit limit;
        # the complete 120-frame snapshot is independently checked below.
        words=[x for l in path.read_text().splitlines() if not l.lstrip().startswith('//') for x in l.split()]
        known=[]
        for word in words:
            if 'x' in word.lower() or 'z' in word.lower():break
            known.append(int(word,16))
        return np.array(known,dtype=np.uint8).view(np.int8)
    captured=read_mem(out/'frontend_capture.hex')[:n_frames*128];snapshot=read_mem(out/'runtime_x0_at_op0.hex')
    actual=re.search(r'FABRIC_LOGITS6 \[([^]]+)\]',log);logits=[int(x) for x in actual.group(1).split(',')][:5]
    assert captured.size>=min(n_frames,512)*128 and snapshot.size==120*128
    result={**initial,'rtl_logits':logits,'frontend_bytes_checked':int(captured.size),'frontend_mismatches':int(np.count_nonzero(captured!=reference_frontend.reshape(-1)[:captured.size])),'snapshot_bytes_checked':int(snapshot.size),'snapshot_mismatches':int(np.count_nonzero(snapshot!=x0.reshape(-1))),'logit_mismatches':int(np.count_nonzero(logits!=np.asarray(expected))),'model_sha256':manifest['model_sha256'],'scope':'one I2S fixture, full arithmetic and real CPU controls; accelerated clocks; not board or dataset accuracy'}
    result['sd_card_enabled']=args.with_sd_card
    result['status']='PASS' if not any(result[k] for k in ('frontend_mismatches','snapshot_mismatches','logit_mismatches')) else 'FAIL'
    (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
    if result['status']!='PASS':raise RuntimeError('RTL consistency mismatch')
if __name__=='__main__':main()
