import json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')
out=ROOT/'build/sim/template_ddr_bank_20261025';out.mkdir(parents=True,exist_ok=True)
def run(args,name):
    with (out/name).open('w') as f:r=subprocess.run([str(a) for a in args],cwd=out,stdout=f,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError(str(out/name))
lib='work_template_ddr'
if not (out/lib).exists():run([MS/'vlib.exe',lib],'vlib.log')
files=[ROOT/'source/mn04'/f for f in ['mn04_wmerge_bridge.v','mn04_ddr_act_byte_writer.v','mn04_ddr_act_read_cache.v','mn04_template_ddr_bank.v']]
run([MS/'vlog.exe','-quiet','-work',lib,*files,ROOT/'sim/mn04/tb_template_ddr_bank.v'],'compile.log')
run([MS/'vsim.exe','-c',lib+'.tb_template_ddr_bank','-do','run -all; quit -f'],'sim.log')
log=(out/'sim.log').read_text(errors='replace')
if 'TEMPLATE_DDR_BANK_PASS' not in log or '** Fatal' in log:raise RuntimeError(str(out/'sim.log'))
result={'status':'PASS','markers':[l for l in log.splitlines() if 'TEMPLATE_DDR_BANK_PASS' in l]}
(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
