"""Build the CPU5 control firmware image used by the isolated MN04 variant."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "firmware/control_cpu5"
DEFAULT_OUT = ROOT / "build/pds/mn04_cpu5_replacement_20261028"
DEFAULT_TOOL = Path(r"C:/Studying_app/FPGA/fpga_design/tools/xpack-riscv-none-elf-gcc-15.2.0-1/bin")
ROM_BYTES = 32 * 1024
RAM_WORDS = 4096


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def write_words(path, data, words, fill):
    if len(data) > words * 4:
        raise ValueError(f"image too large for {path.name}: {len(data)} > {words * 4}")
    values = [int.from_bytes(data[i:i+4].ljust(4, b"\0"), "little")
              for i in range(0, len(data), 4)]
    values += [fill] * (words - len(values))
    path.write_text("".join(f"{value:08x}\n" for value in values), encoding="ascii", newline="\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--tool-dir", type=Path, default=DEFAULT_TOOL)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    gcc = args.tool_dir / "riscv-none-elf-gcc.exe"
    objcopy = args.tool_dir / "riscv-none-elf-objcopy.exe"
    objdump = args.tool_dir / "riscv-none-elf-objdump.exe"
    elf = args.out / "control_cpu5.elf"
    text_bin = args.out / "control_cpu5_text.bin"
    data_bin = args.out / "control_cpu5_data.bin"
    flags = ["-march=rv32im_zicsr", "-mabi=ilp32", "-Os", "-nostdlib", "-nostartfiles",
             "-ffreestanding", "-fno-builtin", "-fno-pic", "-fno-stack-protector",
             "-msmall-data-limit=0", "-mno-relax", "-Wl,--no-relax", "-Wl,--build-id=none",
             "-T", str(SRC / "link.ld")]
    subprocess.run([str(gcc), *flags, str(SRC / "start.S"), str(SRC / "main.c"), "-o", str(elf)], check=True)
    subprocess.run([str(objcopy), "-O", "binary", "-j", ".text", elf, text_bin], check=True)
    subprocess.run([str(objcopy), "-O", "binary", "-j", ".data", elf, data_bin], check=True)
    subprocess.run([str(objdump), "-d", elf], check=True, stdout=(args.out / "control_cpu5.dis").open("wb"))
    text = text_bin.read_bytes()
    data = data_bin.read_bytes()
    if len(text) > ROM_BYTES:
        raise ValueError(f"CPU5 control text exceeds ROM: {len(text)} bytes")
    write_words(args.out / "control_cpu5.mem", text, ROM_BYTES // 4, 0x00000013)
    write_words(args.out / "control_cpu5_data.mem", data, RAM_WORDS, 0)
    manifest = {
        "status": "BUILT_NOT_SIMULATED_OR_DOWNLOADED",
        "core": "riscv_3stage-main CPU5 five-stage implementation",
        "isa": "RV32IM_Zicsr",
        "rom_bytes": ROM_BYTES,
        "ram_words": RAM_WORDS,
        "ram_base": "0x00010000",
        "control_bus": "AXI4-Lite single outstanding",
        "interrupts": "machine external interrupt, standard M-mode CSRs",
        "custom_vex_csr_removed": "0xbc0",
        "text_bytes": len(text),
        "data_bytes": len(data),
        "text_sha256": sha256(text),
        "data_sha256": sha256(data),
        "firmware_sha256": sha256((SRC / "main.c").read_bytes()),
        "files": {
            name: sha256((args.out / name).read_bytes())
            for name in ("control_cpu5.mem", "control_cpu5_data.mem")
        },
    }
    (args.out / "control_cpu5_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": manifest["status"], "text_bytes": len(text), "data_bytes": len(data),
                      "rom_image": str(args.out / "control_cpu5.mem")}, indent=2))


if __name__ == "__main__":
    main()
