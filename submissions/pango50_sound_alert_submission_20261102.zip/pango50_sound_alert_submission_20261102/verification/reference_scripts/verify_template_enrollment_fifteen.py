import json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')
out=ROOT/'build/sim/template_enrollment_fifteen_20261025';out.mkdir(parents=True,exist_ok=True)
def run(args,name):
    with (out/name).open('w') as f:r=subprocess.run([str(a) for a in args],cwd=out,stdout=f,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError(str(out/name))
lib='work_enroll15'
if not (out/lib).exists():run([MS/'vlib.exe',lib],'vlib.log')
run([MS/'vlog.exe','-quiet','-work',lib,ROOT/'source/mn04/mn04_template_enrollment.v',ROOT/'sim/mn04/tb_template_enrollment_fifteen.v'],'compile.log')
run([MS/'vsim.exe','-c',lib+'.tb_template_enrollment_fifteen','-do','run -all; quit -f'],'sim.log')
log=(out/'sim.log').read_text(errors='replace')
if 'TEMPLATE_ENROLLMENT_FIFTEEN_PASS' not in log or '** Fatal' in log:raise RuntimeError(str(out/'sim.log'))
result={'status':'PASS','markers':[l for l in log.splitlines() if 'TEMPLATE_ENROLLMENT_FIFTEEN_PASS' in l]}
(out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
