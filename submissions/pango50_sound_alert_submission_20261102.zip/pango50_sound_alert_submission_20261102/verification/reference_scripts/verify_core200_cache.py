"""Cache pipeline tests, including three-cycle residual admission pulses."""
from pathlib import Path
import argparse,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--variant-root',type=Path,default=ROOT/'experiments/core200_pipe2_20261028')
ap.add_argument('--out-dir',type=Path,default=ROOT/'build/sim/core200_pipe2_cache_20261028')
ap.add_argument('--pad-transition-check',action='store_true');args=ap.parse_args()
EXP=args.variant_root.resolve();OUT=args.out_dir.resolve();OUT.mkdir(parents=True,exist_ok=True)
MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')
t=(ROOT/'sim/mn04/tb_mn04_ddr_act_read_cache.v').read_text().replace('always #5','always #2.5')
t=t.replace('integer n, i;','integer n, i;\n    integer pulse_phase=0; reg pulse_test=0;\n    always @(negedge clk) if(pulse_test) begin\n      pulse_phase=(pulse_phase+1)%3;candidate_valid=(pulse_phase==0);\n    end')
t=t.replace('''        $display("ACT_READ_CACHE_PASS");''','''        // Residual valid is a one-cycle pulse every three clocks. A delayed
        // candidate-valid pipeline must not deadlock the admission handshake.
        pulse_test=1;
        for(i=0;i<128;i=i+1) begin
            @(negedge clk);candidate_addr=24'h100+(i%32);
            n=0;
            while(!(candidate_valid&&candidate_ready)&&n<100)begin @(negedge clk);n=n+1;end
            if(n==100)$fatal(1,"three-cycle candidate pulse deadlocked i=%0d",i);
            rd_addr=candidate_addr;rd_valid=1;
            @(negedge clk);rd_valid=0;
            await_read({8'h03,8'h02,8'h01,8'h00}+32'h04040404*(i%32/4),i%4);
        end
        pulse_test=0;candidate_valid=0;
        $display("ACT_READ_CACHE_PASS residual_pulses=128");''')
# Memory byte pattern in the inherited TB initializes only its first 256 bytes.
t=t.replace('''        pulse_test=1;''','''        for(i=0;i<32;i=i+1)ddr.mem[24'h100+i]=i;
        pulse_test=1;''')
t=t.replace('#10000; $fatal', '#100000; $fatal')
if args.pad_transition_check:
 t=t.replace('''        pulse_test=0;candidate_valid=0;''','''        pulse_test=0;candidate_valid=0;
        // A pad result must not turn into a cache hit when only pad changes.
        @(negedge clk);candidate_addr=24'h100100;candidate_pad=1;candidate_valid=1;
        repeat(4) @(negedge clk);
        if(!candidate_ready)$fatal(1,"padded candidate not ready");
        candidate_pad=0;#1;
        if(candidate_ready)$fatal(1,"stale padded hit admitted an uncached address");
        await_candidate();candidate_valid=0;
        // A successful tag lookup covers all 32 bytes of its cache line.
        repeat(3) @(negedge clk);
        candidate_addr=24'h10011f;#1;
        if(!candidate_ready)$fatal(1,"same-line candidate needlessly stalled");
        // A hit for the previous line must not admit an unseen next line.
        candidate_valid=1;candidate_addr=24'h100120;#1;
        if(candidate_ready)$fatal(1,"stale hit admitted a different uncached line");
        await_candidate();
        // Return to the original line before testing its invalidation.
        candidate_addr=24'h10011f;await_candidate();candidate_valid=0;
        @(negedge clk);invalidate=1;write_addr=24'h100100;#1;
        if(candidate_ready)$fatal(1,"registered lookup survived invalidation");
        @(negedge clk);invalidate=0;
        candidate_valid=0;''')
tb=EXP/'sim/tb_core200_cache.v';tb.write_text(t)
src=[EXP/'source/mn04/mn04_ddr_act_read_cache.v',ROOT/'source/mn04/mn04_ddr_behav.v',tb]
def run(tool,args,name):
 r=subprocess.run([str(MS/(tool+'.exe')),*map(str,args)],cwd=OUT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace')
 (OUT/name).write_text(r.stdout);assert r.returncode==0,(name,r.stdout[-1800:])
if not (OUT/'work').exists():run('vlib',['work'],'vlib.log')
run('vlog',['-quiet',*src],'compile.log')
run('vsim',['-c','work.tb_mn04_ddr_act_read_cache','-do','run -all;quit -f'],'sim.log')
s=(OUT/'sim.log').read_text();print(s[-1300:]);assert 'ACT_READ_CACHE_PASS' in s and '** Fatal' not in s
(OUT/'result.json').write_text(json.dumps(dict(status='PASS',residual_pulses=128,pad_transition_checked=args.pad_transition_check,
 scope='cache invalidation, refill, padding, synchronous convolution data, 3-cycle scalar admissions',
 sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in src}),indent=2))
