"""Repeat component boundary regressions in an isolated acceptance directory.

These checks supplement the real I2S/full-CNN/SD integration tests. Synthetic
accelerator completions and feature injections are explicitly scoped below.
"""
import argparse,hashlib,json,shutil,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--build-dir',type=Path,required=True)
    ap.add_argument('--out-dir',type=Path,required=True)
    ap.add_argument('--case',action='append',help='run only named unit cases')
    a=ap.parse_args();build=a.build_dir.resolve();out=a.out_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    assert (build/'control.mem').read_bytes()==(ROOT/'firmware/control_rv32im/build/control.mem').read_bytes()
    shared=[ROOT/'third_party/pythondata_cpu_vexriscv/pythondata_cpu_vexriscv/verilog/VexRiscv_Lite.v']
    mn=lambda *names:[ROOT/'source/mn04'/f'{n}.v' for n in names]
    cpu=shared+[ROOT/'source/post/v1_ms_tick.v',ROOT/'source/post/v1_key_debounce.v']+mn('mn04_wishbone_axil_bridge','mn04_rv32im_control')
    rt=shared+list((ROOT/'source/mn04').glob('*.v'))+[p for p in (ROOT/'source/post').glob('*.v') if p.name!='v1_fullscreen_image_pixel.v']
    rt+=[ROOT/'source/uart_rx_8n1.v',ROOT/'source/uart_tx_8n1.v',build/'v1_fullscreen_image_pixel_pds.v']
    tests=[
        ('uniform120_windows',mn('mn04_snapshot_manager'),'tb_mn04_uniform120_snapshot_manager','UNIFORM_120_SNAPSHOT_MANAGER_PASS',{},'production 400-frame warmup, 120-frame window / 60-frame hop, ring wrap and epoch rearm'),
        ('cpu_control',cpu,'tb_rv32im_control','RV32IM_CONTROL_PASS',{},'real RV32IM firmware/M instructions, AXI-Lite, interrupt mailbox, thresholds and empty-slot policy'),
        ('cpu_realtime',rt,'tb_rv32im_realtime_control','RV32IM_REALTIME_CONTROL_PASS',{},'all five CNN IDs and three template IDs through real CPU/event/motor/TFT/ack; accelerator arithmetic represented by per-op completions'),
        ('enrollment15',mn('mn04_template_enrollment'),'tb_template_enrollment_fifteen','TEMPLATE_ENROLLMENT_FIFTEEN_PASS',{},'15 templates, actual 400-frame warmup, short recording rejection and occupied-slot protection'),
        ('ddr_templates',mn('mn04_wmerge_bridge','mn04_ddr_act_byte_writer','mn04_ddr_act_read_cache','mn04_template_ddr_bank'),'tb_template_ddr_bank','TEMPLATE_DDR_BANK_PASS',{},'DDR template writer/cache; behavioral memory'),
        ('matcher15',mn('mn04_template_matcher'),'tb_template_matcher_external15','TEMPLATE_MATCHER_EXTERNAL15_PASS',{},'15 external-memory templates, three template identities'),
    ]
    sd_sources=mn('mn04_template_sd_store')+[ROOT/'source/sd/sd_card_spi.v',ROOT/'sim/sd/sd_card_model.v']
    for name,hc,reject in [('sdhc15',1,0),('sdsc15',0,0),('sd_reject_map',1,1),('sd_reject_header',1,2)]:
        tests.append((name,sd_sources,'tb_mn04_template_sd_store','_PASS',dict(MAP_COUNT=15,SD_HIGH_CAPACITY=hc,REJECT_WRITE_COMMAND=reject,ASYNC_READ=1),'actual SPI/CRC SD model; 15 maps or injected card rejection'))
    tests.append(('sd_idle_reentry',sd_sources,'tb_mn04_template_sd_store','_PASS',dict(MAP_COUNT=15,ASYNC_READ=1,WAIT_LIMIT=5000000,IDLE_CYCLES=5000010),'idle longer than timeout then save and restore all 15 maps; production timeout parameter scaled only for this unit test'))
    failed_card=ROOT/'build/sim/five_cpu_acceptance_sd_final2_20261027/sd_card_before_reset.hex'
    if failed_card.exists():
        tests.append(('sd_recorded_gas_restore',sd_sources,'tb_mn04_template_sd_store','SD_PRELOADED_RESTORE_PASS',dict(MAP_COUNT=15,ASYNC_READ=1,BOOT_RESTORE_ONLY=1,EXPECTED_VALID_MASK="15'h400",CARD_IMAGE_HEX=failed_card),'replay unmodified SD image captured in the failed I2S gas/CO test'))
    if a.case:
        tests=[t for t in tests if t[0] in a.case]
        assert len(tests)==len(a.case),'unknown case name'
    def run_test(case):
        name,src,tb,marker,params,scope=case;d=out/name;d.mkdir(exist_ok=True)
        for folder in ('rom','v1_run'):shutil.copytree(build/folder,d/folder,dirs_exist_ok=True)
        tb_path=ROOT/('sim/sd' if name.startswith('sd') else 'sim/mn04')/f'{tb}.v'
        def run(cmd,log):
            with (d/log).open('w') as f:p=subprocess.run(list(map(str,cmd)),cwd=d,stdout=f,stderr=subprocess.STDOUT)
            if p.returncode:raise RuntimeError(str(d/log))
        if not (d/'work').exists():run([MS/'vlib.exe','work'],'vlib.log')
        run([MS/'vlog.exe','-quiet',*src,tb_path],'compile.log')
        run([MS/'vsim.exe','-c','work.'+tb,*[f'-g{k}={v}' for k,v in params.items()],'-do','run -all; quit -f'],'sim.log')
        log=(d/'sim.log').read_text(errors='replace')
        if marker not in log or '** Fatal' in log or '** Error' in log:raise RuntimeError(str(d/'sim.log'))
        result=dict(status='PASS',scope=scope,markers=[l for l in log.splitlines() if '_PASS' in l],
            source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*src,tb_path]})
        (d/'result.json').write_text(json.dumps(result,indent=2));print(name+': PASS',flush=True)
        return dict(test=name,status='PASS',scope=scope,result=str(d/'result.json'))
    with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run_test,tests))
    (out/'result.json').write_text(json.dumps(dict(status='PASS',cases=results),indent=2))

if __name__=='__main__':main()
