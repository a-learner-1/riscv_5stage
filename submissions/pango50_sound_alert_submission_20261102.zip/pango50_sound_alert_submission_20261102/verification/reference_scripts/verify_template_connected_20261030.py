"""Connect production enrollment, DDR bank and matcher under stalled AXI."""
from pathlib import Path
import subprocess, json

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'build/sim/template_connected_20261030'
MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')
OUT.mkdir(parents=True,exist_ok=True)
tb=(ROOT/'sim/mn04/tb_template_ddr_bank.v').read_text()
tb=tb.replace('module tb_template_ddr_bank;', 'module tb_template_connected;')
start=tb.index('    integer a,m;')
tb=tb[:start]+'''
    reg recording=0,enable=0,xvalid=0;
    reg signed [7:0] x0=0;
    wire ewe,commit,rv,mbusy,mreq;
    wire [17:0] eaddr,maddr;
    wire [7:0] edata;
    wire [14:0] mask,invalid;
    wire [1:0] cls; wire [15:0] score;
    mn04_template_enrollment #(.CNN_CLASS_COUNT(5),.MAPS_PER_CLASS(5),.USE_CPU_SLOT_SELECT(1)) enroll(
      .clk(clk),.rst_n(rst_n),.capture_recording_i(recording),.capture_category_i(4'd5),
      .overflow_i(2'd0),.x0_i(x0),.x0_valid_i(xvalid),.cpu_selected_slot_i(4'd0),
      .existing_valid_mask_i(mask),.template_load_we_o(ewe),.template_load_addr_o(eaddr),
      .template_load_data_o(edata),.valid_mask_o(mask),.invalid_mask_o(invalid),
      .enrollment_commit_o(commit),.enrollment_category_o(),.enrollment_map_o());
    mn04_template_matcher #(.DOORBELL_MAPS(5),.SMOKE_ALARM_MAPS(5),.GAS_CO_ALARM_MAPS(5),
      .MAX_MAPS_PER_CLASS(5),.EXTERNAL_TEMPLATE_MEMORY(1),.USE_TEMPLATE_VALID_MASK(1),
      .CENTER_ALPHA_Q4(8),.THRESHOLD_Q15(18022)) matcher(
      .clk(clk),.rst_n(rst_n),.enable_i(enable),.x0_i(x0),.x0_valid_i(xvalid&&enable),
      .template_load_we_i(1'b0),.template_load_addr_i(18'd0),.template_load_data_i(8'd0),
      .template_external_rd_en_i(1'b0),.template_external_rd_addr_i(18'd0),.template_external_rd_data_o(),
      .template_valid_mask_i(mask & ~invalid & {15{!fault}}),
      .template_ddr_rd_req_o(mreq),.template_ddr_rd_addr_o(maddr),
      .template_ddr_rd_valid_i(valid),.template_ddr_rd_data_i(result),
      .result_valid_o(rv),.result_class_o(cls),.result_score_q15_o(score),.busy_o(mbusy));
    always @* begin load=ewe;addr=eaddr;data=edata;req=mreq;rdaddr=maddr;end
    integer n,commits=0;
    always @(posedge clk) if(commit) commits=commits+1;
    task stream;input integer count;begin
      for(n=0;n<count;n=n+1) begin
        @(negedge clk);x0=pattern(n%12800);xvalid=1;
        @(negedge clk);xvalid=0;repeat(30) @(negedge clk);
      end
    end endtask
    initial begin
      repeat(8) @(negedge clk);rst_n=1;recording=1;
      stream(8*12800);
      @(negedge clk);recording=0;repeat(5) @(negedge clk);wait(drained);
      if(mask!=1 || invalid!=0 || commits!=1 || fault) $fatal(1,"enroll failed mask=%h invalid=%h commits=%d fault=%b",mask,invalid,commits,fault);
      for(n=0;n<12800;n=n+1) if(mem[n]!==pattern(n)) $fatal(1,"DDR mismatch byte=%d",n);
      $display("CONNECTED_ENROLL_PASS eight_seconds=1 bytes_checked=12800 mask=%h",mask);
      enable=1;stream(5*12800);wait(rv);@(negedge clk);
      if(cls!=1 || score<32000 || fault) $fatal(1,"match failed cls=%d score=%d fault=%b",cls,score,fault);
      $display("TEMPLATE_CONNECTED_PASS class=%d score=%d fault=%b",cls,score,fault);$finish;
    end
    initial begin #300000000;$fatal(1,"connected timeout");end
endmodule
'''
(OUT/'tb.v').write_text(tb)
def run(args,name):
    r=subprocess.run([str(a) for a in args],cwd=OUT,capture_output=True,text=True)
    (OUT/name).write_text(r.stdout+r.stderr)
    if r.returncode: raise RuntimeError(OUT/name)
run([MS/'vlib.exe','work'],'vlib.log')
names=['mn04_wmerge_bridge','mn04_ddr_act_byte_writer','mn04_ddr_act_read_cache','mn04_template_ddr_bank','mn04_template_enrollment','mn04_template_matcher']
run([MS/'vlog.exe','-quiet',*[ROOT/'source/mn04'/f'{n}.v' for n in names],OUT/'tb.v'],'compile.log')
run([MS/'vsim.exe','-c','work.tb_template_connected','-do','run -all; quit -f'],'sim.log')
log=(OUT/'sim.log').read_text()
result={'status':'PASS' if 'TEMPLATE_CONNECTED_PASS' in log and '** Fatal' not in log else 'FAIL','markers':[s for s in log.splitlines() if '_PASS' in s]}
(OUT/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if result['status']!='PASS': raise RuntimeError(OUT/'sim.log')
