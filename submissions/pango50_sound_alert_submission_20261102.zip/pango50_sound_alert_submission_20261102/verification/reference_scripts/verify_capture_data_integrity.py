"""Exercise actual transpose writer, DDR bridge, class capture and UART bytes."""
import argparse,json,subprocess,sys,zlib,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MS=Path('C:/Studying_app/FPGA/modelsim_2019/win64')
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out-dir',type=Path,default=ROOT/'build/sim/capture_data_integrity_20261026')
ap.add_argument('--train-capture',type=Path,default=ROOT/'source/mn04/mn04_train_capture.v')
args=ap.parse_args()
OUT=args.out_dir.resolve()
OUT.mkdir(parents=True,exist_ok=True)
def run(args,name):
    with (OUT/name).open('w') as f:
        r=subprocess.run([str(x) for x in args],cwd=OUT,stdout=f,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError(str(OUT/name))
if not (OUT/'work').exists():run([MS/'vlib.exe','work'],'vlib.log')
sources=[ROOT/'source/mn04'/f'{name}.v' for name in ('mn04_train_capture','mn04_x0_writer','mn04_ddr_act_byte_writer','mn04_axi4_ddr_bridge','mn04_ddr_behav')]
sources[0]=args.train_capture.resolve()
sources += [ROOT/'source/uart_tx_8n1.v',ROOT/'source/uart_rx_8n1.v',ROOT/'sim/mn04/tb_mn04_capture_data_integrity.v']
run([MS/'vlog.exe','-quiet',*sources],'compile.log')
sys.path.insert(0,str(ROOT/'scripts'))
import board_button_capture_to_pc as receiver
cases=[]
for enabled in (0,1):
    logname=f'sim_diag{enabled}.log'
    run([MS/'vsim.exe','-c','work.tb_mn04_capture_data_integrity',f'-gDIAGNOSTICS={enabled}','-do','run -all; quit -f'],logname)
    log=(OUT/logname).read_text(errors='replace')
    if 'CAPTURE_DATA_INTEGRITY_PASS' not in log or '** Fatal' in log or '** Error' in log:
        raise RuntimeError(str(OUT/logname))
    raw=bytes(int(word,16) for line in (OUT/'uart_bytes.hex').read_text().splitlines() if not line.startswith('//') for word in line.split())
    (OUT/f'uart_diag{enabled}.bin').write_bytes(raw)
    class SerialBytes:
        def __init__(self,data):self.data=data
        def read(self,n):r=self.data[:n];self.data=self.data[n:];return r
    code,records=receiver.receive_batch(SerialBytes(raw),30)
    assert code==0 and len(records)==2
    for take,record in enumerate(records):
        payload,code,slot,frames,status=record
        expected=bytes((take*71+frame*5+mel*3)&255 for mel in range(128) for frame in range(frames))
        assert payload==expected and status==0
        if enabled:
            d=record.diagnostics
            check=receiver.check_diagnostics(payload,frames,d)
            assert all(check[k] for k in ('count_matches','crc_matches','first16_matches','frames_match')),check
            values=[(take*71+frame*5+mel*3)&255 for frame in range(frames) for mel in range(128)]
            pcm=b''.join(bytes((0x5a,v)) for v in values)
            pcm_values=struct.unpack('<'+'h'*len(values),pcm)
            assert d['pcm_crc32']==f'{zlib.crc32(pcm):08x}' and d['pcm_count']==len(values)
            assert (d['pcm_min'],d['pcm_max'])==(min(pcm_values),max(pcm_values))
            assert d['pcm_changes']==sum(a!=b for a,b in zip(pcm_values,pcm_values[1:]))
            assert d['slot_base_byte']==0x540000+take*128000 and d['start_slot']==(0 if take==0 else 121)
            # A corrupted stored byte must invalidate the DDR comparison.
            damaged=bytes((payload[0]^1,))+payload[1:]
            assert not receiver.check_diagnostics(damaged,frames,d)['crc_matches']
        else:assert record.diagnostics is None
    cases.append(dict(diagnostics=bool(enabled),status='PASS',uart_bytes=len(raw),records=2))
result=dict(status='PASS',cases=cases,
    feature_bytes=32512,takes=2,scope='RTL feature-stream injection through real writer/DDR bridge/UART; independent Python CRC/parser; behavioral DDR, not physical microphone or board DDR proof')
(OUT/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
if result['status']!='PASS':raise RuntimeError(str(OUT/'sim.log'))
