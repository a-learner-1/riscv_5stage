"""Compare the RTL template score at two CENTER_ALPHA_Q4 settings with numpy.

The board captures in training/output/board_captures/template were recorded
from the same phone, distance and volume, so they are the only existing
"same position, same sound" evidence.  This script enrolls one 1 s window of
one capture, replays a 1 s window of another capture through the real
matcher RTL, and prints the Q15 score for alpha=16 (old zero-mean cosine) and
alpha=8 (half mean removed), next to the numpy value of the same formula.
"""
from pathlib import Path
import json
import math
import subprocess
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build" / "template_center_alpha_verify_20261024"
MS = Path(r"C:/Studying_app/FPGA/modelsim_2019/win64")
CAPTURES = ROOT / "training" / "output" / "board_captures" / "template"


def load_capture(path: Path) -> np.ndarray:
    raw = np.fromfile(path, dtype=np.uint8).astype(np.int16)
    raw = np.where(raw > 127, raw - 256, raw).astype(np.int8)
    return raw.reshape(128, 250)


def window_frame_major(capture: np.ndarray, start: int) -> np.ndarray:
    return np.ascontiguousarray(capture[:, start:start + 100].T.reshape(-1))


def reference_score(query: np.ndarray, template: np.ndarray, alpha_q4: int) -> float:
    alpha = alpha_q4 / 16.0
    q = query.astype(np.float64)
    t = template.astype(np.float64)
    q = q - alpha * q.mean()
    t = t - alpha * t.mean()
    den = np.linalg.norm(q) * np.linalg.norm(t)
    return float(q @ t / den) if den else 0.0


def write_mem(path: Path, values: np.ndarray) -> None:
    path.write_text("".join(f"{int(v) & 255:02x}\n" for v in values), encoding="ascii")


TB = """`timescale 1ns/1ps
module tb_center_alpha;
  parameter QUERY_FILE="query.mem";
  parameter integer ALPHA_Q4=16;
  reg clk=0,rst_n=0,recording=0,enable=0,valid=0;
  reg signed [7:0] x0=0;
  always #5 clk=~clk;
  wire we,commit,rv; wire [17:0] addr; wire signed [7:0] data;
  wire [5:0] mask,invalid_mask; wire [1:0] cls; wire [15:0] score;
  reg signed [7:0] enrollment[0:12799],query[0:12799];
  integer i;
  mn04_template_enrollment enroll(.clk(clk),.rst_n(rst_n),
    .capture_recording_i(recording),.capture_category_i(4'd6),.overflow_i(2'd0),
    .x0_i(x0),.x0_valid_i(valid),.template_load_we_o(we),
    .template_load_addr_o(addr),.template_load_data_o(data),
    .valid_mask_o(mask),.invalid_mask_o(invalid_mask),.enrollment_commit_o(commit),
    .enrollment_category_o(),.enrollment_map_o());
  mn04_template_matcher #(.DOORBELL_MAPS(2),.SMOKE_ALARM_MAPS(2),
    .GAS_CO_ALARM_MAPS(2),.USE_TEMPLATE_VALID_MASK(1),.CENTER_ALPHA_Q4(ALPHA_Q4)) matcher(
    .clk(clk),.rst_n(rst_n),.enable_i(enable),.x0_i(x0),.x0_valid_i(valid && enable),
    .template_load_we_i(we),.template_load_addr_i(addr),.template_load_data_i(data),
    .template_valid_mask_i(mask & ~invalid_mask),.result_valid_o(rv),
    .result_class_o(cls),.result_score_q15_o(score),.busy_o());
  initial begin
    $readmemh("enrollment.mem",enrollment); $readmemh(QUERY_FILE,query);
    repeat(5) @(negedge clk); rst_n=1; recording=1;
    @(negedge clk);
    for(i=0;i<2560;i=i+1) begin x0=8'sd120;valid=1;@(negedge clk);end
    for(i=0;i<12800;i=i+1) begin x0=enrollment[i];valid=1;@(negedge clk);end
    valid=0;recording=0;@(negedge clk);
    if(!commit || !mask[0]) $fatal(1,"enrollment did not commit");
    repeat(5) @(negedge clk);enable=1;
    for(i=0;i<2560;i=i+1) begin @(negedge clk);x0=8'sd120;valid=1;end
    for(i=0;i<12800;i=i+1) begin @(negedge clk);x0=query[i];valid=1;end
    @(negedge clk);valid=0;
    wait(rv);@(negedge clk);
    $display("RESULT alpha_q4=%0d class=%0d score=%0d",ALPHA_Q4,cls,score);
    $finish;
  end
  initial begin #20000000; $fatal(1,"watchdog");end
endmodule
"""


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    files = sorted(CAPTURES.glob("doorbell_*.raw"))
    if len(files) < 2:
        raise SystemExit("need at least two doorbell board captures")
    template = load_capture(files[0])
    query = load_capture(files[1])
    write_mem(OUT / "enrollment.mem", window_frame_major(template, 0))
    # The controller samples a window every 50 frames, so test those offsets.
    results = []
    for start in (0, 50, 100, 150):
        write_mem(OUT / f"query_{start}.mem", window_frame_major(query, start))
    (OUT / "tb_center_alpha.v").write_text(TB, encoding="ascii")
    for cmd in ([MS / "vlib.exe", "work"],
                [MS / "vlog.exe", "-quiet", "-work", "work",
                 ROOT / "source/mn04/mn04_template_enrollment.v",
                 ROOT / "source/mn04/mn04_template_matcher.v",
                 OUT / "tb_center_alpha.v"]):
        proc = subprocess.run([str(c) for c in cmd], cwd=OUT, capture_output=True, text=True)
        (OUT / "compile.log").write_text(proc.stdout + proc.stderr, encoding="utf-8")
        proc.check_returncode()
    for start in (0, 50, 100, 150):
        q = window_frame_major(query, start)
        row = {"query_offset": start}
        for alpha_q4 in (16, 8):
            proc = subprocess.run(
                [str(MS / "vsim.exe"), "-c", "work.tb_center_alpha",
                 f"-gQUERY_FILE=query_{start}.mem", f"-gALPHA_Q4={alpha_q4}",
                 "-do", "run -all; quit -f"],
                cwd=OUT, capture_output=True, text=True)
            log = proc.stdout + proc.stderr
            (OUT / f"sim_{start}_{alpha_q4}.log").write_text(log, encoding="utf-8")
            if "** Fatal" in log or "RESULT" not in log:
                raise RuntimeError(log)
            line = [l for l in log.splitlines() if "RESULT" in l][0]
            rtl = int(line.split("score=")[1])
            ref = reference_score(q, window_frame_major(template, 0), alpha_q4)
            row[f"alpha{alpha_q4}"] = {"rtl_q15": rtl, "rtl": round(rtl / 32767, 4),
                                       "numpy": round(ref, 4),
                                       "abs_err": round(abs(rtl / 32767 - ref), 4)}
        results.append(row)
        print(json.dumps(row), flush=True)
    (OUT / "center_alpha_verify.json").write_text(
        json.dumps({"template": files[0].name, "query": files[1].name,
                    "threshold_q15_default": 26214,
                    "threshold_q15_template_only": 18022,
                    "results": results}, indent=2), encoding="utf-8")
    run_degenerate_case()
    print(f"artifacts: {OUT}")


def run_degenerate_case() -> None:
    """A silent enrollment take must never match, at either alpha."""
    rng = np.random.default_rng(7)
    silent_template = np.full(128 * 100, -100, dtype=np.int8)
    silent_query = np.clip(np.rint(-100 + rng.normal(0, 1.5, 128 * 100)),
                           -128, 127).astype(np.int8)
    write_mem(OUT / "enrollment.mem", silent_template)
    write_mem(OUT / "query_silence.mem", silent_query)
    for alpha_q4 in (16, 8):
        proc = subprocess.run(
            [str(MS / "vsim.exe"), "-c", "work.tb_center_alpha",
             "-gQUERY_FILE=query_silence.mem", f"-gALPHA_Q4={alpha_q4}",
             "-do", "run -all; quit -f"],
            cwd=OUT, capture_output=True, text=True)
        log = proc.stdout + proc.stderr
        (OUT / f"sim_silence_{alpha_q4}.log").write_text(log, encoding="utf-8")
        line = [l for l in log.splitlines() if "RESULT" in l]
        if not line:
            raise RuntimeError(log)
        print("silent template/query ->", line[0].strip())


if __name__ == "__main__":
    main()
