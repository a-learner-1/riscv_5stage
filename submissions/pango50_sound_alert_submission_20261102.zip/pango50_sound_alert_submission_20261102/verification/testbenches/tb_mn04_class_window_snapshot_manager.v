`timescale 1ns/1ps
module tb_mn04_class_window_snapshot_manager;
    reg clk=0, rst_n=0, enable=0, frame_done=0, accept=0, dma_busy=0, dma_done=0;
    reg [9:0] next_slot=0;
    wire dma_start,ready;
    wire [1:0] dma_mode,ready_mode;
    wire [9:0] dma_slot;
    integer i;
    always #5 clk=~clk;

    mn04_class_window_snapshot_manager dut(
        .clk(clk),.rst_n(rst_n),.epoch_reset_i(1'b0),
        .recognition_enable_i(enable),.frame_done_i(frame_done),
        .next_frame_slot_i(next_slot),.snapshot_accept_i(accept),
        .dma_busy_i(dma_busy),.dma_done_i(dma_done),
        .dma_start_o(dma_start),.dma_window_mode_o(dma_mode),
        .dma_next_frame_slot_o(dma_slot),.snapshot_ready_o(ready),
        .snapshot_window_mode_o(ready_mode));

    task frame_pulses(input integer count);
        begin
            for(i=0;i<count;i=i+1) begin
                @(negedge clk); frame_done=1; next_slot=next_slot+1'b1;
                @(negedge clk); frame_done=0;
            end
        end
    endtask

    task complete_mode(input [1:0] expected_mode);
        integer watchdog;
        begin
            watchdog=0;
            while(!dma_start && watchdog<20) begin @(negedge clk); watchdog=watchdog+1; end
            if(!dma_start) $fatal(1,"DMA start timeout mode=%0d",expected_mode);
            if(dma_mode!==expected_mode) $fatal(1,"DMA mode=%0d expected=%0d",dma_mode,expected_mode);
            if(dma_slot>=1000) $fatal(1,"ring slot out of range=%0d",dma_slot);
            @(negedge clk); accept=0;
            repeat(2) @(negedge clk);
            dma_done=1;
            @(negedge clk); dma_done=0;
            #1;
            if(!ready || ready_mode!==expected_mode)
                $fatal(1,"ready mode=%0d expected=%0d ready=%b",ready_mode,expected_mode,ready);
            @(negedge clk);
        end
    endtask

    initial begin
        repeat(4) @(negedge clk); rst_n=1; enable=1; accept=1;
        frame_pulses(100);
        complete_mode(2'd0);
        // Hold the single arena while all three hop counters expire. Requests
        // must queue/coalesce and then drain in the 100/120/150 priority order.
        accept=0;
        frame_pulses(100);
        accept=1;
        complete_mode(2'd0);
        accept=1; complete_mode(2'd1);
        accept=1; complete_mode(2'd2);
        $display("CLASS_WINDOW_SNAPSHOT_MANAGER_PASS modes=100/120/150 hops=50/60/75");
        $finish;
    end
    initial begin #1000000; $fatal(1,"class snapshot manager watchdog"); end
endmodule
