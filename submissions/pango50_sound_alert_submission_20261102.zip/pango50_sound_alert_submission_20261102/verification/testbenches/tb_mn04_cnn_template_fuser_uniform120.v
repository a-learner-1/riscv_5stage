`timescale 1ns/1ps
module tb_mn04_cnn_template_fuser_uniform120;
    parameter PROTOTYPE_FILE = "cnn_template_prob_q16.mem";
    reg clk=0, rst_n=0, start=0;
    reg [95:0] probabilities=96'd0;
    reg [1:0] window_mode=2'd1;
    wire valid;
    wire [95:0] fused;
    integer c,k;
    reg [17:0] expected_numerator;
    always #5 clk=~clk;

    mn04_cnn_template_fuser #(
        .PROTOTYPE_FILE(PROTOTYPE_FILE),
        .VALID_MASK(24'h03ffff),
        .TEMPLATE_WEIGHT_Q2(1)
    ) dut (
        .clk(clk), .rst_n(rst_n), .start_i(start),
        .probabilities_i(probabilities), .window_mode_i(window_mode),
        .valid_o(valid), .fused_probabilities_o(fused)
    );

    task run_fuser;
        begin
            @(negedge clk); start=1;
            @(negedge clk); start=0;
            wait(valid===1'b1);
            #1;
        end
    endtask

    initial begin
        repeat(3) @(negedge clk);
        rst_n=1;
        for(c=0;c<6;c=c+1) begin
            for(k=0;k<6;k=k+1)
                probabilities[k*16 +: 16] = dut.prototype_mem[(c*3)*6+k];
            if (^probabilities === 1'bx)
                $fatal(1,"uniform-120 prototype ROM contains unknown data");
            run_fuser();
            expected_numerator = 18'd65535 +
                                 (probabilities[c*16 +: 16] * 3);
            if(fused[c*16 +: 16] !== expected_numerator[17:2])
                $fatal(1,"uniform-120 class %0d failed fusion expected=%0d got=%0d",
                    c,expected_numerator[17:2],fused[c*16 +: 16]);
        end

        window_mode=2'd0;
        probabilities={16'd60000,16'd5000,16'd100,16'd100,16'd100,16'd235};
        run_fuser();
        if(fused!==probabilities) $fatal(1,"uniform-120 bank leaked into 100-frame mode");
        window_mode=2'd2;
        run_fuser();
        if(fused!==probabilities) $fatal(1,"uniform-120 bank leaked into 150-frame mode");

        $display("CNN_TEMPLATE_FUSER_UNIFORM120_PASS classes=0..5 templates=3_each slots=0..17");
        $finish;
    end
    initial begin #2000000; $fatal(1,"uniform-120 template fuser watchdog"); end
endmodule
