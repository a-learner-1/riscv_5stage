`timescale 1ns/1ps
module tb_template_enrollment_fifteen;
    reg clk=0,rst_n=0,recording=0,valid=0;always #5 clk=~clk;
    reg [3:0] category=5,slot=0;
    reg [1:0] overflow=0;reg [7:0] sample=0;
    wire we,commit;wire [17:0] addr;wire [7:0] data;
    wire [14:0] mask,invalid_mask;wire [3:0] committed_map;
    integer writes=0,commits=0,i,m;
    reg [7:0] mem[0:191999];
    mn04_template_enrollment #(.CNN_CLASS_COUNT(5),.MAPS_PER_CLASS(5),.USE_CPU_SLOT_SELECT(1)) dut(
        .clk(clk),.rst_n(rst_n),.capture_recording_i(recording),.capture_category_i(category),
        .overflow_i(overflow),.x0_i(sample),.x0_valid_i(valid),.cpu_selected_slot_i(slot),
        .existing_valid_mask_i(15'd0),.template_load_we_o(we),.template_load_addr_o(addr),
        .template_load_data_o(data),.valid_mask_o(mask),.invalid_mask_o(invalid_mask),
        .enrollment_commit_o(commit),.enrollment_category_o(),.enrollment_map_o(committed_map));
    always @(posedge clk) begin
        if(we) begin mem[addr]<=data;writes=writes+1;end
        if(commit) commits=commits+1;
    end
    function [7:0] pattern;input integer a;input integer map;begin pattern=(a*13)^(a>>6)^(map*23);end endfunction
    task take;input integer map;input integer length;begin
        @(negedge clk);category=5+map/5;slot=map;recording=1;
        @(negedge clk);
        for(i=0;i<51200+length;i=i+1) begin
            sample=i<51200?8'h7f:pattern(i-51200,map);valid=1;@(negedge clk);
        end
        valid=0;repeat(4) @(negedge clk);recording=0;repeat(4) @(negedge clk);
    end endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        take(0,100);if(commits!=0 || mask!=0) $fatal(1,"short take committed");
        writes=0;
        for(m=0;m<15;m=m+1) begin
            take(m,12800);
            if(commits!=m+1 || committed_map!=m) $fatal(1,"slot commit %0d",m);
            for(i=0;i<12800;i=i+1)
                if(mem[m*12800+i]!==pattern(i,m)) $fatal(1,"click warmup/data mismatch map=%0d byte=%0d",m,i);
        end
        if(mask!==15'h7fff || writes!=192000) $fatal(1,"15 slot totals wrong");
        take(0,12800);if(commits!=15 || writes!=192000) $fatal(1,"occupied CPU slot overwritten");
        $display("TEMPLATE_ENROLLMENT_FIFTEEN_PASS classes=3 maps_per_class=5 bytes=192000 warmup_400_frames=1 short_take_rejected=1 occupied_slot_protected=1");
        $finish;
    end
endmodule
