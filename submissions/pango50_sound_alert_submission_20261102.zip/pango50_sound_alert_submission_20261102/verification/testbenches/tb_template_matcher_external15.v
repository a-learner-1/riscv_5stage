`timescale 1ns/1ps
module tb_template_matcher_external15;
    reg clk=0,rst_n=0,enable=0,valid=0;always #5 clk=~clk;
    reg signed [7:0] x0=0,rd_data=0;
    reg rd_valid=0;wire req,result_valid,busy;
    wire [17:0] addr;wire [1:0] result_class;wire [15:0] score;
    reg [14:0] mask=15'h7fff;
    integer wait_cycles=0;reg [17:0] held_addr;
    integer n,t,expected,selected,cycles,received=0;
    function [7:0] pattern;input integer pos,map;reg [31:0] v;begin
        v=(pos+map*12800+17)*32'd1103515245+32'd12345;
        v=(v^(v>>11))*32'd2654435761;
        pattern=v[23:16];
    end endfunction
    mn04_template_matcher #(.DOORBELL_MAPS(5),.SMOKE_ALARM_MAPS(5),.GAS_CO_ALARM_MAPS(5),
        .MAX_MAPS_PER_CLASS(5),.EXTERNAL_TEMPLATE_MEMORY(1),.USE_TEMPLATE_VALID_MASK(1),.WARMUP_FRAMES(0)) dut(
        .clk(clk),.rst_n(rst_n),.enable_i(enable),.x0_i(x0),.x0_valid_i(valid),
        .template_load_we_i(1'b0),.template_load_addr_i(18'd0),.template_load_data_i(8'd0),
        .template_external_rd_en_i(1'b0),.template_external_rd_addr_i(18'd0),.template_external_rd_data_o(),
        .template_valid_mask_i(mask),.template_ddr_rd_req_o(req),.template_ddr_rd_addr_o(addr),
        .template_ddr_rd_valid_i(rd_valid),.template_ddr_rd_data_i(rd_data),
        .result_valid_o(result_valid),.result_class_o(result_class),.result_score_q15_o(score),.busy_o(busy));
    always @(posedge clk) begin
        rd_valid<=0;
        if(req) begin
            if(wait_cycles!=0) $fatal(1,"multiple outstanding template reads");
            held_addr<=addr;wait_cycles<=1+addr%7;
        end
        if(wait_cycles>0) wait_cycles<=wait_cycles-1;
        if(wait_cycles==1) begin rd_valid<=1;rd_data<=pattern(held_addr%12800,held_addr/12800);end
        if(result_valid) received=received+1;
    end
    task query;input integer map,expected_class,flat;begin
        @(negedge clk);enable=0;repeat(4) @(negedge clk);enable=1;
        for(n=0;n<12800;n=n+1) begin @(negedge clk);x0=flat?0:pattern(n,map);valid=1;end
        @(negedge clk);valid=0;wait(busy);
        // Live features arriving during the fifteen-map scan are retained.
        for(n=0;n<1024;n=n+1) begin @(negedge clk);x0=pattern(n,map);valid=1;end
        @(negedge clk);valid=0;cycles=0;
        while(!result_valid && cycles<3000000) begin @(negedge clk);cycles=cycles+1;end
        if(!result_valid || result_class!=expected_class || dut.input_fifo_overflow_r)
            $fatal(1,"external map match got=%0d expected=%0d score=%0d cycles=%0d overflow=%b",result_class,expected_class,score,cycles,dut.input_fifo_overflow_r);
        if(expected_class && score<32000) $fatal(1,"identical template did not score near 1.0");
        $display("EXTERNAL15_MATCH_CASE_PASS slot=%0d class=%0d score=%0d scan_cycles=%0d queued=%0d",map,result_class,score,cycles,dut.input_fifo_count_r);
        @(negedge clk);enable=0;repeat(10) @(negedge clk);
    end endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        query(0,1,0);query(7,2,0);query(14,3,0);query(0,0,1);
        if(received!=4) $fatal(1,"missing matcher results");
        $display("TEMPLATE_MATCHER_EXTERNAL15_PASS classes=3 slots=15 variable_latency_reads=1 live_FIFO=1 silence_reject=1");$finish;
    end
endmodule
