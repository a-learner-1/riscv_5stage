`timescale 1ns/1ps
module tb_mn04_board_capture_keys;
    reg clk=0,rst_n=0;
    reg category_n=1,start_n=1,stop_n=1,mode_n=1;
    reg recognition_enable=0,capture_busy=0,capture_recording=0;
    wire preview_enable,category_advance,capture_start,capture_stop,template_mode;
    integer start_count=0,stop_count=0,advance_count=0;
    reg fail=0;

    always #5 clk=~clk;
    mn04_board_capture_keys #(.CLOCK_HZ(100000)) dut (
        .clk(clk),.rst_n(rst_n),
        .category_key_n_i(category_n),.start_key_n_i(start_n),.stop_key_n_i(stop_n),
        .mode_key_n_i(mode_n),
        .recognition_enable_i(recognition_enable),.capture_busy_i(capture_busy),
        .capture_recording_i(capture_recording),
        .category_advance_o(category_advance),.template_mode_o(template_mode),
        .preview_enable_o(preview_enable),
        .capture_start_o(capture_start),.capture_stop_o(capture_stop));

    always @(posedge clk) begin
        if(category_advance) advance_count<=advance_count+1;
        if(capture_start) start_count<=start_count+1;
        if(capture_stop) stop_count<=stop_count+1;
    end

    initial begin
        repeat(5) @(negedge clk); rst_n=1;
        repeat(2) @(negedge clk);
        if(!preview_enable) begin $display("FAIL preview missing in idle"); fail=1; end

        // KEY7 held down advances into template mode only once.
        mode_n=0; repeat(10000) @(negedge clk); mode_n=1; repeat(3000) @(negedge clk);
        if(!template_mode) begin $display("FAIL KEY7 did not select template input"); fail=1; end

        start_n=0; repeat(3000) @(negedge clk); start_n=1; repeat(3000) @(negedge clk);
        if(start_count!=1 || capture_start) begin $display("FAIL K5 one-shot start"); fail=1; end

        capture_busy=1; capture_recording=1;
        mode_n=0; repeat(3000) @(negedge clk); mode_n=1; repeat(3000) @(negedge clk);
        category_n=0; repeat(3000) @(negedge clk); category_n=1; repeat(3000) @(negedge clk);
        stop_n=0; repeat(3000) @(negedge clk); stop_n=1; repeat(3000) @(negedge clk);
        if(advance_count!=0 || stop_count!=1 || preview_enable || !template_mode) begin
            $display("FAIL controls during active recording"); fail=1;
        end

        capture_busy=0; capture_recording=0; repeat(2) @(negedge clk);
        // Hold K4 for 100 ms: it must still emit one class-advance pulse.
        category_n=0; repeat(10000) @(negedge clk); category_n=1; repeat(3000) @(negedge clk);
        if(advance_count!=1 || category_advance || !preview_enable) begin
            $display("FAIL K4 single class-advance pulse"); fail=1;
        end

        recognition_enable=1;
        mode_n=0; repeat(3000) @(negedge clk); mode_n=1; repeat(3000) @(negedge clk);
        category_n=0; repeat(3000) @(negedge clk); category_n=1; repeat(3000) @(negedge clk);
        start_n=0; repeat(3000) @(negedge clk); start_n=1; repeat(3000) @(negedge clk);
        stop_n=0; repeat(3000) @(negedge clk); stop_n=1; repeat(3000) @(negedge clk);
        if(advance_count!=1 || start_count!=1 || stop_count!=1 || !template_mode) begin
            $display("FAIL keys were active during recognition"); fail=1;
        end
        if(!fail) $display("BOARD_CAPTURE_KEYS_PASS"); else $display("BOARD_CAPTURE_KEYS_FAIL");
        $finish;
    end

    initial begin #1000000; $display("BOARD_CAPTURE_KEYS_WATCHDOG"); $finish; end
endmodule
