`timescale 1ns/1ps
module tb_mn04_x0_continuous_snapshot;
    reg clk=0,rst_n=0,x0_valid=0,epoch_reset=0;
    reg [7:0] x0_data=0;
    reg [23:0] ring_base=24'h500000;
    always #5 clk=~clk;
    wire short_ready,long_ready,overflow;
    wire ring_drained,snapshot_busy,frame_done;
    wire [9:0] next_slot;
    wire [27:0] ring_awaddr,dma_awaddr,dma_araddr;
    wire ring_awvalid,ring_wvalid,ring_wlast,ring_bready;
    wire dma_awvalid,dma_wvalid,dma_wlast,dma_bready,dma_arvalid,dma_rready;
    wire ring_awready,ring_wready,dma_awready,dma_wready,dma_arready;
    wire [1:0] ring_bresp,dma_bresp,dma_rresp;
    wire ring_bvalid,dma_bvalid,dma_rvalid;
    wire [255:0] ring_wdata,dma_wdata,dma_rdata;
    wire [31:0] ring_wstrb,dma_wstrb;
    wire [27:0] s_awaddr,s_araddr;
    wire [3:0] s_awlen,s_arlen;
    wire s_awvalid,s_arvalid,s_awready,s_arready,s_wvalid,s_wlast,s_wready;
    wire [255:0] s_wdata,s_rdata;
    wire [31:0] s_wstrb;
    wire [1:0] s_bresp,s_rresp;
    wire s_bvalid,s_bready,s_rlast,s_rvalid,s_rready;
    integer f,m,mism,epoch;

    mn04_x0_continuous_snapshot_top dut (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),
        .overflow_clear_i(1'b0),
        .ring_base_byte_i(ring_base),.epoch_reset_i(epoch_reset),
        .x0_i(x0_data),.x0_valid_i(x0_valid),
        .recognition_enable_i(1'b1),
        .short_snapshot_accept_i(1'b1),.long_snapshot_accept_i(1'b0),
        .short_snapshot_ready_o(short_ready),
        .long_snapshot_ready_o(long_ready),.x0_overflow_o(overflow),
        .ring_drained_o(ring_drained),.snapshot_busy_o(snapshot_busy),
        .ring_frame_done_o(frame_done),.ring_next_frame_slot_o(next_slot),
        .ring_awaddr_o(ring_awaddr),.ring_awvalid_o(ring_awvalid),
        .ring_awready_i(ring_awready),.ring_wdata_o(ring_wdata),
        .ring_wstrb_o(ring_wstrb),.ring_wvalid_o(ring_wvalid),
        .ring_wlast_o(ring_wlast),.ring_wready_i(ring_wready),
        .ring_bresp_i(ring_bresp),.ring_bvalid_i(ring_bvalid),
        .ring_bready_o(ring_bready),
        .dma_awaddr_o(dma_awaddr),.dma_awvalid_o(dma_awvalid),
        .dma_awready_i(dma_awready),.dma_wdata_o(dma_wdata),
        .dma_wstrb_o(dma_wstrb),.dma_wvalid_o(dma_wvalid),
        .dma_wlast_o(dma_wlast),.dma_wready_i(dma_wready),
        .dma_bresp_i(dma_bresp),.dma_bvalid_i(dma_bvalid),
        .dma_bready_o(dma_bready),.dma_araddr_o(dma_araddr),
        .dma_arvalid_o(dma_arvalid),.dma_arready_i(dma_arready),
        .dma_rdata_i(dma_rdata),.dma_rresp_i(dma_rresp),
        .dma_rvalid_i(dma_rvalid),.dma_rready_o(dma_rready));

    // Only the ring writer (m3) and snapshot DMA (m4) are active.
    mn04_axi4_interconnect arb (
        .clk(clk),.rst_n(rst_n),
        .m0_awaddr(28'd0),.m0_araddr(28'd0),.m0_awlen(4'd0),.m0_arlen(4'd0),
        .m0_awvalid(1'b0),.m0_arvalid(1'b0),.m0_awready(),.m0_arready(),
        .m0_wdata(256'd0),.m0_wstrb(32'd0),.m0_wvalid(1'b0),.m0_wlast(1'b0),
        .m0_wready(),.m0_bresp(),.m0_bvalid(),.m0_bready(1'b1),
        .m0_rdata(),.m0_rresp(),.m0_rlast(),.m0_rvalid(),.m0_rready(1'b1),
        .m1_awaddr(28'd0),.m1_araddr(28'd0),.m1_awlen(4'd0),.m1_arlen(4'd0),
        .m1_awvalid(1'b0),.m1_arvalid(1'b0),.m1_awready(),.m1_arready(),
        .m1_wdata(256'd0),.m1_wstrb(32'd0),.m1_wvalid(1'b0),.m1_wlast(1'b0),
        .m1_wready(),.m1_bresp(),.m1_bvalid(),.m1_bready(1'b1),
        .m1_rdata(),.m1_rresp(),.m1_rlast(),.m1_rvalid(),.m1_rready(1'b1),
        .m2_awaddr(28'd0),.m2_araddr(28'd0),.m2_awlen(4'd0),.m2_arlen(4'd0),
        .m2_awvalid(1'b0),.m2_arvalid(1'b0),.m2_awready(),.m2_arready(),
        .m2_wdata(256'd0),.m2_wstrb(32'd0),.m2_wvalid(1'b0),.m2_wlast(1'b0),
        .m2_wready(),.m2_bresp(),.m2_bvalid(),.m2_bready(1'b1),
        .m2_rdata(),.m2_rresp(),.m2_rlast(),.m2_rvalid(),.m2_rready(1'b1),
        .m3_awaddr(ring_awaddr),.m3_araddr(28'd0),.m3_awlen(4'd0),.m3_arlen(4'd0),
        .m3_awvalid(ring_awvalid),.m3_arvalid(1'b0),.m3_awready(ring_awready),
        .m3_arready(),.m3_wdata(ring_wdata),.m3_wstrb(ring_wstrb),
        .m3_wvalid(ring_wvalid),.m3_wlast(ring_wlast),.m3_wready(ring_wready),
        .m3_bresp(ring_bresp),.m3_bvalid(ring_bvalid),.m3_bready(ring_bready),
        .m3_rdata(),.m3_rresp(),.m3_rlast(),.m3_rvalid(),.m3_rready(1'b1),
        .m4_awaddr(dma_awaddr),.m4_araddr(dma_araddr),.m4_awlen(4'd0),.m4_arlen(4'd0),
        .m4_awvalid(dma_awvalid),.m4_arvalid(dma_arvalid),
        .m4_awready(dma_awready),.m4_arready(dma_arready),
        .m4_wdata(dma_wdata),.m4_wstrb(dma_wstrb),.m4_wvalid(dma_wvalid),
        .m4_wlast(dma_wlast),.m4_wready(dma_wready),
        .m4_bresp(dma_bresp),.m4_bvalid(dma_bvalid),.m4_bready(dma_bready),
        .m4_rdata(dma_rdata),.m4_rresp(dma_rresp),.m4_rlast(),
        .m4_rvalid(dma_rvalid),.m4_rready(dma_rready),
        .m5_araddr(28'd0),.m5_arlen(4'd0),.m5_arvalid(1'b0),.m5_arready(),
        .m5_rdata(),.m5_rresp(),.m5_rlast(),.m5_rvalid(),.m5_rready(1'b1),
        .s_awaddr(s_awaddr),.s_araddr(s_araddr),.s_awlen(s_awlen),.s_arlen(s_arlen),
        .s_awvalid(s_awvalid),.s_arvalid(s_arvalid),.s_awready(s_awready),
        .s_arready(s_arready),.s_wdata(s_wdata),.s_wstrb(s_wstrb),
        .s_wvalid(s_wvalid),.s_wlast(s_wlast),.s_wready(s_wready),
        .s_bresp(s_bresp),.s_bvalid(s_bvalid),.s_bready(s_bready),
        .s_rdata(s_rdata),.s_rresp(s_rresp),.s_rlast(s_rlast),
        .s_rvalid(s_rvalid),.s_rready(s_rready));

    mn04_byte_ddr_behav #(.MEM_BYTES(24'h600000),.RD_LATENCY(3)) ddr (
        .clk(clk),.rst_n(rst_n),.awaddr_i(s_awaddr),.awvalid_i(s_awvalid),
        .awready_o(s_awready),.wdata_i(s_wdata),.wstrb_i(s_wstrb),
        .wvalid_i(s_wvalid),.wready_o(s_wready),.bresp_o(s_bresp),
        .bvalid_o(s_bvalid),.bready_i(s_bready),.araddr_i(s_araddr),
        .arvalid_i(s_arvalid),.arready_o(s_arready),.rdata_o(s_rdata),
        .rlast_o(s_rlast),.rvalid_o(s_rvalid));

    task feed_epoch;
        input integer epoch_tag;
        begin
            for(f=0;f<100;f=f+1) begin
                for(m=0;m<128;m=m+1) begin
                    @(negedge clk);
                    x0_data=(epoch_tag*41+f*3+m*7)&255;
                    x0_valid=1;
                end
                @(negedge clk);x0_valid=0;
                repeat(1100) @(negedge clk);
            end
            wait(short_ready);
            @(negedge clk);
            if(overflow || long_ready)
                $fatal(1,"ring overflow or early long ready epoch=%0d",epoch_tag);
            mism=0;
            for(m=0;m<128;m=m+1)
                for(f=0;f<100;f=f+1)
                    if(ddr.mem[24'h200000+m*100+f] !==
                       ((epoch_tag*41+f*3+m*7)&255))
                        mism=mism+1;
            if(mism)
                $fatal(1,"epoch %0d banked short snapshot mismatch=%0d",epoch_tag,mism);
        end
    endtask

    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        feed_epoch(0);
        // Emulate the runtime fabric's switch from frozen capture bank 0 to
        // live recognition bank 1 and reset its 1 s window epoch.
        @(negedge clk);ring_base=24'h520000;epoch_reset=1;
        @(negedge clk);epoch_reset=0;
        feed_epoch(1);
        $display("CONTINUOUS_SNAPSHOT_PASS dual_bank_epochs=2 frames_per_epoch=100 bytes=25600");
        $finish;
    end
    initial begin
        #50000000;
        $display("DEBUG f=%0d slot=%0d overflow=%b frame_done=%b left=%0d pending=%b dma_start=%b dma_busy=%b state=%0d",
                 f,next_slot,overflow,frame_done,dut.u_manager.short_left_r,
                 dut.u_manager.short_pending_r,dut.dma_start,dut.dma_busy,
                 dut.u_snapshot_dma.state_r);
        $fatal(1,"continuous snapshot watchdog");
    end
endmodule
