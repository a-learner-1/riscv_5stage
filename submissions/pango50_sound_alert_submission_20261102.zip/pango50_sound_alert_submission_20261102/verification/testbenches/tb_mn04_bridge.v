`timescale 1ns/1ps
// MN04 write-merge bridge UNIT test under a bounded-backpressure DDR write port.
//
// This isolates the write path (no dependence on the op0 read-side probe).
// A producer writes N bytes in core-like bursts; the DDR write port accepts
// only ACCEPT bytes then stalls STALL cycles; the bridge must:
//   * never drop / reorder / corrupt a byte (FIFO order),
//   * expose wr_ready_o that gates the producer at the STALL_THRESHOLD,
//   * never overflow (depth guard), and
//   * drain all N bytes into DDR once the producer is done.
// The received byte sequence must equal the produced sequence exactly.
module tb_mn04_bridge #(
    parameter N         = 4096,
    parameter ACCEPT    = 1,
    parameter STALL     = 7,
    parameter DEPTH     = 16,
    parameter THRESHOLD = 8
)();
    reg clk = 0, rst_n = 0;

    wire        wr_en_i;
    wire [23:0] wr_addr_i;
    wire [7:0]  wr_data_i;
    wire        wr_ready_o;
    wire        mem_wr_en_o; wire [23:0] mem_wr_addr_o; wire [7:0] mem_wr_data_o;
    reg         mem_wr_ready_i = 0;

    mn04_wmerge_bridge #(.DEPTH(DEPTH), .STALL_THRESHOLD(THRESHOLD)) u_br (
        .clk(clk), .rst_n(rst_n),
        .wr_en_i(wr_en_i), .wr_addr_i(wr_addr_i), .wr_data_i(wr_data_i),
        .wr_ready_o(wr_ready_o),
        .mem_wr_en_o(mem_wr_en_o), .mem_wr_addr_o(mem_wr_addr_o),
        .mem_wr_data_o(mem_wr_data_o), .mem_wr_ready_i(mem_wr_ready_i)
    );

    // DDR write-port bounded backpressure: accept ACCEPT bytes, then stall
    // STALL cycles, repeat (explicit state machine -- no deadlock).
    integer acc_r = 0, stall_r = 0;
    always @(posedge clk) begin
        if (STALL == 0) mem_wr_ready_i <= 1'b1;
        else if (acc_r > 0) begin
            mem_wr_ready_i <= 1'b1; acc_r <= acc_r - 1;
            if (acc_r == 1) stall_r <= STALL;
        end else if (stall_r > 0) begin
            mem_wr_ready_i <= 1'b0; stall_r <= stall_r - 1;
            if (stall_r == 1) acc_r <= ACCEPT;
        end else begin
            // initial / both-zero: start accepting
            mem_wr_ready_i <= 1'b0; acc_r <= ACCEPT;
        end
    end
    initial begin acc_r = ACCEPT; stall_r = 0; mem_wr_ready_i = 1; end

    // received sequence reference
    reg [7:0] recv [0:N-1];
    reg [23:0] recv_addr [0:N-1];
    integer recv_i = 0;

    // producer: core-like, valid/ready handshake -- wr_en_i is high only when
    // the bridge can accept, prod_i advances exactly when the bridge accepts.
    integer prod_i = 0;
    wire attempt = (prod_i < N) && wr_ready_o;
    assign wr_en_i   = attempt;
    assign wr_addr_i = prod_i[23:0];
    assign wr_data_i = prod_i[7:0];
    always @(posedge clk) begin
        if (rst_n && attempt) prod_i <= prod_i + 1;
    end

    // capture DDR side
    integer max_fill = 0;
    integer stalled_cycles = 0;
    always @(posedge clk) begin
        if (mem_wr_en_o) begin
            recv[recv_i]       <= mem_wr_data_o;
            recv_addr[recv_i]  <= mem_wr_addr_o;
            recv_i             <= recv_i + 1;
        end
        if (u_br.fill_r > max_fill) max_fill <= u_br.fill_r;
        if (!mem_wr_ready_i) stalled_cycles <= stalled_cycles + 1;
    end

    integer i;
    integer bad = 0;
    integer cycles = 0;
    reg done = 0;
    initial begin
        #20 rst_n = 1;
        // let producer finish + drain
        wait(prod_i >= N);
        wait(u_br.fill_r == 0);
        #20;
        cycles = $time / 10;   // 10ns clock
        $display("BRIDGE: prod=%0d recv=%0d max_fill=%0d stalled_cycles=%0d total_cycles=%0d",
                 prod_i, recv_i, max_fill, stalled_cycles, cycles);
        // verify order + content
        bad = 0;
        for (i = 0; i < N; i = i + 1) begin
            if (recv[i] != i[7:0] || recv_addr[i] != i) begin
                if (bad < 20)
                    $display("BRIDGE BAD i=%0d got_data=%0d got_addr=%h expect=%0d", i, recv[i], recv_addr[i], i);
                bad = bad + 1;
            end
        end
        if (prod_i != N || recv_i != N) bad = bad + 1;
        if (bad == 0) $display("BRIDGE VERDICT: PASS (N=%0d, ACCEPT=%0d, STALL=%0d, DEPTH=%0d, THRESH=%0d)",
                               N, ACCEPT, STALL, DEPTH, THRESHOLD);
        else $display("BRIDGE VERDICT: FAIL bad=%0d", bad);
        $finish;
    end

    // clock
    always #5 clk = ~clk;
    // watchdog (long: heavy stall drain of N bytes needs ~ N*(ACCEPT+STALL)*10ns)
    initial begin
        #(64'd5000000);   // 5 ms
        $display("BRIDGE: WATCHDOG TIMEOUT");
        $finish;
    end
endmodule
