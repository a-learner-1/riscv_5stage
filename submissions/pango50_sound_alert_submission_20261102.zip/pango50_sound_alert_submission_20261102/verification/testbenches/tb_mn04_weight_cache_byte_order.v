`timescale 1ns/1ps
module tb_mn04_weight_cache_byte_order;
reg clk=0,rst_n=0,start=0,valid=0,req=0;always #5 clk=~clk;
reg [7:0] data=0;reg[17:0] term=0;wire loaded,rv;wire[7:0] a,b,c,d;wire[1:0] lane;
integer i,pass,base,checked=0;
function [7:0] pattern;input integer addr,epoch;begin pattern=(addr*73)^(addr>>3)^(epoch*91);end endfunction
mn04_weight_block_cache dut(.clk(clk),.rst_n(rst_n),.load_start_i(start),.flash_base_i(24'd0),.loaded_o(loaded),.qspi_start_o(),.qspi_addr_o(),.qspi_count_o(),.qspi_byte_i(data),.qspi_byte_valid_i(valid),.qspi_byte_ready_o(),.weight_offset_i(12'd0),.req_valid_i(req),.req_ready_o(),.term_index_i(term),.rsp_valid_o(rv),.byte_lane_o(lane),.w0_o(a),.w1_o(b),.w2_o(c),.w3_o(d));
initial begin
repeat(4)@(negedge clk);rst_n=1;
for(pass=0;pass<3;pass=pass+1)begin
start=1;@(negedge clk);start=0;
for(i=0;i<4096;i=i+1)begin
valid=1;data=pattern(i,pass);@(negedge clk);
if(i%7==0)begin valid=0;repeat(3)@(negedge clk);end
end
valid=0;wait(loaded);
for(i=0;i<4096;i=i+1)begin
term=i;req=1;@(negedge clk);req=0;@(negedge clk);base=(i/4)*4;
if(a!==pattern(base,pass)||b!==pattern(base+1,pass)||c!==pattern(base+2,pass)||d!==pattern(base+3,pass)||lane!==i%4||!rv)
$fatal(1,"WEIGHT_CACHE_MISMATCH pass=%0d term=%0d word=%h lane=%d valid=%b",pass,i,{d,c,b,a},lane,rv);
checked=checked+4;
end
end
$display("WEIGHT_CACHE_BYTE_ORDER_PASS bytes_checked=%0d loads=3 offsets=4096 gaps=1 reload_without_reset=1",checked);$finish;end
endmodule
