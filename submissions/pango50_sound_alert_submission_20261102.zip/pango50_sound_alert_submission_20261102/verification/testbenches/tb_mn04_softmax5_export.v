`timescale 1ns/1ps
module tb_mn04_softmax5_export #(
    parameter LUT_FILE = "softmax_exp_q24_five_class.mem"
);
    reg clk = 0;
    always #10 clk = ~clk;
    reg rst_n = 0, logits_valid = 0;
    // class 0 in low bits: [33, 29, -24, -44, -10]
    reg [39:0] logits = {8'hf6, 8'hd4, 8'he8, 8'h1d, 8'h21};
    wire probs_valid, busy;
    wire [79:0] probs;
    mn04_softmax_q16 #(.N_CLASSES(5), .LUT_FILE(LUT_FILE)) dut (
        .clk(clk), .rst_n(rst_n), .logits_valid_i(logits_valid),
        .logits_i(logits), .probs_valid_o(probs_valid),
        .probs_q16_o(probs), .busy_o(busy));
    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1;
        logits_valid = 1;
        @(negedge clk);
        logits_valid = 0;
        wait (probs_valid);
        if (probs !== {16'd2076, 16'd221, 16'd825, 16'd27118, 16'd35295})
            $fatal(1, "export softmax mismatch: %h", probs);
        $display("SOFTMAX5_EXPORT_PASS %h", probs);
        $finish;
    end
    initial begin
        #100000;
        $fatal(1, "softmax5 export timeout");
    end
endmodule
