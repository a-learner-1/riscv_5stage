`timescale 1ns/1ps
// ---------------------------------------------------------------------------
// Read-only invariant monitor for the mn04_core residual (scale/bias) FSM.
//
// WHY THIS EXISTS
//   The residual FSM is the one structure in mn04_core that has a documented
//   deadlock history (see the comments around the 0->-1 == 15 counter wrap in
//   mn04_core.v).  Any change that touches its 32-bit "resid_k < resid_total"
//   issue compare therefore has to be proven equivalent before it can be kept.
//   This module supplies that proof harness: it is instantiated from the
//   testbench with hierarchical probes, so it changes nothing in the RTL and
//   adds no area to the synthesised netlist.
//
// INVARIANTS CHECKED (while the FSM is in S_RESID)
//   I1  resid_k never decreases.
//   I2  resid_k never advances by more than one per clock.
//   I3  resid_k never exceeds resid_total.
//   I4  when resid_k reaches resid_total the FSM must leave S_RESID within
//       STUCK_LIMIT cycles, otherwise it is reported as a suspected deadlock.
//
// The final line printed at end of simulation is machine-checkable:
//   RESID_FSM_MON items=<n> maxk=<n> errors=<n> max_stuck=<n>
// ---------------------------------------------------------------------------
module mn04_resid_fsm_monitor #(
    // Generous: a real operation issues at most a few hundred residual
    // requests, each of which needs a DDR round trip.
    parameter integer STUCK_LIMIT = 200000
)(
    input wire        clk,
    input wire        rst_n,
    input wire [3:0]  st,            // u_core.st_r (4 bits)
    input wire [31:0] resid_k,       // u_core.resid_k_r
    input wire [31:0] resid_total,   // u_core.resid_total_r
    input wire        resid_setup,   // u_core.resid_setup_r
    input wire        cand_valid     // u_core.scalar_candidate_valid_o
);
    localparam [3:0] S_RESID = 4'd10;

    integer errors;
    integer items;          // residual requests offered
    integer max_k;          // largest resid_k observed in one visit
    integer stuck_cycles;
    integer max_stuck;
    integer visits;
    integer cyc_in_resid;   // raw cycle count with st == S_RESID

    reg        in_resid_d;
    reg [31:0] prev_k;

    initial begin
        errors = 0; items = 0; max_k = 0; stuck_cycles = 0; max_stuck = 0; visits = 0; cyc_in_resid = 0;
        in_resid_d = 1'b0; prev_k = 32'd0;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            in_resid_d  <= 1'b0;
            prev_k      <= 32'd0;
            stuck_cycles = 0;
        end else begin
            if (!in_resid_d && (st == S_RESID)) begin
                // entering S_RESID: start a fresh visit
                visits     = visits + 1;
                prev_k    <= resid_k;
                stuck_cycles = 0;
                max_k      = 0;
            end else if (in_resid_d && (st == S_RESID)) begin
                // I1: never decreases
                if (resid_k < prev_k) begin
                    errors = errors + 1;
                    $display("RESID_MON_ERROR I1 k decreased %0d -> %0d at %0t",
                             prev_k, resid_k, $time);
                end
                // I2: never advances by more than one
                if (resid_k > (prev_k + 32'd1)) begin
                    errors = errors + 1;
                    $display("RESID_MON_ERROR I2 k jumped %0d -> %0d at %0t",
                             prev_k, resid_k, $time);
                end
                // I3: never exceeds the total it was given
                //     (resid_total is only valid after the setup cycle)
                if (!resid_setup && (resid_total != 32'd0) && (resid_k > resid_total)) begin
                    errors = errors + 1;
                    $display("RESID_MON_ERROR I3 k=%0d > total=%0d at %0t",
                             resid_k, resid_total, $time);
                end
                if (resid_k > max_k) max_k = resid_k;
                // I4: must leave once complete
                if (!resid_setup && (resid_total != 32'd0) && (resid_k >= resid_total)) begin
                    stuck_cycles = stuck_cycles + 1;
                    if (stuck_cycles > max_stuck) max_stuck = stuck_cycles;
                    if (stuck_cycles == STUCK_LIMIT) begin
                        errors = errors + 1;
                        $display("RESID_MON_ERROR I4 stuck in S_RESID for %0d cycles with k=%0d total=%0d at %0t",
                                 STUCK_LIMIT, resid_k, resid_total, $time);
                    end
                end else begin
                    stuck_cycles = 0;
                end
                prev_k <= resid_k;
            end else if (in_resid_d && (st != S_RESID)) begin
                // leaving S_RESID: an incomplete visit is a real problem
                if (!resid_setup && (resid_total != 32'd0) && (resid_k != resid_total)) begin
                    errors = errors + 1;
                    $display("RESID_MON_ERROR leave S_RESID early: k=%0d total=%0d at %0t",
                             resid_k, resid_total, $time);
                end
                stuck_cycles = 0;
            end

            if (st == S_RESID) cyc_in_resid = cyc_in_resid + 1;
            if (cand_valid) items = items + 1;
            in_resid_d <= (st == S_RESID);
        end
    end
endmodule