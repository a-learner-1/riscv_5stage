`timescale 1ns/1ps
// Small byte-addressed DDR user-port model for feature-ring simulations.
// Unlike mn04_ddr_behav, this follows the byte addresses and WSTRB lanes used
// by mn04_ddr_act_byte_writer and emits a delayed write response.
module mn04_byte_ddr_behav #(
    parameter integer MEM_BYTES = 24'h600000,
    parameter integer RD_LATENCY = 3
)(
    input  wire clk, rst_n,
    input  wire [27:0] awaddr_i,
    input  wire awvalid_i,
    output wire awready_o,
    input  wire [255:0] wdata_i,
    input  wire [31:0] wstrb_i,
    input  wire wvalid_i,
    output wire wready_o,
    output reg [1:0] bresp_o,
    output reg bvalid_o,
    input  wire bready_i,
    input  wire [27:0] araddr_i,
    input  wire arvalid_i,
    output wire arready_o,
    output reg [255:0] rdata_o,
    output reg rlast_o,
    output reg rvalid_o
);
    reg [7:0] mem [0:MEM_BYTES-1];
    reg wr_pending_r, rd_pending_r;
    reg [27:0] wr_addr_r, rd_addr_r;
    reg [7:0] rd_delay_r;
    reg [2:0] b_delay_r;
    integer lane;

    assign awready_o = !wr_pending_r && !rd_pending_r && !bvalid_o;
    assign wready_o = wr_pending_r;
    assign arready_o = !wr_pending_r && !rd_pending_r && !bvalid_o;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_pending_r <= 1'b0;
            rd_pending_r <= 1'b0;
            wr_addr_r <= 0;
            rd_addr_r <= 0;
            rd_delay_r <= 0;
            b_delay_r <= 0;
            bresp_o <= 0;
            bvalid_o <= 1'b0;
            rdata_o <= 0;
            rlast_o <= 1'b0;
            rvalid_o <= 1'b0;
        end else begin
            rvalid_o <= 1'b0;
            rlast_o <= 1'b0;
            if (bvalid_o && bready_i) bvalid_o <= 1'b0;
            if (b_delay_r != 0) begin
                b_delay_r <= b_delay_r - 1'b1;
                if (b_delay_r == 1) begin
                    bvalid_o <= 1'b1;
                    bresp_o <= 2'b00;
                end
            end

            if (!wr_pending_r && !rd_pending_r && !bvalid_o) begin
                if (arvalid_i && arready_o) begin
                    rd_pending_r <= 1'b1;
                    rd_addr_r <= araddr_i;
                    rd_delay_r <= RD_LATENCY[7:0];
                end else if (awvalid_i && awready_o) begin
                    wr_pending_r <= 1'b1;
                    wr_addr_r <= awaddr_i;
                end
            end

            if (wr_pending_r && wvalid_i && wready_o) begin
                for (lane = 0; lane < 32; lane = lane + 1)
                    if (wstrb_i[lane])
                        mem[(wr_addr_r & 28'hFFFFFE0) + lane] <=
                            wdata_i[8*lane +: 8];
                wr_pending_r <= 1'b0;
                b_delay_r <= 3'd3;
            end

            if (rd_pending_r) begin
                if (rd_delay_r == 0) begin
                    for (lane = 0; lane < 32; lane = lane + 1)
                        rdata_o[8*lane +: 8] <=
                            mem[(rd_addr_r & 28'hFFFFFE0) + lane];
                    rd_pending_r <= 1'b0;
                    rvalid_o <= 1'b1;
                    rlast_o <= 1'b1;
                end else rd_delay_r <= rd_delay_r - 1'b1;
            end
        end
    end
endmodule
