`timescale 1ns/1ps
module tb_mn04_template_enrollment #(parameter integer CNN_CLASS_COUNT=6);
    localparam integer WINDOW_BYTES=128*100;
    localparam integer WARMUP_BYTES=128*20;
    localparam integer TEMPLATE_BYTES=6*WINDOW_BYTES;
    reg clk=0,rst_n=0,capture_recording=0,x0_valid=0;
    reg [3:0] capture_category=0;
    reg signed [7:0] x0=0;
    reg [1:0] overflow=0;
    wire load_we,commit;
    wire [17:0] load_addr;
    wire signed [7:0] load_data;
    wire [5:0] valid_mask,invalid_mask;
    wire [3:0] committed_category;
    wire [2:0] committed_map;
    reg signed [7:0] matcher_mem [0:TEMPLATE_BYTES-1];
    integer i,checked;

    always #5 clk=~clk;

    mn04_template_enrollment #(.CNN_CLASS_COUNT(CNN_CLASS_COUNT)) enrollment(
        .clk(clk),.rst_n(rst_n),
        .capture_recording_i(capture_recording),
        .capture_category_i(capture_category),.overflow_i(overflow),
        .x0_i(x0),.x0_valid_i(x0_valid),
        .template_load_we_o(load_we),.template_load_addr_o(load_addr),
        .template_load_data_o(load_data),.valid_mask_o(valid_mask),
        .invalid_mask_o(invalid_mask),
        .enrollment_commit_o(commit),
        .enrollment_category_o(committed_category),
        .enrollment_map_o(committed_map));

    always @(posedge clk)
        if(load_we) matcher_mem[load_addr] <= load_data;

    function [7:0] feature_value;
        input integer category;
        input integer sample_index;
        integer signed value;
        begin
            value=((sample_index*13 + category*29) % 113)-56;
            feature_value=value[7:0];
        end
    endfunction

    task record_aborted_partial_take;
        integer sample_index;
        begin
            @(negedge clk);
            capture_category=CNN_CLASS_COUNT;
            capture_recording=1'b1;
            @(negedge clk);
            for(sample_index=0;sample_index<256;sample_index=sample_index+1) begin
                x0=feature_value(6,sample_index);
                x0_valid=1'b1;
                @(negedge clk);
            end
            x0_valid=1'b0;
            capture_recording=1'b0;
            @(negedge clk);
            if(commit || valid_mask[0] || !invalid_mask[0])
                $fatal(1,"aborted partial capture left a corrupt template marked valid");
            @(negedge clk);
        end
    endtask

    task record_take;
        input integer category;
        input integer map_index;
        input [5:0] expected_valid_mask;
        integer sample_index;
        begin
            @(negedge clk);
            capture_category=category[3:0];
            capture_recording=1'b1;
            @(negedge clk);
            if(!invalid_mask[map_index] || valid_mask[map_index])
                $fatal(1,"map %0d was not invalidated while being replaced",map_index);
            // The first 20 feature frames model the start-button click/reverb.
            // They must be discarded independently for every take.
            for(sample_index=0;sample_index<WARMUP_BYTES;sample_index=sample_index+1) begin
                x0=8'sd120;
                x0_valid=1'b1;
                @(negedge clk);
            end
            for(sample_index=0;sample_index<WINDOW_BYTES;sample_index=sample_index+1) begin
                x0=feature_value(category,sample_index);
                x0_valid=1'b1;
                @(negedge clk);
            end
            x0_valid=1'b0;
            capture_recording=1'b0;
            @(negedge clk);
            if(!commit || committed_category!==category[3:0] ||
               committed_map!==map_index[2:0])
                $fatal(1,"wrong template commit category=%0d map=%0d commit=%b got=%0d/%0d",
                       category,map_index,commit,committed_category,committed_map);
            if(valid_mask!==expected_valid_mask)
                $fatal(1,"valid mask did not reflect complete committed maps: expected=%b got=%b",
                       expected_valid_mask,valid_mask);
            if(invalid_mask!==6'b000000)
                $fatal(1,"completed enrollment left an invalidation bit set: %b",invalid_mask);
            checked=0;
            for(sample_index=0;sample_index<WINDOW_BYTES;sample_index=sample_index+1) begin
                if(matcher_mem[map_index*WINDOW_BYTES+sample_index] !==
                   feature_value(category,sample_index))
                    checked=checked+1;
            end
            if(checked!=0)
                $fatal(1,"category %0d template RAM differs at %0d bytes",category,checked);
            @(negedge clk);
        end
    endtask

    task reject_transient_overflow;
        integer n;
        begin
            @(negedge clk);capture_category=CNN_CLASS_COUNT;capture_recording=1;
            @(negedge clk);
            for(n=0;n<WINDOW_BYTES;n=n+1) begin
                x0=feature_value(CNN_CLASS_COUNT,n);x0_valid=1;
                overflow=(n==100) ? 2'b10 : 2'b00;
                @(negedge clk);
            end
            x0_valid=0;overflow=0;capture_recording=0;@(negedge clk);
            if(commit || valid_mask[0] || !invalid_mask[0])
                $fatal(1,"transient overflow was forgotten and corrupt template committed");
            @(negedge clk);
            $display("TRANSIENT_OVERFLOW_REJECT_PASS");
        end
    endtask

    initial begin
        repeat(4) @(negedge clk);
        rst_n=1'b1;
        record_aborted_partial_take();
        reject_transient_overflow();
        record_take(CNN_CLASS_COUNT,0,6'b000001); // doorbell template 1
        record_take(CNN_CLASS_COUNT,1,6'b000011); // doorbell template 2
        record_take(CNN_CLASS_COUNT+1,2,6'b000111); // smoke alarm template 1
        record_take(CNN_CLASS_COUNT+1,3,6'b001111); // smoke alarm template 2
        record_take(CNN_CLASS_COUNT+2,4,6'b011111); // gas / CO template 1
        record_take(CNN_CLASS_COUNT+2,5,6'b111111); // gas / CO template 2
        if(valid_mask!==6'b111111)
            $fatal(1,"three template classes did not occupy maps 0..5: %b",valid_mask);
        $display("LOCAL_TEMPLATE_ENROLLMENT_ALL_THREE_PASS categories=%0d/%0d/%0d maps=0..5 warmup_frames=20 each bytes_each=%0d",
                 CNN_CLASS_COUNT,CNN_CLASS_COUNT+1,CNN_CLASS_COUNT+2,WINDOW_BYTES);
        $finish;
    end

    initial begin
        #50000000;
        $fatal(1,"local template enrollment test watchdog");
    end
endmodule
