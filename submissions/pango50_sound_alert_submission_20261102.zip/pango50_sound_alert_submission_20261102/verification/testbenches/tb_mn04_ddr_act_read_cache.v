`timescale 1ns/1ps
module tb_mn04_ddr_act_read_cache;
    reg clk=0, rst_n=0;
    always #5 clk=~clk;
    reg flush=0, invalidate=0, drained=1;
    reg [23:0] write_addr=0;
    reg candidate_valid=0, candidate_pad=0;
    reg [23:0] candidate_addr=0;
    wire candidate_ready;
    reg rd_valid=0, rd_pad=0;
    reg [23:0] rd_addr=0;
    wire rd_rsp;
    wire [31:0] rd_data;
    wire [1:0] rd_lane;
    wire [31:0] conv_data;
    wire [1:0] conv_lane;
    wire [27:0] araddr;
    wire arvalid, arready, rvalid;
    wire [255:0] rdata;
    integer n, i;
    mn04_ddr_act_read_cache #(.LINE_BITS(11)) dut(
        .clk(clk),.rst_n(rst_n),.flush_i(flush),
        .write_invalidate_i(invalidate),.write_addr_i(write_addr),
        .writes_drained_i(drained),
        .candidate_valid_i(candidate_valid),.candidate_addr_i(candidate_addr),
        .candidate_pad_i(candidate_pad),.candidate_ready_o(candidate_ready),
        .rd_req_valid_i(rd_valid),.rd_byte_addr_i(rd_addr),.rd_req_pad_i(rd_pad),
        .rd_rsp_valid_o(rd_rsp),.rd_data_o(rd_data),.rd_lane_o(rd_lane),
        .conv_data_o(conv_data),.conv_lane_o(conv_lane),
        .ddr_araddr_o(araddr),.ddr_arvalid_o(arvalid),
        .ddr_arready_i(arready),.ddr_rdata_i(rdata),
        .ddr_rresp_i(2'b00),.ddr_rvalid_i(rvalid),.ddr_rready_o());
    mn04_ddr_behav #(.MEM_BYTES(24'h140100),.RD_LATENCY(4)) ddr(
        .clk(clk),.rst_n(rst_n),
        .awaddr_i(28'd0),.awlen_i(4'd0),.awvalid_i(1'b0),
        .awready_o(),.wdata_i(256'd0),.wstrb_i(32'd0),.wready_o(),
        .araddr_i(araddr >> 2),.arlen_i(4'd0),.arvalid_i(arvalid),
        .arready_o(arready),.rdata_o(rdata),.rlast_o(),.rvalid_o(rvalid));

    task await_candidate;
        begin
            n=0;
            while (!candidate_ready && n<100) begin @(negedge clk); n=n+1; end
            if (!candidate_ready) $fatal(1,"candidate never became ready");
        end
    endtask
    task await_read;
        input [31:0] expect_data;
        input [1:0] expect_lane;
        begin
            n=0;
            while (!rd_rsp && n<100) begin @(negedge clk); n=n+1; end
            if (!rd_rsp || rd_data !== expect_data || rd_lane !== expect_lane)
                $fatal(1,"read mismatch got=%h lane=%d expected=%h lane=%d",
                       rd_data,rd_lane,expect_data,expect_lane);
            @(negedge clk);
        end
    endtask
    initial begin
        #1;
        for (i=0;i<1024;i=i+1) ddr.mem[i]=i[7:0];
        repeat(4) @(negedge clk);
        rst_n=1;
        // Padded convolution terms are valid requests whose value must be
        // exactly zero, independent of the cache RAM's uninitialized state.
        rd_addr=24'hffff9b; rd_pad=1; rd_valid=1;
        @(negedge clk); rd_valid=0; rd_pad=0;
        await_read(32'd0,2'd3);

        candidate_addr=24'h24; candidate_valid=1;
        #1; if (candidate_ready) $fatal(1,"cold miss incorrectly ready");
        await_candidate();
        candidate_valid=0;
        rd_addr=24'h24; rd_valid=1;
        @(negedge clk); rd_valid=0;
        await_read(32'h27262524,2'd0);

        candidate_addr=24'h24; candidate_valid=1;
        invalidate=1; write_addr=24'h25; drained=0;
        #1; if (candidate_ready) $fatal(1,"invalidated line still ready");
        // The invalidate is a registered full-cycle pulse in the real fabric
        // (mn04_core wr_en).  Hold it across a clock edge so a registered
        // candidate-lookup pipeline actually samples it; a sub-cycle pulse
        // would be invisible to any flop-based suppression.
        @(posedge clk); @(negedge clk);
        invalidate=0;
        repeat(4) begin
            @(negedge clk);
            if (arvalid || candidate_ready) $fatal(1,"miss bypassed write drain");
        end
        ddr.mem[8'h25]=8'haa;
        drained=1;
        await_candidate();
        candidate_valid=0;
        rd_addr=24'h25; rd_valid=1;
        @(negedge clk); rd_valid=0;
        await_read(32'h2726aa24,2'd1);

        // Continuous convolution reads use the synchronous BRAM result path
        // directly. It must track the request at issue+1 so the core's two
        // activation registers line up with its three-edge MAC-valid pipe.
        repeat(2) @(negedge clk);
        rd_addr=24'h24; rd_valid=1;
        @(posedge clk); #1;
        if(conv_data!==32'h2726aa24 || conv_lane!==2'd0)
            $fatal(1,"conv read 0 misaligned data=%h lane=%0d",conv_data,conv_lane);
        @(negedge clk); rd_addr=24'h25;
        @(posedge clk); #1;
        if(conv_data!==32'h2726aa24 || conv_lane!==2'd1)
            $fatal(1,"conv read 1 misaligned data=%h lane=%0d",conv_data,conv_lane);
        @(negedge clk); rd_addr=24'h26;
        @(posedge clk); #1;
        if(conv_data!==32'h2726aa24 || conv_lane!==2'd2)
            $fatal(1,"conv read 2 misaligned data=%h lane=%0d",conv_data,conv_lane);
        @(negedge clk); rd_valid=0;
        repeat(4) @(negedge clk); // drain the non-conv response-valid pipeline

        drained=0;
        rd_addr=24'h44; rd_valid=1;
        @(negedge clk); rd_valid=0;
        repeat(4) begin @(negedge clk); if (rd_rsp) $fatal(1,"early miss response"); end
        drained=1;
        await_read(32'h47464544,2'd0);
        flush=1; @(negedge clk); flush=0;
        candidate_addr=24'h44; candidate_valid=1;
        #1; if (candidate_ready) $fatal(1,"flush retained line");
        await_candidate();
        candidate_valid=0;
        ddr.mem[24'h040000]=8'h11;
        ddr.mem[24'h140000]=8'h22;
        candidate_addr=24'h140000; candidate_valid=1;
        await_candidate();
        candidate_valid=0;
        rd_addr=24'h140000; rd_valid=1;
        @(negedge clk); rd_valid=0;
        await_read(32'h00000022,2'd0);
        $display("ACT_READ_CACHE_PASS");
        $finish;
    end
    initial begin #10000; $fatal(1,"watchdog"); end
endmodule
