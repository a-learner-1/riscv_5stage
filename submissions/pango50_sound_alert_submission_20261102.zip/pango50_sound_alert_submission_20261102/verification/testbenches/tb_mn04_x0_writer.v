`timescale 1ns/1ps
// Standalone tb for mn04_x0_writer: feeds a frame-major x0 stream (numpy
// transpose of the mel-major x0 hex) and checks that the behavioral DDR ends
// up byte-identical to the mel-major reference the MN04 core consumes.
module tb_mn04_x0_writer #(
    parameter integer MEL_BINS = 128,
    parameter integer N_FRAMES = 1000
);
    localparam integer TOTAL = MEL_BINS * N_FRAMES;   // 128000
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    reg [7:0] x0_frame [0:TOTAL-1];     // frame-major input (numpy transpose)
    reg [7:0] x0_mel_ref [0:TOTAL-1];   // mel-major reference (= x0 hex)
    integer i;

    reg x0_valid = 0;
    reg [7:0] x0_data = 0;
    wire x0_ready, done;
    wire [27:0] awaddr; wire awvalid, awready, wready;
    wire [255:0] wdata; wire [31:0] wstrb; wire drained;

    mn04_x0_writer #(.MEL_BINS(MEL_BINS), .N_FRAMES(N_FRAMES)) dut (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(1'b1),
        .overflow_clear_i(1'b0),
        .x0_valid_i(x0_valid), .x0_data_i(x0_data),
        .x0_base_byte_i(24'h000000), .x0_ready_o(x0_ready),
        .done_o(done),
        .ddr_awaddr_o(awaddr), .ddr_awvalid_o(awvalid), .ddr_awready_i(awready),
        .ddr_wdata_o(wdata), .ddr_wstrb_o(wstrb), .ddr_wready_i(wready),
        .drained_o(drained));

    mn04_ddr_behav #(.MEM_BYTES(24'h200000), .RD_LATENCY(4)) ddr (
        .clk(clk), .rst_n(rst_n),
        .awaddr_i(awaddr), .awlen_i(4'd0), .awvalid_i(awvalid),
        .awready_o(awready), .wdata_i(wdata), .wstrb_i(wstrb),
        .wready_o(wready),
        .araddr_i(28'd0), .arlen_i(4'd0), .arvalid_i(1'b0),
        .arready_o(), .rdata_o(), .rlast_o(), .rvalid_o());

    integer n, mism;
    initial begin
        $readmemh("mem/x0_frame_major_car_horn_car_horn_001.hex", x0_frame);
        $readmemh("mem/x0_car_horn_car_horn_001.wav.hex", x0_mel_ref);
        repeat (4) @(negedge clk);
        rst_n = 1;
        @(negedge clk);
        n = 0;
        while (n < TOTAL) begin
            @(negedge clk);
            if (x0_ready) begin
                x0_data = x0_frame[n];
                x0_valid = 1;
                @(negedge clk);
                x0_valid = 0;
                n = n + 1;
            end
        end
        wait (done);
        repeat (3) @(negedge clk);
        mism = 0;
        for (i = 0; i < TOTAL; i = i + 1)
            if (ddr.mem[i] !== x0_mel_ref[i]) begin
                if (mism < 8)
                    $display("MISM i=%0d got=%02x exp=%02x", i, ddr.mem[i], x0_mel_ref[i]);
                mism = mism + 1;
            end
        if (mism != 0) $fatal(1, "x0 writer transpose mismatch: %0d bytes", mism);
        $display("X0_WRITER_PASS total=%0d done=%0d", TOTAL, done);
        $finish;
    end
    initial begin #20000000; $fatal(1, "watchdog timeout"); end
endmodule
