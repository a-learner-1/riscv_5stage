`timescale 1ns/1ps
// Cross-module test for the real board UART protocol: R arms the one-shot
// listener while T0/T1 starts a capture. Exercise both result sources (CNN
// class output and template match) while UART capture is active; the alert
// remains latched, but listening/audio work stops only after the TX drain.
module tb_uart_capture_control_integration;
    localparam integer CLOCK_HZ = 1152000;
    localparam integer BAUD = 115200;
    localparam integer CAPTURE_FRAMES = 4;
    localparam integer TOTAL_BYTES = 64;
    localparam integer TX_FIFO_DEPTH = 16;

    reg clk = 0, rst_n = 0, uart_rx = 1;
    reg ring_frame_done = 0;
    reg probs_valid = 0, template_valid = 0;
    reg [127:0] probs = 0;
    reg [1:0] template_class = 0;
    reg [9:0] ring_next_slot = 10'd37;
    wire uart_tx, freeze, task_busy, stream_phase;
    wire recognition_enable, motor, work_mode, alert_accept;
    wire [3:0] display_class;
    wire display_valid;
    wire [27:0] cap_araddr;
    wire cap_arvalid, cap_rready;
    reg cap_arready = 0;
    reg [255:0] cap_rdata = 0;
    reg [1:0] cap_rresp = 0;
    reg cap_rvalid = 0;
    integer rx_buf_len = 0;
    reg [7:0] rx_buf [0:200];
    integer i;

    always #5 clk = ~clk;

    mn04_train_capture #(
        .RING_BASE_BYTE(24'h500000), .TOTAL_BYTES(TOTAL_BYTES),
        .CAPTURE_FRAMES(CAPTURE_FRAMES), .CLOCK_HZ(CLOCK_HZ),
        .BAUD(BAUD), .TX_FIFO_DEPTH(TX_FIFO_DEPTH)
    ) capture (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(1'b1),
        .uart_rx_i(uart_rx), .uart_tx_o(uart_tx),
        .freeze_o(freeze), .task_busy_o(task_busy), .stream_phase_o(stream_phase),
        .freeze_ack_i(freeze), .ring_drained_i(freeze),
        .ring_frame_done_i(ring_frame_done),
        .ring_next_slot_i(ring_next_slot), .overflow_i(2'b00),
        .ddr_araddr_o(cap_araddr), .ddr_arvalid_o(cap_arvalid),
        .ddr_arready_i(cap_arready), .ddr_rdata_i(cap_rdata),
        .ddr_rresp_i(cap_rresp), .ddr_rvalid_i(cap_rvalid),
        .ddr_rready_o(cap_rready)
    );

    v1_board_postcnn_top #(
        .EIGHT_CLASS_MODE(1), .ONE_SHOT_MODE(1), .CLOCK_HZ(CLOCK_HZ),
        .KNOCK_THRESHOLD_Q16(16'd100),
        .SPI_HZ(BAUD), .RESET_CYCLES(1), .PWR_DELAY_CYCLES(1),
        .DISPLAY_DELAY_CYCLES(1)
    ) control (
        .clk(clk), .rst_n(rst_n), .work_key_n_i(1'b1),
        .confirm_key_n_i(1'b1), .uart_rx_i(uart_rx),
        .external_task_busy_i(task_busy), .probs_valid_i(probs_valid),
        .probs_q16_i(probs), .template_result_valid_i(template_valid),
        .template_result_class_i(template_class), .short_window_i(1'b1),
        .display_asset_we_i(1'b0), .display_asset_addr_i(15'd0),
        .display_asset_data_i(8'd0),
        .set_time_i(1'b0), .set_hour_i(8'b0),
        .set_minute_i(8'b0), .set_second_i(8'b0),
        .motor_o(motor), .recognition_enable_o(recognition_enable),
        .work_mode_o(work_mode), .alert_accept_o(alert_accept), .confirm_pulse_o(),
        .panel_ready_o(), .panel_busy_o(), .tft_nrst_o(),
        .tft_backlight_o(), .tft_sclk_o(), .tft_mosi_o(),
        .tft_dc_o(), .tft_cs_n_o()
    );

    function [255:0] beat_data(input [27:0] addr);
        integer k;
        begin
            beat_data = 256'd0;
            for (k = 0; k < 32; k = k + 1)
                beat_data[8*k +: 8] = (addr[7:0] + k) & 8'hFF;
        end
    endfunction

    always @(posedge clk) begin
        if (!rst_n) begin
            cap_arready <= 0;
            cap_rvalid <= 0;
        end else begin
            cap_rvalid <= 0;
            if (cap_arvalid && cap_arready) begin
                cap_rdata <= beat_data(cap_araddr);
                cap_rvalid <= 1;
            end
            cap_arready <= ~(cap_arvalid && cap_arready);
        end
    end

    task uart_byte(input [7:0] d);
        integer b;
        begin
            uart_rx = 0; repeat(10) @(negedge clk);
            for (b = 0; b < 8; b = b + 1) begin
                uart_rx = d[b]; repeat(10) @(negedge clk);
            end
            uart_rx = 1; repeat(30) @(negedge clk);
        end
    endtask

    task frame_done_pulse;
        begin
            @(negedge clk); ring_frame_done = 1;
            @(negedge clk); ring_frame_done = 0;
            repeat(2) @(negedge clk);
        end
    endtask

    initial begin : uart_tx_monitor
        forever begin
            @(negedge uart_tx);
            repeat(15) @(negedge clk);
            for (i = 0; i < 8; i = i + 1) begin
                rx_buf[rx_buf_len][i] = uart_tx;
                repeat(10) @(negedge clk);
            end
            rx_buf_len = rx_buf_len + 1;
        end
    end

    integer f;
    initial begin
        repeat(5) @(negedge clk); rst_n = 1;
        repeat(5) @(negedge clk);
        uart_byte("R");
        if (!recognition_enable) $fatal(1, "UART R did not arm recognition");
        uart_byte("T");
        uart_byte("0");
        if (!task_busy || !recognition_enable)
            $fatal(1, "T0 capture did not run beside the armed listener");
        // A CNN knock decision arrives while the first capture is active.
        repeat(2) frame_done_pulse();
        probs[47:32] = 16'd20000; // class 2: knock
        probs_valid = 1;
        wait(alert_accept);
        if (!motor || !recognition_enable)
            $fatal(1, "CNN result did not alert while UART capture remained active");
        @(negedge clk); probs_valid = 0; probs = 0;
        for (f = 2; f < CAPTURE_FRAMES; f = f + 1) frame_done_pulse();
        wait(rx_buf_len >= 9 + TOTAL_BYTES + 2);
        if (!task_busy || !recognition_enable)
            $fatal(1, "listener stopped before UART stop bits and FIFO drained");
        wait(!task_busy);
        repeat(5) @(negedge clk);
        if (rx_buf[0] !== 8'hAA || rx_buf[1] !== 8'h55 ||
            rx_buf[2] !== 8'd0 || rx_buf[3] !== TOTAL_BYTES[7:0])
            $fatal(1, "capture response header mismatch");
        if (task_busy || recognition_enable || !work_mode || !motor) begin
            $display("DEBUG busy=%b enable=%b work=%b bytes=%0d", task_busy,
                     recognition_enable, work_mode, rx_buf_len);
            $fatal(1, "CNN alert/session state incorrect after UART dump drained");
        end

        // Acknowledge the first alert and exercise the independent template
        // result path in a second enrollment-style T1 capture.
        uart_byte("C");
        if (motor) $fatal(1, "C did not clear the CNN alert");
        uart_byte("R");
        if (!recognition_enable)
            $fatal(1, "R did not rearm after acknowledging the first alert");
        uart_byte("T");
        uart_byte("1");
        if (!task_busy || !recognition_enable) begin
            $display("DEBUG second_start busy=%b enable=%b motor=%b work=%b bytes=%0d",
                     task_busy, recognition_enable, motor, work_mode, rx_buf_len);
            $fatal(1, "T1 capture did not run beside the rearmed listener");
        end
        repeat(2) frame_done_pulse();
        template_class = 2'd1; // doorbell
        template_valid = 1;
        wait(alert_accept);
        if (!motor || !recognition_enable)
            $fatal(1, "template result did not alert while UART capture remained active");
        @(negedge clk); template_valid = 0; template_class = 0;
        for (f = 2; f < CAPTURE_FRAMES; f = f + 1) frame_done_pulse();
        wait(rx_buf_len >= 2 * (9 + TOTAL_BYTES + 2));
        wait(!task_busy);
        repeat(5) @(negedge clk);
        if (rx_buf[9 + TOTAL_BYTES + 2] !== 8'hAA ||
            rx_buf[9 + TOTAL_BYTES + 3] !== 8'h55 ||
            rx_buf[9 + TOTAL_BYTES + 4] !== 8'd1)
            $fatal(1, "template capture response header mismatch");
        if (task_busy || recognition_enable || !work_mode || !motor)
            $fatal(1, "template alert/session state incorrect after UART dump drained");
        $display("UART_CAPTURE_CONTROL_INTEGRATION_PASS CNN+template->UART drain->idle");
        $finish;
    end

    initial begin
        #2000000;
        $fatal(1, "watchdog timeout rx_buf_len=%0d busy=%b enable=%b",
               rx_buf_len, task_busy, recognition_enable);
    end
endmodule
