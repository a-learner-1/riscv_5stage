`timescale 1ns/1ps
module tb_mn04_softmax_q16 #(
    parameter LUT_FILE = "softmax_exp_q24.mem"
)();
    reg clk=0, rst_n=0, logits_valid=0;
    reg [55:0] logits=0;
    wire probs_valid, busy;
    wire [111:0] probs;
    integer cycles=0;
    always #5 clk=~clk;
    always @(posedge clk) cycles <= cycles+1;

    mn04_softmax_q16 #(.LUT_FILE(LUT_FILE)) dut(
        .clk(clk), .rst_n(rst_n), .logits_valid_i(logits_valid),
        .logits_i(logits), .probs_valid_o(probs_valid),
        .probs_q16_o(probs), .busy_o(busy));

    task check;
        input [55:0] input_logits;
        begin
            @(negedge clk);
            logits=input_logits;
            logits_valid=1;
            @(negedge clk);
            logits_valid=0;
            wait (probs_valid);
            $display("SMTEST logits=%h probs=%h cycles=%0d", input_logits, probs, cycles);
            @(negedge clk);
        end
    endtask

    initial begin
        #25 rst_n=1;
        check(56'h00000000000000);
        check(56'hd8d8d8d8d828d8);
        // Frozen V1 baby-cry golden logits, class0 in low byte.
        check(56'h04d6eae8e04bef);
        check(56'h7f807f80807f80);
        $display("SMTEST DONE");
        $finish;
    end
    initial begin
        #100000;
        $fatal(1,"softmax timeout");
    end
endmodule
