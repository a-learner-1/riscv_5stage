`timescale 1ns/1ps
// Functional check of manually delimited mn04_train_capture. The fake DDR
// returns bytes from aligned 32-byte beats; checks dynamic length, minimum
// duration, mel-major ordering, checksum, and UART FIFO backpressure.
module tb_mn04_train_capture;
    localparam integer CLOCK_HZ = 1152000;   // 10 bits/cycle UART, fast sim
    localparam integer BAUD = 115200;
    localparam integer MEL_BINS = 128;
    localparam integer RING_FRAMES = 1000;
    parameter integer CAPTURE_FRAMES = 4;
    localparam integer MIN_CAPTURE_FRAMES = CAPTURE_FRAMES < 100 ? CAPTURE_FRAMES : 100;
    localparam integer TOTAL_BYTES = MEL_BINS * CAPTURE_FRAMES;
    localparam integer TX_FIFO_DEPTH = 16;
    localparam [23:0] RING_BASE = 24'h500000;

    reg clk = 0;
    reg rst_n = 0;
    reg ddr_init_done = 0;
    reg uart_rx = 1'b1;
    reg local_capture_start = 0, local_capture_stop = 0, local_capture_label_confirm=0;
    reg [3:0] local_capture_label = 4'd10;
    wire uart_tx;
    wire freeze,task_busy;
    wire label_select_wait;
    reg freeze_ack = 0, ring_drained = 0, ring_frame_done = 0;
    reg [9:0] ring_next_slot = 10'd37;
    reg [1:0] overflow = 0;
    wire [27:0] cap_araddr;
    wire cap_arvalid;
    reg  cap_arready = 0;
    reg  [255:0] cap_rdata;
    reg  [1:0] cap_rresp = 2'b0;
    reg  cap_rvalid = 0;
    wire cap_rready;

    always #5 clk = ~clk;   // 100 ns period

    mn04_train_capture #(
        .RING_BASE_BYTE(RING_BASE), .MEL_BINS(MEL_BINS),
        .RING_FRAMES(RING_FRAMES),
        .MIN_CAPTURE_FRAMES(MIN_CAPTURE_FRAMES),
        .MAX_CAPTURE_FRAMES(RING_FRAMES),
        .CLOCK_HZ(CLOCK_HZ), .BAUD(BAUD),.TX_FIFO_DEPTH(TX_FIFO_DEPTH)
    ) dut (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done),
        .uart_rx_i(uart_rx), .uart_tx_o(uart_tx), .freeze_o(freeze),
        .local_capture_start_i(local_capture_start),
        .local_capture_stop_i(local_capture_stop),
        .local_capture_label_confirm_i(local_capture_label_confirm),
        .local_capture_label_i(local_capture_label),
        .task_busy_o(task_busy), .stream_phase_o(),
        .label_select_wait_o(label_select_wait),
        .freeze_ack_i(freeze_ack), .ring_drained_i(ring_drained),
        .ring_frame_done_i(ring_frame_done), .ring_next_slot_i(ring_next_slot),
        .overflow_i(overflow),
        .ddr_araddr_o(cap_araddr), .ddr_arvalid_o(cap_arvalid),
        .ddr_arready_i(cap_arready), .ddr_rdata_i(cap_rdata),
        .ddr_rresp_i(cap_rresp), .ddr_rvalid_i(cap_rvalid),
        .ddr_rready_o(cap_rready));

    // --- fake DDR read responder: one outstanding, one-cycle latency ---------
    always @(posedge clk) begin
        if (!rst_n) begin
            cap_arready <= 0; cap_rvalid <= 0;
        end else begin
            cap_rvalid <= 0;   // pulse
            if (cap_arvalid && cap_arready) begin
                cap_rdata <= beat_data(cap_araddr);
                cap_rvalid <= 1'b1;
            end
            cap_arready <= ~(cap_arvalid && cap_arready);
        end
    end

    function [255:0] beat_data(input [27:0] addr);
        integer k;
        reg [27:0] aligned_addr;
        begin
            beat_data = 256'd0;
            aligned_addr = {addr[27:5],5'b0};
            for (k = 0; k < 32; k = k + 1)
                beat_data[8*k +: 8] = (aligned_addr[7:0] + k) & 8'hFF;
        end
    endfunction

    // --- UART RX driver (10 cycles/bit) -------------------------------------
    task uart_byte(input [7:0] d);
        integer b;
        begin
            uart_rx = 0;                       // start bit
            repeat (10) @(negedge clk);
            for (b = 0; b < 8; b = b + 1) begin
                uart_rx = d[b];
                repeat (10) @(negedge clk);
            end
            uart_rx = 1'b1;                    // stop bit
            repeat (10) @(negedge clk);
        end
    endtask

    // --- UART TX monitor: sample mid-bit, collect bytes ---------------------
    integer rx_buf_len = 0;
    integer max_len = 9 + TOTAL_BYTES + 2;
    reg [7:0] rx_buf [0:TOTAL_BYTES+20];
    integer i;
    integer max_fifo_count = 0;
    reg saw_fifo_full = 0;
    always @(posedge clk) begin
        if (rst_n) begin
            if (dut.tx_fifo_count > max_fifo_count) max_fifo_count = dut.tx_fifo_count;
            if (dut.tx_fifo_full) saw_fifo_full = 1;
        end
    end
    initial begin : monitor
        forever begin
            @(negedge uart_tx);                // start bit falling edge
            repeat (15) @(negedge clk);        // to middle of data bit 0
            for (i = 0; i < 8; i = i + 1) begin
                rx_buf[rx_buf_len][i] = uart_tx;
                repeat (10) @(negedge clk);
            end
            rx_buf_len = rx_buf_len + 1;
        end
    end

    // --- stimulus + checks ---------------------------------------------------
    reg [7:0] xorsum;
    integer n, f, mel, frame, source_slot, expected_byte;
    reg fail;
    initial begin
        fail = 0;
        repeat (5) @(negedge clk);
        rst_n = 1'b1;
        repeat (5) @(negedge clk);
        ddr_init_done = 1'b1;
        repeat (5) @(negedge clk);
        if (freeze || task_busy) begin $display("FAIL task busy before trigger"); fail = 1; end
        local_capture_start = 1;
        repeat (2) @(negedge clk);
        local_capture_start = 0;
        repeat (2) @(negedge clk);
        if (!task_busy) begin $display("FAIL capture task did not become busy"); fail = 1; end
        repeat (100) @(negedge clk);
        if (freeze || rx_buf_len != 0) begin
            $display("FAIL capture started before fresh frames"); fail = 1;
        end
        for (f = 0; f < CAPTURE_FRAMES - 1; f = f + 1) begin
            ring_frame_done = 1;
            @(negedge clk); ring_frame_done = 0;
            @(negedge clk);
        end
        if (freeze) begin $display("FAIL capture stopped before the stop key"); fail = 1; end
        local_capture_stop = 1;
        @(negedge clk);
        local_capture_stop = 0;
        repeat (2) @(negedge clk);
        ring_frame_done = 1;
        @(negedge clk); ring_frame_done = 0;
        wait (freeze);
        repeat (100) @(negedge clk);
        if (rx_buf_len != 0) begin $display("FAIL sent before freeze ack"); fail = 1; end
        freeze_ack = 1;
        repeat (100) @(negedge clk);
        if (rx_buf_len != 0) begin $display("FAIL sent before DDR drain"); fail = 1; end
        ring_drained = 1;
        wait(label_select_wait);
        if (rx_buf_len != 0) begin $display("FAIL sent before label confirmation"); fail = 1; end
        local_capture_label = 4'd10;
        @(negedge clk); local_capture_label_confirm = 1;
        @(negedge clk); local_capture_label_confirm = 0;
        wait (rx_buf_len >= max_len);          // full frame received
        @(negedge clk);
        // header
        if (rx_buf[0] !== 8'hAA) begin $display("FAIL hdr0 %h", rx_buf[0]); fail = 1; end
        if (rx_buf[1] !== 8'h55) begin $display("FAIL hdr1 %h", rx_buf[1]); fail = 1; end
        if (rx_buf[2] !== 8'h0A) begin $display("FAIL label %h", rx_buf[2]); fail = 1; end
        if (rx_buf[3] !== TOTAL_BYTES[7:0]  || rx_buf[4] !== TOTAL_BYTES[15:8] ||
            rx_buf[5] !== TOTAL_BYTES[23:16]) begin
            $display("FAIL len %h%h%h", rx_buf[5], rx_buf[4], rx_buf[3]); fail = 1;
        end
        if (rx_buf[6] !== 8'd37 || rx_buf[7] !== 8'd0) begin
            $display("FAIL next ring slot %h%h", rx_buf[7], rx_buf[6]); fail = 1;
        end
        if (rx_buf[8] !== 8'd0) begin $display("FAIL overflow status %h", rx_buf[8]); fail = 1; end
        if (!saw_fifo_full || max_fifo_count != TX_FIFO_DEPTH) begin
            $display("FAIL UART FIFO was not exercised full=%0d max=%0d", saw_fifo_full, max_fifo_count);
            fail = 1;
        end
        // payload byte order + checksum
        xorsum = 0;
        for (n = 0; n < TOTAL_BYTES; n = n + 1) begin
            xorsum = xorsum ^ rx_buf[9 + n];
            mel = n / CAPTURE_FRAMES;
            frame = n % CAPTURE_FRAMES;
            source_slot = (ring_next_slot + RING_FRAMES - CAPTURE_FRAMES + frame) % RING_FRAMES;
            expected_byte = (RING_BASE + mel * RING_FRAMES + source_slot) & 8'hFF;
            if (rx_buf[9 + n] !== expected_byte[7:0]) begin
                $display("FAIL payload[%0d]=%h", n, rx_buf[9 + n]); fail = 1;
            end
        end
        if (rx_buf[9 + TOTAL_BYTES] !== xorsum) begin
            $display("FAIL xorsum %h != %h", rx_buf[9 + TOTAL_BYTES], xorsum); fail = 1;
        end
        if (rx_buf[9 + TOTAL_BYTES + 1] !== 8'h5A) begin
            $display("FAIL trailer %h", rx_buf[9 + TOTAL_BYTES + 1]); fail = 1;
        end
        // freeze deasserts once the FSM returns to idle after the trailer.
        repeat (50) @(negedge clk);
        if (freeze || task_busy) begin $display("FAIL capture task did not return idle"); fail = 1; end
        if (!fail) $display("TRAIN_CAPTURE_PASS");
        else $display("TRAIN_CAPTURE_FAIL");
        $finish;
    end

    // watchdog
    initial begin
        #((TOTAL_BYTES + 4096) * 1000)
            $display("WATCHDOG TIMEOUT (rx_buf_len=%0d)", rx_buf_len);
        $finish;
    end
endmodule
