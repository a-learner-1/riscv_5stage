`timescale 1ns/1ps
module tb_mn04_pcm_elastic_fifo;
    reg clk=0, rst_n=0;
    always #5 clk=~clk;
    reg signed [15:0] sample_i=0;
    reg sample_valid_i=0, sample_ready_i=0;
    wire signed [15:0] sample_o;
    wire sample_valid_o, overflow_o;
    integer sent=0, received=0, cycle=0;
    mn04_pcm_elastic_fifo #(.ADDR_BITS(7)) dut (
        .clk(clk), .rst_n(rst_n), .sample_i(sample_i),
        .sample_valid_i(sample_valid_i), .sample_o(sample_o),
        .sample_valid_o(sample_valid_o), .sample_ready_i(sample_ready_i),
        .overflow_o(overflow_o));
    initial begin
        repeat (4) @(negedge clk);
        rst_n=1;
        for (cycle=0; cycle<2500; cycle=cycle+1) begin
            @(negedge clk);
            // One source sample every five clocks; hold the consumer for
            // 300 clocks once, then resume. At most 60 samples accumulate.
            sample_valid_i=(cycle%5==0 && sent<400);
            sample_i=sent;
            sample_ready_i=!(cycle>=500 && cycle<800);
            @(posedge clk);
            if (sample_valid_i) sent=sent+1;
            if (sample_valid_o && sample_ready_i) begin
                if (sample_o !== received[15:0])
                    $fatal(1,"fifo order got=%0d expected=%0d",sample_o,received);
                received=received+1;
            end
        end
        @(negedge clk);
        sample_valid_i=0;
        sample_ready_i=1;
        wait (!sample_valid_o);
        if (received!=400 || overflow_o)
            $fatal(1,"fifo count=%0d overflow=%b",received,overflow_o);
        $display("PCM_FIFO_PASS samples=%0d",received);
        $finish;
    end
    initial begin #1000000; $fatal(1,"pcm fifo watchdog"); end
endmodule
