`timescale 1ns/1ps
module tb_mn04_template_flash_loader;
    localparam [23:0] FLASH_BASE = 24'h610080;
    localparam integer TEMPLATE_BYTES = 102400;
    reg clk=0,rst_n=0,start=0;
    always #5 clk=~clk;
    wire busy,done,cs,sck,mosi,load_we;
    wire [23:0] flash_addr;
    wire [16:0] load_addr;
    wire [7:0] flash_data,load_data;
    integer bytes_written=0;
    integer timeout=0;
    integer expected;

    function [7:0] pattern(input [23:0] addr);
        reg [31:0] offset;
        begin
            offset=addr-FLASH_BASE;
            pattern=(offset*32'd37 + (offset>>8) + 32'h5a) & 32'hff;
        end
    endfunction
    assign flash_data=pattern(flash_addr);

    mn04_template_flash_loader #(
        .TEMPLATE_BASE(FLASH_BASE),.TEMPLATE_BYTES(TEMPLATE_BYTES),
        .FAST_BYTES(1)
    ) dut (
        .clk(clk),.rst_n(rst_n),.start_i(start),.base_i(24'd0),.use_base_i(1'b0),.busy_o(busy),.done_o(done),
        .flash_rd_addr_o(flash_addr),.flash_rd_data_i(flash_data),
        .cs_o(cs),.sck_o(sck),.mosi_o(mosi),.miso_i(1'b0),
        .load_we_o(load_we),.load_addr_o(load_addr),.load_data_o(load_data));

    always @(posedge clk) begin
        if (rst_n && load_we) begin
            if (load_addr !== bytes_written[16:0]) begin
                $display("FAIL template load address got=%0d expected=%0d",load_addr,bytes_written);
                $fatal(1);
            end
            expected=pattern(FLASH_BASE+bytes_written);
            if (load_data !== expected[7:0]) begin
                $display("FAIL template load byte index=%0d got=%02x expected=%02x",
                         bytes_written,load_data,expected[7:0]);
                $fatal(1);
            end
            bytes_written=bytes_written+1;
        end
    end

    initial begin
        repeat (5) @(posedge clk);
        rst_n=1;
        repeat (3) @(posedge clk);
        start=1;
        while (!done && timeout<300000) begin
            @(posedge clk);
            timeout=timeout+1;
        end
        #1;
        if (!done || busy || bytes_written!=TEMPLATE_BYTES) begin
            $display("FAIL loader done=%b busy=%b bytes=%0d timeout=%0d",
                     done,busy,bytes_written,timeout);
            $fatal(1);
        end
        repeat (8) @(posedge clk);
        if (bytes_written!=TEMPLATE_BYTES) $fatal(1,"loader wrote after completion");
        $display("TEMPLATE_FLASH_LOADER_PASS bytes=%0d cycles=%0d",bytes_written,timeout);
        $finish;
    end
endmodule
