`timescale 1ns/1ps
// Verifies the USE_DDR_WEIGHTS wiring in mn04_core: the weight block cache's
// byte source is mn04_ddr_weight_feeder (fed by a behavioral DDR) instead of the
// QSPI reader.  This is the exact new interaction the standalone feeder test did
// NOT cover: the cache drives the feeder with a ONE-CYCLE qspi_start_o pulse and
// a level-high byte_ready, and the feeder's bytes flow back into the cache.
//
// Drives load_start_i the way the core's S_WLOAD does (level-high until loaded),
// loads several 4 KB blocks from DDR, and compares every cache word against the
// image reference.

module tb_mn04_wc_ddr #(
    parameter IMAGE_HEX   = "mem/image.hex",
    parameter IMG_BYTES   = 812420,
    parameter RD_LATENCY  = 4,
    parameter [27:0] WEIGHT_BASE = 28'h80   // DDR word-address base of the image
)();
    reg clk = 0, rst_n = 0, ddr_init_done = 0;

    // ---- cache load controls (mirror mn04_core S_WLOAD) ----
    reg         load_start = 0;
    reg  [23:0] flash_base = 0;

    wire wc_loaded, wc_qspi_start, wc_byte_ready, wc_req_ready, wc_rsp_valid;
    wire [23:0] wc_qspi_addr; wire [15:0] wc_qspi_count;
    wire [7:0] wc_src_byte; wire wc_src_byte_valid;
    wire [1:0] wc_lane; wire signed [7:0] wc_w0, wc_w1, wc_w2, wc_w3;

    // ---- feeder DDR master side ----
    wire [27:0]  f_araddr; wire f_arvalid, f_arready;
    wire [255:0] f_rdata;  wire f_rvalid;

    mn04_weight_block_cache wc (
        .clk(clk), .rst_n(rst_n),
        .load_start_i(load_start), .flash_base_i(flash_base),
        .loaded_o(wc_loaded), .qspi_start_o(wc_qspi_start),
        .qspi_addr_o(wc_qspi_addr), .qspi_count_o(wc_qspi_count),
        .qspi_byte_i(wc_src_byte), .qspi_byte_valid_i(wc_src_byte_valid),
        .qspi_byte_ready_o(wc_byte_ready),
        .weight_offset_i(12'd0), .req_valid_i(1'b0),
        .req_ready_o(wc_req_ready), .term_index_i(18'd0),
        .rsp_valid_o(wc_rsp_valid), .byte_lane_o(wc_lane),
        .w0_o(wc_w0), .w1_o(wc_w1), .w2_o(wc_w2), .w3_o(wc_w3)
    );

    mn04_ddr_weight_feeder #(.FIFO_DEPTH(4), .WEIGHT_BASE_WORD(WEIGHT_BASE)) u_feeder (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done),
        .start_i(wc_qspi_start), .addr_i(wc_qspi_addr), .count_i(wc_qspi_count),
        .busy_o(), .done_o(),
        .byte_o(wc_src_byte), .byte_valid_o(wc_src_byte_valid),
        .byte_ready_i(wc_byte_ready),
        .araddr_o(f_araddr), .arvalid_o(f_arvalid), .arready_i(f_arready),
        .rdata_i(f_rdata), .rvalid_i(f_rvalid)
    );

    mn04_ddr_behav #(.MEM_BYTES(24'h100000), .RD_LATENCY(RD_LATENCY)) u_ddr (
        .clk(clk), .rst_n(rst_n),
        .awaddr_i(28'd0), .awlen_i(4'd0), .awvalid_i(1'b0), .awready_o(),
        .wdata_i(256'd0), .wstrb_i(32'd0), .wready_o(),
        .araddr_i(f_araddr), .arlen_i(4'd0), .arvalid_i(f_arvalid),
        .arready_o(f_arready), .rdata_o(f_rdata), .rlast_o(), .rvalid_o(f_rvalid)
    );

    // ---- reference image + boot-load into DDR ----
    reg [7:0] img [0:IMG_BYTES-1];
    integer li;
    initial begin
        $readmemh(IMAGE_HEX, img);
        for (li = 0; li < IMG_BYTES; li = li + 1)
            u_ddr.mem[(WEIGHT_BASE << 2) + li] = img[li];
        $display("TB: loaded %0d bytes into DDR at word base 0x%h", IMG_BYTES, WEIGHT_BASE);
    end

    // ---- verify a loaded block against the image reference ----
    integer mismatch = 0;
    integer blocks_done = 0;
    integer wi;
    reg [31:0] exp_word;
    task verify_block;
        input [23:0] base;
        begin
            // wc_loaded rises on the same edge the last word (wmem[1023]) commits,
            // so one extra cycle is belt-and-suspenders.
            @(posedge clk);
            for (wi = 0; wi < 1024; wi = wi + 1) begin
                exp_word = { img[base + 4*wi + 3], img[base + 4*wi + 2],
                             img[base + 4*wi + 1], img[base + 4*wi + 0] };
                if (wc.wmem[wi] !== exp_word) begin
                    if (mismatch < 8)
                        $display("MISMATCH block_base=%0d word=%0d got=%h exp=%h",
                                 base, wi, wc.wmem[wi], exp_word);
                    mismatch = mismatch + 1;
                end
            end
            blocks_done = blocks_done + 1;
        end
    endtask

    // ---- driver: load several 4 KB blocks (the core's S_WLOAD pattern) ----
    initial begin
        #20 rst_n = 1;
        #20 ddr_init_done = 1;
        @(posedge clk); @(posedge clk);

        // a few low blocks + one high block (still fully inside the image)
        load_block(24'd0);
        load_block(24'd4096);
        load_block(24'd4168);    // MN04 op1 starts eight bytes into a DDR beat
        load_block(24'd8192);
        load_block(24'd12288);
        load_block(24'd798720);   // 195 * 4096, near the end of the weight region

        #20;
        $display("WC_DDR: rd_latency=%0d blocks=%0d mismatch=%0d",
                 RD_LATENCY, blocks_done, mismatch);
        if (blocks_done == 6 && mismatch == 0)
            $display("WC_DDR VERDICT: PASS");
        else
            $display("WC_DDR VERDICT: FAIL blocks=%0d mismatch=%0d", blocks_done, mismatch);
        $finish;
    end

    task load_block;
        input [23:0] base;
        begin
            // Race-free handshake.  Hold load_start until the cache's internal
            // `loading` flag actually rises (so the request cannot be missed no
            // matter the scheduler order), then deassert so the finished block
            // never re-triggers.  loaded_o alone is insufficient: it stays high
            // from the previous block, so waiting on it returns too early.
            flash_base = base;
            @(posedge clk);
            load_start = 1;
            wait(wc.loading == 1'b1);   // cache actually started this block
            load_start = 0;             // deassert: never let it re-trigger
            wait(wc_loaded == 1'b1);    // this block's load complete
            verify_block(base);
        end
    endtask

    always #5 clk = ~clk;

    initial begin
        #(64'd20000000);   // 20 ms watchdog
        $display("WC_DDR: WATCHDOG TIMEOUT blocks=%0d mismatch=%0d", blocks_done, mismatch);
        $finish;
    end
endmodule
