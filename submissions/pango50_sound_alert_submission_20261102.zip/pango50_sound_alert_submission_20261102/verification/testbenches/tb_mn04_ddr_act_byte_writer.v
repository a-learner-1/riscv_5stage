`timescale 1ns/1ps
module tb_mn04_ddr_act_byte_writer;
    reg clk=0, rst_n=0;
    always #5 clk=~clk;
    reg byte_valid=0;
    reg [23:0] byte_addr=0;
    reg [7:0] byte_data=0;
    wire byte_ready, drained;
    wire [27:0] awaddr;
    wire awvalid, awready, wready;
    wire [255:0] wdata;
    wire [31:0] wstrb;
    integer n, writes=0;
    mn04_ddr_act_byte_writer dut(
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),
        .byte_valid_i(byte_valid),.byte_addr_i(byte_addr),
        .byte_data_i(byte_data),.byte_ready_o(byte_ready),
        .ddr_awaddr_o(awaddr),.ddr_awvalid_o(awvalid),
        .ddr_awready_i(awready),.ddr_wdata_o(wdata),
        .ddr_wstrb_o(wstrb),.ddr_wready_i(wready),.drained_o(drained));
    mn04_ddr_behav #(.MEM_BYTES(24'h140100),.RD_LATENCY(4)) ddr(
        .clk(clk),.rst_n(rst_n),
        .awaddr_i(awaddr),.awlen_i(4'd0),.awvalid_i(awvalid),
        .awready_o(awready),.wdata_i(wdata),.wstrb_i(wstrb),
        .wready_o(wready),
        .araddr_i(28'd0),.arlen_i(4'd0),.arvalid_i(1'b0),
        .arready_o(),.rdata_o(),.rlast_o(),.rvalid_o());
    always @(posedge clk) if (awvalid && awready) writes=writes+1;
    task send_byte;
        input [23:0] addr;
        input [7:0] data;
        begin
            @(negedge clk);
            byte_addr=addr; byte_data=data; byte_valid=1;
            n=0;
            while (!byte_ready && n<100) begin @(negedge clk); n=n+1; end
            if (!byte_ready) $fatal(1,"writer never ready");
            @(negedge clk);
            byte_valid=0;
        end
    endtask
    initial begin
        repeat(4) @(negedge clk);
        rst_n=1;
        send_byte(24'h000000,8'h11);
        send_byte(24'h00001f,8'h22);
        send_byte(24'h000020,8'h33);
        send_byte(24'h140000,8'h44);
        n=0;
        while (!drained && n<100) begin @(negedge clk); n=n+1; end
        repeat(3) @(negedge clk);
        if (ddr.mem[0] !== 8'h11 || ddr.mem[31] !== 8'h22 ||
            ddr.mem[32] !== 8'h33 || ddr.mem[24'h140000] !== 8'h44 ||
            writes != 4)
            $fatal(1,"byte writer mismatch writes=%0d data=%h/%h/%h/%h",
                writes,ddr.mem[0],ddr.mem[31],ddr.mem[32],ddr.mem[24'h140000]);
        $display("ACT_BYTE_WRITER_PASS writes=%0d",writes);
        $finish;
    end
    initial begin #10000; $fatal(1,"watchdog"); end
endmodule
