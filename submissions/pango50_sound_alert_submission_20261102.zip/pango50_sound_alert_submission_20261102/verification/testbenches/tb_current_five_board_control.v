`timescale 1ns/1ps
// Current five-logit contract -> real softmax -> event mapping -> physical
// debounced work/confirm keys -> display selection and motor. No UART commands.
module tb_current_five_board_control #(parameter integer CPU_CONTROL=0);
    reg clk=0,rst_n=0,work_key=1,confirm_key=1,valid=0,template_valid=0;
    reg [47:0] logits=0;
    reg [1:0] template_class=0;
    wire recognition,motor;
    wire [5:0] control_keys;
    generate if(CPU_CONTROL) begin:g_cpu
        mn04_vexriscv_supervisor #(.CLOCK_HZ(1000000)) supervisor(
            .clk(clk),.rst_n(rst_n),.key_n_i({4'hf,confirm_key,work_key}),
            .boot_ready_i(1'b1),.codec_ready_i(1'b1),.recognition_i(recognition),
            .capture_busy_i(1'b0),.recording_i(1'b0),.alert_i(motor),
            .command_key_n_o(control_keys),.firmware_signature_o(),.command_count_o());
    end else begin:g_direct
        assign control_keys={4'hf,confirm_key,work_key};
    end endgenerate
    integer c,j;
    always #5 clk=~clk;
    mn04_six_class_realtime_control #(
        .CURRENT_FIVE_CLASS_MODE(1),.CLASS_WINDOW_MODE(1),.UNIFORM_120_WINDOW_MODE(1),
        .SOFTMAX_LUT_FILE("C:/Studying_file/pango50_sound_alert_v1/training/output/pc_five_class_fixed120_deployment_20261024/softmax_exp_q24_six_class.mem"),
        .BABY_THRESHOLD_Q16(59637),.KNOCK_THRESHOLD_Q16(47841),
        .EMERGENCY_VEHICLE_THRESHOLD_Q16(49152),.CAR_HORN_THRESHOLD_Q16(29491),
        .DOG_BARK_THRESHOLD_Q16(65535),.CLOCK_HZ(1000000),.SPI_HZ(100000),
        .RESET_CYCLES(1),.PWR_DELAY_CYCLES(1),.DISPLAY_DELAY_CYCLES(1)
    ) dut(
        .clk(clk),.rst_n(rst_n),.short_snapshot_ready_i(1'b0),.short_snapshot_mode_i(2'd1),
        .core_busy_i(1'b0),.core_done_i(1'b0),.core_logits_valid_i(valid),.core_logits_i(logits),
        .template_result_valid_i(template_valid),.template_result_class_i(template_class),
        .display_asset_we_i(1'b0),.display_asset_addr_i(15'd0),.display_asset_data_i(8'd0),
        .work_key_n_i(control_keys[0]),.confirm_key_n_i(control_keys[1]),.uart_rx_i(1'b1),
        .template_preview_i(1'b0),.template_preview_class_i(4'd0),.external_task_busy_i(1'b0),
        .set_time_i(1'b0),.set_hour_i(8'd0),.set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(),.core_start_op_o(),.core_end_op_o(),.core_short_window_o(),
        .core_context_short_o(),.core_class_window_mode_o(),.short_snapshot_accept_o(),
        .short_result_valid_o(),.work_mode_o(),.panel_ready_o(),.panel_busy_o(),
        .tft_nrst_o(),.tft_backlight_o(),.tft_sclk_o(),.tft_mosi_o(),.tft_dc_o(),.tft_cs_n_o(),
        .motor_o(motor),.recognition_enable_o(recognition));
    task start_key;
        begin
            @(negedge clk);work_key=0;repeat(25000) @(negedge clk);
            work_key=1;repeat(25000) @(negedge clk);
            if(!recognition) $fatal(1,"work key failed to start listening");
        end
    endtask
    task acknowledge;
        begin
            @(negedge clk);confirm_key=0;repeat(25000) @(negedge clk);
            confirm_key=1;repeat(25000) @(negedge clk);
            if(motor || dut.backend.path.display_valid) $fatal(1,"confirm key did not clear alert");
        end
    endtask
    task send_logits;
        input integer cls;
        begin
            @(negedge clk);
            for(j=0;j<5;j=j+1) logits[j*8+:8]=-100;
            logits[cls*8+:8]=100;
            valid=1;@(negedge clk);valid=0;
            repeat(350) @(negedge clk);
            if(dut.probs[4*16+:16]!==16'd0) $fatal(1,"removed dog output is nonzero");
        end
    endtask
    task check_alert;
        input integer display_id;
        begin
            if(!motor || recognition || !dut.backend.path.display_valid ||
               dut.backend.path.display_class!==display_id || dut.backend.path.screen_class!==display_id)
                $fatal(1,"wrong screen/motor mapping expected=%0d actual=%0d motor=%b",display_id,dut.backend.path.display_class,motor);
        end
    endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        start_key();send_logits(0);
        if(motor || !recognition) $fatal(1,"background incorrectly alerted");
        for(c=1;c<5;c=c+1) begin
            if(c>1) start_key();
            send_logits(c);check_alert(c==4 ? 5 : c);acknowledge();
        end
        for(c=0;c<3;c=c+1) begin
            start_key();@(negedge clk);template_class=c+1;template_valid=1;
            @(negedge clk);template_valid=0;repeat(10) @(negedge clk);
            check_alert(c+8);acknowledge();
        end
        $display("CURRENT_FIVE_CONTROL_PASS cnn=4 background=listen templates=3 work_key=1 confirm_key=1 dog_disabled=1 screen=1 motor=1 uart_commands=0");
        if(CPU_CONTROL) $display("VEXRISCV_CURRENT_FIVE_CONTROL_PASS cpu_firmware_to_real_backend=1");
        $finish;
    end
    initial begin #20000000;$fatal(1,"current five control watchdog");end
endmodule
