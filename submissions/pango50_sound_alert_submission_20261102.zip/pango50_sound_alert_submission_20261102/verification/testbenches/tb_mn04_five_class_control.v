`timescale 1ns/1ps
module tb_mn04_five_class_control;
    reg clk=0,rst_n=0,short_ready=0,long_ready=0,uart_rx=1;
    reg core_busy=0,core_done=0,logits_valid=0;
    reg [39:0] logits=0;
    wire core_start,core_short,context_short,short_accept,long_accept;
    wire [8:0] start_op,end_op;
    wire motor,recognition_enable;
    integer timer=0;
    reg [8:0] running_op;
    reg running_short;
    always #10 clk=~clk;
    mn04_five_class_realtime_control #(
        .SOFTMAX_LUT_FILE("../../training/output/dual_window_integer_full/softmax_exp_q24_five_class.mem"),
        .CLOCK_HZ(1152000),.SPI_HZ(115200),
        .RESET_CYCLES(1),.PWR_DELAY_CYCLES(1),
        .DISPLAY_DELAY_CYCLES(1)) dut(
        .clk(clk),.rst_n(rst_n),.short_snapshot_ready_i(short_ready),
        .long_snapshot_ready_i(long_ready),.core_busy_i(core_busy),
        .core_done_i(core_done),.core_logits_valid_i(logits_valid),
        .core_logits_i(logits),.template_result_valid_i(1'b0),
        .template_result_class_i(2'd0),.work_key_n_i(1'b1),
        .confirm_key_n_i(1'b1),.uart_rx_i(uart_rx),.external_task_busy_i(1'b0),
        .set_time_i(1'b0),.set_hour_i(8'd0),
        .set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(core_start),.core_start_op_o(start_op),
        .core_end_op_o(end_op),.core_short_window_o(core_short),
        .core_context_short_o(context_short),
        .short_snapshot_accept_o(short_accept),
        .long_snapshot_accept_o(long_accept),
        .short_result_valid_o(),.long_result_valid_o(),
        .motor_o(motor),.recognition_enable_o(recognition_enable),
        .work_mode_o(),.panel_ready_o(),.panel_busy_o(),
        .tft_nrst_o(),.tft_backlight_o(),.tft_sclk_o(),
        .tft_mosi_o(),.tft_dc_o(),.tft_cs_n_o());
    // Stand-in for one real core operation; only the final op emits logits.
    always @(posedge clk) begin
        core_done<=0;
        logits_valid<=0;
        if (core_start) begin
            if (core_busy || start_op!==end_op) $fatal(1,"bad core start");
            core_busy<=1;
            running_op<=start_op;
            running_short<=core_short;
            timer<=1;
        end else if (core_busy && timer==0) begin
            core_busy<=0;
            core_done<=1;
            if (running_op==90) begin
                logits=0;
                logits[(running_short ? 2 : 4)*8 +: 8]=8'd100;
                logits_valid<=1;
            end
        end else if (core_busy) timer<=timer-1;
    end
    task uart_byte(input [7:0] data);integer i;begin
        uart_rx=0;repeat(10) @(negedge clk);
        for(i=0;i<8;i=i+1) begin
            uart_rx=data[i];repeat(10) @(negedge clk);
        end
        uart_rx=1;repeat(30) @(negedge clk);
    end endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        uart_byte("R");
        if (!recognition_enable) $fatal(1,"start failed");
        short_ready=1;
        @(negedge clk);short_ready=0;
        wait(motor);
        @(negedge clk);
        if (recognition_enable || dut.backend.path.alerts.display_class_o!=2)
            $fatal(1,"short horn alert failed");
        uart_byte("C");
        if (motor || recognition_enable) $fatal(1,"confirm should leave one-shot control stopped");
        uart_byte("R");
        repeat(5) @(negedge clk);
        if (!recognition_enable) $fatal(1,"fresh R command did not restart");
        long_ready=1;
        @(negedge clk);long_ready=0;
        wait(motor);
        @(negedge clk);
        if (recognition_enable || dut.backend.path.alerts.display_class_o!=4)
            $fatal(1,"long fire alert failed");
        $display("CONTROL_INTEGRATION_PASS: fake core -> softmax -> alert -> confirm");
        $finish;
    end
    initial begin #1000000; $fatal(1,"control integration timeout"); end
endmodule
