`timescale 1ns/1ps
module tb_mn04_short_only_scheduler;
    reg clk=0,rst_n=0,short_ready=0,recognition=0,alert=0,confirmed=0;
    reg core_busy=0,core_done=0;
    wire core_start;
    wire [8:0] start_op,end_op;
    wire short_window,context_short,short_result,long_result;
    wire short_accept,long_accept;
    always #5 clk=~clk;
    mn04_dual_window_scheduler #(.N_OPS(2),.SHORT_ONLY(1)) dut(
        .clk(clk),.rst_n(rst_n),.short_ready_i(short_ready),.long_ready_i(1'b1),
        .recognition_enable_i(recognition),.alert_i(alert),.confirmed_i(confirmed),
        .core_busy_i(core_busy),.core_done_i(core_done),.core_start_o(core_start),
        .core_start_op_o(start_op),.core_end_op_o(end_op),
        .core_short_window_o(short_window),.core_context_short_o(context_short),
        .short_result_valid_o(short_result),.long_result_valid_o(long_result),
        .alert_latched_o(),.short_snapshot_accept_o(short_accept),
        .long_snapshot_accept_o(long_accept));
    initial begin
        repeat(3) @(negedge clk); rst_n=1; recognition=1;
        #1;
        if(long_accept) begin $display("FAIL long accepted"); $finish; end
        short_ready=1;
        wait(core_start); #1;
        if(!short_window || !context_short || start_op!=end_op || long_accept) begin
            $display("FAIL short-only start: short=%b context=%b",short_window,context_short);
            $finish;
        end
        $display("SHORT_ONLY_SCHEDULER_PASS");
        $finish;
    end
    initial begin #10000; $display("FAIL watchdog"); $finish; end
endmodule
