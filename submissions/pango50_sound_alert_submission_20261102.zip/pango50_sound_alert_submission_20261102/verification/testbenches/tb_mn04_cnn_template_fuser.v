`timescale 1ns/1ps
module tb_mn04_cnn_template_fuser;
    reg clk, rst_n, start;
    reg [95:0] probabilities;
    reg [1:0] window_mode;
    wire valid, passthrough_valid;
    wire [95:0] fused, passthrough;

    always #5 clk = ~clk;

    mn04_cnn_template_fuser #(
        .PROTOTYPE_FILE("mem/cnn_template_fuser_unit.mem"),
        .VALID_MASK(24'hffffff),
        .TEMPLATE_WEIGHT_Q2(1)
    ) dut (
        .clk(clk), .rst_n(rst_n), .start_i(start),
        .probabilities_i(probabilities), .window_mode_i(window_mode),
        .valid_o(valid), .fused_probabilities_o(fused)
    );

    mn04_cnn_template_fuser #(
        .PROTOTYPE_FILE(""), .VALID_MASK(24'h000000),
        .TEMPLATE_WEIGHT_Q2(1)
    ) passthrough_dut (
        .clk(clk), .rst_n(rst_n), .start_i(start),
        .probabilities_i(probabilities), .window_mode_i(window_mode),
        .valid_o(passthrough_valid), .fused_probabilities_o(passthrough)
    );

    task set_probs;
        input [15:0] p0,p1,p2,p3,p4,p5;
        begin
            probabilities[0*16 +: 16] = p0;
            probabilities[1*16 +: 16] = p1;
            probabilities[2*16 +: 16] = p2;
            probabilities[3*16 +: 16] = p3;
            probabilities[4*16 +: 16] = p4;
            probabilities[5*16 +: 16] = p5;
        end
    endtask

    task run_fuser;
        begin
            @(negedge clk); start = 1'b1;
            @(negedge clk); start = 1'b0;
            wait(valid === 1'b1);
            #1;
            if (passthrough !== probabilities)
                $fatal(1,"FAIL zero-mask instance must be exact pass-through");
        end
    endtask

    task expect_class;
        input integer class_index;
        input [15:0] expected_score;
        integer i;
        begin
            for (i = 0; i < 6; i = i + 1) begin
                if (i == class_index) begin
                    if (fused[i*16 +: 16] !== expected_score) begin
                        $display("FAIL class=%0d expected=%0d got=%0d", class_index,
                                 expected_score, fused[i*16 +: 16]);
                        $fatal(1);
                    end
                end else if (!((window_mode==0 && (i==0 || i==4 || i==5)) ||
                               (window_mode==1 && (i==0 || i==3)) ||
                               (window_mode==2 && (i==0 || i==1 || i==2))) &&
                             fused[i*16 +: 16] !== probabilities[i*16 +: 16]) begin
                    $display("FAIL inactive class changed class=%0d mode=%0d", i, window_mode);
                    $fatal(1);
                end
            end
        end
    endtask

    initial begin
        clk=0; rst_n=0; start=0; probabilities=96'd0; window_mode=0;
        repeat (3) @(negedge clk);
        rst_n=1;

        set_probs(16'd50000,16'd3107,16'd3107,16'd3107,16'd3107,16'd3107);
        run_fuser(); expect_class(0,16'd53883);
        set_probs(16'd3107,16'd3107,16'd3107,16'd3107,16'd50000,16'd3107);
        run_fuser(); expect_class(4,16'd53883);
        set_probs(16'd3107,16'd3107,16'd3107,16'd3107,16'd3107,16'd50000);
        run_fuser(); expect_class(5,16'd53883);

        // A 120-frame signature must not leak into the 100-frame class set.
        window_mode=0;
        set_probs(16'd3107,16'd3107,16'd3107,16'd50000,16'd3107,16'd3107);
        run_fuser();
        if (fused[3*16 +: 16] !== probabilities[3*16 +: 16] ||
            fused[1*16 +: 16] !== probabilities[1*16 +: 16] ||
            fused[2*16 +: 16] !== probabilities[2*16 +: 16])
            $fatal(1,"FAIL mode isolation");

        window_mode=1;
        set_probs(16'd50000,16'd3107,16'd3107,16'd3107,16'd3107,16'd3107);
        run_fuser(); expect_class(0,16'd53883);
        set_probs(16'd3107,16'd3107,16'd3107,16'd50000,16'd3107,16'd3107);
        run_fuser(); expect_class(3,16'd53883);

        window_mode=2;
        set_probs(16'd50000,16'd3107,16'd3107,16'd3107,16'd3107,16'd3107);
        run_fuser(); expect_class(0,16'd53883);
        set_probs(16'd3107,16'd50000,16'd3107,16'd3107,16'd3107,16'd3107);
        run_fuser(); expect_class(1,16'd53883);
        set_probs(16'd3107,16'd3107,16'd50000,16'd3107,16'd3107,16'd3107);
        run_fuser(); expect_class(2,16'd53883);

        $display("CNN_TEMPLATE_FUSER_ALL_SIX_CLASSES_PASS windows=100/120/150 templates=3_each sequential=1");
        $finish;
    end
endmodule
