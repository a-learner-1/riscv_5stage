`timescale 1ns/1ps
module tb_mn04_snapshot_manager;
    reg clk=0,rst_n=0,frame_done=0;
    always #5 clk=~clk;
    reg [9:0] next_slot=0;
    reg dma_busy=0,dma_done_short=0,dma_done_long=0;
    wire dma_start,dma_short,short_ready,long_ready;
    wire [9:0] snapshot_slot;
    integer frame,delay_count=0,short_count=0,long_count=0;
    reg active_short;
    mn04_snapshot_manager dut (
        .clk(clk),.rst_n(rst_n),.epoch_reset_i(1'b0),
        .recognition_enable_i(1'b1),
        .frame_done_i(frame_done),.next_frame_slot_i(next_slot),
        .short_snapshot_accept_i(1'b1),.long_snapshot_accept_i(1'b1),
        .dma_busy_i(dma_busy),.dma_done_short_i(dma_done_short),
        .dma_done_long_i(dma_done_long),
        .dma_start_o(dma_start),.dma_short_o(dma_short),
        .dma_next_frame_slot_o(snapshot_slot),
        .short_snapshot_ready_o(short_ready),
        .long_snapshot_ready_o(long_ready));
    always @(posedge clk) if(rst_n) begin
        dma_done_short<=0;
        dma_done_long<=0;
        if(dma_start && !dma_busy) begin
            dma_busy<=1;
            active_short<=dma_short;
            delay_count<=3;
            if((dma_short && snapshot_slot==0 && frame<1000) ||
               (!dma_short && snapshot_slot!=0))
                $fatal(1,"snapshot slot incorrect frame=%0d slot=%0d",frame,snapshot_slot);
        end else if(dma_busy) begin
            if(delay_count==0) begin
                dma_busy<=0;
                if(active_short) dma_done_short<=1;
                else dma_done_long<=1;
            end else delay_count<=delay_count-1;
        end
        if(short_ready) short_count<=short_count+1;
        if(long_ready) long_count<=long_count+1;
    end
    initial begin
        repeat(4) @(negedge clk);rst_n=1;
        for(frame=1;frame<=1000;frame=frame+1) begin
            repeat(10) @(negedge clk);
            frame_done=1;
            next_slot=frame%1000;
            @(negedge clk);frame_done=0;
        end
        repeat(40) @(negedge clk);
        if(short_count!=13 || long_count!=1)
            $fatal(1,"cadence short=%0d long=%0d",short_count,long_count);
        $display("SNAPSHOT_MANAGER_PASS short=%0d long=%0d",short_count,long_count);
        $finish;
    end
    initial begin #200000; $fatal(1,"snapshot manager watchdog"); end
endmodule
