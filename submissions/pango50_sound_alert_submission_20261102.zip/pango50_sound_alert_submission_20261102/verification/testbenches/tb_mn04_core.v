`timescale 1ns/1ps
// MN04 core testbench (GATE4).
//
// Loads the V1 unsigned runtime image into a behavioral SPI-NOR flash model,
// pumps the clip's x0 (128x1000 int8) into the act memory, starts the core
// and on every dump boundary writes the RTL output region (NHWC order) to
//   sim\mn04\out\rtl_<clip>_<di:02d>_<gtag>.bin
// for the Python bit-exact comparison against the golden .bin.  Prints the
// final cycle count (throughput evidence) and dumps a watchdog error if the
// run does not finish within MAX_CYCLES.
module tb_mn04_core #(
    parameter CLIP_TAG     = "baby_cry_baby_cry_001.wav",
    parameter OP_FILE      = "op_desc.mem",
    parameter IMAGE_HEX    = "image.hex",
    parameter X0_HEX       = "x0_baby_cry_baby_cry_001.wav.hex",
    parameter LUTS_BASE    = 24'h0,
    parameter N_OPS        = 91,
    parameter MAX_CYCLES   = 100000000,
    parameter STOP_AFTER_DUMP = 99,
    parameter OUT_DIR      = "out",
    parameter DUMP_GEOM    = "dump_geom.mem",
    parameter START_OP     = 0,
    parameter END_OP       = N_OPS-1,
    parameter SHORT_WINDOW = 0,
    parameter SHORT_FRAMES = 100,
    parameter CLASS_WINDOW_MODE = 0,
    parameter CLASS_MODE = 0,
    parameter DW_HEX       = "block5_dw_nhwc.hex",
    parameter L004_HEX     = "block5_l004_nhwc.hex",
    parameter L005_HEX     = "block6_l005_nhwc.hex",
    parameter L010_HEX     = "block11_l010_nhwc.hex",
    parameter L013_HEX     = "block14_l013_nhwc.hex",
    parameter TARGET_STOP_OP = 21,
    parameter HEAD0_HEX = "head0_baby_cry.hex",
    parameter EMBEDDING_HEX = "embedding_baby_cry.hex",
    parameter SOFTMAX_LUT = "softmax_exp_q24.mem",
    parameter N_CLASSES = 7,
    parameter integer CONV_STALL_PERIOD = 0,
    parameter integer ACT_CACHE_LINE_BITS = 6,
    parameter integer WEIGHT_RD_LATENCY = 4,   // superseded: one shared DDR below
    parameter integer ACT_RD_LATENCY = 4,      // shared DDR read latency
    parameter [27:0] WEIGHT_BASE_WORD = 28'h100000,  // weight image DDR word base
    parameter [23:0] IMAGE_BYTES      = 24'd811890,  // five-class image size in bytes
    parameter [31:0] IMAGE_CHECKSUM   = 32'h053e2a11 // sum of image bytes mod 2^32
)();
    reg clk = 0, rst_n = 0;
    reg start_i = 0;
    reg x0_done_r;
    wire busy_o, done_o;
    wire [23:0] flash_rd_addr_o;
    wire [7:0]  flash_rd_data_i;
    wire qspi_cs, qspi_sck, qspi_mosi;
    wire conv_candidate_valid;
    wire [23:0] conv_candidate_addr;
    wire conv_candidate_pad;
    wire scalar_candidate_valid;
    wire [23:0] scalar_candidate_addr;
    wire scalar_req_ready;
    wire        wr_en_o; wire [23:0] wr_addr_o; wire [7:0] wr_data_o;
    wire        rd_req_valid_o; wire [23:0] rd_byte_addr_o;
    wire        rd_req_pad_o;
    wire        rd_rsp_valid_i; wire [31:0] rd_data_i; wire [1:0] rd_lane_i;
    wire        act_model_rsp; wire [31:0] act_model_data; wire [1:0] act_model_lane;
    wire        dump_valid_o; wire [7:0] dump_id_o; wire [15:0] dump_op_index_o;
    wire [31:0] cycle_count_o;
`ifdef USE_DDR_ACT_READ
    wire conv_req_ready;
    wire cache_candidate_ready;
    assign conv_req_ready = cache_candidate_ready;
    assign scalar_req_ready = cache_candidate_ready;
`else
    wire conv_req_ready = (CONV_STALL_PERIOD == 0) ? 1'b1 :
                          ((cycle_count_o % CONV_STALL_PERIOD) != 0);
    assign scalar_req_ready = 1'b1;
`endif
    reg held_candidate = 0;
    reg [23:0] held_addr = 0;
    reg held_pad = 0;
    integer candidate_stalls = 0;
    always @(posedge clk) begin
        if (!rst_n) held_candidate <= 0;
        else begin
            if (held_candidate && (!conv_candidate_valid ||
                conv_candidate_addr !== held_addr ||
                conv_candidate_pad !== held_pad))
                $fatal(1, "candidate changed while activation cache held ready low");
            held_candidate <= conv_candidate_valid && !conv_req_ready;
            if (conv_candidate_valid && !conv_req_ready) begin
                held_addr <= conv_candidate_addr;
                held_pad <= conv_candidate_pad;
                candidate_stalls <= candidate_stalls + 1;
            end
        end
    end
    wire logits_valid_o, probs_valid_o, softmax_busy_o;
    wire [8*N_CLASSES-1:0] logits_o;
    wire [16*N_CLASSES-1:0] probs_q16_o;

    // flash model
    reg [7:0] flash_mem [0:24'h100000-1];
    reg [31:0] flash_len_r;
    integer fi;
    initial begin
        $readmemh(IMAGE_HEX, flash_mem);
        fi = 0;
        while (fi < 24'h100000 && flash_mem[fi] !== 8'hx) fi = fi + 1;
        flash_len_r = fi;
        $display("TB: flash loaded %0d bytes", flash_len_r);
    end
    assign flash_rd_data_i = flash_mem[flash_rd_addr_o];

`ifdef USE_DDR_WEIGHTS
    // Weight-feeder master (read-only). Routed to the single shared DDR via
    // the arbiter's m2 port below; the packed image lives at word
    // WEIGHT_BASE_WORD (byte WEIGHT_BASE_WORD*4), clear of the activation
    // arenas (byte 0x000000..0x38FFFF).
    wire [27:0] weight_araddr;
    wire weight_arvalid, weight_arready, weight_rvalid;
    wire [255:0] weight_rdata;
`else
    wire [27:0] weight_araddr = 28'd0;
    wire weight_arvalid = 1'b0;
    wire weight_arready, weight_rvalid;
    wire [255:0] weight_rdata = 256'd0;
`endif

    // act memory
    mn04_act_mem #(.DEPTH_BYTES(24'h190000)) u_act (
        .clk(clk), .rst_n(rst_n),
        .wr_en_i(wr_en_o), .wr_addr_i(wr_addr_o), .wr_data_i(wr_data_o),
        .rd_req_valid_i(rd_req_valid_o), .rd_byte_addr_i(rd_byte_addr_o),
        .rd_rsp_valid_o(act_model_rsp), .rd_data_o(act_model_data),
        .rd_lane_o(act_model_lane)
    );
    wire [27:0] act_araddr;
    wire act_arvalid, act_arready, act_rvalid;
    wire [255:0] act_rdata;
    wire bridge_ready, writer_drained;
    wire [27:0] writer_awaddr;
    wire writer_awvalid, writer_awready, writer_wready;
    wire [255:0] writer_wdata;
    wire [31:0] writer_wstrb;
`ifdef USE_DDR_ACT_READ
    wire cache_rsp;
    wire [31:0] cache_data;
    wire [1:0] cache_lane;
`ifdef USE_DDR_ACT_RW
    wire bridge_valid, writer_ready;
    wire [23:0] bridge_addr;
    wire [7:0] bridge_data;
    mn04_wmerge_bridge u_write_bridge(
        .clk(clk),.rst_n(rst_n),.wr_en_i(wr_en_o),
        .wr_addr_i(wr_addr_o),.wr_data_i(wr_data_o),
        .wr_ready_o(bridge_ready),.mem_wr_en_o(bridge_valid),
        .mem_wr_addr_o(bridge_addr),.mem_wr_data_o(bridge_data),
        .mem_wr_ready_i(writer_ready));
    mn04_ddr_act_byte_writer u_writer(
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),
        .byte_valid_i(bridge_valid),.byte_addr_i(bridge_addr),
        .byte_data_i(bridge_data),.byte_ready_o(writer_ready),
        .ddr_awaddr_o(writer_awaddr),.ddr_awvalid_o(writer_awvalid),
        .ddr_awready_i(writer_awready),.ddr_wdata_o(writer_wdata),
        .ddr_wstrb_o(writer_wstrb),.ddr_wready_i(writer_wready),
        .drained_o(writer_drained));
`else
    assign bridge_ready   = 1'b1;
    assign writer_drained = 1'b1;
    assign writer_awaddr  = 28'd0;
    assign writer_awvalid = 1'b0;
    assign writer_wdata   = 256'd0;
    assign writer_wstrb   = 32'd0;
`endif
    mn04_ddr_act_read_cache #(.LINE_BITS(ACT_CACHE_LINE_BITS)) u_act_cache (
        .clk(clk),.rst_n(rst_n),.flush_i(1'b0),
        .write_invalidate_i(wr_en_o),.write_addr_i(wr_addr_o),
        .writes_drained_i(writer_drained),
        .candidate_valid_i(conv_candidate_valid || scalar_candidate_valid),
        .candidate_addr_i(conv_candidate_valid ? conv_candidate_addr :
                          scalar_candidate_addr),
        .candidate_pad_i(conv_candidate_pad),
        .candidate_ready_o(cache_candidate_ready),
        .rd_req_valid_i(rd_req_valid_o),.rd_byte_addr_i(rd_byte_addr_o),
        .rd_req_pad_i(rd_req_pad_o),
        .rd_rsp_valid_o(cache_rsp),.rd_data_o(cache_data),
        .rd_lane_o(cache_lane),
        .ddr_araddr_o(act_araddr),.ddr_arvalid_o(act_arvalid),
        .ddr_arready_i(act_arready),.ddr_rdata_i(act_rdata),
        .ddr_rvalid_i(act_rvalid));
    integer act_ddr_reads=0;
    always @(posedge clk) if (act_arvalid && act_arready)
        act_ddr_reads=act_ddr_reads+1;
    always @(posedge clk) if (rst_n && u_core.op_act_r<=2 && u_core.st_r==7 &&
        (u_core.is_pw ? u_core.eng4.mac_pair_valid :
                        u_core.eng1.mac_pair_valid) && !u_core.pad_d1_r &&
        (rd_data_i !== act_model_data || rd_lane_i !== act_model_lane))
        $fatal(1,"MAC_ACT_MISMATCH cycle=%0d data=%h model=%h lane=%d model_lane=%d",
               cycle_count_o,rd_data_i,act_model_data,rd_lane_i,act_model_lane);
`ifdef CACHE_READY_MODEL_DATA
    assign rd_rsp_valid_i = act_model_rsp;
    assign rd_data_i = act_model_data;
    assign rd_lane_i = act_model_lane;
`else
    assign rd_rsp_valid_i = cache_rsp;
    assign rd_data_i = cache_data;
    assign rd_lane_i = cache_lane;
`endif
    // Simulation-only mirror to isolate the DDR read-cache contract.
`ifndef USE_DDR_ACT_RW
    always @(posedge clk) if (wr_en_o) ddr.mem[wr_addr_o] <= wr_data_o;
`endif
    integer mirror_mismatch=0, mirror_scan_i;
    always @(posedge clk) if (dump_valid_o && dump_id_o==0 && writer_drained) begin
        mirror_mismatch=0;
        for (mirror_scan_i=0;mirror_scan_i<25600;mirror_scan_i=mirror_scan_i+1)
            if (ddr.mem[24'h040000+mirror_scan_i] !==
                u_act.mem[24'h040000+mirror_scan_i]) mirror_mismatch=mirror_mismatch+1;
        $display("TB: ACT_MIRROR_MISMATCH=%0d",mirror_mismatch);
        if (mirror_mismatch != 0) $fatal(1,"behavioral DDR write mirror diverged");
    end
    integer mirror_i;
    initial begin
        wait(x0_done_r);
        for (mirror_i=0; mirror_i<(SHORT_WINDOW ? 128*SHORT_FRAMES : 128000);
             mirror_i=mirror_i+1)
            ddr.mem[mirror_i] = u_act.mem[mirror_i];
    end
`else  // !USE_DDR_ACT_READ: model feedthrough, DDR masters tied off
    assign act_araddr  = 28'd0;
    assign act_arvalid = 1'b0;
    assign bridge_ready   = 1'b1;
    assign writer_drained = 1'b1;
    assign writer_awaddr  = 28'd0;
    assign writer_awvalid = 1'b0;
    assign writer_wdata   = 256'd0;
    assign writer_wstrb   = 32'd0;
    assign rd_rsp_valid_i = act_model_rsp;
    assign rd_data_i = act_model_data;
    assign rd_lane_i = act_model_lane;
`endif
`ifdef USE_DDR_WEIGHTS
    // Single shared behavioral DDR (the board has exactly one DDR3).
    // m0 = activation write-back, m1 = activation read cache, m2 = weight
    // feeder. Weight image is preloaded at byte WEIGHT_BASE_WORD*4, well
    // above the activation arenas (byte 0x000000..0x38FFFF).
    wire [27:0] s_awaddr, s_araddr;
    wire [3:0] s_awlen, s_arlen;
    wire s_awvalid, s_arvalid, s_awready, s_arready;
    wire [255:0] s_wdata, s_rdata;
    wire [31:0] s_wstrb;
    wire s_wready, s_rlast, s_rvalid;
    // Bootloader master + control wires (declared before the arbiter so the
    // m3 port connections below are not implicit 1-bit nets).
    wire [23:0] boot_flash_rd_addr;
    wire [7:0]  boot_flash_rd_data;
    assign boot_flash_rd_data = flash_mem[boot_flash_rd_addr];
    wire [27:0] boot_awaddr;
    wire boot_awvalid, boot_awready, boot_wready;
    wire [255:0] boot_wdata;
    wire [31:0] boot_wstrb;
    reg  boot_start = 0;
    wire boot_busy, boot_done, boot_init_done, boot_checksum_ok;
    senior_dbl_ddr3_user_arbiter u_ddr_arbiter(
        .clk(clk),.rst_n(rst_n),
        .m0_awaddr(writer_awaddr),.m0_araddr(28'd0),
        .m0_awlen(4'd0),.m0_arlen(4'd0),
        .m0_awvalid(writer_awvalid),.m0_arvalid(1'b0),
        .m0_awready(writer_awready),.m0_arready(),
        .m0_wdata(writer_wdata),.m0_wstrb(writer_wstrb),
        .m0_wready(writer_wready),.m0_rdata(),.m0_rlast(),.m0_rvalid(),
        .m1_awaddr(28'd0),.m1_araddr(act_araddr),
        .m1_awlen(4'd0),.m1_arlen(4'd0),
        .m1_awvalid(1'b0),.m1_arvalid(act_arvalid),
        .m1_awready(),.m1_arready(act_arready),
        .m1_wdata(256'd0),.m1_wstrb(32'd0),.m1_wready(),
        .m1_rdata(act_rdata),.m1_rlast(),.m1_rvalid(act_rvalid),
        .m2_awaddr(28'd0),.m2_araddr(weight_araddr),
        .m2_awlen(4'd0),.m2_arlen(4'd0),
        .m2_awvalid(1'b0),.m2_arvalid(weight_arvalid),
        .m2_awready(),.m2_arready(weight_arready),
        .m2_wdata(256'd0),.m2_wstrb(32'd0),.m2_wready(),
        .m2_rdata(weight_rdata),.m2_rlast(),.m2_rvalid(weight_rvalid),
        .m3_awaddr(boot_awaddr),.m3_araddr(28'd0),.m3_awlen(4'd0),.m3_arlen(4'd0),
        .m3_awvalid(boot_awvalid),.m3_arvalid(1'b0),.m3_awready(boot_awready),.m3_arready(),
        .m3_wdata(boot_wdata),.m3_wstrb(boot_wstrb),.m3_wready(boot_wready),.m3_rdata(),.m3_rlast(),.m3_rvalid(),
        .m4_awaddr(28'd0),.m4_araddr(28'd0),.m4_awlen(4'd0),.m4_arlen(4'd0),
        .m4_awvalid(1'b0),.m4_arvalid(1'b0),.m4_awready(),.m4_arready(),
        .m4_wdata(256'd0),.m4_wstrb(32'd0),.m4_wready(),.m4_rdata(),.m4_rlast(),.m4_rvalid(),
        .s_awaddr(s_awaddr),.s_araddr(s_araddr),
        .s_awlen(s_awlen),.s_arlen(s_arlen),
        .s_awvalid(s_awvalid),.s_arvalid(s_arvalid),
        .s_awready(s_awready),.s_arready(s_arready),
        .s_wdata(s_wdata),.s_wstrb(s_wstrb),.s_wready(s_wready),
        .s_rdata(s_rdata),.s_rlast(s_rlast),.s_rvalid(s_rvalid));
    mn04_ddr_behav #(.MEM_BYTES(24'h500000),.RD_LATENCY(ACT_RD_LATENCY)) ddr (
        .clk(clk),.rst_n(rst_n),
        .awaddr_i(s_awaddr),.awlen_i(s_awlen),.awvalid_i(s_awvalid),
        .awready_o(s_awready),.wdata_i(s_wdata),.wstrb_i(s_wstrb),
        .wready_o(s_wready),
        .araddr_i(s_araddr),.arlen_i(s_arlen),.arvalid_i(s_arvalid),
        .arready_o(s_arready),.rdata_o(s_rdata),.rlast_o(s_rlast),
        .rvalid_o(s_rvalid));
    // Boot-time loader: reads the packed image out of the SPI-NOR model and
    // writes it into the shared DDR at WEIGHT_BASE_WORD, verifying the 32-bit
    // additive checksum before releasing the core's DDR feeder.  This replaces
    // the old direct preload so the sim exercises the same QSPI->DDR path the
    // board will use.
    mn04_ddr_bootloader #(
        .FLASH_BASE(24'h0), .IMAGE_BYTES(IMAGE_BYTES),
        .DDR_BASE_WORD(WEIGHT_BASE_WORD), .CHECKSUM_EXPECTED(IMAGE_CHECKSUM)
    ) u_bootloader (
        .clk(clk), .rst_n(rst_n), .start_i(boot_start),
        .busy_o(boot_busy), .done_o(boot_done),
        .ddr_init_done_o(boot_init_done), .checksum_ok_o(boot_checksum_ok),
        .flash_rd_addr_o(boot_flash_rd_addr), .flash_rd_data_i(boot_flash_rd_data),
        .cs_o(), .sck_o(), .mosi_o(), .miso_i(1'b1),
        .ddr_awaddr_o(boot_awaddr), .ddr_awvalid_o(boot_awvalid),
        .ddr_awready_i(boot_awready),
        .ddr_wdata_o(boot_wdata), .ddr_wstrb_o(boot_wstrb),
        .ddr_wready_i(boot_wready)
    );
`endif

    // core
    mn04_core #(
        .OP_FILE(OP_FILE), .N_OPS(N_OPS), .LUTS_BASE(LUTS_BASE),
        .FAST_BYTES(1), .START_OP(START_OP), .N_CLASSES(N_CLASSES),
        .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
        .WEIGHT_BASE_WORD(WEIGHT_BASE_WORD)
    ) u_core (
        .clk(clk), .rst_n(rst_n), .start_i(start_i),
        .segment_start_op_i(START_OP[8:0]), .segment_end_op_i(END_OP[8:0]),
        .short_window_i(SHORT_WINDOW != 0),
        .class_window_mode_i(CLASS_MODE[1:0]),
        .busy_o(busy_o), .done_o(done_o),
        .flash_rd_addr_o(flash_rd_addr_o), .flash_rd_data_i(flash_rd_data_i),
        .qspi_cs_o(qspi_cs), .qspi_sck_o(qspi_sck),
        .qspi_mosi_o(qspi_mosi), .qspi_miso_i(1'b1),
        .conv_req_ready_i(conv_req_ready),
        .conv_candidate_valid_o(conv_candidate_valid),
        .conv_candidate_addr_o(conv_candidate_addr),
        .conv_candidate_pad_o(conv_candidate_pad),
        .scalar_candidate_valid_o(scalar_candidate_valid),
        .scalar_candidate_addr_o(scalar_candidate_addr),
        .scalar_req_ready_i(scalar_req_ready),
        .wr_en_o(wr_en_o), .wr_addr_o(wr_addr_o), .wr_data_o(wr_data_o),
        .wr_ready_i(bridge_ready),
        .rd_req_valid_o(rd_req_valid_o), .rd_byte_addr_o(rd_byte_addr_o),
        .rd_req_pad_o(rd_req_pad_o),
        .rd_rsp_valid_i(rd_rsp_valid_i), .rd_data_i(rd_data_i), .rd_lane_i(rd_lane_i),
        .conv_rd_data_i(rd_data_i), .conv_rd_lane_i(rd_lane_i),
        .dump_valid_o(dump_valid_o), .dump_id_o(dump_id_o),
        .dump_op_index_o(dump_op_index_o), .cycle_count_o(cycle_count_o),
        .logits_valid_o(logits_valid_o), .logits_o(logits_o)
`ifdef USE_DDR_WEIGHTS
        , .ddr_init_done_i(boot_init_done),
        .ddr_araddr_o(weight_araddr),.ddr_arvalid_o(weight_arvalid),
        .ddr_arready_i(weight_arready),.ddr_rdata_i(weight_rdata),
        .ddr_rvalid_i(weight_rvalid)
`endif
    );
    mn04_softmax_q16 #(.LUT_FILE(SOFTMAX_LUT), .N_CLASSES(N_CLASSES)) u_softmax (
        .clk(clk), .rst_n(rst_n), .logits_valid_i(logits_valid_o),
        .logits_i(logits_o), .probs_valid_o(probs_valid_o),
        .probs_q16_o(probs_q16_o), .busy_o(softmax_busy_o));

    // x0 load pump
    reg [7:0] x0_mem [0:127999];
    reg [7:0] dw_mem [0:95999];
    reg [7:0] l004_mem [0:31999];
    reg [7:0] l005_mem [0:31999];
    reg [7:0] l010_mem [0:16127];
    reg [7:0] l013_mem [0:8191];
    reg [7:0] head0_mem [0:255];
    reg [7:0] embedding_mem [0:383];
    integer x0_i, x0_n;
    initial begin
        $readmemh(X0_HEX, x0_mem);
        x0_n = 128000;
        $display("TB: x0 loaded %0d bytes", x0_n);
    end
    initial if (START_OP == 20) begin
        $readmemh(DW_HEX, dw_mem);
        $readmemh(L004_HEX, l004_mem);
    end
    initial if (START_OP == 90) $readmemh(HEAD0_HEX, head0_mem);
    initial if (START_OP == 89) $readmemh(EMBEDDING_HEX, embedding_mem);
    initial if (START_OP == 26) $readmemh(L005_HEX, l005_mem);
    initial if (START_OP == 49) $readmemh(L010_HEX, l010_mem);
    initial if (START_OP == 71 || START_OP == 79) $readmemh(L013_HEX, l013_mem);

    // dump geometry ROM: 19 entries x 5 words (base, C, H, W, golden_tag_id)
    reg [31:0] geom [0:19*5-1];
    initial $readmemh(DUMP_GEOM, geom);

    // golden tag names (index = golden_tag_id)
    reg [255:0] gtags [0:18];
    integer t;
    initial begin
        gtags[0]  = "f0_out";
        gtags[1]  = "L001_out"; gtags[2]  = "L002_out"; gtags[3]  = "L003_out";
        gtags[4]  = "L004_out"; gtags[5]  = "L005_out"; gtags[6]  = "L006_out";
        gtags[7]  = "L007_out"; gtags[8]  = "L008_out"; gtags[9]  = "L009_out";
        gtags[10] = "L010_out"; gtags[11] = "L011_out"; gtags[12] = "L012_out";
        gtags[13] = "L013_out"; gtags[14] = "L014_out"; gtags[15] = "L015_out";
        gtags[16] = "f16_out";
        gtags[17] = "embedding";
        gtags[18] = "logits_q";
    end

    // clock
    always #5 clk = ~clk;

    integer fd, c, h, w, idx;
    reg [31:0] base; reg [31:0] C, H, W; reg [31:0] gid;

    task dump_region;
        input [7:0] di;
        reg [2047:0] fname;
        begin
            base = geom[di*5 + 0];
            C    = (di == 18) ? N_CLASSES : geom[di*5 + 1];
            H    = geom[di*5 + 2];
            W    = SHORT_WINDOW ? u_core.short_width(geom[di*5 + 3]) : geom[di*5 + 3];
            gid  = geom[di*5 + 4];
            $sformat(fname, "%s/rtl_%s_%0d_%0d.bin", OUT_DIR, CLIP_TAG, di, gid);
            fd = $fopen(fname, "wb");
            for (c = 0; c < C; c = c + 1)
                for (h = 0; h < H; h = h + 1)
                    for (w = 0; w < W; w = w + 1)
                        $fwrite(fd, "%c", u_act.mem[base + ((h*W + w)*C) + c]);
            $fclose(fd);
            $display("TB: dump di=%0d op=%0d tag=%s base=%h C=%0d H=%0d W=%0d -> %s",
                     di, dump_op_index_o, gtags[gid], base, C, H, W, fname);
        end
    endtask

    // main flow
    integer k;
    initial begin
        #20 rst_n = 1;
`ifdef USE_DDR_WEIGHTS
        // kick off the QSPI->DDR bootloader (runs concurrently with the x0 pump)
        @(posedge clk);
        boot_start = 1;
        @(posedge clk);
        boot_start = 0;
`endif
        if (START_OP == 71 || START_OP == 79) begin
            for (k = 0; k < 8192; k = k + 1) begin
                @(posedge clk);
                u_act.mem[k] = l013_mem[k];
            end
        end else if (START_OP == 49) begin
            for (k = 0; k < 16128; k = k + 1) begin
                @(posedge clk);
                u_act.mem[k] = l010_mem[k];
            end
        end else if (START_OP == 89) begin
            for (k = 0; k < 384; k = k + 1) begin
                @(posedge clk);
                u_act.mem[24'h180000+k] = embedding_mem[k];
            end
        end else if (START_OP == 90) begin
            for (k = 0; k < 256; k = k + 1) begin
                @(posedge clk);
                u_act.mem[24'h180800+k] = head0_mem[k];
            end
        end else if (START_OP == 26) begin
            for (k = 0; k < 32000; k = k + 1) begin
                @(posedge clk);
                u_act.mem[24'h040000+k] = l005_mem[k];
            end
        end else if (START_OP == 20) begin
            for (k = 0; k < 96000; k = k + 1) begin
                @(posedge clk);
                u_act.mem[24'h140000+k] = dw_mem[k];
            end
            for (k = 0; k < 32000; k = k + 1) begin
                @(posedge clk);
                u_act.mem[24'h040000+k] = l004_mem[k];
            end
        end else begin
            // pump x0 into REG_A
            if (SHORT_WINDOW) begin
                // x0 hex is mel-major [128][1000]. Pack the configured short
                // time window into the contiguous activation tensor.
                for (k = 0; k < 128*SHORT_FRAMES; k = k + 1) begin
                    @(posedge clk);
                    u_act.mem[k] = x0_mem[(k / SHORT_FRAMES) * 1000 +
                                          (k % SHORT_FRAMES)];
                end
            end else begin
                for (k = 0; k < x0_n; k = k + 1) begin
                    @(posedge clk);
                    u_act.mem[k] = x0_mem[k];
                end
            end
        end
        x0_done_r = 1;
        if (START_OP == 89)
            $display("TB: embedding first8=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                $signed(u_act.mem[24'h180000]), $signed(u_act.mem[24'h180001]),
                $signed(u_act.mem[24'h180002]), $signed(u_act.mem[24'h180003]),
                $signed(u_act.mem[24'h180004]), $signed(u_act.mem[24'h180005]),
                $signed(u_act.mem[24'h180006]), $signed(u_act.mem[24'h180007]));
        $display("TB: x0 pumped into REG_A");
`ifdef USE_DDR_WEIGHTS
        wait (boot_busy);      // bootloader has started
        wait (!boot_busy);     // bootloader finished the whole copy
        if (!boot_checksum_ok)
            $fatal(1, "boot image checksum mismatch");
        $display("TB: boot image loaded into DDR (checksum ok)");
`endif
        @(posedge clk);
        start_i = 1;
        @(posedge clk);
        start_i = 0;
    end
    integer b11_fd, b11_c, b11_h, b11_w;
    task dump_b11;
        input [23:0] address;
        input integer channels;
        input [1023:0] filename;
        begin
            b11_fd = $fopen(filename,"wb");
            for (b11_c=0; b11_c<channels; b11_c=b11_c+1)
                for (b11_h=0; b11_h<8; b11_h=b11_h+1)
                    for (b11_w=0; b11_w<63; b11_w=b11_w+1)
                        $fwrite(b11_fd,"%c",u_act.mem[address+(b11_h*63+b11_w)*channels+b11_c]);
            $fclose(b11_fd);
        end
    endtask
    integer b14_fd, b14_c, b14_h, b14_w;
    task dump_b14;
        input [23:0] address;
        input integer channels;
        input [1023:0] filename;
        begin
            b14_fd = $fopen(filename,"wb");
            for (b14_c=0; b14_c<channels; b14_c=b14_c+1)
                for (b14_h=0; b14_h<4; b14_h=b14_h+1)
                    for (b14_w=0; b14_w<32; b14_w=b14_w+1)
                        $fwrite(b14_fd,"%c",u_act.mem[address+(b14_h*32+b14_w)*channels+b14_c]);
            $fclose(b14_fd);
        end
    endtask
    reg [3:0] b14_dump_seen=0;
    reg [7:0] b15_dump_seen=0;
    integer b15_fd, b15_c;
    integer b14_addr_off;
    always @(posedge clk) begin
        if (START_OP == 71 && u_core.op_act_r == 71 && u_core.rq_valid_w) begin
            b14_addr_off = u_core.rq_fifo[u_core.rq_head_r] - 24'h080000;
            if ((b14_addr_off % 384 == 24 || b14_addr_off % 384 == 65 ||
                 b14_addr_off % 384 == 334) && b14_addr_off / 384 < 3)
                $display("B14PRE ch=%0d pix=%0d rq=%0d lut=%0d mult=%0d shift=%0d",
                         b14_addr_off % 384, b14_addr_off / 384, $signed(u_core.rq_y),
                         $signed(u_core.lut_rd_data), u_core.rq_mult_r,
                         $signed(u_core.rq_shift_r));
        end
    end
    always @(posedge clk) begin
        if (START_OP == 79 && u_core.st_r == 1 && u_core.fetch_i_r == 0) begin
            if (u_core.op_act_r == 80 && !b15_dump_seen[4]) begin
                b15_dump_seen[4]=1;
                dump_b14(24'h080000,384,"out/rtl_tail79_expand.bin");
            end
            if (u_core.op_act_r == 81 && !b15_dump_seen[5]) begin
                b15_dump_seen[5]=1;
                dump_b14(24'h140000,384,"out/rtl_tail79_dw.bin");
            end
            if (u_core.op_act_r == 85 && !b15_dump_seen[6]) begin
                b15_dump_seen[6]=1;
                dump_b14(24'h140000,384,"out/rtl_tail79_gated.bin");
            end
            if (u_core.op_act_r == 86 && !b15_dump_seen[7]) begin
                b15_dump_seen[7]=1;
                dump_b14(24'h040000,64,"out/rtl_tail79_project.bin");
            end
            if (u_core.op_act_r == 87 && !b15_dump_seen[0]) begin
                b15_dump_seen[0]=1;
                dump_b14(24'h000000,64,"out/rtl_tail79_l015.bin");
            end
            if (u_core.op_act_r == 88 && !b15_dump_seen[1]) begin
                b15_dump_seen[1]=1;
                dump_b14(24'h040000,384,"out/rtl_tail79_f16.bin");
            end
            if (u_core.op_act_r == 89 && !b15_dump_seen[2]) begin
                b15_dump_seen[2]=1;
                b15_fd=$fopen("out/rtl_tail79_embedding.bin","wb");
                for (b15_c=0;b15_c<384;b15_c=b15_c+1)
                    $fwrite(b15_fd,"%c",u_act.mem[24'h180000+b15_c]);
                $fclose(b15_fd);
            end
        end
        if (START_OP == 79 && done_o && !b15_dump_seen[3]) begin
            b15_dump_seen[3]=1;
            b15_fd=$fopen("out/rtl_tail79_logits.bin","wb");
            for (b15_c=0;b15_c<7;b15_c=b15_c+1)
                $fwrite(b15_fd,"%c",u_act.mem[24'h180900+b15_c]);
            $fclose(b15_fd);
        end
    end
    always @(posedge clk) begin
        if (START_OP == 71 && u_core.st_r == 1 && u_core.fetch_i_r == 0) begin
            if (u_core.op_act_r == 72 && !b14_dump_seen[0]) begin
                b14_dump_seen[0]=1;
                dump_b14(24'h080000,384,"out/rtl_block14_expand.bin");
            end
            if (u_core.op_act_r == 73 && !b14_dump_seen[1]) begin
                b14_dump_seen[1]=1;
                dump_b14(24'h140000,384,"out/rtl_block14_dw.bin");
            end
            if (u_core.op_act_r == 77 && !b14_dump_seen[2]) begin
                b14_dump_seen[2]=1;
                dump_b14(24'h140000,384,"out/rtl_block14_gated.bin");
            end
            if (u_core.op_act_r == 78 && !b14_dump_seen[3]) begin
                b14_dump_seen[3]=1;
                dump_b14(24'h040000,64,"out/rtl_block14_project.bin");
            end
            if (u_core.op_act_r == 79) begin
                dump_b14(24'h000000,64,"out/rtl_block14_target_l014.bin");
                $display("BLOCK14 TARGETED DONE cycle_count=%0d",u_core.cycle_count_o);
                $finish;
            end
        end
    end
    reg [5:0] b11_dump_seen=0;
    integer b11_v;
    always @(posedge clk) begin
        if (START_OP == 49 && u_core.st_r == 1 && u_core.fetch_i_r == 0) begin
            if (u_core.op_act_r == 50 && !b11_dump_seen[0]) begin
                b11_dump_seen[0]=1;
                dump_b11(24'h080000,192,"out/rtl_block11_expand.bin");
            end
            if (u_core.op_act_r == 51 && !b11_dump_seen[1]) begin
                b11_dump_seen[1]=1;
                dump_b11(24'h140000,192,"out/rtl_block11_dw.bin");
            end
            if (u_core.op_act_r == 52 && !b11_dump_seen[2]) begin
                b11_dump_seen[2]=1;
                for (b11_v=0;b11_v<192;b11_v=b11_v+1)
                    $display("B11CHK pool[%0d]=%0d",b11_v,$signed(u_act.mem[24'h180000+b11_v]));
            end
            if (u_core.op_act_r == 53 && !b11_dump_seen[3]) begin
                b11_dump_seen[3]=1;
                for (b11_v=0;b11_v<48;b11_v=b11_v+1)
                    $display("B11CHK fc1[%0d]=%0d",b11_v,$signed(u_act.mem[24'h180400+b11_v]));
            end
            if (u_core.op_act_r == 54 && !b11_dump_seen[4]) begin
                b11_dump_seen[4]=1;
                for (b11_v=0;b11_v<192;b11_v=b11_v+1)
                    $display("B11CHK gate[%0d]=%0d",b11_v,u_act.mem[24'h180600+b11_v]);
            end
            if (u_core.op_act_r == 55 && !b11_dump_seen[5]) begin
                b11_dump_seen[5]=1;
                dump_b11(24'h140000,192,"out/rtl_block11_gated.bin");
            end
        end
    end
    always @(posedge clk) begin
        if (START_OP == 49 && u_core.st_r == 1 &&
            u_core.op_act_r == TARGET_STOP_OP && u_core.fetch_i_r == 0) begin
            dump_b11(24'h040000,48,"out/rtl_block11_target_l011.bin");
            $display("BLOCK11 TARGETED DONE");
            $finish;
        end
    end
    always @(posedge clk) begin
        if (START_OP == 26 && u_core.st_r == 1 &&
            u_core.op_act_r == TARGET_STOP_OP && u_core.fetch_i_r == 0) begin
            fd = $fopen("out/rtl_block6_target_l006.bin", "wb");
            for (c=0; c<16; c=c+1)
                for (h=0; h<16; h=h+1)
                    for (w=0; w<125; w=w+1)
                        $fwrite(fd,"%c",u_act.mem[24'h040000+(h*125+w)*16+c]);
            $fclose(fd);
            $display("BLOCK6 TARGETED DONE");
            $finish;
        end
    end
    always @(posedge clk) begin
        if (START_OP == 90 && probs_valid_o) begin
            $display("HEAD90 logits=%h probs_q16=%h cycle=%0d",logits_o,probs_q16_o,cycle_count_o);
            $finish;
        end
    end
    always @(posedge clk) begin
        if (START_OP == 20 && u_core.st_r == 1 &&
            u_core.op_act_r == TARGET_STOP_OP &&
            u_core.fetch_i_r == 0) begin
            if (TARGET_STOP_OP == 26) begin
                fd = $fopen("out/rtl_block5_target_l005.bin", "wb");
                for (c=0; c<16; c=c+1)
                    for (h=0; h<16; h=h+1)
                        for (w=0; w<125; w=w+1)
                            $fwrite(fd,"%c",u_act.mem[24'h040000+(h*125+w)*16+c]);
                $fclose(fd);
            end
            $display("POOL20 TARGETED DONE");
            $finish;
        end
    end
    // op49 (block-11 expand) weight-window load trace: the expand is the first
    // op whose ch_out (192) exceeds ch_per_block (128), forcing a 4KB window
    // reload at co=128.  Log each window load's flash base + first loaded word
    // so the block-1 address/content can be checked against image.hex.
    integer b11_wl_n = 0;
    reg b11_wl_loaded_prev = 0;
    always @(posedge clk) begin
        if (START_OP == 49 && u_core.op_act_r == 49) begin
            if (u_core.wc.qspi_start_o)
                $display("B11WL start n=%0d cyc=%0d co=%0d chblk=%0d base=%h", b11_wl_n,
                         cycle_count_o, u_core.co_r, u_core.ch_per_block, u_core.wc.qspi_addr_o);
            if (u_core.wc.loaded_o && !b11_wl_loaded_prev) begin
                $display("B11WL loaded n=%0d co=%0d w0..7=%02x,%02x,%02x,%02x,%02x,%02x,%02x,%02x",
                         b11_wl_n, u_core.co_r,
                         u_core.wc.wmem_b3[0], u_core.wc.wmem_b0[0],
                         u_core.wc.wmem_b1[0], u_core.wc.wmem_b2[0],
                         u_core.wc.wmem_b3[1], u_core.wc.wmem_b0[1],
                         u_core.wc.wmem_b1[1], u_core.wc.wmem_b2[1]);
                b11_wl_n = b11_wl_n + 1;
            end
            b11_wl_loaded_prev = u_core.wc.loaded_o;
        end
    end

    // GATE4: capture the act_mem write port during the RESIDUAL phase only
    integer wdbg_n = 0;
    always @(posedge clk) begin
        if (u_act.wr_en_i && u_core.cycle_count_o > 32'd9000000 && wdbg_n < 40) begin
            wdbg_n = wdbg_n + 1;
            $display("DBG wmem cyc=%0d addr=%h data=%0d", u_core.cycle_count_o, u_act.wr_addr_i, $signed(u_act.wr_data_i));
        end
    end

    // GATE4: residual read requests + responses (st_r==10 = S_RESID)
    integer rdn = 0, rsn = 0;
    always @(posedge clk) begin
        if (u_core.st_r == 10 && u_act.rd_req_valid_i && rdn < 16) begin
            rdn = rdn + 1;
            $display("DBG rreq cyc=%0d addr=%h ph=%0d k=%0d", u_core.cycle_count_o, u_act.rd_byte_addr_i, u_core.resid_phase_r, u_core.resid_k_r);
        end
        if (u_core.st_r == 10 && u_act.rd_rsp_valid_o && rsn < 16) begin
            rsn = rsn + 1;
            $display("DBG rrsp cyc=%0d d=%h lane=%0d", u_core.cycle_count_o, u_act.rd_data_o, u_act.rd_lane_o);
        end
    end

    // GATE4: one-shot dump of dw region (0xBB800) and project region (0x0) at resid start
    reg resid_dump_done = 0;
    integer di2 = 0;
    always @(posedge clk) begin
        if (u_core.st_r == 10 && !resid_dump_done) begin
            resid_dump_done = 1;
            $display("DBG dwmem first32 @0x140000:");
            for (di2 = 0; di2 < 32; di2 = di2 + 1)
                $display("  dw[%0d]=%0d", di2, $signed(u_act.mem[24'h140000 + di2]));
            $display("DBG pwmem first32 @0x0:");
            for (di2 = 0; di2 < 32; di2 = di2 + 1)
                $display("  pw[%0d]=%0d", di2, $signed(u_act.mem[24'h000000 + di2]));
        end
    end

    // GATE4: one-shot dump of expand region (S1=0x080000) and dw5 region
    // (S2=0x140000) at op6 (L002 project conv) start, to localize L002
    // mismatches to op4 (expand) vs op5 (dw5 stride2).
    reg s1s2_dump_done = 0;
    integer di3 = 0;
    always @(posedge clk) begin
        if (u_core.st_r == 7 && u_core.op_act_r == 6 && u_core.eng_preq && !s1s2_dump_done) begin
            s1s2_dump_done = 1;
            $display("DBG s1mem first32 @0x080000:");
            for (di3 = 0; di3 < 32; di3 = di3 + 1)
                $display("  s1[%0d]=%0d", di3, $signed(u_act.mem[24'h080000 + di3]));
            $display("DBG s2mem first32 @0x140000:");
            for (di3 = 0; di3 < 32; di3 = di3 + 1)
                $display("  s2[%0d]=%0d", di3, $signed(u_act.mem[24'h140000 + di3]));
        end
    end

    // Block 4 SE checkpoints.  The first failed public dump is op17, so
    // inspect the scratch vectors at the boundaries between pool, FCs and
    // gate on the next targeted run.  Read-only testbench diagnostics.
    reg [3:0] se_checkpoint_seen = 0;
    integer se_i;
    always @(posedge clk) begin
        if (u_core.st_r == 1 && u_core.fetch_i_r == 0) begin
            if (u_core.op_act_r == 14 && !se_checkpoint_seen[0]) begin
                se_checkpoint_seen[0] = 1;
                for (se_i = 0; se_i < 32; se_i = se_i + 1)
                    $display("SECHK op14 pool[%0d]=%0d", se_i, $signed(u_act.mem[24'h180000 + se_i]));
            end
            if (u_core.op_act_r == 15 && !se_checkpoint_seen[1]) begin
                se_checkpoint_seen[1] = 1;
                for (se_i = 0; se_i < 8; se_i = se_i + 1)
                    $display("SECHK op15 fc1[%0d]=%0d", se_i, $signed(u_act.mem[24'h180400 + se_i]));
            end
            if (u_core.op_act_r == 16 && !se_checkpoint_seen[2]) begin
                se_checkpoint_seen[2] = 1;
                for (se_i = 0; se_i < 32; se_i = se_i + 1)
                    $display("SECHK op16 gate[%0d]=%0d", se_i, u_act.mem[24'h180600 + se_i]);
                for (se_i = 0; se_i < 32; se_i = se_i + 1)
                    $display("SECHK op16 dw[%0d]=%0d", se_i, u_act.mem[24'h140000 + se_i]);
            end
            if (u_core.op_act_r == 17 && !se_checkpoint_seen[3]) begin
                se_checkpoint_seen[3] = 1;
                for (se_i = 0; se_i < 32; se_i = se_i + 1)
                    $display("SECHK op17 gated[%0d]=%0d", se_i, $signed(u_act.mem[24'h140000 + se_i]));
            end
        end
    end
    integer gate_read_count = 0;
    always @(posedge clk) begin
        if (u_core.st_r == 9 && u_core.op_act_r == 16 && rd_rsp_valid_i
            && gate_read_count < 12) begin
            gate_read_count = gate_read_count + 1;
            $display("SECHK gate_read n=%0d cyc=%0d phase=%0d co=%0d pix=%0d addr=%h lane=%0d byte=%0d",
                gate_read_count, cycle_count_o, u_core.gate_phase_r,
                u_core.gate_co_r, u_core.gate_pix_r, u_act.rd_addr_r,
                rd_lane_i, rd_data_i[8*rd_lane_i +: 8]);
        end
    end
    reg b5_project_dumped = 0;
    integer b5_fd, b5_c, b5_h, b5_w;
    reg b5_gated_dumped = 0;
    integer b5_gate_fd, b5_gate_c, b5_gate_h, b5_gate_w;
    reg b5_dw_dumped = 0;
    integer b5_dw_fd, b5_dw_c, b5_dw_h, b5_dw_w;
    reg [2:0] b5_vector_seen = 0;
    integer b5_v;
    always @(posedge clk) begin
        if (u_core.st_r == 8 && u_core.op_act_r == 20 &&
            u_core.pool_pending_r == 0 && u_core.pool_pix_r == 2000 &&
            u_core.rq_can_start)
            $display("B5CHK poolraw ch=%0d sum=%0d",u_core.pool_co_r,u_core.sum_acc_r);
    end
    always @(posedge clk) begin
        if (u_core.st_r == 1 && u_core.fetch_i_r == 0 &&
            u_core.op_act_r == 20 && !b5_dw_dumped) begin
            b5_dw_dumped = 1;
            b5_dw_fd = $fopen("out/rtl_block5_dw.bin", "wb");
            for (b5_dw_c=0; b5_dw_c<48; b5_dw_c=b5_dw_c+1)
                for (b5_dw_h=0; b5_dw_h<16; b5_dw_h=b5_dw_h+1)
                    for (b5_dw_w=0; b5_dw_w<125; b5_dw_w=b5_dw_w+1)
                        $fwrite(b5_dw_fd, "%c",
                            u_act.mem[24'h140000+(b5_dw_h*125+b5_dw_w)*48+b5_dw_c]);
            $fclose(b5_dw_fd);
            $display("B5CHK DW dumped before pool");
        end
        if (u_core.st_r == 1 && u_core.fetch_i_r == 0) begin
            if (u_core.op_act_r == 21 && !b5_vector_seen[0]) begin
                b5_vector_seen[0] = 1;
                for (b5_v=0; b5_v<48; b5_v=b5_v+1)
                    $display("B5CHK pool[%0d]=%0d",b5_v,$signed(u_act.mem[24'h180000+b5_v]));
            end
            if (u_core.op_act_r == 22 && !b5_vector_seen[1]) begin
                b5_vector_seen[1] = 1;
                for (b5_v=0; b5_v<16; b5_v=b5_v+1)
                    $display("B5CHK fc1[%0d]=%0d",b5_v,$signed(u_act.mem[24'h180400+b5_v]));
            end
            if (u_core.op_act_r == 23 && !b5_vector_seen[2]) begin
                b5_vector_seen[2] = 1;
                for (b5_v=0; b5_v<48; b5_v=b5_v+1)
                    $display("B5CHK gate[%0d]=%0d",b5_v,u_act.mem[24'h180600+b5_v]);
            end
        end
        if (u_core.st_r == 1 && u_core.fetch_i_r == 0 &&
            u_core.op_act_r == 24 && !b5_gated_dumped) begin
            b5_gated_dumped = 1;
            b5_gate_fd = $fopen("out/rtl_block5_gated.bin", "wb");
            for (b5_gate_c=0; b5_gate_c<48; b5_gate_c=b5_gate_c+1)
                for (b5_gate_h=0; b5_gate_h<16; b5_gate_h=b5_gate_h+1)
                    for (b5_gate_w=0; b5_gate_w<125; b5_gate_w=b5_gate_w+1)
                        $fwrite(b5_gate_fd, "%c",
                            u_act.mem[24'h140000+(b5_gate_h*125+b5_gate_w)*48+b5_gate_c]);
            $fclose(b5_gate_fd);
            $display("SECHK block5 gated dumped before projection");
        end
        if (u_core.st_r == 1 && u_core.fetch_i_r == 0 &&
            u_core.op_act_r == 25 && !b5_project_dumped) begin
            b5_project_dumped = 1;
            b5_fd = $fopen("out/rtl_block5_project.bin", "wb");
            for (b5_c=0; b5_c<16; b5_c=b5_c+1)
                for (b5_h=0; b5_h<16; b5_h=b5_h+1)
                    for (b5_w=0; b5_w<125; b5_w=b5_w+1)
                        $fwrite(b5_fd, "%c", u_act.mem[(b5_h*125+b5_w)*16+b5_c]);
            $fclose(b5_fd);
            $display("SECHK block5 project dumped before residual");
        end
    end

    // byte-level preload debug (bias/mult capture alignment)
    integer preb_n = 0;
    always @(posedge clk) begin
        if (u_core.pre_active_r && u_core.qr_byte_valid && preb_n < 24) begin
            $display("TB: prebyte st=%0d cnt=%0d b=%02x", u_core.st_r, u_core.pre_cnt_r, u_core.qr_byte);
            preb_n = preb_n + 1;
        end
    end

    // conv/requant diagnostics for op0 (S_CONV=7) -> own file to survive vsim crashes
    integer dbg_fd;
    integer rsv_n = 0;
    integer rsv_s = 0;
    integer rsv_a = 0;
    integer wr_n = 0;
    integer dw_n = 0;
    integer term_n = 0;
    integer qsp_n = 0;
    integer wl_n = 0;
    integer wl2_n = 0;
    integer ra_n = 0;
    integer rb_n = 0;
    integer ri_n = 0;
    integer pfx_n = 0;
    integer dwn = 0;
    integer dp0_n = 0;
    integer rqcnt = 0;
    reg [17:0] mac_n = 0;
    reg dbg_opened = 0;
    always @(posedge clk) begin
        if (!dbg_opened) begin
            dbg_fd = $fopen({"out/dbg_", CLIP_TAG, ".log"}, "w");
            dbg_opened = 1;
        end
        if (u_core.st_r == 7 && u_core.eng_preq && u_core.wc_loaded && mac_n < 27 && u_core.op_act_r == 0) begin
            $fdisplay(dbg_fd, "mac t=%0d a=%0d w=%0d sum=%0d co=%0d oh=%0d ow=%0d", u_core.eng_ti, u_core.a0_v, u_core.w0_v, u_core.eng1_sum, u_core.co_r, u_core.oh_r, u_core.ow_r);
            mac_n = mac_n + 1;
        end
        if (u_core.st_r == 7 && u_core.eng_preq && u_core.wc_loaded && u_core.op_act_r == 1 && dwn < 96) begin
            $fdisplay(dbg_fd, "dwmac t=%0d a=%0d w=%0d sum=%0d co=%0d oh=%0d ow=%0d", u_core.eng_ti, u_core.a0_v, u_core.w0_v, u_core.eng1_sum, u_core.co_r, u_core.oh_r, u_core.ow_r);
            dwn = dwn + 1;
        end
        if (u_core.rq_start_r && rqcnt < 96) begin
            if ((u_core.oh_r < 2 && u_core.ow_r < 3) || (u_core.oh_r == 63 && u_core.ow_r >= 497))
                $fdisplay(dbg_fd, "rqstart cyc=%0d oh=%0d ow=%0d co=%0d acc=%0d mult=%0d shift=%0d", u_core.cycle_count_o, u_core.oh_r, u_core.ow_r, u_core.co_r, u_core.rq_acc_r, u_core.rq_mult_r, u_core.rq_shift_r);
        end
        if (u_core.cycle_count_o >= 10000000 && u_core.cycle_count_o <= 10000600)
            $fdisplay(dbg_fd, "stk cyc=%0d st=%0d op=%0d residk=%0d residph=%0d pend=%0d head=%0d tail=%0d start=%0d vld=%0d vph=%0d rdreq=%0d rdrsp=%0d acc=%0d vs0=%0d vs5=%0d",
                      u_core.cycle_count_o, u_core.st_r, u_core.op_act_r, u_core.resid_k_r, u_core.resid_phase_r,
                      u_core.rq_pending_r, u_core.rq_head_r, u_core.rq_tail_r, u_core.rq_start_r, u_core.rq_valid_w,
                      u_core.rq_valid_phase_r, u_core.rd_req_valid_r, u_core.rd_rsp_valid_i,
                      u_core.rq_acc_r, u_core.rq.v_s0, u_core.rq.v_s5);
        if (u_core.rq_valid_w && u_core.st_r == 10 && rsv_n < 40) begin
            rsv_n <= rsv_n + 1;
            $fdisplay(dbg_fd, "rsv cyc=%0d n=%0d vph=%0d rta=%0d y=%0d sum=%0d waddr=%h wren=%0d k=%0d",
                      u_core.cycle_count_o, rsv_n, u_core.rq_valid_phase_r,
                      u_core.resid_ta_r, u_core.rq_y, u_core.resid_sum_c,
                      u_core.wr_addr_r, u_core.wr_en_r, u_core.resid_k_d2_r);
        end
        // op1 dw conv probe: MAC inputs at pair_valid (what the MAC actually consumes)
        if (u_core.op_act_r == 1 && qsp_n < 40 && (u_core.qspi_start_o || u_core.qr.byte_valid_o)) begin
            qsp_n <= qsp_n + 1;
            $fdisplay(dbg_fd, "qsp cyc=%0d start=%0d st=%0d addr=%h byte=%0d bv=%0d pre=%0d lut=%0d wcl=%0d",
                      u_core.cycle_count_o, u_core.qspi_start_o, u_core.st_r, u_core.qspi_addr_o,
                      u_core.qr.byte_o, u_core.qr.byte_valid_o, u_core.pre_active_r,
                      u_core.lut_active_r, u_core.wc_load_active_r);
        end
        // op1 dw MAC probe (pair_valid)
        // op1 weight-cache load probe
        if (u_core.wc_qspi_start && u_core.op_act_r == 1 && wl_n < 4) begin
            wl_n <= wl_n + 1;
            $fdisplay(dbg_fd, "wload cyc=%0d n=%0d base=%h co=%0d chblk=%0d woff=%0d",
                      u_core.cycle_count_o, wl_n, u_core.wc_qspi_addr, u_core.co_r,
                      u_core.ch_per_block, u_core.op_w_off);
        end
        if (u_core.wc_loaded && u_core.op_act_r == 1 && wl2_n < 3) begin
            wl2_n <= wl2_n + 1;
            $fdisplay(dbg_fd, "wloaded cyc=%0d n=%0d w0=%0d w1=%0d w2=%0d w3=%0d",
                      u_core.cycle_count_o, wl2_n, u_core.wc_w0, u_core.wc_w1, u_core.wc_w2, u_core.wc_w3);
        end
        if (u_core.eng1.mac_pair_valid && u_core.op_act_r == 1 && term_n < 36) begin
            term_n <= term_n + 1;
            $fdisplay(dbg_fd, "tm cyc=%0d n=%0d co=%0d oh=%0d ow=%0d ti=%0d act=%0d w=%0d pad=%0d",
                      u_core.cycle_count_o, term_n, u_core.co_r, u_core.oh_r, u_core.ow_r,
                      u_core.eng1_ti - 2, u_core.a0_v, u_core.w0_v, u_core.pad_d2_r);
        end
        if (u_core.eng1_done && u_core.mac_run_r && u_core.op_act_r == 1 && dw_n < 10) begin
            dw_n <= dw_n + 1;
            $fdisplay(dbg_fd, "dw cyc=%0d n=%0d co=%0d oh=%0d ow=%0d sum=%0d mult=%0d shift=%0d",
                      u_core.cycle_count_o, dw_n, u_core.co_r, u_core.oh_r, u_core.ow_r,
                      u_core.eng1_sum, u_core.mult_ram[u_core.co_r], u_core.shift_ram[u_core.co_r]);
        end
        if (u_core.st_r == 10 && u_core.resid_k_r < 4 && ri_n < 12 && u_core.rd_req_valid_o) begin
            ri_n <= ri_n + 1;
            $fdisplay(dbg_fd, "req cyc=%0d n=%0d ph=%0d k=%0d addr=%h iss=%0d pend=%0d",
                      u_core.cycle_count_o, ri_n, u_core.resid_phase_r, u_core.resid_k_r,
                      u_core.rd_byte_addr_o, u_core.resid_issue_r, u_core.rq_pending_r);
        end
        if (u_core.rq_start_r && u_core.st_r == 10 && u_core.resid_ph_d2_r && rsv_s < 12) begin
            rsv_s <= rsv_s + 1;
            $fdisplay(dbg_fd, "rsp cyc=%0d n=%0d kd2=%0d kd1=%0d k=%0d acc=%0d push=%h tail=%0d",
                      u_core.cycle_count_o, rsv_s, u_core.resid_k_d2_r, u_core.resid_k_d1_r,
                      u_core.resid_k_r, u_core.rq_acc_r, u_core.rq_fifo[u_core.rq_tail_r], u_core.rq_tail_r);
        end
        if (u_core.rq_start_r && u_core.st_r == 10 && !u_core.resid_ph_d2_r && rsv_a < 8) begin
            rsv_a <= rsv_a + 1;
            $fdisplay(dbg_fd, "rspA cyc=%0d n=%0d kd2=%0d kd1=%0d k=%0d acc=%0d lane=%0d",
                      u_core.cycle_count_o, rsv_a, u_core.resid_k_d2_r, u_core.resid_k_d1_r,
                      u_core.resid_k_r, u_core.rq_acc_r, u_core.rd_lane_i);
        end
        if (u_core.cycle_count_o >= 9883966 && u_core.cycle_count_o <= 9883996 && pfx_n < 16) begin
            pfx_n <= pfx_n + 1;
            $fdisplay(dbg_fd, "pfx cyc=%0d st=%0d rspv=%0d rqacc=%0d k=%0d ph=%0d kd2=%0d ph2=%0d reqv=%0d rqstart=%0d data=%h lane=%0d memA=%0d,%0d,%0d,%0d memB=%0d,%0d,%0d,%0d",
                      u_core.cycle_count_o, u_core.st_r, u_core.rd_rsp_valid_i, u_core.rq_acc_r,
                      u_core.resid_k_r, u_core.resid_phase_r, u_core.resid_k_d2_r, u_core.resid_ph_d2_r,
                      u_core.rd_req_valid_o, u_core.rq_start_r, u_core.rd_data_i, u_core.rd_lane_i,
                      u_act.mem[24'h3e800], u_act.mem[24'h3e801], u_act.mem[24'h3e802], u_act.mem[24'h3e803],
                      u_act.mem[24'h0], u_act.mem[24'h1], u_act.mem[24'h2], u_act.mem[24'h3]);
        end
        if (u_core.st_r == 6 && u_core.wc_started_r && u_core.op_act_r == 1 && wl_n < 8) begin
            wl_n <= wl_n + 1;
            $fdisplay(dbg_fd, "wl cyc=%0d op=%0d base=%h qspiaddr=%h qspistart=%0d count=%0d loading=%0d loaded=%0d",
                      u_core.cycle_count_o, u_core.op_act_r, u_core.wc_flash_base_c,
                      u_core.flash_rd_addr_o, u_core.wc_qspi_start, u_core.wc_qspi_count,
                      u_core.wc_load_active_r, u_core.wc_loaded);
        end
        if (u_core.cycle_count_o == 2500000 || u_core.cycle_count_o == 3000000 ||
            u_core.cycle_count_o == 3700000 || u_core.cycle_count_o == 3900000) begin
            $fdisplay(dbg_fd, "snap2 cyc=%0d st=%0d op=%0d co=%0d f0=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d RA=%0d,%0d,%0d,%0d",
                      u_core.cycle_count_o, u_core.st_r, u_core.op_act_r, u_core.co_r,
                      u_act.mem[24'h3e800], u_act.mem[24'h3e801], u_act.mem[24'h3e802], u_act.mem[24'h3e803],
                      u_act.mem[24'h3e804], u_act.mem[24'h3e805], u_act.mem[24'h3e806], u_act.mem[24'h3e807],
                      u_act.mem[24'h0], u_act.mem[24'h1], u_act.mem[24'h2], u_act.mem[24'h3]);
        end
        if (dump_valid_o && dump_id_o == 0 && dp0_n < 2) begin
            dp0_n <= dp0_n + 1;
            $fdisplay(dbg_fd, "dump0 cyc=%0d f0=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d RA=%0d,%0d,%0d,%0d",
                      u_core.cycle_count_o,
                      u_act.mem[24'h3e800], u_act.mem[24'h3e801], u_act.mem[24'h3e802], u_act.mem[24'h3e803],
                      u_act.mem[24'h3e804], u_act.mem[24'h3e805], u_act.mem[24'h3e806], u_act.mem[24'h3e807],
                      u_act.mem[24'h0], u_act.mem[24'h1], u_act.mem[24'h2], u_act.mem[24'h3]);
        end
        if (u_core.rq_start_r && u_core.op_act_r == 1 && u_core.co_r == 0 && u_core.oh_r == 0 && u_core.ow_r == 0 && dwn < 8) begin
            dwn <= dwn + 1;
            $fdisplay(dbg_fd, "dwsum cyc=%0d sum=%0d mul=%0d sh=%0d engdone=%0d ti=%0d w0=%0d w1=%0d w2=%0d w3=%0d a0=%0d a1=%0d a2=%0d a3=%0d",
                      u_core.cycle_count_o, u_core.rq_acc_r, u_core.rq_mult_r, u_core.rq_shift_r,
                      u_core.eng_done, u_core.eng_ti, u_core.w0_v, u_core.w1_v, u_core.w2_v, u_core.w3_v,
                      u_core.a0_v, u_core.a1_v, u_core.a2_v, u_core.a3_v);
        end
        if (u_core.rd_rsp_valid_i && u_core.st_r == 10 && u_core.resid_ph_d3_r && rb_n < 12) begin
            rb_n <= rb_n + 1;
            $fdisplay(dbg_fd, "rspB cyc=%0d n=%0d kd3=%0d ph3=%0d byte=%0d lane=%0d",
                      u_core.cycle_count_o, rb_n, u_core.resid_k_d3_r, u_core.resid_ph_d3_r,
                      u_core.rd_data_i[8*u_core.rd_lane_i +: 8], u_core.rd_lane_i);
        end
        if (u_core.wr_en_r && u_core.op_act_r == 3 && u_core.wr_addr_r >= 24'h03e800 && u_core.wr_addr_r < 24'h040000 && wr_n < 60) begin
            wr_n <= wr_n + 1;
            $fdisplay(dbg_fd, "wr cyc=%0d n=%0d addr=%h data=%0d st=%0d op=%0d",
                      u_core.cycle_count_o, wr_n, u_core.wr_addr_r, u_core.wr_data_r,
                      u_core.st_r, u_core.op_act_r);
        end
        if (u_core.cycle_count_o % 500000 == 0 && u_core.cycle_count_o < 15000000)
            $fdisplay(dbg_fd, "tick cyc=%0d op=%0d st=%0d co=%0d oh=%0d ow=%0d mac=%0d pend=%0d residk=%0d residph=%0d poolco=%0d gateco=%0d preq=%0d engbusy=%0d done=%0d",
                      u_core.cycle_count_o, u_core.op_act_r, u_core.st_r, u_core.co_r, u_core.oh_r, u_core.ow_r,
                      u_core.mac_run_r, u_core.rq_pending_r, u_core.resid_k_r, u_core.resid_phase_r,
                      u_core.pool_co_r, u_core.gate_co_r, u_core.eng_preq, u_core.eng_busy, u_core.eng_done);
        if (u_core.rq_valid_w && rqcnt < 12) begin
            $fdisplay(dbg_fd, "rqvalid y=%0d lut=%0d", u_core.rq_y, u_core.lut_rd_data);
            rqcnt = rqcnt + 1;
        end
        if (u_core.rq_valid_w && u_core.op_act_r == 3 && rsv_n < 16) begin
            rsv_n <= rsv_n + 1'b1;
            $fdisplay(dbg_fd, "resv n=%0d cyc=%0d st=%0d ph=%0d y=%0d ta=%0d head=%0d tail=%0d waddr=%h",
                      rsv_n, u_core.cycle_count_o, u_core.st_r, u_core.rq_valid_phase_r,
                      u_core.rq_y, u_core.resid_ta_r, u_core.rq_head_r, u_core.rq_tail_r,
                      u_core.wr_addr_r);
        end
        if (u_core.wr_en_r && rqcnt < 16)
            $fdisplay(dbg_fd, "wren cyc=%0d addr=%h data=%0d st=%0d", u_core.cycle_count_o, u_core.wr_addr_r, u_core.wr_data_r, u_core.st_r);
    end

    // ---- GATE4 golden-check probe: at each pair_valid, compute the EXPECTED
    // (a,w,pad) for the consumed term (term_index_r - 2, pair = issue_d2) and
    // print deltas vs what the mac actually sees.  op0 co0 only (diag).
    reg [17:0] win_n = 0;
    integer ct;
    integer c_kh, c_kw, c_ih, c_iw;
    reg  c_padc;
    reg signed [7:0] c_wexp;
    integer c_aexp;
    always @(*) begin
        ct = u_core.eng1.term_index_r - 2;
        c_kh = ct / 3; c_kw = ct % 3;
        c_ih = $signed(u_core.oh_r) * $signed({16'd0, u_core.op_stride}) + c_kh - $signed(u_core.op_pad);
        c_iw = $signed(u_core.ow_r) * $signed({16'd0, u_core.op_stride}) + c_kw - $signed(u_core.op_pad);
        c_padc = (c_ih >= 0 && c_ih < u_core.op_h_in && c_iw >= 0 && c_iw < u_core.op_w_in) ? 1'b0 : 1'b1;
        case (ct)   // op0 co0 weight row (image bytes at offset 0..8)
            0: c_wexp = -8'sd15; 1: c_wexp = -8'sd5;  2: c_wexp =  8'sd17;
            3: c_wexp = -8'sd48; 4: c_wexp = -8'sd101; 5: c_wexp = -8'sd127;
            6: c_wexp =  8'sd22; 7: c_wexp =  8'sd40;  8: c_wexp = -8'sd14;
            default: c_wexp = 0;
        endcase
        if (c_padc) c_aexp = 0;
        else c_aexp = $signed(u_act.mem[c_ih * 1000 + c_iw]);
    end
    always @(posedge clk) begin
        if (u_core.st_r == 7 && u_core.eng1.mac_pair_valid && win_n < 45) begin
            $fdisplay(dbg_fd, "golden cterm=%0d exp(a=%0d w=%0d pad=%0d) act(a=%0d w=%0d pad=%0d) cyc=%0d ow=%0d ctx(t=%0d p=%0d) rd=%0d preq=%0d",
                      ct, c_aexp, c_wexp, c_padc,
                      u_core.eng1.single_lane.mac.activation_i,
                      u_core.eng1.single_lane.mac.weight_i,
                      u_core.pad_d1_r, u_core.cycle_count_o, u_core.ow_r,
                      u_core.ctx_term_r, u_core.ctx_pad_r,
                      u_act.rd_addr_r, u_core.eng_preq);
            win_n = win_n + 1;
        end
    end

    // watch dump_valid
    reg l003_probe_done = 0;
    always @(posedge clk) begin
        if (u_core.st_r == 10 && u_core.op_act_r == 10 && !l003_probe_done) begin
            l003_probe_done = 1;
            // Dump files are CHW, activation memory is NHWC: CHW offset
            // 1711 = (c=0,h=6,w=211) -> byte index 27376.
            $display("L003 probe CHW1711/NHWC27376 skip=%0d project=%0d ra=%0d sa=%0d rb=%0d sb=%0d",
                $signed(u_act.mem[24'h040000 + 27376]),
                $signed(u_act.mem[24'h000000 + 27376]),
                $signed(u_core.op_aux1), $signed(u_core.op_aux2[7:0]),
                $signed(u_core.op_aux3), $signed(u_core.op_aux4[31:24]));
        end
    end
    reg [7:0] ndump_r = 0;
    integer head_probe_n = 0;
    always @(posedge clk) begin
        if (START_OP == 89 && u_core.conv_req && head_probe_n < 4) begin
            head_probe_n = head_probe_n + 1;
            $display("TB: head pair ti=%0d off=%0d weight=%0d,%0d,%0d,%0d",
                u_core.eng_ti, u_core.wc_off_r,
                $signed(u_core.wc_w0), $signed(u_core.wc_w1),
                $signed(u_core.wc_w2), $signed(u_core.wc_w3));
        end
    end
    always @(posedge clk) begin
        if (dump_valid_o && START_OP == 0) begin
            if (dump_id_o == 1)
                $fdisplay(dbg_fd, "DUMP1 regA[0..15]=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d s1[0..7]=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d s2[0..7]=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d f0[0..11]=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                          u_act.mem[0], u_act.mem[1], u_act.mem[2], u_act.mem[3], u_act.mem[4], u_act.mem[5],
                          u_act.mem[6], u_act.mem[7], u_act.mem[8], u_act.mem[9], u_act.mem[10], u_act.mem[11],
                          u_act.mem[12], u_act.mem[13], u_act.mem[14], u_act.mem[15],
                          u_act.mem[24'h080000], u_act.mem[24'h080001], u_act.mem[24'h080002], u_act.mem[24'h080003],
                          u_act.mem[24'h080004], u_act.mem[24'h080005], u_act.mem[24'h080006], u_act.mem[24'h080007],
                          u_act.mem[24'h140000], u_act.mem[24'h140001], u_act.mem[24'h140002], u_act.mem[24'h140003],
                          u_act.mem[24'h140004], u_act.mem[24'h140005], u_act.mem[24'h140006], u_act.mem[24'h140007],
                          u_act.mem[24'h040000], u_act.mem[24'h040001], u_act.mem[24'h040002], u_act.mem[24'h040003],
                          u_act.mem[24'h040004], u_act.mem[24'h040005], u_act.mem[24'h040006], u_act.mem[24'h040007],
                          u_act.mem[24'h040008], u_act.mem[24'h040009], u_act.mem[24'h04000A], u_act.mem[24'h04000B]);
            dump_region(dump_id_o);
            ndump_r <= ndump_r + 1'b1;
            if (ndump_r + 1'b1 >= STOP_AFTER_DUMP) begin
                $display("TB: STOP_AFTER_DUMP=%0d reached at cycle %0d", STOP_AFTER_DUMP, cycle_count_o);
                $finish;
            end
        end
    end

`ifdef DEBUG_CORE
    initial #15 begin
        $display("DBG OP_FILE=%s", OP_FILE);
        $display("DBG opmem[0..3]=%h %h %h %h", u_core.opmem[0], u_core.opmem[1], u_core.opmem[2], u_core.opmem[3]);
        $display("DBG opmem[16..19]=%h %h %h %h", u_core.opmem[16], u_core.opmem[17], u_core.opmem[18], u_core.opmem[19]);
    end
    // ---- debug: sample core internals via hierarchical refs (kept in tb) ----
    // core state encoding: S_IDLE=0 S_FETCH=1 S_PRE_BIAS=2 S_PRE_MULT=3 S_PRE_SHIFT=4
    //                      S_LUT=5 S_WLOAD=6 S_CONV=7 S_POOL=8 S_GATE=9 S_RESID=10 S_DRAIN=11 S_DONE=12
    integer dbg_n = 0, dbg_wr_n = 0, dbg_rq_n = 0, dbg_wc_co = -1;
    integer dbg_pre_b = 0, dbg_pre_m = 0, dbg_pre_s = 0, dbg_lutc = 0;
    reg dbg_pb_prev = 0, dbg_pm_prev = 0, dbg_ps_prev = 0, dbg_la_prev = 0;
    always @(posedge clk) begin
        if (u_core.pre_active_r && u_core.st_r == 4'd2 && u_core.qr_byte_valid) dbg_pre_b = dbg_pre_b + 1;
        if (u_core.pre_active_r && u_core.st_r == 4'd3 && u_core.qr_byte_valid) dbg_pre_m = dbg_pre_m + 1;
        if (u_core.pre_active_r && u_core.st_r == 4'd4 && u_core.qr_byte_valid) dbg_pre_s = dbg_pre_s + 1;
        if (u_core.lut_active_r && u_core.st_r == 4'd5 && u_core.qr_byte_valid) dbg_lutc = dbg_lutc + 1;
        if (dbg_pb_prev && !u_core.pre_active_r) $display("DBG pre bias bytes=%0d first4=%0d,%0d,%0d,%0d", dbg_pre_b, u_core.bias_ram[0], u_core.bias_ram[1], u_core.bias_ram[2], u_core.bias_ram[3]);
        if (dbg_pm_prev && !u_core.pre_active_r) $display("DBG pre mult bytes=%0d first4=%0d,%0d,%0d,%0d", dbg_pre_m, u_core.mult_ram[0], u_core.mult_ram[1], u_core.mult_ram[2], u_core.mult_ram[3]);
        if (dbg_ps_prev && !u_core.pre_active_r) $display("DBG pre shift bytes=%0d first4=%0d,%0d,%0d,%0d", dbg_pre_s, u_core.shift_ram[0], u_core.shift_ram[1], u_core.shift_ram[2], u_core.shift_ram[3]);
        if (dbg_la_prev && !u_core.lut_active_r) $display("DBG lut bytes=%0d lut[112]=%0d lut[128]=%0d lut[200]=%0d", dbg_lutc, u_core.lut.lut[112], u_core.lut.lut[128], u_core.lut.lut[200]);
        dbg_pb_prev = (u_core.st_r == 4'd2) && u_core.pre_active_r;
        dbg_pm_prev = (u_core.st_r == 4'd3) && u_core.pre_active_r;
        dbg_ps_prev = (u_core.st_r == 4'd4) && u_core.pre_active_r;
        dbg_la_prev = (u_core.st_r == 4'd5) && u_core.lut_active_r;
        if (u_core.wr_en_r && u_core.op_act_r == 0 && dbg_wr_n < 16) begin
            dbg_wr_n = dbg_wr_n + 1;
            $display("DBG wr op0 addr=%h data=%0d st=%0d co=%0d oh=%0d ow=%0d rq_y=%0d", u_core.wr_addr_r, u_core.wr_data_r, u_core.st_r, u_core.co_r, u_core.oh_r, u_core.ow_r, u_core.rq_y);
        end
        if (u_core.rq_can_start && u_core.op_act_r == 0 && dbg_rq_n < 8) begin
            dbg_rq_n = dbg_rq_n + 1;
            $display("DBG rqcan op0 st=%0d co=%0d oh=%0d ow=%0d rqy=%0d tail=%0d head=%0d", u_core.st_r, u_core.co_r, u_core.oh_r, u_core.ow_r, u_core.rq_y, u_core.rq_tail_r, u_core.rq_head_r);
        end
        if (u_core.st_r == 4'd1 && u_core.op_act_r == 0 && dbg_n < 1) begin
            dbg_n = dbg_n + 1;
            $display("DBG op0 fetch: terms=%0d H=%0d W=%0d ch_in=%0d ch_out=%0d in=%h out=%h uin=%0d postlut=%0d lutid=%0d", u_core.op_terms, u_core.op_h_in, u_core.op_w_in, u_core.op_ch_in, u_core.op_ch_out, u_core.op_in_base, u_core.op_out_base, u_core.op_uin, u_core.op_postlut, u_core.op_lut_id);
        end
        if (u_core.wc_loaded && u_core.op_act_r == 0 && u_core.co_r != dbg_wc_co && dbg_wc_co < 9) begin
            dbg_wc_co = u_core.co_r;
            $display("DBG wcache loaded co=%0d wmem0=%h wmem1=%h", u_core.co_r, {u_core.wc.wmem_b2[0], u_core.wc.wmem_b1[0], u_core.wc.wmem_b0[0], u_core.wc.wmem_b3[0]}, {u_core.wc.wmem_b2[1], u_core.wc.wmem_b1[1], u_core.wc.wmem_b0[1], u_core.wc.wmem_b3[1]});
        end
        if (u_core.pre_start_c) $display("DBG prestart st=%0d addr=%h cnt=%0d chout=%0d", u_core.st_r, u_core.pre_addr_r, u_core.pre_count_r, u_core.op_ch_out);
        if (u_core.lut_start_c) $display("DBG lutstart addr=%h cnt=%0d lutid=%0d", u_core.lut_addr_r, u_core.qspi_count_o, u_core.op_lut_id);
        if (u_core.wc_load_start_c) $display("DBG wcstart base=%h co=%0d chipb=%0d", u_core.wc_flash_base_c, u_core.co_r, u_core.ch_per_block);
    end
`endif

    // watchdog
    initial begin
        #(MAX_CYCLES * 64'd10);
        $display("TB: WATCHDOG TIMEOUT after %0d cycles", MAX_CYCLES);
`ifdef USE_DDR_ACT_READ
        $display("TB: CACHE_DEBUG op=%0d st=%0d term=%0d candidate=%b addr=%h ready=%b cache_st=%0d fetch_tag=%h arvalid=%b arready=%b rvalid=%b",
                 u_core.op_act_r,u_core.st_r,u_core.eng_ti,
                 conv_candidate_valid,conv_candidate_addr,conv_req_ready,
                 u_act_cache.state_r,u_act_cache.fetch_tag_r,
                 act_arvalid,act_arready,act_rvalid);
`endif
        $finish;
    end

    integer head_fd, head_i, embedding_fd;
    initial begin
        wait (done_o);
        #20;
        if (START_OP == 89) begin
            head_fd = $fopen({OUT_DIR, "/rtl_head_hidden.bin"}, "wb");
            for (head_i=0; head_i<256; head_i=head_i+1)
                $fwrite(head_fd, "%c", u_act.mem[24'h180800+head_i]);
            $fclose(head_fd);
            $display("TB: hidden first8=%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                $signed(u_act.mem[24'h180800]), $signed(u_act.mem[24'h180801]),
                $signed(u_act.mem[24'h180802]), $signed(u_act.mem[24'h180803]),
                $signed(u_act.mem[24'h180804]), $signed(u_act.mem[24'h180805]),
                $signed(u_act.mem[24'h180806]), $signed(u_act.mem[24'h180807]));
            head_fd = $fopen({OUT_DIR, "/rtl_head_logits.bin"}, "wb");
            for (head_i=0; head_i<N_CLASSES; head_i=head_i+1)
                $fwrite(head_fd, "%c", u_act.mem[24'h180900+head_i]);
            $fclose(head_fd);
        end
        $display("TB: DONE cycle_count=%0d", cycle_count_o);
        $display("TB: candidate_stalls=%0d", candidate_stalls);
`ifdef USE_DDR_ACT_READ
        $display("TB: act_ddr_reads=%0d", act_ddr_reads);
`endif
        if (CONV_STALL_PERIOD != 0 && candidate_stalls == 0)
            $fatal(1, "stall test never stalled a candidate");
        if (START_OP == 0) begin
            $display("TB: PASS-STRUCTURAL (bit compare done by python)");
        end
        // Residual-FSM invariant summary (read out of the monitor instance
        // declared at the bottom of this file).
        $display("RESID_FSM_MON visits=%0d cycles=%0d items=%0d maxk=%0d errors=%0d max_stuck=%0d",
                 u_resid_mon.visits, u_resid_mon.cyc_in_resid, u_resid_mon.items, u_resid_mon.max_k,
                 u_resid_mon.errors, u_resid_mon.max_stuck);
        if (u_resid_mon.errors != 0)
            $display("RESID_FSM_MON_FAIL errors=%0d", u_resid_mon.errors);
        else
            $display("RESID_FSM_MON_PASS");
        $finish;
    end

    // ------------------------------------------------------------------
    // Read-only residual-FSM invariant monitor (sim/mn04/mn04_resid_fsm_monitor.v).
    // Connected with hierarchical probes, so mn04_core and its synthesised
    // netlist are completely untouched: the monitor only observes and reports.
    // ------------------------------------------------------------------
    mn04_resid_fsm_monitor u_resid_mon (
        .clk         (clk),
        .rst_n       (rst_n),
        .st          (u_core.st_r),
        .resid_k     (u_core.resid_k_r),
        .resid_total (u_core.resid_total_r),
        .resid_setup (u_core.resid_setup_r),
        .cand_valid  (u_core.scalar_candidate_valid_o)
    );
endmodule
