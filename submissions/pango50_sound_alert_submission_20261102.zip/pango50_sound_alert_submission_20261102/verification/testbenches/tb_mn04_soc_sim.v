`timescale 1ns/1ps
// tb_mn04_soc_sim.v — clean full-chain integration tb (five-class, DDR weights).
//
// This is the "new top-level" data path, minus I2S/decimator/CDC/post:
//   flash(image.hex) -> bootloader (m3) -> DDR weight region
//   x0 (frame-major) -> mn04_x0_writer (m4) -> DDR activation arena (mel-major)
//   mn04_core (USE_DDR_WEIGHTS) with act read cache (m1), write bridge (m0),
//     weight feeder (m2) -> logits_o
//   senior_dbl_ddr3_user_arbiter (m0..m4) -> mn04_ddr_behav
//
// FEED_FILE=1 feeds a frame-major x0 hex (numpy transpose of the core's
// mel-major x0 hex) straight into the writer, so the resulting logits are
// byte-identical to the already-verified full-DDR run.  This validates the
// writer -> arbiter m4 -> DDR -> cache -> core wiring end to end.
module tb_mn04_soc_sim #(
    parameter CLIP_TAG   = "baby_cry_baby_cry_001.wav",
    parameter OP_FILE    = "op_desc_five_class.mem",
    parameter IMAGE_HEX  = "image.hex",
    parameter X0_FRAME_HEX = "x0_frame_major_baby_cry_baby_cry_001.hex",
    parameter PCM_FILE = "pcm_s16le.mem",
    parameter X0_PCM_REF_HEX = "x0_pcm_ref.hex",
    parameter PCM_MODE = 0,
    parameter I2S_MODE = 0,
    parameter POST_MODE = 0,
    parameter BOOT_ONLY = 0,
    parameter CHECK_LOGITS = 1,
    parameter SHORT_WINDOW = 0,
    parameter WINDOW_FRAMES = SHORT_WINDOW ? 100 : 1000,
    parameter PCM_SAMPLES = SHORT_WINDOW ? 32000 : 320000,
    parameter SOFTMAX_LUT_FILE = "softmax_exp_q24_five_class.mem",
    parameter LUTS_BASE  = 799858,
    parameter N_OPS      = 91,
    parameter N_CLASSES  = 5,
    parameter MAX_CYCLES = 240000000,
    parameter [27:0] WEIGHT_BASE_WORD = 28'h100000,
    parameter [23:0] IMAGE_BYTES      = 24'd811890,
    parameter [31:0] IMAGE_CHECKSUM   = 32'h053e2a11,
    parameter LINE_BITS = 11,              // matches proven actrw2048 reference
    parameter ACT_RD_LATENCY = 4,
    // expected logits (class0..class4), long baby_cry float-x0 reference:
    parameter signed [7:0] EXP_L0 = -8'sd3,
    parameter signed [7:0] EXP_L1 =  8'sd76,
    parameter signed [7:0] EXP_L2 = -8'sd29,
    parameter signed [7:0] EXP_L3 = -8'sd35,
    parameter signed [7:0] EXP_L4 = -8'sd22
);
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;              // 100 MHz

    reg start_i = 0;
    wire busy_o, done_o;

    // ---- core DDR/act ports ----
    wire [23:0] flash_rd_addr_o;
    wire [7:0]  flash_rd_data_i;
    wire qspi_cs, qspi_sck, qspi_mosi;
    wire conv_candidate_valid, scalar_candidate_valid;
    wire [23:0] conv_candidate_addr, scalar_candidate_addr;
    wire conv_candidate_pad;
    wire conv_req_ready, scalar_req_ready;
    wire        wr_en_o; wire [23:0] wr_addr_o; wire [7:0] wr_data_o;
    wire        rd_req_valid_o; wire [23:0] rd_byte_addr_o; wire rd_req_pad_o;
    wire        rd_rsp_valid_i; wire [31:0] rd_data_i; wire [1:0] rd_lane_i;
    wire        dump_valid_o; wire [7:0] dump_id_o; wire [15:0] dump_op_index_o;
    wire [31:0] cycle_count_o;
    wire logits_valid_o;
    wire [8*N_CLASSES-1:0] logits_o;

    // ---- flash model (image.hex) ----
    reg [7:0] flash_mem [0:24'h100000-1];
    integer fi;
    initial begin
        $readmemh(IMAGE_HEX, flash_mem);
        fi = 0;
        while (fi < 24'h100000 && flash_mem[fi] !== 8'hx) fi = fi + 1;
        $display("TB: flash loaded %0d bytes", fi);
    end
    assign flash_rd_data_i = flash_mem[flash_rd_addr_o];

    // ---- weight feeder master (m2) ----
    wire [27:0] weight_araddr;
    wire weight_arvalid, weight_arready, weight_rvalid;
    wire [255:0] weight_rdata;

    // ---- activation read cache (m1) ----
    wire [27:0] act_araddr;
    wire act_arvalid, act_arready, act_rvalid;
    wire [255:0] act_rdata;
    wire cache_rsp; wire [31:0] cache_data; wire [1:0] cache_lane;
    wire cache_candidate_ready;
    wire writer_drained;                       // m0 byte-writer drained (used by cache)
    assign conv_req_ready = cache_candidate_ready;
    assign scalar_req_ready = cache_candidate_ready;
    mn04_ddr_act_read_cache #(.LINE_BITS(LINE_BITS)) u_act_cache (
        .clk(clk), .rst_n(rst_n), .flush_i(1'b0),
        .write_invalidate_i(wr_en_o), .write_addr_i(wr_addr_o),
        .writes_drained_i(writer_drained),
        .candidate_valid_i(conv_candidate_valid || scalar_candidate_valid),
        .candidate_addr_i(conv_candidate_valid ? conv_candidate_addr : scalar_candidate_addr),
        .candidate_pad_i(conv_candidate_pad),
        .candidate_ready_o(cache_candidate_ready),
        .rd_req_valid_i(rd_req_valid_o), .rd_byte_addr_i(rd_byte_addr_o),
        .rd_req_pad_i(rd_req_pad_o),
        .rd_rsp_valid_o(cache_rsp), .rd_data_o(cache_data), .rd_lane_o(cache_lane),
        .ddr_araddr_o(act_araddr), .ddr_arvalid_o(act_arvalid),
        .ddr_arready_i(act_arready), .ddr_rdata_i(act_rdata),
        .ddr_rresp_i(2'b00), .ddr_rvalid_i(act_rvalid), .ddr_rready_o());
    assign rd_rsp_valid_i = cache_rsp;
    assign rd_data_i = cache_data;
    assign rd_lane_i = cache_lane;

    // ---- activation write-back bridge + byte writer (m0) ----
    wire bridge_ready;
    wire bridge_valid, writer_ready;
    wire [23:0] bridge_addr; wire [7:0] bridge_data;
    wire [27:0] writer_awaddr;
    wire writer_awvalid, writer_awready, writer_wready, writer_wvalid;
    wire [255:0] writer_wdata; wire [31:0] writer_wstrb;
    reg [1:0] writer_bpipe, boot_bpipe, x0_bpipe;
    mn04_wmerge_bridge u_write_bridge (
        .clk(clk), .rst_n(rst_n), .wr_en_i(wr_en_o),
        .wr_addr_i(wr_addr_o), .wr_data_i(wr_data_o),
        .wr_ready_o(bridge_ready), .mem_wr_en_o(bridge_valid),
        .mem_wr_addr_o(bridge_addr), .mem_wr_data_o(bridge_data),
        .mem_wr_ready_i(writer_ready));
    mn04_ddr_act_byte_writer u_writer (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(1'b1),
        .byte_valid_i(bridge_valid), .byte_addr_i(bridge_addr),
        .byte_data_i(bridge_data), .byte_ready_o(writer_ready),
        .ddr_awaddr_o(writer_awaddr), .ddr_awvalid_o(writer_awvalid),
        .ddr_awready_i(writer_awready), .ddr_wdata_o(writer_wdata),
        .ddr_wstrb_o(writer_wstrb), .ddr_wvalid_o(writer_wvalid), .ddr_wlast_o(),
        .ddr_wready_i(writer_wready),
        .ddr_bresp_i(2'b00), .ddr_bvalid_i(writer_bpipe[1]), .ddr_bready_o(),
        .drained_o(writer_drained));

    // ---- bootloader (m3) + x0 writer (m4) ----
    wire [23:0] boot_flash_rd_addr;
    wire [7:0]  boot_flash_rd_data;
    assign boot_flash_rd_data = flash_mem[boot_flash_rd_addr];
    wire [27:0] boot_awaddr;
    wire boot_awvalid, boot_awready, boot_wready, boot_wvalid;
    wire [255:0] boot_wdata; wire [31:0] boot_wstrb;
    reg  boot_start = 0;
    wire boot_busy, boot_done, boot_init_done, boot_checksum_ok;

    wire [27:0] x0_awaddr;
    wire x0_awvalid, x0_awready, x0_wready, x0_wvalid;
    wire [255:0] x0_wdata; wire [31:0] x0_wstrb;
    // The legacy arbiter/DDR model has no AXI B channel.  Return an OKAY
    // response after each accepted data beat so the current byte writers drain.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            writer_bpipe <= 2'b00;
            boot_bpipe <= 2'b00;
            x0_bpipe <= 2'b00;
        end else begin
            writer_bpipe <= {writer_bpipe[0], writer_wvalid && writer_wready};
            boot_bpipe <= {boot_bpipe[0], boot_wvalid && boot_wready};
            x0_bpipe <= {x0_bpipe[0], x0_wvalid && x0_wready};
        end
    end
    wire x0_writer_done, x0_writer_drained;
    reg  x0_valid = 0;
    reg  [7:0] x0_data = 0;
    wire x0_ready;
    reg pcm_valid = 0;
    reg signed [15:0] pcm_data = 0;
    wire pcm_ready, frontend_x0_valid, frontend_done;
    wire [16:0] front_count_dbg;
    wire signed [7:0] frontend_x0_data;
    reg i2s_bclk=0, i2s_lrck=1, i2s_dout=0;
    wire signed [7:0] i2s_x0_data;
    wire i2s_x0_valid, pcm_overflow;
    wire writer_x0_valid = I2S_MODE ? i2s_x0_valid :
                           PCM_MODE ? frontend_x0_valid : x0_valid;
    wire [7:0] writer_x0_data = I2S_MODE ? i2s_x0_data :
                                PCM_MODE ? frontend_x0_data : x0_data;
    generate if (PCM_MODE) begin : pcm_frontend
        mn04_frontend #(.MAX_FRAMES(WINDOW_FRAMES),
            .PCM_SAMPLES(PCM_SAMPLES)) u_frontend (
            .clk(clk), .rst_n(rst_n), .pcm_valid_i(pcm_valid),
            .pcm_data_i(pcm_data), .pcm_ready_o(pcm_ready),
            .x0_out(frontend_x0_data), .x0_valid(frontend_x0_valid),
            .done_o(frontend_done));
        assign front_count_dbg = u_frontend.x0_cnt;
    end else begin : no_pcm_frontend
        assign pcm_ready = 1'b0;
        assign frontend_x0_valid = 1'b0;
        assign frontend_x0_data = 8'd0;
        assign frontend_done = 1'b0;
        assign front_count_dbg = 17'd0;
    end endgenerate
    generate if (I2S_MODE) begin : i2s_frontend
        mn04_audio_capture_frontend u_capture (
            .clk(clk), .rst_n(rst_n), .es8311_bclk_i(i2s_bclk),
            .es8311_lrck_i(i2s_lrck), .es8311_dout_i(i2s_dout),
            .x0_o(i2s_x0_data), .x0_valid_o(i2s_x0_valid),
            .pcm_overflow_o(pcm_overflow));
    end else begin : no_i2s_frontend
        assign i2s_x0_data=8'd0;
        assign i2s_x0_valid=1'b0;
        assign pcm_overflow=1'b0;
    end endgenerate
    always @(posedge clk) if (rst_n && (PCM_MODE || I2S_MODE) && writer_x0_valid && !x0_ready)
        $fatal(1, "frontend x0 overflowed the DDR writer FIFO");

    // ---- single shared DDR arbiter (m0..m4) ----
    wire [27:0] s_awaddr, s_araddr;
    wire [3:0]  s_awlen, s_arlen;
    wire s_awvalid, s_arvalid, s_awready, s_arready;
    wire [255:0] s_wdata, s_rdata;
    wire [31:0] s_wstrb;
    wire s_wready, s_rlast, s_rvalid;
    senior_dbl_ddr3_user_arbiter u_ddr_arbiter (
        .clk(clk), .rst_n(rst_n),
        .m0_awaddr({2'b00,writer_awaddr[27:5],3'b000}), .m0_araddr(28'd0),
        .m0_awlen(4'd0), .m0_arlen(4'd0),
        .m0_awvalid(writer_awvalid), .m0_arvalid(1'b0),
        .m0_awready(writer_awready), .m0_arready(),
        .m0_wdata(writer_wdata), .m0_wstrb(writer_wstrb),
        .m0_wready(writer_wready), .m0_rdata(), .m0_rlast(), .m0_rvalid(),
        .m1_awaddr(28'd0), .m1_araddr({2'b00,act_araddr[27:5],3'b000}),
        .m1_awlen(4'd0), .m1_arlen(4'd0),
        .m1_awvalid(1'b0), .m1_arvalid(act_arvalid),
        .m1_awready(), .m1_arready(act_arready),
        .m1_wdata(256'd0), .m1_wstrb(32'd0), .m1_wready(),
        .m1_rdata(act_rdata), .m1_rlast(), .m1_rvalid(act_rvalid),
        .m2_awaddr(28'd0), .m2_araddr({2'b00,weight_araddr[27:5],3'b000}),
        .m2_awlen(4'd0), .m2_arlen(4'd0),
        .m2_awvalid(1'b0), .m2_arvalid(weight_arvalid),
        .m2_awready(), .m2_arready(weight_arready),
        .m2_wdata(256'd0), .m2_wstrb(32'd0), .m2_wready(),
        .m2_rdata(weight_rdata), .m2_rlast(), .m2_rvalid(weight_rvalid),
        .m3_awaddr({2'b00,boot_awaddr[27:5],3'b000}), .m3_araddr(28'd0),
        .m3_awlen(4'd0), .m3_arlen(4'd0),
        .m3_awvalid(boot_awvalid), .m3_arvalid(1'b0),
        .m3_awready(boot_awready), .m3_arready(),
        .m3_wdata(boot_wdata), .m3_wstrb(boot_wstrb),
        .m3_wready(boot_wready), .m3_rdata(), .m3_rlast(), .m3_rvalid(),
        .m4_awaddr({2'b00,x0_awaddr[27:5],3'b000}), .m4_araddr(28'd0),
        .m4_awlen(4'd0), .m4_arlen(4'd0),
        .m4_awvalid(x0_awvalid), .m4_arvalid(1'b0),
        .m4_awready(x0_awready), .m4_arready(),
        .m4_wdata(x0_wdata), .m4_wstrb(x0_wstrb),
        .m4_wready(x0_wready), .m4_rdata(), .m4_rlast(), .m4_rvalid(),
        .s_awaddr(s_awaddr), .s_araddr(s_araddr),
        .s_awlen(s_awlen), .s_arlen(s_arlen),
        .s_awvalid(s_awvalid), .s_arvalid(s_arvalid),
        .s_awready(s_awready), .s_arready(s_arready),
        .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wready(s_wready),
        .s_rdata(s_rdata), .s_rlast(s_rlast), .s_rvalid(s_rvalid));
    mn04_ddr_behav #(.MEM_BYTES(24'h500000), .RD_LATENCY(ACT_RD_LATENCY)) ddr (
        .clk(clk), .rst_n(rst_n),
        .awaddr_i(s_awaddr), .awlen_i(s_awlen), .awvalid_i(s_awvalid),
        .awready_o(s_awready), .wdata_i(s_wdata), .wstrb_i(s_wstrb),
        .wready_o(s_wready),
        .araddr_i(s_araddr), .arlen_i(s_arlen), .arvalid_i(s_arvalid),
        .arready_o(s_arready), .rdata_o(s_rdata), .rlast_o(s_rlast),
        .rvalid_o(s_rvalid));

    // ---- bootloader ----
    mn04_ddr_bootloader #(
        .FLASH_BASE(24'h0), .IMAGE_BYTES(IMAGE_BYTES),
        .DDR_BASE_WORD(WEIGHT_BASE_WORD), .CHECKSUM_EXPECTED(IMAGE_CHECKSUM)
    ) u_bootloader (
        .clk(clk), .rst_n(rst_n), .start_i(boot_start),
        .busy_o(boot_busy), .done_o(boot_done),
        .ddr_init_done_o(boot_init_done), .checksum_ok_o(boot_checksum_ok),
        .flash_rd_addr_o(boot_flash_rd_addr), .flash_rd_data_i(boot_flash_rd_data),
        .cs_o(), .sck_o(), .mosi_o(), .miso_i(1'b1),
        .ddr_awaddr_o(boot_awaddr), .ddr_awvalid_o(boot_awvalid),
        .ddr_awready_i(boot_awready),
        .ddr_wdata_o(boot_wdata), .ddr_wstrb_o(boot_wstrb),
        .ddr_wvalid_o(boot_wvalid), .ddr_wlast_o(), .ddr_wready_i(boot_wready),
        .ddr_bresp_i(2'b00), .ddr_bvalid_i(boot_bpipe[1]), .ddr_bready_o());

    // ---- x0 writer (m4) ----
    mn04_x0_writer #(.MEL_BINS(128), .N_FRAMES(WINDOW_FRAMES)) u_x0_writer (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(1'b1),
        .overflow_clear_i(1'b0),
        .x0_valid_i(writer_x0_valid), .x0_data_i(writer_x0_data),
        .x0_base_byte_i(24'h000000), .x0_ready_o(x0_ready),
        .done_o(x0_writer_done),
        .ddr_awaddr_o(x0_awaddr), .ddr_awvalid_o(x0_awvalid),
        .ddr_awready_i(x0_awready), .ddr_wdata_o(x0_wdata),
        .ddr_wstrb_o(x0_wstrb), .ddr_wvalid_o(x0_wvalid), .ddr_wlast_o(),
        .ddr_wready_i(x0_wready),
        .ddr_bresp_i(2'b00), .ddr_bvalid_i(x0_bpipe[1]), .ddr_bready_o(),
        .drained_o(x0_writer_drained), .overflow_o(),
        .next_frame_slot_o(), .frame_done_o());

    // ---- core ----
    mn04_core #(
        .OP_FILE(OP_FILE), .N_OPS(N_OPS), .LUTS_BASE(LUTS_BASE),
        .FAST_BYTES(1), .START_OP(0), .N_CLASSES(N_CLASSES),
        .WEIGHT_BASE_WORD(WEIGHT_BASE_WORD)
    ) u_core (
        .clk(clk), .rst_n(rst_n), .start_i(start_i),
        .segment_start_op_i(9'd0), .segment_end_op_i(9'd90),
        .short_window_i(SHORT_WINDOW != 0),
        .busy_o(busy_o), .done_o(done_o),
        .flash_rd_addr_o(flash_rd_addr_o), .flash_rd_data_i(flash_rd_data_i),
        .qspi_cs_o(qspi_cs), .qspi_sck_o(qspi_sck),
        .qspi_mosi_o(qspi_mosi), .qspi_miso_i(1'b1),
        .conv_req_ready_i(conv_req_ready),
        .conv_candidate_valid_o(conv_candidate_valid),
        .conv_candidate_addr_o(conv_candidate_addr),
        .conv_candidate_pad_o(conv_candidate_pad),
        .scalar_candidate_valid_o(scalar_candidate_valid),
        .scalar_candidate_addr_o(scalar_candidate_addr),
        .scalar_req_ready_i(scalar_req_ready),
        .wr_en_o(wr_en_o), .wr_addr_o(wr_addr_o), .wr_data_o(wr_data_o),
        .wr_ready_i(bridge_ready),
        .rd_req_valid_o(rd_req_valid_o), .rd_byte_addr_o(rd_byte_addr_o),
        .rd_req_pad_o(rd_req_pad_o),
        .rd_rsp_valid_i(rd_rsp_valid_i), .rd_data_i(rd_data_i),
        .rd_lane_i(rd_lane_i),
        .conv_rd_data_i(rd_data_i), .conv_rd_lane_i(rd_lane_i),
        .dump_valid_o(dump_valid_o), .dump_id_o(dump_id_o),
        .dump_op_index_o(dump_op_index_o), .cycle_count_o(cycle_count_o),
        .logits_valid_o(logits_valid_o), .logits_o(logits_o),
        .ddr_init_done_i(boot_init_done),
        .ddr_araddr_o(weight_araddr), .ddr_arvalid_o(weight_arvalid),
        .ddr_arready_i(weight_arready), .ddr_rdata_i(weight_rdata),
        .ddr_rresp_i(2'b00), .ddr_rvalid_i(weight_rvalid), .ddr_rready_o(),
        .scalar_mode_o());

    // Real five-class post path: logits -> softmax -> selector -> latched
    // motor and TFT. The test sends UART R before inference and UART C after
    // checking that the motor remains on until acknowledgement.
    reg uart_rx = 1'b1;
    reg saw_display_transfer = 1'b0;
    wire recognition_enable, motor, panel_ready, panel_busy;
    wire [2:0] display_class_dbg;
    wire tft_nrst, tft_backlight, tft_sclk, tft_mosi, tft_dc, tft_cs_n;
    generate if (POST_MODE) begin : post_path
        wire [79:0] probs;
        wire probs_valid;
        mn04_softmax_q16 #(.LUT_FILE(SOFTMAX_LUT_FILE), .N_CLASSES(5)) u_softmax (
            .clk(clk), .rst_n(rst_n), .logits_valid_i(logits_valid_o),
            .logits_i(logits_o), .probs_valid_o(probs_valid),
            .probs_q16_o(probs), .busy_o());
        v1_board_postcnn_top #(.FIVE_CLASS_MODE(1),
            .CLOCK_HZ(1152000), .SPI_HZ(115200),
            .RESET_CYCLES(1), .PWR_DELAY_CYCLES(1),
            .DISPLAY_DELAY_CYCLES(1)) u_backend (
            .clk(clk), .rst_n(rst_n), .work_key_n_i(1'b1),
            .confirm_key_n_i(1'b1), .uart_rx_i(uart_rx),.external_task_busy_i(1'b0),
            .probs_valid_i(probs_valid), .probs_q16_i({32'd0,probs}),
            .template_result_valid_i(1'b0),.template_result_class_i(2'd0),
            .short_window_i(SHORT_WINDOW != 0), .set_time_i(1'b0),
            .set_hour_i(8'd0), .set_minute_i(8'd0), .set_second_i(8'd0),
            .motor_o(motor), .recognition_enable_o(recognition_enable),
            .work_mode_o(), .alert_accept_o(), .confirm_pulse_o(),
            .panel_ready_o(panel_ready), .panel_busy_o(panel_busy),
            .tft_nrst_o(tft_nrst), .tft_backlight_o(tft_backlight),
            .tft_sclk_o(tft_sclk), .tft_mosi_o(tft_mosi),
            .tft_dc_o(tft_dc), .tft_cs_n_o(tft_cs_n));
        assign display_class_dbg = u_backend.path.alerts.display_class_o;
    end else begin : no_post_path
        assign recognition_enable = 1'b1;
        assign motor = 1'b0;
        assign panel_ready = 1'b0;
        assign panel_busy = 1'b0;
        assign tft_nrst = 1'b0;
        assign tft_backlight = 1'b0;
        assign tft_sclk = 1'b0;
        assign tft_mosi = 1'b0;
        assign tft_dc = 1'b0;
        assign tft_cs_n = 1'b1;
        assign display_class_dbg = 3'd0;
    end endgenerate
    always @(posedge clk) if (rst_n && POST_MODE && motor && panel_ready && !tft_cs_n)
        saw_display_transfer <= 1'b1;

    task uart_byte(input [7:0] data);
        integer bit_i;
        begin
            uart_rx = 0;
            repeat (10) @(negedge clk);
            for (bit_i=0; bit_i<8; bit_i=bit_i+1) begin
                uart_rx = data[bit_i];
                repeat (10) @(negedge clk);
            end
            uart_rx = 1;
            repeat (30) @(negedge clk);
        end
    endtask
    task send_i2s_bit(input channel, input value);
        begin
            @(negedge clk);
            i2s_bclk=0; i2s_lrck=channel; i2s_dout=value;
            repeat (4) @(negedge clk);
            i2s_bclk=1;
            repeat (4) @(negedge clk);
            i2s_bclk=0;
        end
    endtask
    initial if (POST_MODE) begin
        wait (rst_n);
        repeat (5) @(negedge clk);
        uart_byte("R");
    end

    // ---- x0 file feed (frame-major) ----
    reg [7:0] x0_frame [0:127999];
    reg [7:0] pcm_x0_ref [0:127999];
    reg [15:0] pcm_stim [0:319999];
    reg [15:0] i2s_stim [0:48749];
    integer x0_n, x0_i;
    initial begin
        if (BOOT_ONLY) begin
            // Skip all microphone stimulus; exercise only model-image boot,
            // checksum validation and byte-for-byte DDR copy verification.
        end else if (I2S_MODE) begin
            $readmemh(PCM_FILE, i2s_stim);
            $readmemh(X0_PCM_REF_HEX, pcm_x0_ref);
            $display("TB: I2S 48k samples loaded");
        end else if (PCM_MODE) begin
            $readmemh(PCM_FILE, pcm_stim);
            $readmemh(X0_PCM_REF_HEX, pcm_x0_ref);
            $display("TB: PCM32k loaded");
        end else begin
            $readmemh(X0_FRAME_HEX, x0_frame);
            $display("TB: x0 frame-major loaded");
        end
    end

    // ---- control ----
    integer k;
    reg [7:0] logit_byte [0:4];
    integer ci, mism;
    initial begin
        #20 rst_n = 1;
        @(posedge clk);
        boot_start = 1; @(posedge clk); boot_start = 0;
        // feed x0 frame-major into the writer (throttled by x0_ready)
        x0_n = 0;
        if (I2S_MODE) begin
            for (x0_n=0; x0_n<48750; x0_n=x0_n+1) begin
                send_i2s_bit(0,0);
                for (ci=15; ci>=0; ci=ci-1)
                    send_i2s_bit(0,(i2s_stim[x0_n]>>ci)&1);
                for (ci=0; ci<15; ci=ci+1) send_i2s_bit(0,0);
                send_i2s_bit(1,0);
                for (ci=0; ci<31; ci=ci+1) send_i2s_bit(1,0);
            end
            if (pcm_overflow) $fatal(1,"PCM FIFO overflow during I2S capture");
        end else if (PCM_MODE) begin
            while (x0_n < PCM_SAMPLES) begin
                @(negedge clk);
                pcm_valid = 1;
                pcm_data = pcm_stim[x0_n];
                @(posedge clk);
                if (pcm_ready) x0_n = x0_n + 1;
            end
            @(negedge clk);
            pcm_valid = 0;
            wait (frontend_done);
        end else begin
            while (x0_n < WINDOW_FRAMES*128) begin
                @(negedge clk);
                if (x0_ready) begin
                    x0_data = x0_frame[x0_n];
                    x0_valid = 1;
                    @(negedge clk);
                    x0_valid = 0;
                    x0_n = x0_n + 1;
                end
            end
        end
        // wait for writer to finish all DDR beats + bootloader to finish
        if (!BOOT_ONLY) begin
            wait (x0_writer_done);
            wait (x0_writer_drained);
        end
        wait (boot_init_done);
        if (!boot_checksum_ok) $fatal(1, "boot image checksum mismatch");
        // Check the legacy DDR model before inference; the boot checksum only
        // checks bytes read from flash, not the bytes committed to DDR.
        mism = 0;
        for (k=0; k<IMAGE_BYTES; k=k+1)
            if (ddr.mem[(WEIGHT_BASE_WORD << 2) + k] !== flash_mem[k]) begin
                if (mism < 8)
                    $display("BOOT_DDR_MISM byte=%0d got=%02x exp=%02x",
                             k, ddr.mem[(WEIGHT_BASE_WORD << 2) + k], flash_mem[k]);
                mism = mism + 1;
            end
        if (mism != 0) $fatal(1, "boot DDR mismatch: %0d bytes", mism);
        if (BOOT_ONLY) begin
            $display("BOOT_IMAGE_PASS bytes=%0d checksum=%08x", IMAGE_BYTES, IMAGE_CHECKSUM);
            $finish;
        end
        if (!PCM_MODE && !I2S_MODE) begin
            mism = 0;
            for (k=0; k<WINDOW_FRAMES*128; k=k+1)
                if (ddr.mem[(k % 128)*WINDOW_FRAMES + (k / 128)] !== x0_frame[k]) begin
                    if (mism < 8)
                        $display("X0_DDR_MISM frame_byte=%0d got=%02x exp=%02x",
                            k, ddr.mem[(k % 128)*WINDOW_FRAMES + (k / 128)], x0_frame[k]);
                    mism = mism + 1;
                end
            if (mism != 0) $fatal(1, "x0 DDR mismatch: %0d bytes", mism);
        end
        if (PCM_MODE || I2S_MODE) begin
            mism = 0;
            for (k=0; k<WINDOW_FRAMES*128; k=k+1)
                if (ddr.mem[k] !== pcm_x0_ref[k]) begin
                    if (mism < 8)
                        $display("X0_MISM byte=%0d got=%02x exp=%02x", k, ddr.mem[k], pcm_x0_ref[k]);
                    mism = mism + 1;
                end
            if (mism != 0) $fatal(1, "PCM to DDR x0 mismatch: %0d bytes", mism);
            $display("PCM_TO_DDR_X0_PASS bytes=%0d", WINDOW_FRAMES*128);
        end
        $display("TB: x0 written to DDR + boot image loaded (checksum ok)");
        wait (recognition_enable);
        @(posedge clk);
        start_i = 1; @(posedge clk); start_i = 0;
        wait (logits_valid_o);
        @(negedge clk);
        for (ci = 0; ci < N_CLASSES; ci = ci + 1)
            logit_byte[ci] = logits_o[ci*8 +: 8];
        $display("TB: DONE cycle=%0d logits=[%0d,%0d,%0d,%0d,%0d]",
                 cycle_count_o,
                 $signed(logit_byte[0]), $signed(logit_byte[1]),
                 $signed(logit_byte[2]), $signed(logit_byte[3]),
                 $signed(logit_byte[4]));
        // byte-exact check
        mism = 0;
        if (logit_byte[0] !== EXP_L0) mism = mism + 1;
        if (logit_byte[1] !== EXP_L1) mism = mism + 1;
        if (logit_byte[2] !== EXP_L2) mism = mism + 1;
        if (logit_byte[3] !== EXP_L3) mism = mism + 1;
        if (logit_byte[4] !== EXP_L4) mism = mism + 1;
        if (CHECK_LOGITS && mism != 0) $fatal(1, "logits mismatch: got [%0d,%0d,%0d,%0d,%0d] exp [%0d,%0d,%0d,%0d,%0d]",
            $signed(logit_byte[0]), $signed(logit_byte[1]), $signed(logit_byte[2]),
            $signed(logit_byte[3]), $signed(logit_byte[4]),
            EXP_L0, EXP_L1, EXP_L2, EXP_L3, EXP_L4);
        if (POST_MODE) begin
            wait (motor);
            repeat (100000) @(negedge clk);
            if (!motor || recognition_enable || !panel_ready || !tft_backlight)
                $fatal(1, "alert motor/display not latched");
            if (!saw_display_transfer ||
                display_class_dbg !== (SHORT_WINDOW ? 3'd2 : 3'd1))
                $fatal(1, "TFT did not start the expected alert page");
            uart_byte("C");
            repeat (5) @(negedge clk);
            if (motor || !recognition_enable)
                $fatal(1, "confirmation did not resume recognition");
            $display("AUDIO_ALERT_PASS motor/display latched and UART C resumed");
        end
        $display("SOC_SIM_PASS: window=%0d clip=%s logits=[%0d,%0d,%0d,%0d,%0d]",
                 SHORT_WINDOW,
                 CLIP_TAG,
                 $signed(logit_byte[0]), $signed(logit_byte[1]),
                 $signed(logit_byte[2]), $signed(logit_byte[3]),
                 $signed(logit_byte[4]));
        $finish;
    end

    // watchdog
    initial begin
        #(MAX_CYCLES * 64'd10);
        $display("TB: WATCHDOG TIMEOUT x0_n=%0d frontend_done=%b frontend_count=%0d x0_writer_done=%b x0_drained=%b boot_busy=%b boot_done=%b core_busy=%b core_cycle=%0d motor=%b",
                 x0_n, frontend_done,
                 front_count_dbg,
                 x0_writer_done, x0_writer_drained, boot_busy,
                 boot_done, busy_o, cycle_count_o, motor);
        $fatal(1, "soc watchdog");
    end
endmodule
