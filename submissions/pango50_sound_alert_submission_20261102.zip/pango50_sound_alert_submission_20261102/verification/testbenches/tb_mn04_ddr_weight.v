`timescale 1ns/1ps
// MN04 DDR weight feeder verification (GATE: DDR weight channel).
//
// Boot-loads the packed image into a behavioral DDR model, then streams the
// whole image out of DDR through mn04_ddr_weight_feeder in 4 KB blocks (the
// exact block size mn04_weight_block_cache uses) and compares every byte to the
// image reference.  Two configurations, selected by parameters:
//   * USE_ARBITER=0: feeder -> mn04_ddr_behav (isolates the feeder).
//   * USE_ARBITER=1: feeder (m1) + a read hammer (m0) -> senior_dbl_ddr3_user_arbiter
//                    -> mn04_ddr_behav (proves arbiter drop-in + round-robin).
// RD_LATENCY is swept (run script) to prove latency/backpressure tolerance.

// A bare read hammer that competes for the arbiter port (discards its data).
// Holds arvalid until arready (matching the real masters' contract), then waits
// for rvalid before issuing the next read.
module mn04_ddr_hammer (
    input  wire        clk, rst_n, enable_i,
    input  wire        arready_i,
    input  wire [255:0] rdata_i,
    input  wire        rvalid_i,
    output reg  [27:0] araddr_o,
    output reg         arvalid_o
);
    reg [1:0] st;   // 0=idle, 1=hold arvalid until arready, 2=wait rvalid
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            araddr_o <= 28'd0; arvalid_o <= 1'b0; st <= 2'd0;
        end else begin
            case (st)
                2'd0: begin
                    if (enable_i) begin
                        araddr_o <= 28'h0;
                        arvalid_o <= 1'b1;
                        st <= 2'd1;
                    end else begin
                        arvalid_o <= 1'b0;
                    end
                end
                2'd1: begin
                    arvalid_o <= 1'b1;
                    if (arready_i) st <= 2'd2;
                end
                2'd2: begin
                    arvalid_o <= 1'b0;
                    if (rvalid_i) st <= 2'd0;
                end
                default: st <= 2'd0;
            endcase
        end
    end
endmodule

module tb_mn04_ddr_weight #(
    parameter IMAGE_HEX   = "mem/image.hex",
    parameter IMG_BYTES   = 812420,
    parameter RD_LATENCY  = 4,
    parameter USE_ARBITER = 0,
    parameter ENABLE_HAMMER = 0,
    parameter [27:0] WEIGHT_BASE = 28'h80   // DDR word-address base of the image
)();
    reg clk = 0, rst_n = 0;
    reg ddr_init_done = 0;

    // ---- feeder byte-stream side ----
    reg         start_i = 0;
    reg  [23:0] addr_i  = 0;
    reg  [15:0] count_i = 0;
    wire        busy_o, done_o;
    wire [7:0]  byte_o;
    wire        byte_valid_o;
    reg         byte_ready = 1;
    // ---- feeder DDR master side ----
    wire [27:0]  f_araddr;
    wire         f_arvalid, f_arready;
    wire [255:0] f_rdata;
    wire         f_rvalid;

    // ---- DDR port nets (either direct from feeder, or from the arbiter) ----
    wire [27:0] ddr_araddr;
    wire        ddr_arvalid, ddr_arready;
    wire [255:0] ddr_rdata;
    wire        ddr_rvalid;

    // ---- arbiter (USE_ARBITER=1) ----
    wire [27:0] m0_awaddr, m0_araddr, m2_awaddr, m2_araddr, m3_awaddr, m3_araddr, m4_awaddr, m4_araddr;
    wire [3:0]  m0_awlen, m0_arlen, m2_awlen, m2_arlen, m3_awlen, m3_arlen, m4_awlen, m4_arlen;
    wire        m0_awvalid, m0_arvalid, m2_awvalid, m2_arvalid, m3_awvalid, m3_arvalid, m4_awvalid, m4_arvalid;
    wire        m0_awready, m0_arready, m2_awready, m2_arready, m3_awready, m3_arready, m4_awready, m4_arready;
    wire [255:0] m0_wdata, m2_wdata, m3_wdata, m4_wdata;
    wire [31:0]  m0_wstrb, m2_wstrb, m3_wstrb, m4_wstrb;
    wire         m0_wready, m2_wready, m3_wready, m4_wready;
    wire [255:0] m0_rdata, m2_rdata, m3_rdata, m4_rdata;
    wire         m0_rlast, m2_rlast, m3_rlast, m4_rlast;
    wire         m0_rvalid, m2_rvalid, m3_rvalid, m4_rvalid;
    // arbiter slave -> DDR
    wire [27:0] s_awaddr, s_araddr;
    wire [3:0]  s_awlen, s_arlen;
    wire        s_awvalid, s_arvalid, s_awready, s_arready;
    wire [255:0] s_wdata, s_rdata;
    wire [31:0]  s_wstrb;
    wire         s_wready, s_rvalid, s_rlast;

    mn04_ddr_weight_feeder #(.FIFO_DEPTH(4), .WEIGHT_BASE_WORD(WEIGHT_BASE)) u_feeder (
        .clk(clk), .rst_n(rst_n), .ddr_init_done_i(ddr_init_done),
        .start_i(start_i), .addr_i(addr_i), .count_i(count_i),
        .busy_o(busy_o), .done_o(done_o), .byte_o(byte_o),
        .byte_valid_o(byte_valid_o), .byte_ready_i(byte_ready),
        .araddr_o(f_araddr), .arvalid_o(f_arvalid), .arready_i(f_arready),
        .rdata_i(f_rdata), .rvalid_i(f_rvalid)
    );

    generate
        if (USE_ARBITER) begin : gen_arb
            mn04_ddr_hammer u_hammer (
                .clk(clk), .rst_n(rst_n), .enable_i(ENABLE_HAMMER[0]),
                .arready_i(m0_arready), .rdata_i(m0_rdata), .rvalid_i(m0_rvalid),
                .araddr_o(m0_araddr), .arvalid_o(m0_arvalid)
            );
            senior_dbl_ddr3_user_arbiter u_arb (
                .clk(clk), .rst_n(rst_n),
                .m0_awaddr(28'd0), .m0_araddr(m0_araddr),
                .m0_awlen(4'd0), .m0_arlen(4'd0),
                .m0_awvalid(1'b0), .m0_arvalid(m0_arvalid),
                .m0_awready(), .m0_arready(m0_arready),
                .m0_wdata(256'd0), .m0_wstrb(32'd0), .m0_wready(),
                .m0_rdata(m0_rdata), .m0_rlast(), .m0_rvalid(m0_rvalid),
                .m1_awaddr(28'd0), .m1_araddr(f_araddr),
                .m1_awlen(4'd0), .m1_arlen(4'd0),
                .m1_awvalid(1'b0), .m1_arvalid(f_arvalid),
                .m1_awready(), .m1_arready(f_arready),
                .m1_wdata(256'd0), .m1_wstrb(32'd0), .m1_wready(),
                .m1_rdata(f_rdata), .m1_rlast(), .m1_rvalid(f_rvalid),
                .m2_awaddr(28'd0), .m2_araddr(28'd0),
                .m2_awlen(4'd0), .m2_arlen(4'd0),
                .m2_awvalid(1'b0), .m2_arvalid(1'b0),
                .m2_awready(), .m2_arready(),
                .m2_wdata(256'd0), .m2_wstrb(32'd0), .m2_wready(),
                .m2_rdata(), .m2_rlast(), .m2_rvalid(),
                .m3_awaddr(28'd0), .m3_araddr(28'd0),
                .m3_awlen(4'd0), .m3_arlen(4'd0),
                .m3_awvalid(1'b0), .m3_arvalid(1'b0),
                .m3_awready(), .m3_arready(),
                .m3_wdata(256'd0), .m3_wstrb(32'd0), .m3_wready(),
                .m3_rdata(), .m3_rlast(), .m3_rvalid(),
                .m4_awaddr(28'd0), .m4_araddr(28'd0),
                .m4_awlen(4'd0), .m4_arlen(4'd0),
                .m4_awvalid(1'b0), .m4_arvalid(1'b0),
                .m4_awready(), .m4_arready(),
                .m4_wdata(256'd0), .m4_wstrb(32'd0), .m4_wready(),
                .m4_rdata(), .m4_rlast(), .m4_rvalid(),
                .s_awaddr(s_awaddr), .s_araddr(s_araddr),
                .s_awlen(s_awlen), .s_arlen(s_arlen),
                .s_awvalid(s_awvalid), .s_arvalid(s_arvalid),
                .s_awready(s_awready), .s_arready(s_arready),
                .s_wdata(s_wdata), .s_wstrb(s_wstrb), .s_wready(s_wready),
                .s_rdata(s_rdata), .s_rlast(s_rlast), .s_rvalid(s_rvalid)
            );
            assign ddr_araddr  = s_araddr;
            assign ddr_arvalid = s_arvalid;
            assign s_arready   = ddr_arready;
            assign s_rdata     = ddr_rdata;
            assign s_rvalid    = ddr_rvalid;
        end else begin : gen_direct
            assign ddr_araddr  = f_araddr;
            assign ddr_arvalid = f_arvalid;
            assign f_arready   = ddr_arready;
            assign f_rdata     = ddr_rdata;
            assign f_rvalid    = ddr_rvalid;
        end
    endgenerate

    mn04_ddr_behav #(.MEM_BYTES(24'h100000), .RD_LATENCY(RD_LATENCY)) u_ddr (
        .clk(clk), .rst_n(rst_n),
        .awaddr_i(28'd0), .awlen_i(4'd0), .awvalid_i(1'b0), .awready_o(),
        .wdata_i(256'd0), .wstrb_i(32'd0), .wready_o(),
        .araddr_i(ddr_araddr), .arlen_i(4'd0), .arvalid_i(ddr_arvalid),
        .arready_o(ddr_arready), .rdata_o(ddr_rdata), .rlast_o(), .rvalid_o(ddr_rvalid)
    );

    // ---- reference image + boot-load into DDR ----
    reg [7:0] img [0:IMG_BYTES-1];
    integer li;
    initial begin
        $readmemh(IMAGE_HEX, img);
        for (li = 0; li < IMG_BYTES; li = li + 1)
            u_ddr.mem[(WEIGHT_BASE << 2) + li] = img[li];
        $display("TB: loaded %0d bytes into DDR at word base 0x%h", IMG_BYTES, WEIGHT_BASE);
    end

    // ---- byte consumer: compare against contiguous image reference ----
    integer exp_idx = 0;
    integer mismatch = 0;
    integer consumed_total = 0;
    integer max_fifo = 0;
    always @(posedge clk) begin
        if (rst_n && byte_valid_o && byte_ready && busy_o) begin
            if (byte_o !== img[exp_idx]) begin
                if (mismatch < 20)
                    $display("MISMATCH idx=%0d got=%h exp=%h", exp_idx, byte_o, img[exp_idx]);
                mismatch = mismatch + 1;
            end
            exp_idx = exp_idx + 1;
            consumed_total = consumed_total + 1;
        end
        if (u_feeder.fifo_cnt > max_fifo) max_fifo = u_feeder.fifo_cnt;
    end

    // ---- diagnostics: log each block start (compact, for boundary checks) ----
    always @(posedge clk) begin
        if (rst_n && start_i && !busy_o && u_feeder.ir_state == 2'd0) begin
            $display("DBG: start addr_i=%0d count_i=%0d", addr_i, count_i);
        end
    end

    // ---- driver: stream the whole image in 4 KB blocks (then the tail) ----
    // Race-free handshake: hold start_i until the feeder acknowledges (busy_o
    // rises), deassert, then wait for completion.  Never pulse start_i blind.
    integer k;
    integer N_FULL;
    integer TAIL;
    initial begin
        N_FULL = IMG_BYTES / 4096;
        TAIL   = IMG_BYTES % 4096;
        #20 rst_n = 1;
        #20 ddr_init_done = 1;
        @(posedge clk); @(posedge clk);

        for (k = 0; k < N_FULL; k = k + 1) begin
            addr_i  = k * 4096;
            count_i = 4096;
            @(posedge clk); start_i = 1;
            wait(busy_o == 1'b1);   // block actually started
            start_i = 0;
            wait(busy_o == 1'b0);   // block finished
        end
        if (TAIL > 0) begin
            addr_i  = N_FULL * 4096;
            count_i = TAIL;
            @(posedge clk); start_i = 1;
            wait(busy_o == 1'b1);
            start_i = 0;
            wait(busy_o == 1'b0);
        end

        #20;
        $display("DDR_WEIGHT: use_arb=%0d hammer=%0d rd_latency=%0d consumed=%0d expected=%0d mismatch=%0d max_fifo=%0d",
                 USE_ARBITER, ENABLE_HAMMER, RD_LATENCY, consumed_total, IMG_BYTES, mismatch, max_fifo);
        if (consumed_total == IMG_BYTES && mismatch == 0)
            $display("DDR_WEIGHT VERDICT: PASS");
        else
            $display("DDR_WEIGHT VERDICT: FAIL consumed=%0d mismatch=%0d", consumed_total, mismatch);
        $finish;
    end

    always #5 clk = ~clk;

    initial begin
        #(64'd20000000);  // 20 ms watchdog
        $display("DDR_WEIGHT: WATCHDOG TIMEOUT consumed=%0d mismatch=%0d", consumed_total, mismatch);
        $finish;
    end
endmodule
