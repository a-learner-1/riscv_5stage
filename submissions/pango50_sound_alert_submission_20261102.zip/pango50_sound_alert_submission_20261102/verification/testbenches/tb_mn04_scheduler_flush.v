`timescale 1ns/1ps
module tb_mn04_scheduler_flush;
    reg clk=0;
    always #10 clk=~clk;
    reg rst_n=0, short_ready=0, long_ready=0;
    reg recognition_enable=0, alert=0, confirmed=0;
    reg core_busy=0, core_done=0;
    wire core_start, context_short, short_result, long_result, latched;
    wire short_accept, long_accept;
    wire [8:0] start_op;
    mn04_dual_window_scheduler #(.N_OPS(2)) dut(
        .clk(clk),.rst_n(rst_n),.short_ready_i(short_ready),
        .long_ready_i(long_ready),.recognition_enable_i(recognition_enable),
        .alert_i(alert),.confirmed_i(confirmed),.core_busy_i(core_busy),
        .core_done_i(core_done),.core_start_o(core_start),
        .core_start_op_o(start_op),.core_end_op_o(),
        .core_short_window_o(),.core_context_short_o(context_short),
        .short_result_valid_o(short_result),.long_result_valid_o(long_result),
        .alert_latched_o(latched),.short_snapshot_accept_o(short_accept),
        .long_snapshot_accept_o(long_accept));
    initial begin
        repeat(3) @(negedge clk); rst_n=1; recognition_enable=1;
        short_ready=1;
        #1;
        if (!core_start || start_op!=0) $fatal(1,"first short op missing");
        @(negedge clk); short_ready=0; core_busy=1;
        alert=1; recognition_enable=0;
        @(negedge clk); alert=0;
        if (!latched || core_start) $fatal(1,"alert did not freeze");
        confirmed=1; recognition_enable=1;
        @(negedge clk); confirmed=0;
        if (short_accept || long_accept || core_start)
            $fatal(1,"accepted snapshot while draining");
        core_busy=0; core_done=1;
        @(negedge clk); core_done=0;
        if (short_result || long_result || latched || core_start)
            $fatal(1,"stale op result escaped flush");
        short_ready=1;
        #1;
        if (!core_start || start_op!=0)
            $fatal(1,"did not restart cleanly at op zero");
        $display("SCHEDULER_FLUSH_PASS: in-flight op drained and discarded");
        $finish;
    end
    initial begin #10000; $fatal(1,"flush timeout"); end
endmodule
