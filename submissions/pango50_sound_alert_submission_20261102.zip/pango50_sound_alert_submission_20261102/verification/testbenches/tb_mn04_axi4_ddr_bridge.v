`timescale 1ns/1ps
module tb_mn04_axi4_ddr_bridge;
    reg clk=0,rst_n=0;
    always #5 clk=~clk;
    reg [27:0] awaddr=0,araddr=0;
    reg awvalid=0,wvalid=0,wlast=1,bready=0,arvalid=0,rready=0;
    reg [255:0] wdata=0;
    reg [31:0] wstrb=0;
    wire awready,wready,bvalid,arready,rvalid,rlast;
    wire [1:0] bresp,rresp;
    wire [255:0] rdata;
    wire [27:0] d_awaddr,d_araddr;
    wire [3:0] d_awlen,d_arlen;
    wire d_awvalid,d_awready,d_wready,d_arvalid,d_arready,d_rvalid,d_rlast;
    wire [255:0] d_wdata,d_rdata;
    wire [31:0] d_wstrb;
    mn04_axi4_ddr_bridge dut (
        .clk(clk),.rst_n(rst_n),
        .s_awaddr(awaddr),.s_awlen(4'd0),.s_awvalid(awvalid),.s_awready(awready),
        .s_wdata(wdata),.s_wstrb(wstrb),.s_wvalid(wvalid),.s_wlast(wlast),.s_wready(wready),
        .s_bresp(bresp),.s_bvalid(bvalid),.s_bready(bready),
        .s_araddr(araddr),.s_arlen(4'd0),.s_arvalid(arvalid),.s_arready(arready),
        .s_rdata(rdata),.s_rresp(rresp),.s_rlast(rlast),.s_rvalid(rvalid),.s_rready(rready),
        .d_awaddr(d_awaddr),.d_awlen(d_awlen),.d_awvalid(d_awvalid),.d_awready(d_awready),
        .d_wdata(d_wdata),.d_wstrb(d_wstrb),.d_wready(d_wready),
        .d_araddr(d_araddr),.d_arlen(d_arlen),.d_arvalid(d_arvalid),.d_arready(d_arready),
        .d_rdata(d_rdata),.d_rlast(d_rlast),.d_rvalid(d_rvalid));
    mn04_ddr_behav #(.MEM_BYTES(1024),.RD_LATENCY(4)) mem (
        .clk(clk),.rst_n(rst_n),.awaddr_i(d_awaddr),.awlen_i(d_awlen),
        .awvalid_i(d_awvalid),.awready_o(d_awready),
        .wdata_i(d_wdata),.wstrb_i(d_wstrb),.wready_o(d_wready),
        .araddr_i(d_araddr),.arlen_i(d_arlen),.arvalid_i(d_arvalid),
        .arready_o(d_arready),.rdata_o(d_rdata),.rlast_o(d_rlast),.rvalid_o(d_rvalid));
    initial begin
        repeat(5) @(negedge clk); rst_n=1;
        // AW and W together; hold BREADY low after the memory has written.
        @(negedge clk); awaddr=28'h24; awvalid=1; wdata=256'hA500000000; wstrb=32'h00000010; wvalid=1;
        @(posedge clk); if(!awready || !wready) $fatal(1,"first AW/W not accepted");
        @(negedge clk); awvalid=0; wvalid=0;
        wait(bvalid);
        repeat(5) begin @(negedge clk); if(!bvalid || bresp!=0) $fatal(1,"B response lost under backpressure"); end
        bready=1; @(negedge clk); bready=0;
        if(bvalid) $fatal(1,"B response did not retire");
        // Read with RREADY low; data and RLAST must remain stable.
        araddr=28'h24; arvalid=1;
        @(posedge clk); if(!arready) $fatal(1,"AR not accepted");
        @(negedge clk); arvalid=0;
        wait(rvalid);
        repeat(5) begin
            @(negedge clk);
            if(!rvalid || !rlast || rresp!=0 || rdata[39:32]!=8'hA5)
                $fatal(1,"R response lost or changed under backpressure");
        end
        rready=1; @(negedge clk); rready=0;
        if(rvalid) $fatal(1,"R response did not retire");
        $display("AXI4_DDR_BRIDGE_BACKPRESSURE_PASS");
        $finish;
    end
    initial begin #100000; $fatal(1,"bridge watchdog"); end
endmodule
