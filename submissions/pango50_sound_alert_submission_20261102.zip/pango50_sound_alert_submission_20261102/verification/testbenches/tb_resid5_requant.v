`timescale 1ns/1ps
module tb_resid5_requant();
    reg clk=0, rst_n=0, start=0;
    reg signed [31:0] acc=0, mult=0;
    reg signed [7:0] shift=0;
    wire valid;
    wire signed [7:0] y;
    integer phase, x;
    always #5 clk=~clk;
    mn04_requantize_pipe dut(.clk(clk),.rst_n(rst_n),.start_i(start),
        .acc_i(acc),.mult_i(mult),.shift_i(shift),.valid_o(valid),.y_o(y));
    initial begin
        #25 rst_n=1;
        for (phase=0;phase<2;phase=phase+1) begin
            for (x=-128;x<128;x=x+1) begin
                @(negedge clk);
                acc=x;
                mult=(phase==0)?32'sd1123907085:32'sd1281954909;
                shift=(phase==0)?8'sd1:8'sd0;
                start=1;
                @(negedge clk);
                start=0;
                wait(valid);
                $display("RQTEST phase=%0d x=%0d y=%0d",phase,x,y);
                @(negedge clk);
            end
        end
        @(negedge clk); acc=32'sd40485; mult=32'sd1914016904; shift=-8'sd9; start=1;
        @(negedge clk); start=0; wait(valid); $display("RQPOOL acc=40485 y=%0d",y);
        @(negedge clk); acc=32'sd6595; mult=32'sd1914016904; shift=-8'sd9; start=1;
        @(negedge clk); start=0; wait(valid); $display("RQPOOL acc=6595 y=%0d",y);
        $finish;
    end
    initial begin
        #200000; $fatal(1,"requant test timeout");
    end
endmodule
