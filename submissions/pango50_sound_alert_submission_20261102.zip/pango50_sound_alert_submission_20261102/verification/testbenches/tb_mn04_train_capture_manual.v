`timescale 1ns/1ps
module tb_mn04_train_capture_manual;
    localparam integer CLOCK_HZ=1152000, BAUD=115200;
    localparam integer MEL_BINS=2, RING_FRAMES=8;
    localparam integer MIN_FRAMES=2, MAX_FRAMES=8;
    localparam integer TX_FIFO_DEPTH=4;
    reg clk=0,rst_n=0,ddr_init_done=0,uart_rx=1;
    reg start=0,stop=0,label_confirm=0;
    reg [3:0] label=4'd0;
    wire uart_tx,freeze,busy,stream_phase;
    wire label_select_wait;
    reg freeze_ack=0,ring_drained=0,ring_frame_done=0;
    reg [9:0] ring_next_slot=10'd2;
    reg [1:0] overflow=0;
    wire [27:0] cap_araddr;
    wire cap_arvalid,cap_rready;
    reg cap_arready=0;
    reg [255:0] cap_rdata=0;
    reg [1:0] cap_rresp=0;
    reg cap_rvalid=0;
    reg [7:0] rx_buf[0:63];
    integer rx_buf_len=0;
    integer i,k;
    reg [7:0] xor_expected;
    reg fail=0;

    always #5 clk=~clk;
    mn04_train_capture #(
        .RING_BASE_BYTE(24'h500000),.MEL_BINS(MEL_BINS),
        .RING_FRAMES(RING_FRAMES),.CAPTURE_FRAMES(4),
        .MAX_CAPTURE_FRAMES(MAX_FRAMES),.MIN_CAPTURE_FRAMES(MIN_FRAMES),
        .TOTAL_BYTES(512),.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD),
        .TX_FIFO_DEPTH(TX_FIFO_DEPTH)
    ) dut (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(ddr_init_done),
        .uart_rx_i(uart_rx),.local_capture_start_i(start),
        .local_capture_label_i(label),.local_capture_stop_i(stop),
        .local_capture_label_confirm_i(label_confirm),
        .uart_tx_o(uart_tx),.freeze_o(freeze),.task_busy_o(busy),
        .stream_phase_o(stream_phase),.label_select_wait_o(label_select_wait),
        .freeze_ack_i(freeze_ack),
        .ring_drained_i(ring_drained),.ring_frame_done_i(ring_frame_done),
        .ring_next_slot_i(ring_next_slot),.overflow_i(overflow),
        .ddr_araddr_o(cap_araddr),.ddr_arvalid_o(cap_arvalid),
        .ddr_arready_i(cap_arready),.ddr_rdata_i(cap_rdata),
        .ddr_rresp_i(cap_rresp),.ddr_rvalid_i(cap_rvalid),
        .ddr_rready_o(cap_rready));

    function [255:0] beat_data(input [27:0] addr);
        integer b;
        reg [27:0] aligned;
        begin
            aligned={addr[27:5],5'b0};
            for(b=0;b<32;b=b+1) beat_data[8*b +:8]=(aligned[7:0]+b)&8'hff;
        end
    endfunction

    always @(posedge clk) begin
        if(!rst_n) begin cap_arready<=0;cap_rvalid<=0;end
        else begin
            cap_rvalid<=0;
            if(cap_arvalid && cap_arready) begin
                cap_rdata<=beat_data(cap_araddr);cap_rvalid<=1;
            end
            cap_arready<=~(cap_arvalid && cap_arready);
        end
    end

    always begin
        @(negedge uart_tx);
        repeat(15) @(negedge clk);
        for(i=0;i<8;i=i+1) begin rx_buf[rx_buf_len][i]=uart_tx;repeat(10) @(negedge clk);end
        rx_buf_len=rx_buf_len+1;
    end

    task frame_done_pulse;
        begin
            @(negedge clk);ring_frame_done=1;
            @(negedge clk);ring_frame_done=0;
            repeat(2) @(negedge clk);
        end
    endtask

    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        repeat(5) @(negedge clk);ddr_init_done=1;
        @(negedge clk);start=1;
        @(negedge clk);start=0;
        if(!busy) begin $display("FAIL manual capture did not start");fail=1;end
        repeat(3) frame_done_pulse();
        if(freeze) begin $display("FAIL manual capture froze without stop");fail=1;end
        @(negedge clk);stop=1;
        @(negedge clk);stop=0;
        frame_done_pulse();
        wait(freeze);
        freeze_ack=1;ring_drained=1;
        wait(label_select_wait);
        if(rx_buf_len!=0) begin $display("FAIL UART started before label confirmation");fail=1;end
        label=4'd4;
        @(negedge clk);label_confirm=1;
        @(negedge clk);label_confirm=0;
        wait(rx_buf_len>=9+8+2);
        repeat(10) @(negedge clk);
        if(rx_buf[0]!==8'haa || rx_buf[1]!==8'h55 || rx_buf[2]!==8'd4)
            begin $display("FAIL manual header/mode label");fail=1;end
        if(rx_buf[3]!==8'd8 || rx_buf[4]!==0 || rx_buf[5]!==0)
            begin $display("FAIL variable payload length: %h %h %h",rx_buf[5],rx_buf[4],rx_buf[3]);fail=1;end
        if(rx_buf[6]!==8'd2 || rx_buf[7]!==0 || rx_buf[8]!==0)
            begin $display("FAIL ring slot/status header");fail=1;end
        xor_expected=0;
        for(k=0;k<8;k=k+1) begin
            xor_expected=xor_expected^rx_buf[9+k];
            case(k)
                0: if(rx_buf[9+k]!==8'd6) begin $display("FAIL payload[%0d]",k);fail=1;end
                1: if(rx_buf[9+k]!==8'd7) begin $display("FAIL payload[%0d]",k);fail=1;end
                2: if(rx_buf[9+k]!==8'd0) begin $display("FAIL payload[%0d]",k);fail=1;end
                3: if(rx_buf[9+k]!==8'd1) begin $display("FAIL payload[%0d]",k);fail=1;end
                4: if(rx_buf[9+k]!==8'd14) begin $display("FAIL payload[%0d]",k);fail=1;end
                5: if(rx_buf[9+k]!==8'd15) begin $display("FAIL payload[%0d]",k);fail=1;end
                6: if(rx_buf[9+k]!==8'd8) begin $display("FAIL payload[%0d]",k);fail=1;end
                7: if(rx_buf[9+k]!==8'd9) begin $display("FAIL payload[%0d]",k);fail=1;end
            endcase
        end
        if(rx_buf[17]!==xor_expected || rx_buf[18]!==8'h5a)
            begin $display("FAIL trailer/checksum");fail=1;end
        wait(!busy);
        if(!fail) $display("MANUAL_CAPTURE_PASS"); else $display("MANUAL_CAPTURE_FAIL");
        $finish;
    end
    initial begin #2000000;$display("MANUAL_CAPTURE_WATCHDOG bytes=%0d",rx_buf_len);$finish;end
endmodule
