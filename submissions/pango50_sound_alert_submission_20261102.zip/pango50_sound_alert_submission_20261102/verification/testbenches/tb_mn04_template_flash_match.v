`timescale 1ns/1ps
module tb_mn04_template_flash_match #(
    parameter TEMPLATE_FILE="template_maps_q7.mem",
    parameter QUERY_FILE="query_test.mem",
    parameter integer EXPECTED_CLASS=1,
    parameter integer SIM_MIN_VAR_SUM=32768
);
    localparam [23:0] FLASH_BASE=24'h610080;
    localparam integer TEMPLATE_BYTES=76800;
    reg clk=0,rst_n=0,loader_start=0,enable=0,x0_valid=0;
    reg signed [7:0] x0=0;
    reg [7:0] flash_maps [0:TEMPLATE_BYTES-1];
    reg signed [7:0] query [0:12799];
    wire loader_busy,loader_done,flash_cs,flash_sck,flash_mosi,load_we;
    wire [23:0] flash_addr;
    wire [17:0] load_addr;
    wire [7:0] load_data,flash_data;
    wire match_valid,match_busy;
    wire [1:0] match_class;
    wire [15:0] match_score;
    integer i,timeout,loaded=0;

    always #5 clk=~clk;
    initial begin
        $readmemh(TEMPLATE_FILE,flash_maps);
        $readmemh(QUERY_FILE,query);
    end
    assign flash_data=(flash_addr>=FLASH_BASE &&
                       flash_addr<FLASH_BASE+TEMPLATE_BYTES) ?
                       flash_maps[flash_addr-FLASH_BASE] : 8'd0;

    mn04_template_flash_loader #(
        .TEMPLATE_BASE(FLASH_BASE),.TEMPLATE_BYTES(TEMPLATE_BYTES),.FAST_BYTES(1)
    ) loader (
        .clk(clk),.rst_n(rst_n),.start_i(loader_start),.base_i(24'd0),.use_base_i(1'b0),
        .busy_o(loader_busy),.done_o(loader_done),
        .flash_rd_addr_o(flash_addr),.flash_rd_data_i(flash_data),
        .cs_o(flash_cs),.sck_o(flash_sck),.mosi_o(flash_mosi),.miso_i(1'b0),
        .load_we_o(load_we),.load_addr_o(load_addr),.load_data_o(load_data));

    mn04_template_matcher #(
        .INITIAL_TEMPLATE_FILE(""),.DOORBELL_MAPS(2),.SMOKE_ALARM_MAPS(2),
        .MAX_MAPS_PER_CLASS(2),.THRESHOLD_Q15(16'd26214),
        .MIN_VAR_SUM(SIM_MIN_VAR_SUM)
    ) matcher (
        .clk(clk),.rst_n(rst_n),.enable_i(enable),
        .x0_i(x0),.x0_valid_i(x0_valid),
        .template_load_we_i(load_we),.template_load_addr_i(load_addr),
        .template_load_data_i(load_data),.template_external_rd_en_i(1'b0),
        .template_external_rd_addr_i(18'd0),.template_external_rd_data_o(),
        .template_valid_mask_i(6'b111111),
        .result_valid_o(match_valid),.result_class_o(match_class),
        .result_score_q15_o(match_score),.busy_o(match_busy));

    always @(posedge clk) if (rst_n && load_we) loaded=loaded+1;

    initial begin
        repeat(5) @(negedge clk);
        rst_n=1;
        repeat(3) @(negedge clk);
        loader_start=1;
        timeout=0;
        while(!loader_done && timeout<300000) begin
            @(negedge clk); timeout=timeout+1;
        end
        if(!loader_done || loader_busy || loaded!=TEMPLATE_BYTES)
            $fatal(1,"flash load did not finish: done=%b busy=%b bytes=%0d",
                   loader_done,loader_busy,loaded);
        for(i=0;i<TEMPLATE_BYTES;i=i+1)
            if(matcher.template_mem[i] !== flash_maps[i])
                $fatal(1,"template BRAM differs from QSPI at byte %0d: bram=%02x flash=%02x loaded=%0d addr=%0d",
                       i,matcher.template_mem[i],flash_maps[i],loaded,load_addr);

        enable=1;
        // The matcher discards WARMUP_FRAMES after it is enabled so the
        // button-start transient cannot be interpreted as the first window.
        // Send a separate 20-frame transient, then start the query at frame
        // zero. A continuous modulo stream rotates the post-warmup window.
        for(i=0;i<20*128;i=i+1) begin
            @(negedge clk); x0=8'sd0; x0_valid=1;
        end
        for(i=0;i<12800;i=i+1) begin
            @(negedge clk); x0=query[i]; x0_valid=1;
        end
        @(negedge clk); x0_valid=0;
        timeout=0;
        while(!match_valid && timeout<1000000) begin
            @(negedge clk); timeout=timeout+1;
        end
        if(!match_valid) $fatal(1,"match did not finish after QSPI template load");
        if(match_class!=EXPECTED_CLASS)
            $fatal(1,"wrong match class expected=%0d got=%0d score=%0d",
                   EXPECTED_CLASS,match_class,match_score);
        $display("TEMPLATE_FLASH_MATCH_PASS bytes=%0d class=%0d score_q15=%0d",
                 loaded,match_class,match_score);
        $finish;
    end
endmodule
