`timescale 1ns/1ps
module tb_mn04_runtime_fabric_short #(
    parameter OP_FILE="op_desc_five_class.mem",
    parameter IMAGE_HEX="image.hex",
    parameter X0_HEX="x0_short_i2s_car_horn_car_horn_001.hex",
    parameter F0_HEX="f0_out.hex",
    parameter SOFTMAX_LUT_FILE="softmax_exp_q24_five_class.mem",
    parameter PCM_FILE="car_horn_48k_from32k.mem",
    parameter TEMPLATE_ROM_FILE="C:/Studying_file/pango50_sound_alert_v1/build/pds/template_bank_update_resource_20261020/template_maps_q7.mem",
    parameter I2S_INPUT=0,
    parameter integer CURRENT_FIVE_CLASS=0,CPU_TASK_CONTROL=0,
    parameter integer I2S_HALF_CYCLES=4,
    parameter integer EXPECTED_WARMUP_FRAMES=400,
    parameter CPU_FIRMWARE_FILE="C:/Studying_file/pango50_sound_alert_v1/firmware/control_rv32im/build/control.mem",
    parameter integer TEMPLATE_DDR_STORAGE=0,TEMPLATE_MAPS_PER_CLASS=2,
    parameter integer UNIFORM_120_WINDOW=0,
    parameter integer PCM_SAMPLES=48750,
    parameter integer I2S_SD_TEMPLATE_TEST=0,
    parameter integer SD_ENABLED=I2S_SD_TEMPLATE_TEST,
    parameter integer SD_FIRST_CASE=0,SD_CASE_COUNT=3,
    parameter integer SD_HIGH_CAPACITY=1,
    parameter LONG_WINDOW=0,
    parameter CAPTURE_PARALLEL=0,
    parameter EIGHT_CLASS_MODE=0,
    parameter SIX_CLASS_MODE=0,
    parameter FULL_CAPTURE_PARALLEL=0,
    parameter LOCAL_TEMPLATE_ENROLLMENT=0,
    parameter SIM_OPEN_THRESHOLDS=0,
    parameter EXPECT_NO_ALERT=0,
    parameter TEMPLATE_MATCH_ENABLED=0,
    parameter integer CLASS_WINDOW_MODE=0,
    parameter CNN_TEMPLATE_FILE="",
    parameter [23:0] CNN_TEMPLATE_VALID_MASK=24'h000000,
    parameter integer CNN_TEMPLATE_WEIGHT_Q2=1,
    parameter [31:0] MODEL_CHECKSUM=SIX_CLASS_MODE ? 32'h053ec73a :
                                                  (EIGHT_CLASS_MODE ? 32'h0539cd5b : 32'h053e2a11),
    parameter [15:0] FUSED_BABY_THRESHOLD_Q16=16'd47221,
    parameter [15:0] FUSED_KNOCK_THRESHOLD_Q16=16'd60563,
    parameter [15:0] FUSED_SIREN_THRESHOLD_Q16=16'd53921,
    parameter [15:0] FUSED_DOG_THRESHOLD_Q16=16'd54937,
    parameter [15:0] FUSED_CAR_THRESHOLD_Q16=16'd59391,
    parameter [3:0] EXPECTED_DISPLAY_CLASS=4'd3,
    parameter integer N_CLASSES=CURRENT_FIVE_CLASS ? 5 : SIX_CLASS_MODE ? 6 : (EIGHT_CLASS_MODE ? 8 : 5),
    parameter integer MODEL_IMAGE_BYTES=CURRENT_FIVE_CLASS ? 811890 : SIX_CLASS_MODE ? 812155 : (EIGHT_CLASS_MODE ? 812685 : 811890),
    parameter N_FRAMES=CAPTURE_PARALLEL ? 100 : (LONG_WINDOW ? 1000 : 100)
);
    reg clk=0,rst_n=0,boot_start=0,x0_valid=0;
    reg [7:0] x0_data=0;
    reg i2s_bclk=0,i2s_lrck=1,i2s_dout=0;
    wire signed [7:0] capture_x0;
    wire signed [15:0] capture_pcm_debug;
    wire capture_pcm_debug_valid,window_quiet;
    wire capture_valid,pcm_overflow;
    reg uart_rx=1;
    reg work_key_n=1,confirm_key_n=1;
    wire [5:0] cpu_commands;
    reg category_key_n=1,start_capture_key_n=1,stop_capture_key_n=1,mode_key_n=1;
    always #5 clk=~clk;
    reg [7:0] flash_mem [0:1048575];
    reg [7:0] x0_mel [0:127999];
    reg [7:0] f0_expected [0:25599];
    reg [7:0] runtime_f0_dump [0:25599];
    reg [7:0] runtime_x0_at_op0 [0:128*N_FRAMES-1];
    reg [7:0] capture_x0_trace [0:131071];
    reg [15:0] i2s_stim [0:PCM_SAMPLES-1];
    wire [23:0] boot_flash_addr,core_flash_addr;
    wire boot_done,x0_overflow,short_ready,long_ready,capture_busy,capture_uart_tx;
    wire capture_recording,capture_start,capture_stop,category_advance,template_mode;
    wire [3:0] capture_selected_category;
    wire [23:0] capture_ring_base;
    wire short_accept,long_accept,core_start,core_short,context_short;
    wire [8:0] start_op,end_op;
    wire [1:0] core_class_window_mode,short_snapshot_mode;
    wire core_busy,core_done,logits_valid;
    wire [8*N_CLASSES-1:0] fabric_logits;
    wire [63:0] logits;
    assign logits={{(64-8*N_CLASSES){1'b0}},fabric_logits};
    wire template_result_valid;
    wire [1:0] template_result_class;
    wire motor,recognition_enable,panel_ready,panel_busy;
    wire cpu_grant,cpu_event_valid,cpu_probs_valid,cpu_job_done;
    wire [3:0] cpu_slot,cpu_event_class;
    wire [14:0] cpu_slots;
    wire cpu_commit;
    wire [95:0] cpu_probs;
    wire [31:0] cpu_signature,cpu_isa,cpu_irqs;
    wire [15:0] template_score;
    reg [5:0] previous_cpu_commands=6'h3f;
    always @(posedge clk) if(CPU_TASK_CONTROL) begin
        previous_cpu_commands<=cpu_commands;
        if(cpu_commands!=previous_cpu_commands)
            $display("CPU_COMMAND_TRACE t=%0t keys=%b category=%0d busy=%b recording=%b listen=%b",
                $time,cpu_commands,capture_selected_category,capture_busy,capture_recording,recognition_enable);
        if(capture_start || capture_stop || category_advance)
            $display("CPU_CAPTURE_TRACE t=%0t start=%b stop=%b next=%b category=%0d busy=%b",
                $time,capture_start,capture_stop,category_advance,capture_selected_category,capture_busy);
    end
    generate if(CPU_TASK_CONTROL) begin:g_real_cpu
        mn04_rv32im_control #(.CLOCK_HZ(10000),.FIRMWARE_FILE(CPU_FIRMWARE_FILE),
            .BABY_THRESHOLD(FUSED_BABY_THRESHOLD_Q16),.KNOCK_THRESHOLD(FUSED_KNOCK_THRESHOLD_Q16),
            .SIREN_THRESHOLD(FUSED_SIREN_THRESHOLD_Q16),.CAR_THRESHOLD(FUSED_CAR_THRESHOLD_Q16)) cpu(
            .clk(clk),.rst_n(rst_n),.key_n_i({mode_key_n,stop_capture_key_n,start_capture_key_n,category_key_n,confirm_key_n,work_key_n}),
            .boot_ready_i(boot_done),.codec_ready_i(1'b1),.recognition_i(recognition_enable),
            .capture_busy_i(capture_busy),.recording_i(capture_recording),.alert_i(motor),
            .snapshot_ready_i(short_ready),.job_done_i(cpu_job_done),.cnn_valid_i(cpu_probs_valid),.cnn_probabilities_i(cpu_probs),
            .template_valid_i(template_result_valid),.template_class_i(template_result_class),.template_score_i(template_score),
            .capture_category_i(capture_selected_category),.template_slot_mask_i(cpu_slots),.template_commit_i(cpu_commit),
            .command_key_n_o(cpu_commands),.job_authorized_o(cpu_grant),.template_slot_o(cpu_slot),
            .event_valid_o(cpu_event_valid),.event_class_o(cpu_event_class),.firmware_signature_o(cpu_signature),
            .command_count_o(),.irq_count_o(cpu_irqs),.isa_selftest_o(cpu_isa));
    end else begin:g_no_real_cpu
        assign cpu_commands=6'h3f;assign cpu_grant=1;assign cpu_event_valid=0;assign cpu_slot=0;assign cpu_event_class=0;
    end endgenerate
    wire audio_task_active = recognition_enable || capture_recording;
    wire template_sd_clk,template_sd_cs_n,template_sd_mosi,template_sd_miso;
    generate if(SD_ENABLED) begin : g_sd_card_model
        sd_card_model #(.BLOCK_COUNT(512),.HIGH_CAPACITY(SD_HIGH_CAPACITY)) card (
            .sd_clk(template_sd_clk),.sd_cs_n(template_sd_cs_n),
            .sd_mosi(template_sd_mosi),.sd_miso(template_sd_miso));
    end else begin : g_no_sd_card_model
        assign template_sd_miso=1'b1;
    end endgenerate
    wire [3:0] display_class_mon;
    wire display_class_mismatch =
        (SIX_CLASS_MODE && EXPECTED_DISPLAY_CLASS==4'd0) ?
        ((display_class_mon!=4'd4) && (display_class_mon!=4'd5)) :
        (display_class_mon!=((TEMPLATE_MATCH_ENABLED && !I2S_INPUT) ? 4'd8 :
                             (SIX_CLASS_MODE ? EXPECTED_DISPLAY_CLASS :
                              (LONG_WINDOW ? 4'd1 : 4'd2))));
    wire tft_nrst,tft_backlight,tft_sclk,tft_mosi,tft_dc,tft_cs_n;
    wire display_asset_we;
    wire [14:0] display_asset_addr;
    wire [7:0] display_asset_data;
    wire [27:0] awaddr,araddr;
    wire [3:0] awlen,arlen;
    wire awvalid,arvalid,awready,arready,wvalid,wlast,wready;
    wire [1:0] bresp,rresp;
    wire bvalid,bready,rlast,rvalid,rready;
    wire [255:0] wdata,rdata;
    wire [31:0] wstrb;
    // stripped bridge -> behavioral DDR
    wire [27:0] d_awaddr,d_araddr;
    wire [3:0] d_awlen,d_arlen;
    wire d_awvalid,d_arvalid,d_awready,d_arready,d_wready,d_rlast,d_rvalid;
    wire [255:0] d_wdata,d_rdata;
    wire [31:0] d_wstrb;
    wire qspi_cs,qspi_sck,qspi_mosi;
    integer f,m,logits_seen=0;
    integer ci,ring_mism,snapshot_mism;
    integer capture_x0_count=0,capture_x0_mism=0;
    integer accepted_x0_count=0,accepted_x0_mism=0,expected_x0_index;
    integer image_mism,f0_input_mism;
    integer first_unknown_write_reported=0,head0_write_reported=0;
    integer unknown_core_write_count=0;
    integer f0_early_checked=0;
    integer f0_x0_early_checked=0,f0x0_i;
    integer op0_req_trace=0,op0_rsp_trace=0,op0_wr_trace=0;
    reg saw_tft=0;
    reg short_snap_done=0, long_snap_done=0;
    time short_ready_time=0,long_ready_time=0;
    integer ff,mm;
    integer sd_case,sd_byte,sd_sample,sd_base,sd_restored_bytes=0;
    reg [7:0] sd_expected_maps[0:3*TEMPLATE_MAPS_PER_CLASS*12800-1];
    integer sd_stall_cycles=0;
    reg [15:0] sd_last_progress=16'hffff;
    generate if(I2S_SD_TEMPLATE_TEST) begin : g_sd_progress_watchdog
        always @(posedge clk) begin
            if(rst_n && u_fabric.g_sd_template_storage.u_sd_store.state_r==8)
                $display("I2S_SD_CRC_TRACE map=%0d actual=%h expected=%h",
                    u_fabric.g_sd_template_storage.u_sd_store.boot_map_r,
                    u_fabric.g_sd_template_storage.u_sd_store.map_crc_work_r ^ 32'hffffffff,
                    u_fabric.g_sd_template_storage.u_sd_store.map_crc_r[u_fabric.g_sd_template_storage.u_sd_store.boot_map_r]);
            if(rst_n && u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.spi_done &&
               u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.state==3)
                $display("SD_R1_TRACE cmd=%0d byte=%h cardmode=%0d qread=%0d qwrite=%0d",
                    u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.cmd_now,
                    u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.spi_in,
                    g_sd_card_model.card.mode,g_sd_card_model.card.q_rd,g_sd_card_model.card.q_wr);
            if(rst_n && u_fabric.g_sd_template_storage.u_sd_store.sd_done &&
               u_fabric.g_sd_template_storage.u_sd_store.sd_error)
                $fatal(1,"SD command failed before payload: cmd=%0d response=%h store=%0d cardmode=%0d qread=%0d qwrite=%0d",
                    u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.cmd_now,
                    u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.spi_in,
                    u_fabric.g_sd_template_storage.u_sd_store.state_r,
                    g_sd_card_model.card.mode,g_sd_card_model.card.q_rd,g_sd_card_model.card.q_wr);
            if(!rst_n || !u_fabric.sd_store_busy) begin
                sd_stall_cycles=0; sd_last_progress=16'hffff;
            end else if(sd_last_progress != {u_fabric.g_sd_template_storage.u_sd_store.state_r,
                    u_fabric.g_sd_template_storage.u_sd_store.block_r,
                    u_fabric.g_sd_template_storage.u_sd_store.block_byte_r[5:0]}) begin
                sd_stall_cycles=0;
                sd_last_progress={u_fabric.g_sd_template_storage.u_sd_store.state_r,
                    u_fabric.g_sd_template_storage.u_sd_store.block_r,
                    u_fabric.g_sd_template_storage.u_sd_store.block_byte_r[5:0]};
            end else begin
                sd_stall_cycles=sd_stall_cycles+1;
                if(sd_stall_cycles==5000000)
                    $fatal(1,"SD_INTEGRATION_STALL store=%0d block=%0d byte=%0d sd=%0d wready=%b wvalid=%b pref=%0d data=%h cardmode=%0d cardbytes=%0d",
                        u_fabric.g_sd_template_storage.u_sd_store.state_r,
                        u_fabric.g_sd_template_storage.u_sd_store.block_r,
                        u_fabric.g_sd_template_storage.u_sd_store.block_byte_r,
                        u_fabric.g_sd_template_storage.u_sd_store.u_sd_card.state,
                        u_fabric.g_sd_template_storage.u_sd_store.sd_wready,
                        u_fabric.g_sd_template_storage.u_sd_store.sd_wvalid_r,
                        u_fabric.g_sd_template_storage.u_sd_store.prefetch_stage_r,
                        u_fabric.g_sd_template_storage.u_sd_store.sd_wdata_r,
                        g_sd_card_model.card.mode,g_sd_card_model.card.wr_cnt);
            end
        end
    end endgenerate
    always @(posedge clk) if(rst_n && I2S_SD_TEMPLATE_TEST && u_fabric.sd_template_load_we)
        sd_restored_bytes=sd_restored_bytes+1;
    integer weight_mism=0;
    integer short_ready_count=0,matcher_stream_valid_count=0;
    integer parallel_logits_count=0,parallel_template_results=0;
    integer fusion_result_count=0,fusion_modified_count=0;
    integer fusion_mode0_count=0,fusion_mode1_count=0,fusion_mode2_count=0;
    integer runtime_template_result_count=0;
    reg [1:0] runtime_template_class_last=0;
    reg [15:0] runtime_template_score_last=0;
    integer parallel_template_busy_count=0,parallel_template_total=0;
    integer parallel_core_ops_started_tx=0,parallel_core_ops_started_total=0;
    reg parallel_stream_seen=0,parallel_motor_prev=0;
    reg parallel_first_core_logged=0,parallel_stream_core_logged=0;
    reg [3:0] parallel_match_state_last=0;
    reg [6:0] parallel_match_frames_last=0,parallel_match_hop_last=0;
    reg [8:0] parallel_match_fifo_last=0;
    reg parallel_match_overflow_last=0;
    integer bank1_write_count=0,uart_stream_start_count=0;
    integer capture_uart_byte_count=0,capture_input_start=0;
    integer capture_expected_frames=0,capture_expected_bytes=0;
    integer capture_ring_mism=0,capture_start_slot=0;
    reg [23:0] capture_base_seen=0;
    integer ready_before,matcher_before,bin,frame,i2s_sample_index=0;
    reg saw_capture_tx_fifo_full=0;
    always @(posedge clk) if(rst_n && I2S_INPUT && capture_valid) begin
        if(capture_x0_count<131072)
            capture_x0_trace[capture_x0_count]=capture_x0;
        if(!UNIFORM_120_WINDOW && capture_x0_count<12800) begin
            expected_x0_index=(capture_x0_count/128)*1+
                              (capture_x0_count%128)*100;
            if(capture_x0 !== x0_mel[expected_x0_index]) begin
                if(capture_x0_mism<6)
                    $display("CAPTURE_X0_MISM n=%0d mel=%0d frame=%0d got=%02x exp=%02x",
                        capture_x0_count,capture_x0_count%128,
                        capture_x0_count/128,capture_x0,
                        x0_mel[expected_x0_index]);
                capture_x0_mism=capture_x0_mism+1;
            end
        end
        capture_x0_count=capture_x0_count+1;
        if(u_fabric.pass_matcher_x0 && u_fabric.pass_ring_x0) begin
            if(!UNIFORM_120_WINDOW && accepted_x0_count<12800) begin
                expected_x0_index=(accepted_x0_count/128)*1+
                                  (accepted_x0_count%128)*100;
                if(capture_x0 !== x0_mel[expected_x0_index])
                    accepted_x0_mism=accepted_x0_mism+1;
            end
            accepted_x0_count=accepted_x0_count+1;
        end
    end
    always @(posedge clk) if(rst_n && boot_done &&
        u_fabric.u_core.wc_src_byte_valid && u_fabric.u_core.wc_byte_ready) begin
        if(u_fabric.u_core.wc_src_byte !==
           flash_mem[u_fabric.u_core.ddr_w.addr_r +
                     u_fabric.u_core.ddr_w.bytes_out_r]) begin
            if(weight_mism<8) $display("WEIGHT_BYTE_MISM off=%h got=%h exp=%h op=%0d",
                u_fabric.u_core.ddr_w.addr_r + u_fabric.u_core.ddr_w.bytes_out_r,
                u_fabric.u_core.wc_src_byte,
                flash_mem[u_fabric.u_core.ddr_w.addr_r +
                          u_fabric.u_core.ddr_w.bytes_out_r],
                u_fabric.u_core.op_act_r);
            weight_mism=weight_mism+1;
        end
    end
    always @(posedge clk) if(rst_n && capture_recording)
        capture_base_seen<=capture_ring_base;
    always @(posedge clk) if(rst_n) begin
        if(short_ready) short_ready_count=short_ready_count+1;
        if(CAPTURE_PARALLEL && u_fabric.capture_stream_phase &&
           !parallel_stream_seen) begin
            parallel_stream_seen=1;
            $display("PARALLEL_STREAM_START t=%0t busy=%b recog=%b",
                $time,capture_busy,recognition_enable);
        end
        if(CAPTURE_PARALLEL && short_ready)
            $display("PARALLEL_SHORT_READY t=%0t stream=%b busy=%b recog=%b alert_latched=%b",
                $time,u_fabric.capture_stream_phase,capture_busy,
                recognition_enable,motor);
        if(CAPTURE_PARALLEL && core_start) begin
            parallel_core_ops_started_total=parallel_core_ops_started_total+1;
            if(capture_busy && u_fabric.capture_stream_phase) begin
                parallel_core_ops_started_tx=parallel_core_ops_started_tx+1;
                if(!parallel_stream_core_logged) begin
                    parallel_stream_core_logged=1;
                    $display("PARALLEL_CORE_START_TX t=%0t recog=%b alert_latched=%b",
                        $time,recognition_enable,
                        motor);
                end
            end else if(!parallel_first_core_logged) begin
                parallel_first_core_logged=1;
                $display("PARALLEL_CORE_START_PRE_TX t=%0t recog=%b alert_latched=%b",
                    $time,recognition_enable,
                    motor);
            end
        end
        if(CAPTURE_PARALLEL && motor && !parallel_motor_prev)
            $display("PARALLEL_ALERT t=%0t class=%0d stream=%b busy=%b recog=%b",
                $time,display_class_mon,u_fabric.capture_stream_phase,
                capture_busy,recognition_enable);
        parallel_motor_prev=motor;
        if(CAPTURE_PARALLEL && capture_busy &&
           u_fabric.capture_stream_phase && logits_valid)
            parallel_logits_count=parallel_logits_count+1;
        if(CAPTURE_PARALLEL && capture_busy &&
           u_fabric.capture_stream_phase && template_result_valid)
            parallel_template_results=parallel_template_results+1;
        if(CAPTURE_PARALLEL && template_result_valid)
            parallel_template_total=parallel_template_total+1;
        if(CAPTURE_PARALLEL && u_fabric.capture_stream_phase &&
           (I2S_INPUT ? capture_valid : x0_valid) && u_fabric.pass_matcher_x0)
            matcher_stream_valid_count=matcher_stream_valid_count+1;
        if(CAPTURE_PARALLEL && u_fabric.capture_stream_phase &&
           u_fabric.ring_awvalid && u_fabric.ring_awready)
            bank1_write_count=bank1_write_count+1;
        if(CAPTURE_PARALLEL && capture_busy &&
           u_fabric.u_train_capture.tx_fifo_count==256)
            saw_capture_tx_fifo_full=1;
        if(CAPTURE_PARALLEL && capture_busy && u_fabric.u_train_capture.tx_push)
            capture_uart_byte_count=capture_uart_byte_count+1;
        if(CAPTURE_PARALLEL && u_fabric.capture_stream_phase &&
           u_fabric.u_train_capture.tx_fifo_count>256)
            $fatal(1,"capture TX FIFO overflow");
    end
    always @(negedge capture_uart_tx) if(rst_n && capture_busy)
        uart_stream_start_count=uart_stream_start_count+1;
    always @(posedge clk) if(rst_n && template_result_valid) begin
        runtime_template_result_count=runtime_template_result_count+1;
        runtime_template_class_last=template_result_class;
        runtime_template_score_last=u_fabric.template_result_score_q15_o;
    end
    generate if(CAPTURE_PARALLEL) begin : gen_parallel_matcher_monitor
        always @(posedge clk) if(rst_n && capture_busy &&
            u_fabric.capture_stream_phase) begin
            parallel_match_state_last=
                u_fabric.g_templates.u_template_matcher.state_r;
            parallel_match_frames_last=
                u_fabric.g_templates.u_template_matcher.frames_seen_r;
            parallel_match_hop_last=
                u_fabric.g_templates.u_template_matcher.hop_frames_r;
            parallel_match_fifo_last=
                u_fabric.g_templates.u_template_matcher.input_fifo_count_r;
            parallel_match_overflow_last=
                u_fabric.g_templates.u_template_matcher.input_fifo_overflow_r;
            if(u_fabric.g_templates.u_template_matcher.busy_o)
                parallel_template_busy_count=parallel_template_busy_count+1;
        end
    end endgenerate

    initial if(!I2S_INPUT && !LONG_WINDOW && !CAPTURE_PARALLEL) begin
        wait(short_ready);
        ring_mism=0;
        snapshot_mism=0;
        for(ff=0;ff<100;ff=ff+1)
            for(mm=0;mm<128;mm=mm+1) begin
                if(ddr.mem[24'h500000+mm*1000+ff] !== x0_mel[mm*N_FRAMES+ff])
                    ring_mism=ring_mism+1;
                if(ddr.mem[24'h200000+mm*100+ff] !== x0_mel[mm*N_FRAMES+ff])
                    snapshot_mism=snapshot_mism+1;
            end
        $display("X0_COMPARE ring=%0d snapshot=%0d",ring_mism,snapshot_mism);
    end
    initial begin
        $readmemh(IMAGE_HEX,flash_mem);
        $readmemh(X0_HEX,x0_mel);
        if(SIX_CLASS_MODE && !UNIFORM_120_WINDOW) $readmemh(F0_HEX,f0_expected);
        if(I2S_INPUT) $readmemh(PCM_FILE,i2s_stim);
    end
    generate if(I2S_INPUT) begin : gen_i2s
        mn04_audio_capture_frontend u_capture (
            .clk(clk),.rst_n(rst_n && boot_done && audio_task_active),
            .es8311_bclk_i(i2s_bclk),.es8311_lrck_i(i2s_lrck),
            .es8311_dout_i(i2s_dout),.x0_o(capture_x0),
            .x0_valid_o(capture_valid),.pcm_overflow_o(pcm_overflow),
            .pcm_debug_o(capture_pcm_debug),.pcm_debug_valid_o(capture_pcm_debug_valid));
    end else begin : gen_no_i2s
        assign capture_x0=0;
        assign capture_valid=0;
        assign pcm_overflow=0;
        assign capture_pcm_debug=0;assign capture_pcm_debug_valid=0;
    end endgenerate
    mn04_board_capture_keys #(.CLOCK_HZ(10000)) u_capture_keys (
        .clk(clk),.rst_n(rst_n),.category_key_n_i(CPU_TASK_CONTROL?cpu_commands[2]:category_key_n),
        .start_key_n_i(CPU_TASK_CONTROL?cpu_commands[3]:start_capture_key_n),.stop_key_n_i(CPU_TASK_CONTROL?cpu_commands[4]:stop_capture_key_n),
        .mode_key_n_i(CPU_TASK_CONTROL?cpu_commands[5]:mode_key_n),.recognition_enable_i(recognition_enable),
        .capture_busy_i(capture_busy),.capture_recording_i(capture_recording),
        .category_advance_o(category_advance),.template_mode_o(template_mode),
        .preview_enable_o(),.capture_start_o(capture_start),
        .capture_stop_o(capture_stop));
    mn04_runtime_fabric #(.OP_FILE(OP_FILE),.FAST_BYTES(1),
        .LUTS_BASE(CURRENT_FIVE_CLASS ? 24'd799858 : SIX_CLASS_MODE ? 24'd800123 :
                   (EIGHT_CLASS_MODE ? 24'd800653 : 24'd799858)),
        .FLASH_IMAGE_BASE(24'h0),.IMAGE_BYTES(MODEL_IMAGE_BYTES),
        .IMAGE_CHECKSUM_EXPECTED(MODEL_CHECKSUM),
        .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
        .UNIFORM_120_WINDOW(UNIFORM_120_WINDOW),
        .N_CLASSES(N_CLASSES),
        .CNN_CLASS_COUNT(N_CLASSES),
        .SHORT_HOP_FRAMES(UNIFORM_120_WINDOW ? 60 : ((EIGHT_CLASS_MODE || SIX_CLASS_MODE) ? 50 : 75)),
        .ENABLE_LONG_WINDOW((EIGHT_CLASS_MODE || SIX_CLASS_MODE) ? 0 : 1),
        .CACHE_LINE_BITS(9),
        .CAPTURE_CLOCK_HZ(CAPTURE_PARALLEL ? 1152000 : 100000000),
        .CAPTURE_BAUD(115200),
        .CAPTURE_TX_FIFO_DEPTH(256),
        .ENABLE_TEMPLATE_CAPTURE(EIGHT_CLASS_MODE || SIX_CLASS_MODE),
        .ENABLE_LOCAL_TEMPLATE_ENROLLMENT(LOCAL_TEMPLATE_ENROLLMENT || SD_ENABLED),
        .ENABLE_SD_TEMPLATE_STORAGE(SD_ENABLED),
        .TEMPLATE_MAPS_PER_CLASS(TEMPLATE_MAPS_PER_CLASS),.TEMPLATE_DDR_STORAGE(TEMPLATE_DDR_STORAGE),
        .CPU_TEMPLATE_SLOT_SELECT(CPU_TASK_CONTROL),
        .TEMPLATE_FILE(SD_ENABLED ? "" : ((CAPTURE_PARALLEL || (TEMPLATE_MATCH_ENABLED &&
                        !LOCAL_TEMPLATE_ENROLLMENT)) ? TEMPLATE_ROM_FILE : "")),
        .TEMPLATE_DOORBELL_MAPS((LOCAL_TEMPLATE_ENROLLMENT || SD_ENABLED) ? TEMPLATE_MAPS_PER_CLASS :
                                (CAPTURE_PARALLEL ? 1 : (TEMPLATE_MATCH_ENABLED ? 2 : 0))),
        .TEMPLATE_SMOKE_ALARM_MAPS((LOCAL_TEMPLATE_ENROLLMENT || SD_ENABLED) ? TEMPLATE_MAPS_PER_CLASS : 0),
        .TEMPLATE_GAS_CO_ALARM_MAPS((LOCAL_TEMPLATE_ENROLLMENT || SD_ENABLED) ? TEMPLATE_MAPS_PER_CLASS : 0)) u_fabric (
        .clk(clk),.rst_n(rst_n),.boot_start_i(boot_start),
        .x0_i(I2S_INPUT ? capture_x0 : x0_data),
        .x0_valid_i(I2S_INPUT ? capture_valid : x0_valid),
        .pcm_overflow_i(pcm_overflow),
        .capture_pcm_debug_i(capture_pcm_debug),.capture_pcm_debug_valid_i(capture_pcm_debug_valid),
        .recognition_enable_i(recognition_enable),
        .short_snapshot_accept_i(CAPTURE_PARALLEL ? 1'b1 :
                                 (LONG_WINDOW ? 1'b0 : short_accept)),
        .long_snapshot_accept_i(LONG_WINDOW ? long_accept : 1'b0),
        .short_snapshot_ready_o(short_ready),
        .long_snapshot_ready_o(long_ready),
        .short_snapshot_mode_o(short_snapshot_mode),
        .x0_overflow_o(x0_overflow),.boot_init_done_o(boot_done),
        .window_quiet_o(window_quiet),
        .core_start_i(core_start),.core_start_op_i(start_op),
        .core_end_op_i(end_op),.core_short_window_i(core_short),
        .core_context_short_i(context_short),
        .core_class_window_mode_i(core_class_window_mode),
        .core_busy_o(core_busy),.core_done_o(core_done),
        .core_logits_valid_o(logits_valid),.core_logits_o(fabric_logits),
        .template_result_valid_o(template_result_valid),
        .template_result_class_o(template_result_class),
        .template_result_score_q15_o(template_score),
        .cpu_template_slot_i(cpu_slot),.cpu_template_slot_mask_o(cpu_slots),.cpu_template_commit_o(cpu_commit),
        .display_asset_we_o(display_asset_we),
        .display_asset_addr_o(display_asset_addr),
        .display_asset_data_o(display_asset_data),
        .boot_flash_rd_addr_o(boot_flash_addr),
        .core_flash_rd_addr_o(core_flash_addr),
        .boot_flash_rd_data_i(flash_mem[boot_flash_addr]),
        .core_flash_rd_data_i(flash_mem[core_flash_addr]),
        .qspi_cs_o(qspi_cs),.qspi_sck_o(qspi_sck),
        .qspi_mosi_o(qspi_mosi),.qspi_miso_i(1'b1),
        .uart_rx_i(uart_rx),
        .sd_card_detect_n_i(!SD_ENABLED),.sd_miso_i(template_sd_miso),
        .sd_clk_o(template_sd_clk),.sd_cs_n_o(template_sd_cs_n),.sd_mosi_o(template_sd_mosi),
        .template_capture_category_advance_i(category_advance),
        .template_capture_start_i(capture_start),
        .template_capture_stop_i(capture_stop),
        .template_capture_mode_i(template_mode),
        .uart_tx_o(capture_uart_tx),.capture_task_busy_o(capture_busy),
        .capture_recording_o(capture_recording),
        .capture_selected_category_o(capture_selected_category),
        .capture_ring_base_o(capture_ring_base),
        .ddr_awaddr_o(awaddr),.ddr_araddr_o(araddr),
        .ddr_awlen_o(awlen),.ddr_arlen_o(arlen),
        .ddr_awvalid_o(awvalid),.ddr_arvalid_o(arvalid),
        .ddr_awready_i(awready),.ddr_arready_i(arready),
        .ddr_wdata_o(wdata),.ddr_wstrb_o(wstrb),
        .ddr_wvalid_o(wvalid),.ddr_wlast_o(wlast),
        .ddr_wready_i(wready),
        .ddr_bresp_i(bresp),.ddr_bvalid_i(bvalid),.ddr_bready_o(bready),
        .ddr_rdata_i(rdata),.ddr_rresp_i(rresp),
        .ddr_rlast_i(rlast),.ddr_rvalid_i(rvalid),.ddr_rready_o(rready));
    localparam integer TEMPLATE_TEST_BYTES = 6*128*100;
    wire [7:0] local_template_mem_probe [0:TEMPLATE_TEST_BYTES-1];
    genvar template_probe_idx;
    generate if(LOCAL_TEMPLATE_ENROLLMENT) begin : gen_local_template_probe
        for(template_probe_idx=0;template_probe_idx<TEMPLATE_TEST_BYTES;
            template_probe_idx=template_probe_idx+1) begin : gen_byte
            assign local_template_mem_probe[template_probe_idx] =
                u_fabric.g_templates.u_template_matcher.template_mem[template_probe_idx];
        end
    end else begin : gen_no_local_template_probe
        for(template_probe_idx=0;template_probe_idx<TEMPLATE_TEST_BYTES;
            template_probe_idx=template_probe_idx+1) begin : gen_byte
            assign local_template_mem_probe[template_probe_idx] = 8'd0;
        end
    end endgenerate
    mn04_axi4_ddr_bridge u_bridge (
        .clk(clk),.rst_n(rst_n),
        .s_awaddr(awaddr),.s_awlen(awlen),
        .s_awvalid(awvalid),.s_awready(awready),
        .s_wdata(wdata),.s_wstrb(wstrb),
        .s_wvalid(wvalid),.s_wlast(wlast),.s_wready(wready),
        .s_bresp(bresp),.s_bvalid(bvalid),.s_bready(bready),
        .s_araddr(araddr),.s_arlen(arlen),
        .s_arvalid(arvalid),.s_arready(arready),
        .s_rdata(rdata),.s_rresp(rresp),
        .s_rlast(rlast),.s_rvalid(rvalid),.s_rready(rready),
        .d_awaddr(d_awaddr),.d_awlen(d_awlen),
        .d_awvalid(d_awvalid),.d_awready(d_awready),
        .d_wdata(d_wdata),.d_wstrb(d_wstrb),.d_wready(d_wready),
        .d_araddr(d_araddr),.d_arlen(d_arlen),
        .d_arvalid(d_arvalid),.d_arready(d_arready),
        .d_rdata(d_rdata),.d_rlast(d_rlast),.d_rvalid(d_rvalid));
    mn04_ddr_behav #(.MEM_BYTES(TEMPLATE_DDR_STORAGE ? 16777216 : 6291456),.RD_LATENCY(4)) ddr (
        .clk(clk),.rst_n(rst_n),.awaddr_i(d_awaddr),.awlen_i(d_awlen),
        .awvalid_i(d_awvalid),.awready_o(d_awready),
        .wdata_i(d_wdata),.wstrb_i(d_wstrb),.wready_o(d_wready),
        .araddr_i(d_araddr),.arlen_i(d_arlen),.arvalid_i(d_arvalid),
        .arready_o(d_arready),.rdata_o(d_rdata),.rlast_o(d_rlast),.rvalid_o(d_rvalid));
    generate if(SIX_CLASS_MODE) begin : gen_six_class_control
    mn04_six_class_realtime_control #(
        .SOFTMAX_LUT_FILE(SOFTMAX_LUT_FILE),
        .CLASS_WINDOW_MODE(CLASS_WINDOW_MODE),
        .UNIFORM_120_WINDOW_MODE(UNIFORM_120_WINDOW),
        .CURRENT_FIVE_CLASS_MODE(CURRENT_FIVE_CLASS),.CPU_TASK_CONTROL(CPU_TASK_CONTROL),
        .CNN_TEMPLATE_FILE(CNN_TEMPLATE_FILE),
        .CNN_TEMPLATE_VALID_MASK(CNN_TEMPLATE_VALID_MASK),
        .CNN_TEMPLATE_WEIGHT_Q2(CNN_TEMPLATE_WEIGHT_Q2),
        // SIM_OPEN_THRESHOLDS is used only to prove the selected class can
        // traverse the production display/vibration path. The second run
        // keeps the exported, validation-calibrated thresholds unchanged.
        .BABY_THRESHOLD_Q16(SIM_OPEN_THRESHOLDS ? 16'd0 : FUSED_BABY_THRESHOLD_Q16),
        .KNOCK_THRESHOLD_Q16(SIM_OPEN_THRESHOLDS ? 16'd0 : FUSED_KNOCK_THRESHOLD_Q16),
        .EMERGENCY_VEHICLE_THRESHOLD_Q16(SIM_OPEN_THRESHOLDS ? 16'd0 : FUSED_SIREN_THRESHOLD_Q16),
        .DOG_BARK_THRESHOLD_Q16(SIM_OPEN_THRESHOLDS ? 16'd0 : FUSED_DOG_THRESHOLD_Q16),
        .CAR_HORN_THRESHOLD_Q16(SIM_OPEN_THRESHOLDS ? 16'd0 : FUSED_CAR_THRESHOLD_Q16),
        .CLOCK_HZ(CPU_TASK_CONTROL ? 10000 : 1152000),.SPI_HZ(CPU_TASK_CONTROL ? 1000 : 115200),
        .RESET_CYCLES(1),.PWR_DELAY_CYCLES(1),
        .DISPLAY_DELAY_CYCLES(1)) u_control (
        .clk(clk),.rst_n(rst_n),.short_snapshot_ready_i(short_ready),
        .short_snapshot_mode_i(short_snapshot_mode),.core_busy_i(core_busy),.core_done_i(core_done),
        .core_logits_valid_i(logits_valid),.core_logits_i(logits[47:0]),
        .window_quiet_i(window_quiet),
        .template_result_valid_i(template_result_valid),
        .template_result_class_i(template_result_class),
        .display_asset_we_i(display_asset_we),
        .display_asset_addr_i(display_asset_addr),
        .display_asset_data_i(display_asset_data),
        .template_preview_i(1'b0),.template_preview_class_i(4'd0),
        .work_key_n_i(CPU_TASK_CONTROL?cpu_commands[0]:1'b1),.confirm_key_n_i(CPU_TASK_CONTROL?cpu_commands[1]:1'b1),
        .uart_rx_i(CPU_TASK_CONTROL?1'b1:uart_rx),
        .cpu_job_authorized_i(cpu_grant),.cpu_event_valid_i(cpu_event_valid),.cpu_event_class_i(cpu_event_class),
        .cpu_probs_valid_o(cpu_probs_valid),.cpu_job_done_o(cpu_job_done),.cpu_probs_o(cpu_probs),
        .external_task_busy_i(capture_busy),.set_time_i(1'b0),
        .set_hour_i(8'd0),.set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(core_start),.core_start_op_o(start_op),
        .core_end_op_o(end_op),.core_short_window_o(core_short),
        .core_context_short_o(context_short),
        .core_class_window_mode_o(core_class_window_mode),
        .short_snapshot_accept_o(short_accept),
        .short_result_valid_o(),.motor_o(motor),
        .recognition_enable_o(recognition_enable),.work_mode_o(),
        .panel_ready_o(panel_ready),.panel_busy_o(panel_busy),
        .tft_nrst_o(tft_nrst),.tft_backlight_o(tft_backlight),
        .tft_sclk_o(tft_sclk),.tft_mosi_o(tft_mosi),
        .tft_dc_o(tft_dc),.tft_cs_n_o(tft_cs_n));
    assign display_class_mon =
        gen_six_class_control.u_control.backend.path.alerts.display_class_o;
    end else if(EIGHT_CLASS_MODE) begin : gen_eight_class_control
    mn04_eight_class_realtime_control #(
        .SOFTMAX_LUT_FILE(SOFTMAX_LUT_FILE),
        // Open thresholds only in the deterministic end-to-end fixture so
        // this PCM test verifies the true model -> class -> motor/TFT route
        // independently of acoustic calibration. Production thresholds are
        // covered by the selector and board-control regressions.
        .BABY_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd8160),
        .KNOCK_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd8694),
        .SIREN_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd7859),
        .FIRE_TRUCK_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd8045),
        .AMBULANCE_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd7879),
        .DOG_BARK_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd8339),
        .CAR_HORN_THRESHOLD_Q16(FULL_CAPTURE_PARALLEL ? 16'd0 : 16'd8600),
        .CLOCK_HZ(CPU_TASK_CONTROL ? 10000 : 1152000),.SPI_HZ(CPU_TASK_CONTROL ? 1000 : 115200),
        .RESET_CYCLES(1),.PWR_DELAY_CYCLES(1),
        .DISPLAY_DELAY_CYCLES(1)) u_control (
        .clk(clk),.rst_n(rst_n),
        .short_snapshot_ready_i(short_ready),
        .core_busy_i(core_busy),.core_done_i(core_done),
        .core_logits_valid_i(logits_valid),.core_logits_i(logits),
        .template_result_valid_i(template_result_valid),
        .template_result_class_i(template_result_class),
        .display_asset_we_i(display_asset_we),
        .display_asset_addr_i(display_asset_addr),
        .display_asset_data_i(display_asset_data),
        .template_preview_i(1'b0),.template_preview_class_i(4'd0),
        .work_key_n_i(1'b1),.confirm_key_n_i(1'b1),
        .uart_rx_i(uart_rx),.external_task_busy_i(capture_busy),
        .set_time_i(1'b0),.set_hour_i(8'd0),
        .set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(core_start),.core_start_op_o(start_op),
        .core_end_op_o(end_op),.core_short_window_o(core_short),
        .core_context_short_o(context_short),
        .core_class_window_mode_o(core_class_window_mode),
        .short_snapshot_accept_o(short_accept),.short_result_valid_o(),
        .motor_o(motor),.recognition_enable_o(recognition_enable),
        .work_mode_o(),.panel_ready_o(panel_ready),.panel_busy_o(panel_busy),
        .tft_nrst_o(tft_nrst),.tft_backlight_o(tft_backlight),
        .tft_sclk_o(tft_sclk),.tft_mosi_o(tft_mosi),.tft_dc_o(tft_dc),
        .tft_cs_n_o(tft_cs_n));
    assign display_class_mon =
        gen_eight_class_control.u_control.backend.path.alerts.display_class_o;
    end else begin : gen_five_class_control
    assign core_class_window_mode=2'd0;
    mn04_five_class_realtime_control #(
        .SOFTMAX_LUT_FILE(SOFTMAX_LUT_FILE),
        .CLOCK_HZ(CPU_TASK_CONTROL ? 10000 : 1152000),.SPI_HZ(CPU_TASK_CONTROL ? 1000 : 115200),
        .RESET_CYCLES(1),.PWR_DELAY_CYCLES(1),
        .DISPLAY_DELAY_CYCLES(1)) u_control (
        .clk(clk),.rst_n(rst_n),
        .short_snapshot_ready_i(short_ready),
        .long_snapshot_ready_i(long_ready),
        .core_busy_i(core_busy),.core_done_i(core_done),
        .core_logits_valid_i(logits_valid),.core_logits_i(logits[39:0]),
        .template_result_valid_i(template_result_valid),
        .template_result_class_i(template_result_class),
        .display_asset_we_i(display_asset_we),
        .display_asset_addr_i(display_asset_addr),
        .display_asset_data_i(display_asset_data),
        .template_preview_i(1'b0),.template_preview_class_i(4'd0),
        .work_key_n_i(1'b1),.confirm_key_n_i(1'b1),
        .uart_rx_i(uart_rx),.external_task_busy_i(capture_busy),.set_time_i(1'b0),
        .set_hour_i(8'd0),.set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(core_start),.core_start_op_o(start_op),
        .core_end_op_o(end_op),.core_short_window_o(core_short),
        .core_context_short_o(context_short),
        .short_snapshot_accept_o(short_accept),
        .long_snapshot_accept_o(long_accept),
        .short_result_valid_o(),.long_result_valid_o(),
        .motor_o(motor),.recognition_enable_o(recognition_enable),
        .work_mode_o(),.panel_ready_o(panel_ready),
        .panel_busy_o(panel_busy),.tft_nrst_o(tft_nrst),
        .tft_backlight_o(tft_backlight),.tft_sclk_o(tft_sclk),
        .tft_mosi_o(tft_mosi),.tft_dc_o(tft_dc),.tft_cs_n_o(tft_cs_n));
    assign display_class_mon =
        gen_five_class_control.u_control.backend.path.alerts.display_class_o;
    end endgenerate

    generate if(SIX_CLASS_MODE && CNN_TEMPLATE_VALID_MASK != 24'h000000) begin : gen_fuser_checks
        always @(posedge clk) begin
            if(rst_n && gen_six_class_control.u_control.probs_valid) begin
                fusion_result_count = fusion_result_count + 1;
                if(gen_six_class_control.u_control.fused_probs !==
                   gen_six_class_control.u_control.probs)
                    fusion_modified_count = fusion_modified_count + 1;
                case(gen_six_class_control.u_control.result_mode_r)
                    2'd0: fusion_mode0_count = fusion_mode0_count + 1;
                    2'd1: fusion_mode1_count = fusion_mode1_count + 1;
                    2'd2: fusion_mode2_count = fusion_mode2_count + 1;
                    default: begin end
                endcase
            end
        end
    end endgenerate
    task uart_byte(input [7:0] data);
        integer b;
        begin
            if(CPU_TASK_CONTROL && (data=="R" || data=="C")) begin
                if(data=="R") work_key_n=0;else confirm_key_n=0;
                repeat(4000) @(negedge clk);
                work_key_n=1;confirm_key_n=1;repeat(4000) @(negedge clk);
            end else begin
            uart_rx=0;repeat(10) @(negedge clk);
            for(b=0;b<8;b=b+1) begin
                uart_rx=data[b];repeat(10) @(negedge clk);
            end
            uart_rx=1;repeat(30) @(negedge clk);
            end
        end
    endtask
    task press_k4;
        begin
            @(negedge clk);category_key_n=0;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
            category_key_n=1;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
            wait(!capture_busy);
        end
    endtask
    task press_k5;
        begin
            @(negedge clk);start_capture_key_n=0;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
            start_capture_key_n=1;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
        end
    endtask
    task press_k6;
        begin
            @(negedge clk);stop_capture_key_n=0;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
            stop_capture_key_n=1;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
        end
    endtask
    task press_key7;
        begin
            @(negedge clk);mode_key_n=0;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
            mode_key_n=1;
            repeat(CPU_TASK_CONTROL ? 4000 : 240) @(negedge clk);
        end
    endtask
    task feed_capture_frame(input integer frame_index);
        integer bin;
        begin
            for(bin=0;bin<128;bin=bin+1) begin
                @(negedge clk);
                x0_data=x0_mel[bin*N_FRAMES+(frame_index%N_FRAMES)];
                x0_valid=1;
            end
            @(negedge clk);x0_valid=0;
            wait(u_fabric.ring_frame_done);
            // 11520 clocks at the accelerated 1.152 MHz test clock model one
            // 10 ms feature frame and retain the production UART/data ratio.
            repeat(11000) @(negedge clk);
        end
    endtask
    task feed_capture_frame_fast(input integer frame_index);
        integer bin;
        begin
            for(bin=0;bin<128;bin=bin+1) begin
                @(negedge clk);
                x0_data=x0_mel[bin*N_FRAMES+(frame_index%N_FRAMES)];
                x0_valid=1;
            end
            @(negedge clk);x0_valid=0;
            wait(u_fabric.ring_frame_done);
        end
    endtask
    task feed_capture_frame_slow(input integer frame_index);
        begin
            feed_capture_frame(frame_index);
            // Match the physical 100 MHz DDR clock cadence: one 10 ms Mel
            // frame is 1,000,000 user-clock cycles. This avoids overloading
            // the template matcher's 256-byte input FIFO with test speedup.
            repeat(1000000) @(negedge clk);
        end
    endtask
    task feed_capture_frame_match(input integer frame_index);
        integer bin;
        begin
            for(bin=0;bin<128;bin=bin+1) begin
                @(negedge clk);
                x0_data=x0_mel[bin*N_FRAMES+(frame_index%N_FRAMES)];
                x0_valid=1;
            end
            @(negedge clk);x0_valid=0;
            wait(u_fabric.ring_frame_done);
            // A half-millisecond frame interval gives the one-map cosine
            // matcher time to finish without artificially overflowing its
            // bounded 256-byte input FIFO in accelerated simulation.
            repeat(50000) @(negedge clk);
        end
    endtask
    task record_local_template_take;
        begin
            press_k5();
            wait(capture_recording);
            for(frame=0;frame<100;frame=frame+1)
                feed_capture_frame_fast(frame);
            press_k6();
            feed_capture_frame_fast(100);
            wait(!capture_busy);
            repeat(3) @(negedge clk);
        end
    endtask
    task send_i2s_bit(input channel,input value);
        begin
            @(negedge clk);
            i2s_bclk=0;i2s_lrck=channel;i2s_dout=value;
            repeat(I2S_HALF_CYCLES) @(negedge clk);
            i2s_bclk=1;
            repeat(I2S_HALF_CYCLES) @(negedge clk);
            i2s_bclk=0;
        end
    endtask
    task send_i2s_sample;
        input integer sample_index;
        integer bit_index;
        begin
            send_i2s_bit(0,0);
            for(bit_index=15;bit_index>=0;bit_index=bit_index-1)
                send_i2s_bit(0,(i2s_stim[sample_index%PCM_SAMPLES]>>bit_index)&1);
            for(bit_index=0;bit_index<15;bit_index=bit_index+1)
                send_i2s_bit(0,0);
            send_i2s_bit(1,0);
            for(bit_index=0;bit_index<31;bit_index=bit_index+1)
                send_i2s_bit(1,0);
            // I2S bit timing is accelerated in this testbench. Sample order
            // and values still come from the 48 kHz input fixture; this avoids
            // simulating billions of idle clock edges.
        end
    endtask
    always @(posedge clk) if(rst_n) begin
        if(short_ready) begin
            short_snap_done<=1;
            if(short_ready_time==0) short_ready_time=$time;
        end
        if(long_ready) begin
            long_snap_done<=1;
            if(long_ready_time==0) long_ready_time=$time;
        end
        if(motor && panel_ready && !tft_cs_n) saw_tft<=1;
        if(logits_valid) begin
            logits_seen=logits_seen+1;
            $display("CORE_LOGITS_TAP n_classes=%0d packed=%h internal=%h final_op=%0d op_act=%0d state=%0d",
                N_CLASSES,fabric_logits,u_fabric.u_core.logits_o,
                u_fabric.u_core.op_act_r,u_fabric.u_core.op_act_r,
                u_fabric.u_core.st_r);
            $display("SNAPSHOT_TO_LOGITS_NS=%0d",
                $time-(LONG_WINDOW ? long_ready_time : short_ready_time));
            if(SIX_CLASS_MODE) begin
                $display("FABRIC_LOGITS6 [%0d,%0d,%0d,%0d,%0d,%0d]",
                    $signed(logits[7:0]),$signed(logits[15:8]),
                    $signed(logits[23:16]),$signed(logits[31:24]),
                    $signed(logits[39:32]),$signed(logits[47:40]));
                if(I2S_INPUT && !UNIFORM_120_WINDOW && logits[47:0] !==
                        {8'hdb,8'h17,8'h2e,8'he8,8'hf4,8'h02})
                    $fatal(1,"six-class DDR logits differ from the bit-exact audio reference: %h",
                        logits[47:0]);
            end else if(EIGHT_CLASS_MODE)
                $display("FABRIC_LOGITS8 [%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d]",
                    $signed(logits[7:0]),$signed(logits[15:8]),
                    $signed(logits[23:16]),$signed(logits[31:24]),
                    $signed(logits[39:32]),$signed(logits[47:40]),
                    $signed(logits[55:48]),$signed(logits[63:56]));
            else
                $display("FABRIC_LOGITS5 [%0d,%0d,%0d,%0d,%0d]",
                    $signed(logits[7:0]),$signed(logits[15:8]),
                    $signed(logits[23:16]),$signed(logits[31:24]),
                    $signed(logits[39:32]));
            if(!SIX_CLASS_MODE && !EIGHT_CLASS_MODE && (!CAPTURE_PARALLEL || logits_seen==1) && logits !== (LONG_WINDOW ?
                {8'hEA,8'hDD,8'hE4,8'h48,8'hFF} :
                {8'hE8,8'hD4,8'h1F,8'hF5,8'h13}))
                $fatal(1,"fabric logits mismatch");
            if (^logits === 1'bx)
                $fatal(1,"fabric logits contain unknown bits");
        end
    end
    always @(posedge clk) if(rst_n && u_fabric.u_core.wr_en_r &&
        u_fabric.u_core.op_act_r==90 &&
        u_fabric.u_core.wr_addr_r>=24'h180900 &&
        u_fabric.u_core.wr_addr_r<24'h180906)
        $display("SIX_FINAL_HEAD_WRITE addr=%h data=%h",u_fabric.u_core.wr_addr_r,
            u_fabric.u_core.wr_data_r);
    always @(posedge clk) if(rst_n && u_fabric.u_core.wr_en_r) begin
        if(!first_unknown_write_reported &&
           (^u_fabric.u_core.wr_data_r === 1'bx)) begin
            first_unknown_write_reported=1;
            unknown_core_write_count=unknown_core_write_count+1;
            $display("FIRST_UNKNOWN_CORE_WRITE op=%0d addr=%h data=%h state=%0d short=%b active_short=%b in_base=%h vaddr=%h pad=%b rd=%h ddr_x0=%h",
                u_fabric.u_core.op_act_r,u_fabric.u_core.wr_addr_r,
                u_fabric.u_core.wr_data_r,u_fabric.u_core.st_r,core_short,
                u_fabric.active_short_r,u_fabric.u_core.op_in_base,
                u_fabric.u_core.vaddr_r,u_fabric.u_core.pad_r,
                u_fabric.rd_data,ddr.mem[24'h200000]);
        end else if (^u_fabric.u_core.wr_data_r === 1'bx)
            unknown_core_write_count=unknown_core_write_count+1;
        if(!head0_write_reported && u_fabric.u_core.op_act_r==89 &&
           u_fabric.u_core.wr_addr_r>=24'h180800) begin
            head0_write_reported=1;
            $display("HEAD0_FIRST_WRITE addr=%h data=%h",
                u_fabric.u_core.wr_addr_r,u_fabric.u_core.wr_data_r);
        end
    end
    // Op 1 starts after op 0 has produced F0 and before later in-place
    // residual/gating operations reuse that activation arena.
    always @(posedge clk) if(rst_n && SIX_CLASS_MODE && I2S_INPUT &&
        !f0_x0_early_checked && u_fabric.u_core.op_act_r==0 &&
        u_fabric.u_core.st_r==1) begin
        f0_x0_early_checked=1;
        f0_input_mism=0;
        for(f0x0_i=0;f0x0_i<128*N_FRAMES;f0x0_i=f0x0_i+1) begin
            runtime_x0_at_op0[f0x0_i]=ddr.mem[24'h200000+f0x0_i];
            if(!UNIFORM_120_WINDOW && ddr.mem[24'h200000+f0x0_i] !== x0_mel[f0x0_i])
                f0_input_mism=f0_input_mism+1;
        end
        $writememh("runtime_x0_at_op0.hex",runtime_x0_at_op0);
        $display("SIX_OP0_INPUT_COMPARE mismatches=%0d",f0_input_mism);
    end
    always @(posedge clk) if(rst_n && SIX_CLASS_MODE && I2S_INPUT &&
        u_fabric.u_core.op_act_r==0) begin
        if(u_fabric.rd_req_valid && op0_req_trace<8) begin
            $display("SIX_OP0_READ_REQ n=%0d rel=%h phys=%h ddr=%h",
                op0_req_trace,u_fabric.rd_addr,u_fabric.rd_addr_p,
                ddr.mem[u_fabric.rd_addr_p]);
            op0_req_trace=op0_req_trace+1;
        end
        if(u_fabric.rd_rsp_valid && op0_rsp_trace<8) begin
            $display("SIX_OP0_READ_RSP n=%0d lane=%0d data=%h",
                op0_rsp_trace,u_fabric.rd_lane,u_fabric.rd_data);
            op0_rsp_trace=op0_rsp_trace+1;
        end
        if(u_fabric.wr_en && op0_wr_trace<12) begin
            $display("SIX_OP0_WRITE n=%0d rel=%h phys=%h data=%h",
                op0_wr_trace,u_fabric.wr_addr,u_fabric.wr_addr_p,u_fabric.wr_data);
            op0_wr_trace=op0_wr_trace+1;
        end
    end
    always @(posedge clk) if(rst_n && SIX_CLASS_MODE && !UNIFORM_120_WINDOW &&
        (I2S_INPUT || CLASS_WINDOW_MODE) &&
        !f0_early_checked && u_fabric.u_core.op_act_r==1 &&
        u_fabric.writer_drained) begin
        f0_early_checked=1;
        image_mism=0;
        for(ci=0;ci<25600;ci=ci+1) begin
            // Golden dumps are channel-first (C,H,W); the runtime activation
            // buffer is pixel-first (H,W,C).
            if(ddr.mem[24'h240000+ci] !==
               f0_expected[(ci%8)*3200+(ci/8)]) begin
                if(image_mism<8)
                    $display("SIX_F0_MISM offset=%h got=%h expected=%h",
                        ci,ddr.mem[24'h240000+ci],
                        f0_expected[(ci%8)*3200+(ci/8)]);
                image_mism=image_mism+1;
            end
            runtime_f0_dump[ci]=ddr.mem[24'h240000+ci];
        end
        $writememh("runtime_f0_dump.hex",runtime_f0_dump);
        $display("SIX_F0_FIRST_ACTUAL %h %h %h %h %h %h %h %h",
            runtime_f0_dump[0],runtime_f0_dump[1],runtime_f0_dump[2],runtime_f0_dump[3],
            runtime_f0_dump[4],runtime_f0_dump[5],runtime_f0_dump[6],runtime_f0_dump[7]);
        $display("SIX_F0_COMPARE mismatches=%0d after_op0_write_drain=1 before_arena_reuse=1",image_mism);
        if(image_mism!=0)
            $fatal(1,"six-class runtime first convolution differs from integer reference");
    end
    always @(posedge clk) if(rst_n && core_start)
        $display("CORE_START short=%b context=%b accept=%b short_ready=%b",
            core_short,context_short,short_accept,short_ready);
    // Keep optional model hierarchy out of non-SD elaborations. A procedural
    // parameter check does not remove variable-index memory references in vopt.
    reg sd_scenario_start=0;
    generate if(I2S_SD_TEMPLATE_TEST) begin:g_sd_scenario
        initial begin
            wait(sd_scenario_start);
            press_key7();
            repeat(SD_FIRST_CASE) press_k4();
            for(sd_case=SD_FIRST_CASE;sd_case<SD_FIRST_CASE+SD_CASE_COUNT;sd_case=sd_case+1) begin
                if(capture_selected_category!==N_CLASSES+sd_case)
                    $fatal(1,"SD test key category mismatch got=%0d",capture_selected_category);
                capture_x0_count=0;
                press_k5(); wait(capture_recording);
                sd_base=sd_case*(PCM_SAMPLES/3);
                sd_sample=0;
                repeat(4) @(negedge clk);
                while(capture_x0_count<(EXPECTED_WARMUP_FRAMES+124)*128) begin
                    send_i2s_sample(sd_base+sd_sample); sd_sample=sd_sample+1;
                end
                press_k6();
                while(capture_recording) begin
                    send_i2s_sample(sd_base+sd_sample); sd_sample=sd_sample+1;
                end
                wait(!capture_busy);
                wait(u_fabric.sd_template_valid_mask[sd_case*TEMPLATE_MAPS_PER_CLASS]);
                wait(!u_fabric.sd_store_busy);
                for(sd_byte=0;sd_byte<12800;sd_byte=sd_byte+1) begin
                    sd_expected_maps[sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte]=capture_x0_trace[EXPECTED_WARMUP_FRAMES*128+sd_byte];
                    if((TEMPLATE_DDR_STORAGE ? ddr.mem[24'hf00000+sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte] :
                       u_fabric.g_templates.u_template_matcher.template_mem[sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte]) !==
                       sd_expected_maps[sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte])
                        $fatal(1,"I2S enrollment map mismatch case=%0d byte=%0d",sd_case,sd_byte);
                    if(g_sd_card_model.card.mem[(1+sd_case*TEMPLATE_MAPS_PER_CLASS*25)*512+sd_byte] !==
                       sd_expected_maps[sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte])
                        $fatal(1,"I2S enrollment SD payload mismatch case=%0d byte=%0d",sd_case,sd_byte);
                end
                $display("I2S_SD_ENROLL_PASS category=%0d map=%0d bytes=12800 UART_upload=0",N_CLASSES+sd_case,sd_case*TEMPLATE_MAPS_PER_CLASS);
                if(sd_case<SD_FIRST_CASE+SD_CASE_COUNT-1) press_k4();
            end
            @(negedge clk); rst_n=0;
            $writememh("sd_card_before_reset.hex",g_sd_card_model.card.mem);
            // Model loss of volatile template RAM, not merely a soft reset
            // whose old contents could make a broken SD restore look correct.
            for(sd_byte=0;sd_byte<3*TEMPLATE_MAPS_PER_CLASS*12800;sd_byte=sd_byte+1)
                if(TEMPLATE_DDR_STORAGE) ddr.mem[24'hf00000+sd_byte]=8'h55;
                else u_fabric.g_templates.u_template_matcher.template_mem[sd_byte]=8'h55;
            repeat(5) @(negedge clk); rst_n=1;
            @(negedge clk); boot_start=1;
            @(negedge clk); boot_start=0;
            wait(boot_done);
            if(u_fabric.sd_template_valid_mask!==(((1<<(SD_CASE_COUNT*TEMPLATE_MAPS_PER_CLASS))-1)/((1<<TEMPLATE_MAPS_PER_CLASS)-1) << (SD_FIRST_CASE*TEMPLATE_MAPS_PER_CLASS)) || sd_restored_bytes!=SD_CASE_COUNT*12800)
                $fatal(1,"SD reboot restore mask/byte count wrong mask=%b bytes=%0d",u_fabric.sd_template_valid_mask,sd_restored_bytes);
            for(sd_case=SD_FIRST_CASE;sd_case<SD_FIRST_CASE+SD_CASE_COUNT;sd_case=sd_case+1)
                for(sd_byte=0;sd_byte<12800;sd_byte=sd_byte+1)
                    if((TEMPLATE_DDR_STORAGE ? ddr.mem[24'hf00000+sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte] :
                       u_fabric.g_templates.u_template_matcher.template_mem[sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte]) !==
                       sd_expected_maps[sd_case*TEMPLATE_MAPS_PER_CLASS*12800+sd_byte])
                        $fatal(1,"SD reboot RAM mismatch case=%0d byte=%0d",sd_case,sd_byte);
            $display("I2S_SD_REBOOT_RESTORE_PASS maps=%0d bytes=%0d erased_volatile_RAM=1",SD_CASE_COUNT,SD_CASE_COUNT*12800);
            for(sd_case=SD_FIRST_CASE;sd_case<SD_FIRST_CASE+SD_CASE_COUNT;sd_case=sd_case+1) begin
                capture_x0_count=0; runtime_template_result_count=0; saw_tft=0;
                uart_byte("R");
                sd_base=sd_case*(PCM_SAMPLES/3); sd_sample=0;
                repeat(4) @(negedge clk);
                while(!motor && sd_sample<PCM_SAMPLES/3) begin
                    send_i2s_sample(sd_base+sd_sample); sd_sample=sd_sample+1;
                end
                repeat(200000) @(negedge clk);
                if(!motor || display_class_mon!==8+sd_case || !saw_tft ||
                   runtime_template_class_last!==sd_case+1 || pcm_overflow || x0_overflow)
                    $fatal(1,"SD restored I2S matching/output failed case=%0d class=%0d template=%0d score=%0d motor=%b tft=%b",
                        sd_case,display_class_mon,runtime_template_class_last,runtime_template_score_last,motor,saw_tft);
                $display("I2S_SD_MATCH_OUTPUT_PASS class=%0d score_q15=%0d motor=1 TFT=1",display_class_mon,runtime_template_score_last);
                uart_byte("C"); repeat(5) @(negedge clk);
                if(motor || recognition_enable) $fatal(1,"SD test acknowledgement did not stop/clear");
            end
            if(logits_seen!=0) $fatal(1,"template fixture unexpectedly relied on CNN decisions");
            $display("I2S_SD_SELECTED_FULL_PATH_PASS first_class=%0d classes=%0d maps=%0d bytes=%0d CRC_reboot=1 TFT_motor_ack=1 high_capacity=%0d",8+SD_FIRST_CASE,SD_CASE_COUNT,SD_CASE_COUNT,SD_CASE_COUNT*12800,SD_HIGH_CAPACITY);
            $finish;
        end
    end endgenerate
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        @(negedge clk);boot_start=1;
        @(negedge clk);boot_start=0;
        if(!CPU_TASK_CONTROL && !CAPTURE_PARALLEL && !LOCAL_TEMPLATE_ENROLLMENT && !I2S_SD_TEMPLATE_TEST) uart_byte("R");
        wait(boot_done);
        if(CPU_TASK_CONTROL && (cpu_signature!==32'h56584d32 || cpu_isa!==32'h4d554c44))
            $fatal(1,"CPU firmware/ISA self-test failed signature=%h isa=%h",cpu_signature,cpu_isa);
        if(CPU_TASK_CONTROL && !CAPTURE_PARALLEL && !LOCAL_TEMPLATE_ENROLLMENT && !I2S_SD_TEMPLATE_TEST) uart_byte("R");
        image_mism=0;
        for(ci=0;ci<MODEL_IMAGE_BYTES;ci=ci+1)
            if(ddr.mem[24'h400000+ci] !== flash_mem[ci]) image_mism=image_mism+1;
        $display("BOOT_IMAGE_COMPARE mism=%0d",image_mism);
        if(image_mism) $fatal(1,"boot image mismatch");
        if(!CAPTURE_PARALLEL && !LOCAL_TEMPLATE_ENROLLMENT && !I2S_SD_TEMPLATE_TEST && !recognition_enable)
            $fatal(1,"work mode not armed");
        if(I2S_SD_TEMPLATE_TEST) begin
            sd_scenario_start=1;
            wait(1'b0); // The generated SD scenario owns completion.
        end
        if(LOCAL_TEMPLATE_ENROLLMENT) begin
            if(recognition_enable || capture_selected_category!==0)
                $fatal(1,"local template test must start stopped on CNN background");
            press_key7();
            if(!template_mode || capture_selected_category!==6)
                $fatal(1,"KEY7/K4 did not select pure-template doorbell category");
            record_local_template_take();
            if(u_fabric.u_train_capture.record_count[6]!=1 ||
               u_fabric.local_template_valid_mask!==6'b000001)
                $fatal(1,"button take did not enroll a valid doorbell map count=%0d mask=%b",
                    u_fabric.u_train_capture.record_count[6],
                    u_fabric.local_template_valid_mask);
            capture_ring_mism=0;
            for(ci=0;ci<12800;ci=ci+1)
                if(local_template_mem_probe[ci] !==
                   x0_mel[(ci%128)*N_FRAMES+(ci/128)])
                    capture_ring_mism=capture_ring_mism+1;
            if(capture_ring_mism)
                $fatal(1,"enrolled doorbell RAM differs from captured X0 (%0d bytes)",
                    capture_ring_mism);
            press_key7();
            if(template_mode || capture_busy)
                $fatal(1,"KEY7 did not return to CNN capture family after enrollment");
            uart_byte("R");
            for(frame=0;frame<100;frame=frame+1)
                feed_capture_frame_match(frame);
            wait(runtime_template_result_count>0);
            if(runtime_template_class_last!==2'd1)
                $fatal(1,"local doorbell template did not match: class=%0d score=%0d",
                    runtime_template_class_last,runtime_template_score_last);
            $display("BOARD_LOCAL_TEMPLATE_ENROLL_PASS selected=doorbell id=6 map=0 bytes=12800 DDR_record=1 uart_upload=disabled");
        end else if(CAPTURE_PARALLEL) begin
            if(recognition_enable || capture_selected_category!==0)
                $fatal(1,"capture test must start idle on CNN background");
            press_k5();
            wait(capture_recording);
            if(I2S_INPUT) begin
                // Exercise the board button path with real serialized I2S;
                // the frontend produces the 128-bin Mel frame written to DDR.
                repeat(4) @(negedge clk);
                i2s_sample_index=0;
                while(capture_x0_count<32000) begin
                    send_i2s_sample(i2s_sample_index);
                    i2s_sample_index=i2s_sample_index+1;
                    if(pcm_overflow) $fatal(1,"I2S PCM overflow during capture");
                end
            end else begin
                for(frame=0;frame<250;frame=frame+1)
                    feed_capture_frame(frame);
            end
            press_k6();
            if(I2S_INPUT) begin
                // K6 is debounced, so continue input only until the next full
                // Mel frame boundary has acknowledged the stop request.
                while(capture_recording) begin
                    send_i2s_sample(i2s_sample_index);
                    i2s_sample_index=i2s_sample_index+1;
                    if(pcm_overflow) $fatal(1,"I2S PCM overflow while stopping capture");
                end
            end else begin
                feed_capture_frame(250);
            end
            wait(!capture_busy);
            @(negedge clk);
            capture_expected_frames=u_fabric.u_train_capture.record_frames[0];
            if(u_fabric.u_train_capture.record_count[0]!=1 ||
               capture_expected_frames<250 || capture_expected_frames>260 ||
               capture_base_seen!==24'h540000)
                $fatal(1,"button capture did not store one adjacent class-0 record: count=%0d frames=%0d base=%h",
                    u_fabric.u_train_capture.record_count[0],
                    capture_expected_frames,capture_base_seen);
            capture_start_slot=u_fabric.u_train_capture.record_start_slot[0];
            capture_ring_mism=0;
            for(ff=0;ff<capture_expected_frames;ff=ff+1)
                for(mm=0;mm<128;mm=mm+1) begin
                    if(ddr.mem[capture_base_seen+mm*1000+
                       ((capture_start_slot+ff)%1000)] !==
                       (I2S_INPUT ? capture_x0_trace[ff*128+mm] :
                        x0_mel[mm*N_FRAMES+(ff%N_FRAMES)]))
                        capture_ring_mism=capture_ring_mism+1;
                end
            if(capture_ring_mism)
                $fatal(1,"button audio capture differs from DDR record (%0d bytes)",
                    capture_ring_mism);
            capture_expected_bytes=22+capture_expected_frames*128;
            capture_uart_byte_count=0;
            uart_stream_start_count=0;
            saw_capture_tx_fifo_full=0;
            press_k4();
            if(capture_selected_category!==1)
                $fatal(1,"K4 did not advance class after sending its batch");
            wait(!capture_busy);
            if(capture_uart_byte_count!=capture_expected_bytes ||
               u_fabric.u_train_capture.tx_fifo_count!=0 ||
               u_fabric.u_train_capture.state!=4'd0 ||
               uart_stream_start_count==0 || !saw_capture_tx_fifo_full)
                $fatal(1,"UART batch did not drain correctly bytes=%0d expected=%0d fifo=%0d state=%0d started=%0d full=%b",
                    capture_uart_byte_count,capture_expected_bytes,
                    u_fabric.u_train_capture.tx_fifo_count,
                    u_fabric.u_train_capture.state,uart_stream_start_count,
                    saw_capture_tx_fifo_full);
            if(I2S_INPUT && SIX_CLASS_MODE)
                $display("CAPTURE_SIX_CLASS_I2S_FULL_PASS source=I2S_PCM class=0 frames=%0d DDR_bytes=%0d UART_bytes=%0d FIFO_full=1",
                    capture_expected_frames,capture_expected_frames*128,
                    capture_uart_byte_count);
            else if(I2S_INPUT)
                $display("CAPTURE_EIGHT_CLASS_I2S_FULL_PASS source=I2S_PCM class=0 frames=%0d DDR_bytes=%0d UART_bytes=%0d FIFO_full=1",
                    capture_expected_frames,capture_expected_frames*128,
                    capture_uart_byte_count);
            else
                $display("CAPTURE_EIGHT_CLASS_FULL_PASS source=feature_stream class=0 frames=%0d DDR_bytes=%0d UART_bytes=%0d FIFO_full=1",
                    capture_expected_frames,capture_expected_frames*128,
                    capture_uart_byte_count);
            $display("CAPTURE_DRAIN_PASS fifo_empty=1 state=IDLE next_class=%0d",
                capture_selected_category);
            $finish;
        end else if(I2S_INPUT) begin
            // Let the synchronized LRCK settle at the idle right-channel level
            // after audio reset/boot release before the first left-channel edge.
            repeat(4) @(negedge clk);
            for(f=0;f<PCM_SAMPLES;f=f+1) send_i2s_sample(f);
            if(pcm_overflow) $fatal(1,"I2S PCM overflow");
        end else begin
            for(f=0;f<N_FRAMES;f=f+1) begin
                for(m=0;m<128;m=m+1) begin
                    @(negedge clk);x0_data=x0_mel[m*N_FRAMES+f];x0_valid=1;
                end
                @(negedge clk);x0_valid=0;
                // A physical frontend emits one frame every 10 ms.  Do not
                // inject the next burst before this frame reaches DDR: the
                // AXI4 single-byte transactions need more than 1000 clocks.
                wait(u_fabric.u_snapshots.frame_done);
                @(negedge clk);
            end
        end
        if(I2S_INPUT && UNIFORM_120_WINDOW) begin
            wait(logits_seen==1);
            repeat(200000) @(negedge clk);
            if(x0_overflow || pcm_overflow || weight_mism || unknown_core_write_count ||
               !f0_x0_early_checked || short_snapshot_mode!==2'd1 ||
               capture_x0_count<(EXPECTED_WARMUP_FRAMES+120)*128)
                $fatal(1,"120f integrated path overflow/weight/X/snapshot failure");
            $writememh("frontend_capture.hex",capture_x0_trace,0,capture_x0_count-1);
            $display("UNIFORM120_I2S_RESULT frames=%0d logits=%h class=%0d motor=%b tft=%b template_results=%0d fusion_results=%0d",
                capture_x0_count/128,logits[47:0],display_class_mon,motor,saw_tft,
                runtime_template_result_count,fusion_result_count);
            if(!EXPECT_NO_ALERT && (!motor || !saw_tft || display_class_mon!=EXPECTED_DISPLAY_CLASS))
                $fatal(1,"120f production event did not reach expected display/motor");
            if(EXPECT_NO_ALERT && (motor || display_class_mon!=0))
                $fatal(1,"120f rejection unexpectedly produced alert");
            if(!EXPECT_NO_ALERT) begin
                uart_byte("C"); repeat(5) @(negedge clk);
                if(motor || recognition_enable) $fatal(1,"120f ack did not stop/clear");
                uart_byte("R"); repeat(5) @(negedge clk);
                if(!recognition_enable) $fatal(1,"120f restart did not rearm");
            end else if(!recognition_enable)
                $fatal(1,"120f below-threshold result stopped listening");
            $display("UNIFORM120_I2S_FULL_PATH_PASS input=I2S window=120 hop=60 all_outputs=1 CPU_control=%0d alert_case=%0d", CPU_TASK_CONTROL,!EXPECT_NO_ALERT);
            $finish;
        end
        if(I2S_INPUT) begin
            wait(short_snap_done);
            ring_mism=0;
            snapshot_mism=0;
            for(f=0;f<100;f=f+1)
                for(ci=0;ci<128;ci=ci+1)
                    begin
                    if(ddr.mem[24'h500000+ci*1000+f] !== x0_mel[ci*100+f]) begin
                        if(ring_mism<6) $display("I2S_RING_MISM frame=%0d bin=%0d got=%02x exp=%02x",
                            f,ci,ddr.mem[24'h500000+ci*1000+f],x0_mel[ci*100+f]);
                        ring_mism=ring_mism+1;
                    end
                    if(ddr.mem[24'h200000+ci*100+f] !== x0_mel[ci*100+f]) begin
                        if(snapshot_mism<6) $display("I2S_SNAP_MISM frame=%0d bin=%0d got=%02x exp=%02x",
                            f,ci,ddr.mem[24'h200000+ci*100+f],x0_mel[ci*100+f]);
                        snapshot_mism=snapshot_mism+1;
                    end
                    end
            $display("I2S_X0_COMPARE ring=%0d snapshot=%0d",ring_mism,snapshot_mism);
            $display("I2S_CAPTURE_X0 count=%0d mism=%0d accepted=%0d accepted_mism=%0d",
                capture_x0_count,capture_x0_mism,accepted_x0_count,accepted_x0_mism);
            if(ring_mism || snapshot_mism || capture_x0_mism ||
               accepted_x0_mism || accepted_x0_count<12800)
                $fatal(1,"I2S feature mismatch ring=%0d snapshot=%0d capture=%0d accepted=%0d",
                    ring_mism,snapshot_mism,capture_x0_mism,accepted_x0_mism);
        end
        if(SIX_CLASS_MODE && EXPECT_NO_ALERT && !SIM_OPEN_THRESHOLDS && !TEMPLATE_MATCH_ENABLED) begin
            wait(logits_seen==1);
            repeat(100000) @(negedge clk);
            if(x0_overflow || weight_mism!=0 || unknown_core_write_count!=0 || motor ||
               display_class_mon!=3'd0 || recognition_enable!==1'b1)
                $fatal(1,"calibrated threshold gate failed overflow=%b weights=%0d unknown=%0d tft=%b motor=%b class=%0d enable=%b",
                    x0_overflow,weight_mism,unknown_core_write_count,saw_tft,motor,
                    display_class_mon,recognition_enable);
            $display("SIX_CLASS_FIXED_WINDOW_LISTEN_PASS class_gate=closed motor=0 display=0 listener=active unknown_writes=%0d",
                unknown_core_write_count);
            $finish;
        end
        wait(motor);
        repeat(100000) @(negedge clk);
        if(x0_overflow || weight_mism!=0 || unknown_core_write_count!=0 ||
           ((!TEMPLATE_MATCH_ENABLED || I2S_INPUT) && logits_seen!=1) || !saw_tft ||
            display_class_mismatch)
            $fatal(1,"fabric alert/display failed overflow=%b logits=%0d tft=%b",
                x0_overflow,logits_seen,saw_tft);
        uart_byte("C");
        repeat(5) @(negedge clk);
        if(motor || recognition_enable)
            $fatal(1,"one-shot confirmation must clear alert and remain stopped");
        uart_byte("R");
        repeat(5) @(negedge clk);
        if(!recognition_enable)
            $fatal(1,"fresh start command did not re-arm recognition");
        if(SIX_CLASS_MODE && TEMPLATE_MATCH_ENABLED && !I2S_INPUT) begin
            if(runtime_template_result_count==0 ||
               runtime_template_class_last!=2'd1)
                $fatal(1,"doorbell template did not produce its bound event: results=%0d class=%0d",
                    runtime_template_result_count,runtime_template_class_last);
            $display("SIX_CLASS_TEMPLATE_OUTPUT_PASS event=doorbell template_class=1 display_id=8 score_q15=%0d motor=1 tft=1 stop/rearm",
                runtime_template_score_last);
        end else if(SIX_CLASS_MODE && TEMPLATE_MATCH_ENABLED) begin
            if(runtime_template_result_count==0)
                $fatal(1,"live I2S stream did not reach the enabled template matcher");
            $display("SIX_CLASS_I2S_DUAL_PATH_PASS class=emergency_vehicle template_results=%0d template_class=%0d template_score_q15=%0d x0->template+100f-CNN->softmax->TFT/motor->stop/rearm",
                runtime_template_result_count,runtime_template_class_last,
                runtime_template_score_last);
        end else if(SIX_CLASS_MODE && !SIM_OPEN_THRESHOLDS)
            // The legacy I2S fixture's reference logits [2,-12,-24,46,23,-37]
            // exceed the exported siren threshold. Calibration must permit
            // that event; absence of an event is tested with the fixed head.
            $display("SIX_CLASS_I2S_CALIBRATED_PASS class_gate=open class=emergency_vehicle motor=1 tft=1 stop/rearm");
        else if(SIX_CLASS_MODE)
            $display("SIX_CLASS_I2S_OUTPUT_PASS class=emergency_vehicle x0-ring->100f-CNN->softmax->TFT/motor->stop/rearm");
        else
            $display("RUNTIME_FABRIC_PASS long=%0d x0-ring->snapshot->91ops->motor/TFT->confirm",
                     LONG_WINDOW);
        if(SIX_CLASS_MODE && CNN_TEMPLATE_VALID_MASK != 24'h000000) begin
            if(fusion_result_count==0 || fusion_modified_count==0 ||
               (CLASS_WINDOW_MODE && fusion_mode0_count==0))
                $fatal(1,"CNN template fusion was not exercised results=%0d modified=%0d modes=%0d/%0d/%0d",
                    fusion_result_count,fusion_modified_count,
                    fusion_mode0_count,fusion_mode1_count,fusion_mode2_count);
            $display("SIX_CLASS_FIXED_WINDOW_FUSION_PASS mode_counts=%0d/%0d/%0d modified=%0d display=%0d motor=1",
                fusion_mode0_count,fusion_mode1_count,fusion_mode2_count,
                fusion_modified_count,display_class_mon);
        end
        $finish;
    end
    initial begin
        #((CAPTURE_PARALLEL || I2S_SD_TEMPLATE_TEST) ? 64'd11000000000 : 64'd3000000000);
        if(CAPTURE_PARALLEL)
            $display("PARALLEL_WATCHDOG busy=%b enabled=%b state=%0d bytes=%0d fifo=%0d logits=%0d template=%0d frame=%0d",
                capture_busy,recognition_enable,u_fabric.u_train_capture.state,
                u_fabric.u_train_capture.payload_cnt,
                u_fabric.u_train_capture.tx_fifo_count,
                parallel_logits_count,parallel_template_results,frame);
        $fatal(1,"runtime fabric watchdog");
    end
    integer boot_cycles=0;
    always @(posedge clk) if(rst_n && !boot_done) begin
        boot_cycles=boot_cycles+1;
        if(boot_cycles==20000000) $fatal(1,"boot timeout");
    end
endmodule
