`timescale 1ns/1ps
module tb_mn04_template_matcher #(
    parameter TEMPLATE_FILE = "template_test.mem",
    parameter QUERY_FILE = "query_test.mem",
    parameter integer EXPECTED_CLASS = 1,
    parameter integer SIM_MIN_VAR_SUM = 32768
);
    reg clk=0, rst_n=0, enable=0, x0_valid=0;
    reg signed [7:0] x0=0;
    wire result_valid;
    wire [1:0] result_class;
    wire [15:0] result_score;
    wire busy;
    reg start=0;
    wire recognition_enable,motor,alert_accept;
    wire [3:0] display_class;
    wire display_valid;
    reg signed [7:0] query [0:12799];
    reg [1:0] first_class;
    reg [15:0] first_score;
    reg [3:0] first_display_class;
    integer i, timeout, match_cycles, queue_timeout, second_cycles;

    always #5 clk=~clk;
    initial $readmemh(QUERY_FILE,query);

    mn04_template_matcher #(
        .INITIAL_TEMPLATE_FILE(TEMPLATE_FILE),.DOORBELL_MAPS(2),.SMOKE_ALARM_MAPS(2),
        .GAS_CO_ALARM_MAPS(2),
        .MAX_MAPS_PER_CLASS(2),.THRESHOLD_Q15(16'd26214),
        .MIN_VAR_SUM(SIM_MIN_VAR_SUM)
    ) dut (
        .clk(clk),.rst_n(rst_n),.enable_i(enable),
        .x0_i(x0),.x0_valid_i(x0_valid),
        .template_load_we_i(1'b0),.template_load_addr_i(18'd0),
        .template_load_data_i(8'd0),.template_external_rd_en_i(1'b0),
        .template_external_rd_addr_i(18'd0),.template_external_rd_data_o(),
        .template_valid_mask_i(6'b111111),
        .result_valid_o(result_valid),.result_class_o(result_class),
        .result_score_q15_o(result_score),.busy_o(busy)
    );
    v1_alert_display_top #(
        .EIGHT_CLASS_MODE(1),.ONE_SHOT_MODE(1),.CLOCK_HZ(1000000),.SPI_HZ(100000),
        .RESET_CYCLES(1),.PWR_DELAY_CYCLES(1),.DISPLAY_DELAY_CYCLES(1)
    ) reminder (
        .clk(clk),.rst_n(rst_n),.probs_valid_i(1'b0),.probs_q16_i(128'd0),
        .template_result_valid_i(result_valid),.template_result_class_i(result_class),
        .template_preview_i(1'b0),.template_preview_class_i(4'd0),
        .display_asset_we_i(1'b0),.display_asset_addr_i(15'd0),
        .display_asset_data_i(8'd0),
        .short_window_i(1'b1),.start_i(start),.ack_i(1'b0),
        .external_task_busy_i(1'b0),.set_time_i(1'b0),
        .set_hour_i(8'd0),.set_minute_i(8'd0),.set_second_i(8'd0),
        .recognition_enable_o(recognition_enable),.work_mode_o(),
        .alert_accept_o(alert_accept),.motor_o(motor),.panel_ready_o(),.panel_busy_o(),
        .tft_nrst_o(),.tft_backlight_o(),.tft_sclk_o(),.tft_mosi_o(),
        .tft_dc_o(),.tft_cs_n_o()
    );
    assign display_class=reminder.alerts.display_class_o;
    assign display_valid=reminder.alerts.display_valid_o;

    initial begin
        repeat(5) @(negedge clk); rst_n=1; enable=1; start=1;
        @(negedge clk); start=0;
        repeat(3) @(negedge clk);
        if(!recognition_enable) $fatal(1,"reminder did not arm");
        for(i=0;i<12800;i=i+1) begin
            @(negedge clk); x0=query[i]; x0_valid=1;
        end
        @(negedge clk); x0_valid=0;
        timeout=0;
        while(!busy && timeout<20) begin
            @(negedge clk); timeout=timeout+1;
        end
        if(!busy) $fatal(1,"matcher did not begin full-window work");
        // Emulate the next frame arriving while the template bank is being
        // scanned. It must queue in order and replay after matching finishes.
        repeat(1000) @(negedge clk);
        for(i=0;i<128;i=i+1) begin
            @(negedge clk); x0=query[i]; x0_valid=1;
        end
        @(negedge clk); x0_valid=0;
        timeout=0;
        while(!result_valid && timeout<1000000) begin
            @(negedge clk); timeout=timeout+1;
        end
        if(!result_valid) $fatal(1,"template match timed out after %0d cycles",timeout);
        match_cycles=timeout;
        if(result_class != EXPECTED_CLASS)
            $fatal(1,"wrong template class: expected=%0d got=%0d score=%0d",
                   EXPECTED_CLASS,result_class,result_score);
        repeat(3) @(negedge clk);
        queue_timeout=0;
        while(dut.input_fifo_count_r != 0 && queue_timeout<2000) begin
            @(negedge clk); queue_timeout=queue_timeout+1;
        end
        if(dut.input_fifo_count_r != 0 || dut.input_fifo_overflow_r)
            $fatal(1,"matcher input queue failed to drain cleanly");
        if(EXPECTED_CLASS != 0) begin
            if(result_score < 16'd26214)
                $fatal(1,"expected similarity >= 0.8, got Q15=%0d",result_score);
            if(!motor || !display_valid || recognition_enable ||
               display_class != 4'd7 + EXPECTED_CLASS)
                $fatal(1,"matched template did not reach reminder: motor=%b class=%0d",
                       motor,display_class);
        end else if(result_score >= 16'd26214 || motor || !recognition_enable || display_valid)
            $fatal(1,"unknown query unexpectedly triggered: score=%0d motor=%b class=%0d",
                   result_score,motor,display_class);
        first_class=result_class;
        first_score=result_score;
        first_display_class=display_class;
        // The queued frame plus 49 further frames make the next 100-frame
        // window ready at the configured 50-frame (0.5 s) hop.
        for(i=0;i<49*128;i=i+1) begin
            @(negedge clk); x0=query[(i+128)%12800]; x0_valid=1;
        end
        @(negedge clk); x0_valid=0;
        timeout=0;
        while(!busy && timeout<20) begin
            @(negedge clk); timeout=timeout+1;
        end
        if(!busy) $fatal(1,"matcher did not start its 0.5-second hop window");
        second_cycles=0;
        while(!result_valid && second_cycles<1000000) begin
            @(negedge clk); second_cycles=second_cycles+1;
        end
        if(!result_valid || dut.input_fifo_overflow_r)
            $fatal(1,"second sliding window did not finish cleanly");
        $display("TEMPLATE_MATCHER_PASS class=%0d score_q15=%0d display_id=%0d cycles=%0d",
                 first_class,first_score,first_display_class,match_cycles);
        $display("TEMPLATE_MATCHER_HOP_PASS second_class=%0d cycles=%0d",
                 result_class,second_cycles);
        $finish;
    end
endmodule
