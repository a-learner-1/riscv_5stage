`timescale 1ns/1ps
module tb_mn04_x0_writer_overflow_clear;
    reg clk=0,rst_n=0,ddr_init_done=0;
    reg overflow_clear=0,x0_valid=0;
    reg [7:0] x0_data=0;
    wire x0_ready,overflow;
    wire [27:0] awaddr;
    wire awvalid,wvalid,wlast,bready,drained;
    wire [255:0] wdata;
    wire [31:0] wstrb;
    always #5 clk=~clk;

    mn04_x0_writer #(.MEL_BINS(2),.N_FRAMES(8),.FIFO_DEPTH(2),.FIFO_AW(1)) dut (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(ddr_init_done),
        .overflow_clear_i(overflow_clear),.x0_valid_i(x0_valid),
        .x0_data_i(x0_data),.x0_base_byte_i(24'h540000),
        .x0_ready_o(x0_ready),.done_o(),.frame_done_o(),
        .next_frame_slot_o(),.overflow_o(overflow),
        .ddr_awaddr_o(awaddr),.ddr_awvalid_o(awvalid),.ddr_awready_i(1'b0),
        .ddr_wdata_o(wdata),.ddr_wstrb_o(wstrb),
        .ddr_wvalid_o(wvalid),.ddr_wlast_o(wlast),.ddr_wready_i(1'b0),
        .ddr_bresp_i(2'b00),.ddr_bvalid_i(1'b0),.ddr_bready_o(bready),
        .drained_o(drained));

    task send_byte(input [7:0] value);
        begin
            @(negedge clk);x0_data=value;x0_valid=1;
            @(negedge clk);x0_valid=0;
        end
    endtask

    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        send_byte(8'h11);
        send_byte(8'h22);
        if(x0_ready) $fatal(1,"writer FIFO did not fill");
        send_byte(8'h33);
        @(negedge clk);
        if(!overflow) $fatal(1,"overflow was not latched");
        overflow_clear=1;
        @(negedge clk);overflow_clear=0;
        @(negedge clk);
        if(overflow) $fatal(1,"new recording start did not clear prior overflow");
        $display("X0_WRITER_OVERFLOW_CLEAR_PASS");
        $finish;
    end
    initial begin #10000;$fatal(1,"overflow clear watchdog");end
endmodule
