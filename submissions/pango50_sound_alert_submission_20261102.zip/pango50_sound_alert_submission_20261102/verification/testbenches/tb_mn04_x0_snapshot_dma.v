`timescale 1ns/1ps
module tb_mn04_x0_snapshot_dma;
    reg clk=0,rst_n=0,start=0,short_window=0;
    reg [9:0] next_slot=0;
    always #5 clk=~clk;
    wire busy,done,done_short,done_long;
    wire [27:0] awaddr,araddr;
    wire awvalid,awready,wvalid,wready,wlast,bvalid,bready;
    wire [1:0] bresp;
    wire arvalid,arready,rvalid,rready;
    wire [255:0] wdata,rdata;
    wire [31:0] wstrb;
    wire rlast;
    integer m,f,idx,mism;
    mn04_x0_snapshot_dma dut (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),
        .ring_base_byte_i(24'h500000),
        .start_i(start),.short_i(short_window),.next_frame_slot_i(next_slot),
        .busy_o(busy),.done_o(done),.done_short_o(done_short),
        .done_long_o(done_long),
        .ddr_awaddr_o(awaddr),.ddr_awvalid_o(awvalid),
        .ddr_awready_i(awready),.ddr_wdata_o(wdata),.ddr_wstrb_o(wstrb),
        .ddr_wvalid_o(wvalid),.ddr_wlast_o(wlast),.ddr_wready_i(wready),
        .ddr_bresp_i(bresp),.ddr_bvalid_i(bvalid),.ddr_bready_o(bready),
        .ddr_araddr_o(araddr),
        .ddr_arvalid_o(arvalid),.ddr_arready_i(arready),
        .ddr_rdata_i(rdata),.ddr_rresp_i(2'b00),.ddr_rvalid_i(rvalid),
        .ddr_rready_o(rready));
    mn04_byte_ddr_behav #(.MEM_BYTES(24'h600000),.RD_LATENCY(4)) ddr (
        .clk(clk),.rst_n(rst_n),.awaddr_i(awaddr),.awvalid_i(awvalid),
        .awready_o(awready),.wdata_i(wdata),.wstrb_i(wstrb),
        .wvalid_i(wvalid),.wready_o(wready),.bresp_o(bresp),
        .bvalid_o(bvalid),.bready_i(bready),.araddr_i(araddr),
        .arvalid_i(arvalid),.arready_o(arready),.rdata_o(rdata),
        .rlast_o(rlast),.rvalid_o(rvalid));
    initial begin
        for(m=0;m<128;m=m+1)
            for(f=0;f<1000;f=f+1)
                ddr.mem[24'h500000 + m*1000 + f] = (m*7+f*3)&255;
        repeat(5) @(negedge clk);
        rst_n=1;
        @(negedge clk);short_window=1;next_slot=50;start=1;
        @(negedge clk);start=0;
        wait(done_short);
        mism=0;
        for(m=0;m<128;m=m+1)
            for(f=0;f<100;f=f+1) begin
                idx=(950+f)%1000;
                if(ddr.mem[24'h200000+m*100+f] !== ((m*7+idx*3)&255))
                    mism=mism+1;
            end
        if(mism) $fatal(1,"short snapshot mismatch=%0d",mism);
        @(negedge clk);short_window=0;next_slot=200;start=1;
        @(negedge clk);start=0;
        wait(done_long);
        mism=0;
        for(m=0;m<128;m=m+1)
            for(f=0;f<1000;f=f+1) begin
                idx=(200+f)%1000;
                if(ddr.mem[m*1000+f] !== ((m*7+idx*3)&255))
                    mism=mism+1;
            end
        if(mism) $fatal(1,"long snapshot mismatch=%0d",mism);
        $display("X0_SNAPSHOT_DMA_PASS short=12800 long=128000");
        $finish;
    end
    initial begin #30000000; $fatal(1,"snapshot dma watchdog"); end
endmodule
