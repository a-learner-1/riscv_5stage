`timescale 1ns/1ps
// Two different takes, two different DDR slots, one class-batched UART export.
// Pre-filled DDR sentinels make stale/wrong-region reads fail byte by byte.
module tb_mn04_capture_fabric_banks #(parameter integer DIAGNOSTICS=1, parameter integer RUNNING_START=0,
    parameter integer TEMPLATE_DDR_TEST=0);
 reg recognize=0;
    reg clk=0,rst_n=0,start=0,stop=0,advance=0;
    always #5 clk=~clk;
    reg [7:0] x0=0;
    reg xvalid=0;
    wire recording,busy,stream,freeze,uart_tx;
    wire [23:0] base;
    wire [3:0] category;
    wire [9:0] next_slot;
    wire frame_done,drained,overflow;
    wire [27:0] awaddr,araddr,da,dr;
    wire awvalid,awready,wvalid,wready,wlast,bvalid,bready;
    wire arvalid,arready,rvalid,rready;
    wire [255:0] wd,rd,hw,hr;
    wire [31:0] ws,hws;
    wire [1:0] br,rr;
    wire ha,hv,hwready,hra,hrv,hrvalid,hrlast;
    wire [3:0] halen,hrlen;
    integer take,frame,mel,n,cycles=0,received=0,write_count=0,read_count=0;
    reg [7:0] got [0:262143];
    localparam integer RECORD_OFFSET=TEMPLATE_DDR_TEST ? 40 : 0;
    localparam integer RECORD_BASE='h540000+RECORD_OFFSET*128000;
    function [7:0] value(input integer t,input integer f,input integer m);
        value=(t*71+f*5+m*3)&255;
    endfunction
    mn04_runtime_fabric #(.N_CLASSES(5),.CNN_CLASS_COUNT(5),.ENABLE_TEMPLATE_CAPTURE(1),
        .ENABLE_LOCAL_TEMPLATE_ENROLLMENT(TEMPLATE_DDR_TEST),.TEMPLATE_DDR_STORAGE(TEMPLATE_DDR_TEST),
        .TEMPLATE_MAPS_PER_CLASS(5),.TEMPLATE_DOORBELL_MAPS(TEMPLATE_DDR_TEST?5:0),
        .TEMPLATE_SMOKE_ALARM_MAPS(TEMPLATE_DDR_TEST?5:0),.TEMPLATE_GAS_CO_ALARM_MAPS(TEMPLATE_DDR_TEST?5:0),
        .CLASS_WINDOW_MODE(1),.UNIFORM_120_WINDOW(1),.ENABLE_LONG_WINDOW(0),
        .OP_FILE("C:/Studying_file/pango50_sound_alert_v1/training/output/pc_five_class_fixed120_deployment_20261024/op_desc_120f_six_class.mem"),
        .CAPTURE_CLOCK_HZ(1152000),.CAPTURE_BAUD(115200),.CAPTURE_DIAGNOSTICS(DIAGNOSTICS)) fabric(
        .clk(clk),.rst_n(rst_n),.boot_start_i(1'b0),.x0_i(x0),.x0_valid_i(xvalid),.pcm_overflow_i(1'b0),
        .capture_pcm_debug_i({x0,8'h5a}),.capture_pcm_debug_valid_i(xvalid),
        .recognition_enable_i(recognize),.short_snapshot_accept_i(1'b0),.long_snapshot_accept_i(1'b0),
        .core_start_i(1'b0),.core_start_op_i(9'd0),.core_end_op_i(9'd90),.core_short_window_i(1'b1),
        .core_context_short_i(1'b1),.core_class_window_mode_i(2'd1),
        .boot_flash_rd_data_i(8'd0),.core_flash_rd_data_i(8'd0),.qspi_miso_i(1'b0),.uart_rx_i(1'b1),
        .sd_card_detect_n_i(1'b1),.sd_miso_i(1'b1),.cpu_template_slot_i(4'd0),
        .template_capture_category_advance_i(advance),.template_capture_start_i(start),
        .template_capture_stop_i(stop),.template_capture_mode_i(TEMPLATE_DDR_TEST!=0),
        .uart_tx_o(uart_tx),.capture_task_busy_o(busy),.capture_recording_o(recording),
        .capture_selected_category_o(category),.capture_ring_base_o(base),.x0_overflow_o(overflow),
        .ddr_awaddr_o(awaddr),.ddr_awlen_o(),.ddr_awvalid_o(awvalid),.ddr_awready_i(awready),
        .ddr_wdata_o(wd),.ddr_wstrb_o(ws),.ddr_wvalid_o(wvalid),.ddr_wlast_o(wlast),.ddr_wready_i(wready),
        .ddr_bresp_i(br),.ddr_bvalid_i(bvalid),.ddr_bready_o(bready),
        .ddr_araddr_o(araddr),.ddr_arlen_o(),.ddr_arvalid_o(arvalid),.ddr_arready_i(arready),
        .ddr_rdata_i(rd),.ddr_rresp_i(rr),.ddr_rlast_i(1'b1),.ddr_rvalid_i(rvalid),.ddr_rready_o(rready));
    assign next_slot=fabric.ring_next_slot;
    assign frame_done=fabric.ring_frame_done;
    assign drained=fabric.ring_drained;
    mn04_axi4_ddr_bridge bridge(
        .clk(clk),.rst_n(rst_n),.s_awaddr(awaddr),.s_awlen(4'd0),.s_awvalid(awvalid),.s_awready(awready),
        .s_wdata(wd),.s_wstrb(ws),.s_wvalid(wvalid),.s_wlast(wlast),.s_wready(wready),
        .s_bresp(br),.s_bvalid(bvalid),.s_bready(bready),
        .s_araddr(araddr),.s_arlen(4'd0),.s_arvalid(arvalid),.s_arready(arready),
        .s_rdata(rd),.s_rresp(rr),.s_rlast(),.s_rvalid(rvalid),.s_rready(rready),
        .d_awaddr(da),.d_awlen(halen),.d_awvalid(hv),.d_awready(ha),
        .d_wdata(hw),.d_wstrb(hws),.d_wready(hwready),
        .d_araddr(dr),.d_arlen(hrlen),.d_arvalid(hrv),.d_arready(hra),
        .d_rdata(hr),.d_rlast(hrlast),.d_rvalid(hrvalid));
    mn04_ddr_behav #(.MEM_BYTES(TEMPLATE_DDR_TEST?16777216:6291456),.RD_LATENCY(9)) mem(
        .clk(clk),.rst_n(rst_n),.awaddr_i(da),.awlen_i(halen),.awvalid_i(hv),.awready_o(ha),
        .wdata_i(hw),.wstrb_i(hws),.wready_o(hwready),.araddr_i(dr),.arlen_i(hrlen),
        .arvalid_i(hrv),.arready_o(hra),.rdata_o(hr),.rlast_o(hrlast),.rvalid_o(hrvalid));
    wire [7:0] rxbyte;
    wire rxvalid;
    uart_rx_8n1 #(.CLOCK_HZ(1152000),.BAUD(115200)) rx(
        .clk(clk),.rst_n(rst_n),.rx_i(uart_tx),.data_o(rxbyte),.valid_o(rxvalid));
    always @(posedge clk) begin
        if(rxvalid) begin got[received]=rxbyte;received=received+1;end
        if(awvalid&&awready) write_count=write_count+1;
        if(arvalid&&arready) read_count=read_count+1;
        if(overflow) $fatal(1,"feature writer overflow");
        if(rst_n && fabric.window_quiet_o!==1'b0)
            $fatal(1,"uncalibrated stale quiet flag suppresses CNN results");
        cycles=cycles+1;
        if(cycles>40000000) $fatal(1,"capture integrity timeout state=%0d received=%0d",fabric.u_train_capture.state,received);
    end
    integer offset,len,checksum,slot0,frames0,slots[0:1],lengths[0:1];
    initial begin
        #1;
        force fabric.model_boot_done=1;
        for(n=RECORD_BASE;n<RECORD_BASE+256000;n=n+1) mem.mem[n]=8'he7;
        repeat(5) @(negedge clk);rst_n=1;
        wait(fabric.boot_init_done_o);
        // Runtime template writes must not retract one-time boot readiness,
        // reset the ring writer, or switch its master back to the bootloader.
        @(negedge clk);force fabric.template_writes_drained=0;
        repeat(5) @(negedge clk);
        if(fabric.boot_init_done_o!==1'b1)
            $fatal(1,"runtime template write incorrectly retracts boot readiness");
        release fabric.template_writes_drained;
        if(RUNNING_START) begin
            recognize=1;
            for(frame=0;frame<3;frame=frame+1) begin
                for(mel=0;mel<128;mel=mel+1) begin
                    @(negedge clk);xvalid=1;x0=value(7,frame,mel);
                end
                @(negedge clk);xvalid=0;wait(frame_done);@(negedge clk);
            end
        end
        for(take=0;take<2;take=take+1) begin
            @(negedge clk);start=1;
            @(negedge clk);start=0;
            wait(recording);slots[take]=next_slot;lengths[take]=TEMPLATE_DDR_TEST?(take==0?601:533):(take==0?121:133);
            if(base!==(RECORD_BASE+take*128000)) $fatal(1,"wrong write bank %h",base);
            for(frame=0;frame<lengths[take];frame=frame+1) begin
                if(frame==lengths[take]-1) begin
                    @(negedge clk);stop=1;@(negedge clk);stop=0;
                end
                for(mel=0;mel<128;mel=mel+1) begin
                    @(negedge clk);xvalid=1;x0=value(take,frame,mel);
                end
                @(negedge clk);xvalid=0;
                wait(frame_done);@(negedge clk);
            end
            wait(!busy);
            if(fabric.u_train_capture.record_frames[RECORD_OFFSET+take]!==lengths[take] || fabric.u_train_capture.record_start_slot[RECORD_OFFSET+take]!==slots[take])
                $fatal(1,"wrong record metadata take=%0d",take);
            for(mel=0;mel<128;mel=mel+1) for(frame=0;frame<lengths[take];frame=frame+1)
                if(mem.mem[RECORD_BASE+take*128000+mel*1000+(slots[take]+frame)%1000]!==value(take,frame,mel))
                    $fatal(1,"DDR capture mismatch take=%0d mel=%0d frame=%0d",take,mel,frame);
            $display("CAPTURE_DDR_TAKE_PASS take=%0d frames=%0d start_slot=%0d base=%h",take,lengths[take],slots[take],base);
            if(TEMPLATE_DDR_TEST) begin
                if(fabric.template_bank_fault) $fatal(1,"template DDR bank fault");
                for(frame=0;frame<100;frame=frame+1) for(mel=0;mel<128;mel=mel+1)
                    if(mem.mem['hf00000+take*12800+frame*128+mel]!==value(take,400+frame,mel))
                        $fatal(1,"enrolled template mismatch take=%0d frame=%0d mel=%0d",take,frame,mel);
                $display("CAPTURE_TEMPLATE_DDR_PASS take=%0d bytes=12800 boot_readiness_preserved=1",take);
            end
        end
        @(negedge clk);advance=1;@(negedge clk);advance=0;
        wait(!busy);repeat(200) @(negedge clk);
        offset=0;
        for(take=0;take<2;take=take+1) begin
            len=lengths[take]*128;
            if(got[offset]!==8'haa || got[offset+1]!==8'h55 || got[offset+2]!== (TEMPLATE_DDR_TEST?5:0) ||
               {got[offset+5],got[offset+4],got[offset+3]}!==len)
                $fatal(1,"UART header mismatch take=%0d",take);
            checksum=0;
            for(mel=0;mel<128;mel=mel+1) for(frame=0;frame<lengths[take];frame=frame+1) begin
                n=offset+9+mel*lengths[take]+frame;
                if(got[n]!==value(take,frame,mel))
                    $fatal(1,"UART feature mismatch take=%0d mel=%0d frame=%0d got=%h expected=%h",take,mel,frame,got[n],value(take,frame,mel));
                checksum=checksum^got[n];
            end
            if(got[offset+9+len]!==checksum[7:0] || got[offset+10+len]!==8'h5a)
                $fatal(1,"UART trailer mismatch");
            offset=offset+len+11;
            if(DIAGNOSTICS) begin
                if(got[offset+2]!==8'hfd || got[offset+3]!==64 ||
                   {got[offset+12],got[offset+11],got[offset+10],got[offset+9]}!==32'h31304443)
                    $fatal(1,"diagnostic header/magic mismatch");
                checksum=0;
                for(n=0;n<64;n=n+1) checksum=checksum^got[offset+9+n];
                if(got[offset+73]!==checksum[7:0] || got[offset+74]!==8'h5a)
                    $fatal(1,"diagnostic trailer mismatch");
                offset=offset+75;
            end
        end
        if(got[offset+2]!==8'hfe || got[offset+8]!==2 || received!==offset+11)
            $fatal(1,"UART class batch marker mismatch bytes=%0d expected=%0d",received,offset+11);
        $display("CAPTURE_FABRIC_BANKS_PASS takes=2 differing_features=1 feature_bytes=%0d UART_bytes=%0d writes=%0d reads=%0d no_stale_sentinel=1",254*128,received,write_count,read_count);
        $writememh("uart_bytes.hex",got,0,received-1);
        $finish;
    end
endmodule
