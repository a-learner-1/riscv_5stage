`timescale 1ns/1ps
module tb_mn04_dual_window_scheduler;
    reg clk = 0;
    always #10 clk = ~clk;
    reg rst_n = 0, short_ready = 0, long_ready = 0;
    reg alert = 0, confirmed = 0, recognition_enable = 0;
    reg core_busy = 0, core_done = 0;
    wire core_start, core_short, context_short, short_result, long_result, latched;
    wire [8:0] start_op, end_op;
    wire [23:0] mapped_read, mapped_write;
    wire short_accept, long_accept;
    integer n = 0, timer = 0, short_results = 0, long_results = 0;
    reg [15:0] observed [0:7];
    mn04_dual_window_scheduler #(.N_OPS(4)) dut (
        .clk(clk), .rst_n(rst_n), .short_ready_i(short_ready),
        .long_ready_i(long_ready),.recognition_enable_i(recognition_enable),
        .alert_i(alert), .confirmed_i(confirmed),
        .core_busy_i(core_busy), .core_done_i(core_done),
        .core_start_o(core_start), .core_start_op_o(start_op),
        .core_end_op_o(end_op), .core_short_window_o(core_short),
        .core_context_short_o(context_short),
        .short_result_valid_o(short_result), .long_result_valid_o(long_result),
        .alert_latched_o(latched), .short_snapshot_accept_o(short_accept),
        .long_snapshot_accept_o(long_accept));
    mn04_dual_arena_addr arena (
        .short_context_i(context_short),
        .core_read_addr_i(24'h180900), .core_write_addr_i(24'h18ffff),
        .ddr_read_addr_o(mapped_read), .ddr_write_addr_o(mapped_write));

    // A fake core completes each op two cycles after launch.
    always @(posedge clk) begin
        core_done <= 0;
        if (core_start) begin
            if (core_busy || n >= 8 || start_op !== end_op)
                $fatal(1, "invalid core launch");
            if (mapped_read !== (core_short ? 24'h380900 : 24'h180900) ||
                mapped_write !== (core_short ? 24'h38ffff : 24'h18ffff))
                $fatal(1, "wrong DDR arena mapping");
            observed[n] <= {core_short, 6'b0, start_op};
            n <= n + 1;
            core_busy <= 1;
            timer <= 2;
        end else if (core_busy && timer == 0) begin
            core_busy <= 0;
            core_done <= 1;
        end else if (core_busy) timer <= timer - 1;
        if (short_result) short_results <= short_results + 1;
        if (long_result) long_results <= long_results + 1;
    end

    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1;
        long_ready = 1;
        @(negedge clk);
        if (n != 0 || long_accept) $fatal(1, "scheduled before work mode");
        recognition_enable = 1;
        long_ready = 1;
        @(negedge clk);
        long_ready = 0;
        if (n != 1 || observed[0] !== 16'h0000) $fatal(1, "long op0 did not launch");
        short_ready = 1;
        @(negedge clk);
        short_ready = 0;
        if (context_short !== 0) $fatal(1, "DDR context switched during long op");
        wait (short_results == 1 && long_results == 1);
        @(negedge clk);
        if (n != 8) $fatal(1, "expected 8 ops, saw %0d", n);
        if (observed[1] !== 16'h8000 || observed[2] !== 16'h8001 ||
            observed[3] !== 16'h8002 || observed[4] !== 16'h8003 ||
            observed[5] !== 16'h0001 || observed[6] !== 16'h0002 ||
            observed[7] !== 16'h0003) $fatal(1, "priority/order mismatch");
        alert = 1;
        recognition_enable = 0;
        @(negedge clk);
        alert = 0;
        if (!latched) $fatal(1, "alert not latched");
        short_ready = 1;
        long_ready = 1;
        @(negedge clk);
        short_ready = 0;
        long_ready = 0;
        repeat (6) @(negedge clk);
        if (n != 8 || short_accept || long_accept) $fatal(1, "ran while alert latched");
        confirmed = 1;
        @(negedge clk);
        confirmed = 0;
        recognition_enable = 1;
        #1;
        if (latched || !short_accept || !long_accept) $fatal(1, "confirmation failed");
        $display("SCHEDULER_PASS: short preempted at op boundary; alert froze; confirmation resumed");
        $finish;
    end
    initial begin
        #100000;
        $fatal(1, "scheduler timeout");
    end
endmodule
