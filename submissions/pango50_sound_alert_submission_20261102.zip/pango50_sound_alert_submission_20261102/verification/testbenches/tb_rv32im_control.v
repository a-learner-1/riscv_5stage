`timescale 1ns/1ps
module tb_rv32im_control;
    reg clk=0,rst_n=0,boot=0,codec=0,listen=0,busy=0,recording=0,alert=0;
    reg [5:0] keys=6'h3f;
    reg snapshot=0,done=0,cnn=0,template_valid=0,commit=0;
    reg [95:0] probs=0;
    reg [1:0] template_class=0;
    reg [15:0] template_score=0;
    reg [3:0] category=5;
    reg [14:0] slots=0;
    wire [5:0] commands;
    wire grant,event_valid;
    wire [3:0] slot,event_class;
    wire [31:0] signature,command_count,irq_count,isa;
    integer decisions=0;
    reg [3:0] last_class;
    always #5 clk=~clk;
    always @(posedge clk) if(event_valid) begin decisions=decisions+1;last_class=event_class;end
    mn04_rv32im_control #(.CLOCK_HZ(10000)) dut(
        .clk(clk),.rst_n(rst_n),.key_n_i(keys),.boot_ready_i(boot),.codec_ready_i(codec),
        .recognition_i(listen),.capture_busy_i(busy),.recording_i(recording),.alert_i(alert),
        .snapshot_ready_i(snapshot),.job_done_i(done),.cnn_valid_i(cnn),.cnn_probabilities_i(probs),
        .template_valid_i(template_valid),.template_class_i(template_class),.template_score_i(template_score),
        .capture_category_i(category),.template_slot_mask_i(slots),.template_commit_i(commit),
        .command_key_n_o(commands),.job_authorized_o(grant),.template_slot_o(slot),
        .event_valid_o(event_valid),.event_class_o(event_class),.firmware_signature_o(signature),
        .command_count_o(command_count),.irq_count_o(irq_count),.isa_selftest_o(isa));
    task settle;begin repeat(2500) @(negedge clk);end endtask
    task press;
        input [5:0] mask;
        input [5:0] expected;
        integer i;
        reg [5:0] seen;
        begin
            seen=0;@(negedge clk);keys=~mask;
            for(i=0;i<5000;i=i+1) begin @(negedge clk);seen=seen|~commands;end
            keys=6'h3f;
            for(i=0;i<5000;i=i+1) begin @(negedge clk);seen=seen|~commands;end
            if(seen!==expected) $fatal(1,"CPU key policy mask=%b expected=%b got=%b",mask,expected,seen);
        end
    endtask
    task classify;
        input integer class_id,score,expected;
        integer old_count;
        begin
            old_count=decisions;
            @(negedge clk);probs=0;probs[15:0]=10000;probs[class_id*16+:16]=score;cnn=1;
            @(negedge clk);cnn=0;
            settle();
            if(decisions!=old_count+1 || last_class!==expected)
                $fatal(1,"CPU decision id=%0d score=%0d expected=%0d got=%0d count=%0d",class_id,score,expected,last_class,decisions-old_count);
        end
    endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        repeat(10000) @(negedge clk);
        if(signature!==32'h56584d32 || isa!==32'h4d554c44)
            $fatal(1,"RV32IM firmware or M instruction self-test failed signature=%h isa=%h pc=%h",signature,isa,dut.ia);
        press(1,0);boot=1;codec=1;
        press(1,1);listen=1;
        @(negedge clk);snapshot=1;@(negedge clk);snapshot=0;
        settle();if(!grant) $fatal(1,"CPU did not authorize snapshot job");
        @(negedge clk);done=1;@(negedge clk);done=0;settle();
        if(grant) $fatal(1,"CPU completion did not release job");
        classify(1,58000,0);classify(1,61000,1);classify(2,50000,2);
        classify(3,52000,3);classify(5,40000,5);classify(4,65000,0);
        @(negedge clk);template_class=1;template_score=27000;template_valid=1;
        @(negedge clk);template_valid=0;settle();
        if(last_class!==8) $fatal(1,"CPU pure template event failed");
        press(4,0);listen=0;slots=15'h0003;
        press(8,8);if(slot!==2) $fatal(1,"CPU did not choose first empty slot");
        slots=15'h001f;press(8,0);
        category=6;slots=15'h0020;press(8,8);
        if(slot!==6) $fatal(1,"CPU slot class mapping wrong");
        busy=1;recording=1;press(16,16);press(32,0);
        busy=0;recording=0;press(32,32);
        if(irq_count<10 || dut.overrun_count!=0) $fatal(1,"completion IRQ missing or mailbox overrun");
        $display("RV32IM_CONTROL_PASS mul_div_rem=1 AXIL=1 IRQ=1 job_admission=1 CPU_thresholds=1 dog_disabled=1 slots_5_per_class=1 commands=%0d irqs=%0d",command_count,irq_count);
        $finish;
    end
    initial begin #5000000;$fatal(1,"RV32IM control watchdog pc=%h sig=%h irq=%h",dut.ia,signature,dut.irq_pending);end
endmodule
