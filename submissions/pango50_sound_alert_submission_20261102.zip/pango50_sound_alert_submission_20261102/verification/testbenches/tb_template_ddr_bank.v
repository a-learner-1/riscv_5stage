`timescale 1ns/1ps
module tb_template_ddr_bank;
    reg clk=0;always #5 clk=~clk;
    reg rst_n=0,load=0,req=0;
    reg [17:0] addr=0,rdaddr=0;
    reg [7:0] data=0;
    wire drained,fault,valid;wire signed [7:0] result;
    wire [27:0] awaddr,araddr;wire awvalid,arvalid,wvalid,wlast,bready,rready;
    wire [255:0] wdata;wire [31:0] wstrb;
    reg [255:0] rdata=0;reg bvalid=0,rvalid=0;
    integer cycle=0,awdelay=0,rdelay=0,write_count=0,read_count=0;
    reg [27:0] held_aw,held_ar;reg aw_seen=0,w_seen=0;
    reg [255:0] held_w;reg [31:0] held_s;
    reg [7:0] mem[0:191999];
    wire awready=cycle%7==2 && !aw_seen;
    wire wready=cycle%5==3 && !w_seen;
    wire arready=cycle%11==4 && rdelay==0 && !rvalid;
    mn04_template_ddr_bank dut(.clk(clk),.rst_n(rst_n),.ddr_ready_i(1'b1),
        .load_we_i(load),.load_addr_i(addr),.load_data_i(data),.writes_drained_o(drained),.fault_o(fault),
        .rd_req_i(req),.rd_addr_i(rdaddr),.rd_valid_o(valid),.rd_data_o(result),
        .awaddr_o(awaddr),.araddr_o(araddr),.awvalid_o(awvalid),.arvalid_o(arvalid),
        .awready_i(awready),.arready_i(arready),.wdata_o(wdata),.wstrb_o(wstrb),
        .wvalid_o(wvalid),.wlast_o(wlast),.wready_i(wready),.bresp_i(2'd0),.rresp_i(2'd0),
        .bvalid_i(bvalid),.rvalid_i(rvalid),.rdata_i(rdata),.bready_o(bready),.rready_o(rready));
    integer j,base;
    always @(posedge clk) begin
        cycle<=cycle+1;
        if(rst_n) begin
            if(awvalid && awready) begin held_aw<=awaddr;aw_seen<=1;end
            if(wvalid && wready) begin held_w<=wdata;held_s<=wstrb;w_seen<=1;end
            if(aw_seen && w_seen && !bvalid) begin
                base=(held_aw & 28'hfffffe0)-28'hf00000;
                if(base<0 || base+31>=192000) $fatal(1,"write out of region");
                for(j=0;j<32;j=j+1) if(held_s[j]) begin mem[base+j]<=held_w[j*8+:8];write_count<=write_count+1;end
                bvalid<=1;
            end
            if(bvalid && bready) begin bvalid<=0;aw_seen<=0;w_seen<=0;end
            if(arvalid && arready) begin held_ar<=araddr;rdelay<=6;read_count<=read_count+1;end
            if(rdelay>1) rdelay<=rdelay-1;
            if(rdelay==1) begin
                base=(held_ar & 28'hfffffe0)-28'hf00000;
                for(j=0;j<32;j=j+1) rdata[j*8+:8]<=mem[base+j];
                rdelay<=0;rvalid<=1;
            end
            if(rvalid && rready) rvalid<=0;
        end
    end
    function [7:0] pattern;input integer a;begin pattern=(a*17)^(a>>7)^(a/12800*23);end endfunction
    task read_byte;input integer a;input [7:0] expected;integer timeout;begin
        @(negedge clk);rdaddr=a;req=1;
        @(negedge clk);req=0;timeout=0;
        while(!valid && timeout<500) begin @(negedge clk);timeout=timeout+1;end
        if(!valid || result!==expected) $fatal(1,"DDR read addr=%0d got=%h expected=%h timeout=%0d",a,result,expected,timeout);
        @(negedge clk);
    end endtask
    integer a,m;
    initial begin
        repeat(8) @(negedge clk);rst_n=1;
        for(a=0;a<192000;a=a+1) begin
            @(negedge clk);load=1;addr=a;data=pattern(a);
            @(negedge clk);load=0;
            // Stream cadence bounds the write FIFO under deliberately stalled AXI.
            repeat(30) @(negedge clk);
        end
        wait(drained);repeat(3) @(negedge clk);
        if(write_count!=192000 || fault) $fatal(1,"writes lost %0d fault=%b",write_count,fault);
        for(a=0;a<192000;a=a+1) read_byte(a,pattern(a));
        // A cached line must be invalidated after replacement, including byte lane 31.
        @(negedge clk);load=1;addr=191999;data=8'had;
        @(negedge clk);load=0;wait(drained);
        read_byte(191999,8'had);read_byte(0,pattern(0));
        if(fault) $fatal(1,"unexpected bank fault");
        $display("TEMPLATE_DDR_BANK_PASS maps=15 bytes=192000 byte_exact=1 independently_stalled_AXI=1 cache_invalidation=1 read_beats=%0d",read_count);
        $finish;
    end
    initial begin #300000000;$fatal(1,"DDR bank timeout");end
endmodule
