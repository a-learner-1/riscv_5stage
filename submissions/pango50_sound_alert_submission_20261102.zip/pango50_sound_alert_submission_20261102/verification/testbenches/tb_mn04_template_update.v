`timescale 1ns/1ps
// End-to-end simulation of the runtime template updater against a behavioural
// W25Q128 model.  Checks a blank-journal update, journal record contents,
// boot selection, torn commit, corrupted body and a second generation.
module tb_mn04_template_update;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #5 clk = ~clk;

    reg         idle_ok = 1'b1;
    reg         host_valid = 1'b0;
    reg  [7:0]  host_data = 8'h00;
    wire        host_ready;
    wire        msg_valid;
    wire [7:0]  msg_data;
    reg         msg_ready = 1'b0;
    wire        busy;

    wire qspi_cs_n, qspi_sck, qspi_mosi, qspi_miso;

    // ---------------- behavioural SPI-NOR (W25Q128) ----------------
    reg [7:0] mem [0:16777215];
    reg miso = 1'b1;
    reg [7:0] sh_in = 8'h00;
    reg [2:0] bitcnt = 3'd0;
    reg [1:0] phase = 2'd0;
    reg [7:0] cmd = 8'h00;
    reg [23:0] addr = 24'd0;
    reg [1:0] addr_left = 2'd0;
    reg [7:0] out_byte = 8'hFF;
    reg [2:0] out_bit = 3'd7;
    integer busy_cnt = 0;
    reg wel = 1'b0;
    integer i, j;

    assign qspi_miso = miso;

    initial begin
        for (i = 24'h600000; i <= 24'h680000; i = i + 1) mem[i] = 8'hFF;
    end

    always @(posedge clk) if (busy_cnt > 0) busy_cnt <= busy_cnt - 1;

    always @(negedge qspi_cs_n) begin
        phase = 2'd0; bitcnt = 3'd0; sh_in = 8'h00;
        addr = 24'd0; addr_left = 2'd0;
    end
    always @(posedge qspi_cs_n) begin
        miso <= 1'b1;
    end

    wire [7:0] sh_next = {sh_in[6:0], qspi_mosi};
    wire [23:0] addr_next = {addr[15:0], sh_next};

    always @(posedge qspi_sck) if (!qspi_cs_n) begin
        sh_in <= sh_next;
        if (bitcnt == 3'd7) begin
            bitcnt <= 3'd0;
            case (phase)
                2'd0: begin
                    cmd <= sh_next;
                    if (sh_next == 8'h06) begin
                        wel <= 1'b1;
                        phase <= 2'd3;
                    end else if (sh_next == 8'h05) begin
                        out_byte <= {7'd0, (busy_cnt != 0)};
                        out_bit <= 3'd7;
                        phase <= 2'd4;
                    end else if (sh_next == 8'h03 || sh_next == 8'h02 ||
                                 sh_next == 8'h20) begin
                        phase <= 2'd1;
                        addr_left <= 2'd3;
                        addr <= 24'd0;
                    end else phase <= 2'd3;
                end
                2'd1: begin
                    addr <= addr_next;
                    addr_left <= addr_left - 2'd1;
                    if (addr_left == 2'd1) begin
                        if (cmd == 8'h03) begin
                            out_byte <= mem[addr_next];
                            out_bit <= 3'd7;
                            phase <= 2'd2;
                        end else if (cmd == 8'h02) begin
                            phase <= 2'd2;
                        end else begin
                            for (j = 0; j < 4096; j = j + 1)
                                mem[{addr_next[23:12], 12'd0} + j] <= 8'hFF;
                            busy_cnt <= 300;
                            wel <= 1'b0;
                            phase <= 2'd3;
                        end
                    end
                end
                2'd2: begin
                    if (cmd == 8'h03) begin
                        addr <= addr + 24'd1;
                        out_byte <= mem[addr + 24'd1];
                        out_bit <= 3'd7;
                    end else begin
                        mem[addr] <= mem[addr] & sh_next;
                        addr <= addr + 24'd1;
                        busy_cnt <= 40;
                        wel <= 1'b0;
                    end
                end
                default: ;
            endcase
        end else bitcnt <= bitcnt + 3'd1;
    end

    always @(negedge qspi_sck) if (!qspi_cs_n) begin
        if ((phase == 2'd2 && cmd == 8'h03) || phase == 2'd4) begin
            miso <= out_byte[out_bit];
            if (out_bit != 3'd0) out_bit <= out_bit - 3'd1;
        end else miso <= 1'b1;
    end

    // ---------------- design under test ----------------
    wire active_valid, active_slot;
    wire [31:0] active_gen;
    mn04_template_update #(
        .SPI_DIV_HALF(1)
    ) dut (
        .clk(clk), .rst_n(rst_n), .idle_ok_i(idle_ok),
        .host_valid_i(host_valid), .host_data_i(host_data),
        .host_ready_o(host_ready),
        .msg_valid_o(msg_valid), .msg_data_o(msg_data), .msg_ready_i(msg_ready),
        .qspi_cs_o(qspi_cs_n), .qspi_sck_o(qspi_sck),
        .qspi_mosi_o(qspi_mosi), .qspi_miso_i(qspi_miso),
        .busy_o(busy), .active_valid_o(active_valid),
        .active_slot_o(active_slot), .active_generation_o(active_gen));

    // ---------------- independent boot selector ----------------
    reg  chk_start = 1'b0, chk_valid = 1'b0;
    reg  [7:0] chk_data = 8'h00;
    wire chk_ready, chk_done, chk_active_valid, chk_slot, chk_ferased_valid;
    wire [7:0] chk_conflicts, chk_invalid_count;
    wire [31:0] chk_gen;
    mn04_template_selector #(.RECORDS(128)) chk (
        .clk(clk), .rst_n(rst_n), .start_i(chk_start),
        .byte_i(chk_data), .valid_i(chk_valid), .ready_o(chk_ready),
        .done_o(chk_done), .active_valid_o(chk_active_valid), .slot_o(chk_slot),
        .generation_o(chk_gen), .container_bytes_o(),
        .first_erased_index_o(), .first_erased_valid_o(chk_ferased_valid),
        .uncommitted_count_o(), .invalid_count_o(chk_invalid_count),
        .conflict_count_o(chk_conflicts));

    // ---------------- helpers ----------------
    reg [7:0] cont [0:131071];
    reg [7:0] cur_sha [0:31];
    integer cur_len;
    reg [31:0] cur_hcrc, cur_ccrc;

    function [31:0] crc_step(input [31:0] c, input [7:0] b);
        integer k;
        reg [31:0] v;
        begin
            v = c;
            for (k = 0; k < 8; k = k + 1)
                v = (v[0] ^ b[k]) ? ((v >> 1) ^ 32'hEDB88320) : (v >> 1);
            crc_step = v;
        end
    endfunction

    function [31:0] mem_crc(input [23:0] base, input integer n);
        integer k, bit;
        reg [31:0] c;
        reg [7:0] b;
        begin
            c = 32'hFFFFFFFF;
            for (k = 0; k < n; k = k + 1) begin
                b = mem[base + k];
                for (bit = 0; bit < 8; bit = bit + 1)
                    c = (c[0] ^ b[bit]) ? ((c >> 1) ^ 32'hEDB88320) : (c >> 1);
            end
            mem_crc = ~c;
        end
    endfunction

    task write_selector_record(input integer rec_index, input [31:0] gen,
                               input reg slot, input [17:0] nbytes,
                               input [7:0] sha_seed);
        integer k;
        reg [23:0] base;
        reg [31:0] c;
        begin
            base = 24'h670000 + rec_index * 64;
            mem[base + 0] = 8'h50; mem[base + 1] = 8'h35;
            mem[base + 2] = 8'h30; mem[base + 3] = 8'h53;
            mem[base + 4] = 8'h45; mem[base + 5] = 8'h4C;
            mem[base + 6] = 8'h30; mem[base + 7] = 8'h31;
            mem[base + 8] = 8'h01; mem[base + 9] = 8'h00;
            mem[base + 10] = 8'h00; mem[base + 11] = 8'h00;
            mem[base + 12] = gen[7:0]; mem[base + 13] = gen[15:8];
            mem[base + 14] = gen[23:16]; mem[base + 15] = gen[31:24];
            mem[base + 16] = {7'd0, slot}; mem[base + 17] = 8'h00;
            mem[base + 18] = 8'h00; mem[base + 19] = 8'h00;
            mem[base + 20] = nbytes[7:0]; mem[base + 21] = nbytes[15:8];
            mem[base + 22] = {6'd0, nbytes[17:16]}; mem[base + 23] = 8'h00;
            for (k = 0; k < 32; k = k + 1)
                mem[base + 24 + k] = sha_seed + k[7:0];
            c = mem_crc(base, 56);
            mem[base + 56] = c[7:0]; mem[base + 57] = c[15:8];
            mem[base + 58] = c[23:16]; mem[base + 59] = c[31:24];
            mem[base + 60] = 8'h43; mem[base + 61] = 8'h4D;
            mem[base + 62] = 8'h54; mem[base + 63] = 8'h31;
        end
    endtask

    integer guard;

    task host_send(input [7:0] b);
        begin
            @(negedge clk);
            host_valid = 1'b1; host_data = b;
            @(posedge clk);
            guard = 0;
            while (!host_ready && guard < 1000000) begin
                @(posedge clk); guard = guard + 1;
            end
            if (!host_ready) begin $display("FAIL host_send timeout"); $fatal; end
            @(negedge clk);
            host_valid = 1'b0;
        end
    endtask

    task host_recv(output [7:0] b);
        begin
            @(negedge clk);
            guard = 0;
            while (!msg_valid && guard < 20000000) begin
                @(negedge clk); guard = guard + 1;
            end
            if (!msg_valid) begin $display("FAIL host_recv timeout"); $fatal; end
            b = msg_data;
            msg_ready = 1'b1;
            @(posedge clk);
            @(negedge clk);
            msg_ready = 1'b0;
        end
    endtask

    task send_header;
        integer k;
        reg [31:0] c;
        begin
            c = 32'hFFFFFFFF;
            c = crc_step(c, cur_len[7:0]);
            c = crc_step(c, cur_len[15:8]);
            c = crc_step(c, cur_len[23:16]);
            c = crc_step(c, cur_len[31:24]);
            for (k = 0; k < 32; k = k + 1) c = crc_step(c, cur_sha[k]);
            cur_hcrc = ~c;
            host_send(8'hA5);
            host_send(8'h01);
            host_send(cur_len[7:0]);
            host_send(cur_len[15:8]);
            host_send(cur_len[23:16]);
            host_send(cur_len[31:24]);
            for (k = 0; k < 32; k = k + 1) host_send(cur_sha[k]);
            host_send(cur_hcrc[7:0]);
            host_send(cur_hcrc[15:8]);
            host_send(cur_hcrc[23:16]);
            host_send(cur_hcrc[31:24]);
        end
    endtask

    task send_container;
        integer k;
        reg [31:0] c;
        begin
            c = 32'hFFFFFFFF;
            for (k = 0; k < cur_len; k = k + 1) begin
                host_send(cont[k]);
                c = crc_step(c, cont[k]);
                if (((k + 1) % 256) == 0 || k + 1 == cur_len)
                    expect_msg(8'h41); // 'A' after each complete flash page
            end
            cur_ccrc = ~c;
            host_send(cur_ccrc[7:0]);
            host_send(cur_ccrc[15:8]);
            host_send(cur_ccrc[23:16]);
            host_send(cur_ccrc[31:24]);
        end
    endtask

    task set_current_container_header(input [15:0] version,
                                      input [7:0] maps_per_class,
                                      input [31:0] metadata_bytes);
        integer k;
        reg [31:0] counts;
        reg [31:0] value;
        begin
            cont[0]=8'h50; cont[1]=8'h35; cont[2]=8'h30; cont[3]=8'h54;
            cont[4]=8'h4D; cont[5]=8'h42; cont[6]=8'h30; cont[7]=8'h33;
            cont[8]=version[7:0]; cont[9]=version[15:8];
            cont[10]=8'd128; cont[11]=8'd0;
            value=32'd76800;
            for (k=0;k<4;k=k+1) cont[12+k]=(value>>(k*8))&8'hFF;
            for (k=0;k<4;k=k+1) cont[16+k]=(metadata_bytes>>(k*8))&8'hFF;
            value=32'd28032;
            for (k=0;k<4;k=k+1) cont[20+k]=(value>>(k*8))&8'hFF;
            counts={8'd0,maps_per_class,maps_per_class,maps_per_class};
            for (k=0;k<4;k=k+1) cont[24+k]=(counts>>(k*8))&8'hFF;
            cur_len=128+76800+metadata_bytes+28032;
        end
    endtask

    task run_check_selector;
        integer k;
        begin
            @(negedge clk); chk_start = 1'b1;
            @(negedge clk); chk_start = 1'b0;
            for (k = 0; k < 8192; k = k + 1) begin
                @(negedge clk);
                chk_valid = 1'b1;
                chk_data = mem[24'h670000 + k];
                @(posedge clk);
                guard = 0;
                while (!chk_ready && guard < 100000) begin
                    @(posedge clk); guard = guard + 1;
                end
                @(negedge clk);
                chk_valid = 1'b0;
            end
            guard = 0;
            while (!chk_done && guard < 100000) begin
                @(posedge clk); guard = guard + 1;
            end
            if (!chk_done) begin $display("FAIL selector done timeout"); $fatal; end
        end
    endtask

    task expect_msg(input [7:0] want);
        reg [7:0] got;
        begin
            host_recv(got);
            if (got !== want) begin
                $display("FAIL message want %02x got %02x", want, got);
                $fatal;
            end
        end
    endtask

    task expect_ok2(input [7:0] a, input [7:0] b);
        reg [7:0] got;
        begin
            host_recv(got);
            if (got !== a) begin $display("FAIL want %02x got %02x", a, got); $fatal; end
            host_recv(got);
            if (got !== b) begin $display("FAIL want %02x got %02x", b, got); $fatal; end
        end
    endtask

    // ---------------- stimulus ----------------
    initial begin : main
        integer k;
        reg [7:0] m;

        rst_n = 1'b0;
        repeat (20) @(posedge clk);
        rst_n = 1'b1;
        repeat (20) @(posedge clk);

        // -------- generation 1: blank journal, target B --------
        cur_len = 121600;
        for (k = 0; k < 32; k = k + 1) cur_sha[k] = 8'h70 + k[7:0];
        idle_ok = 1'b0;
        send_header;
        expect_ok2(8'h45, 8'd2);            // drain the header, then busy
        repeat (4) @(posedge clk);
        if (busy) begin $display("FAIL busy after busy-reject response"); $fatal; end
        idle_ok = 1'b1;

        cur_len = 104960;
        send_header;
        expect_ok2(8'h45, 8'd1);            // reject before scanning/erase
        repeat (4) @(posedge clk);
        if (busy) begin $display("FAIL still busy after short-container error"); $fatal; end

        cur_len = 121600;
        for (k = 0; k < 32; k = k + 1) cur_sha[k] = 8'hA0 + k[7:0];
        for (k = 0; k < cur_len; k = k + 1) cont[k] = (k * 7 + 3) & 255;
        set_current_container_header(16'd3,8'd2,32'd384);

        send_header;
        expect_msg(8'h52);                  // 'R' after erase
        send_container;
        expect_msg(8'h43);                  // 'C'
        begin : read_c
            reg [7:0] got;
            host_recv(got); if (got !== 8'h01) begin $display("FAIL slot %02x", got); $fatal; end
            host_recv(got); if (got !== 8'h01) begin $display("FAIL gen0 %02x", got); $fatal; end
            host_recv(got); if (got !== 8'h00) begin $display("FAIL gen1 %02x", got); $fatal; end
            host_recv(got); if (got !== 8'h00) begin $display("FAIL gen2 %02x", got); $fatal; end
            host_recv(got); if (got !== 8'h00) begin $display("FAIL gen3 %02x", got); $fatal; end
        end
        if (active_valid !== 1'b1 || active_slot !== 1'b1 || active_gen !== 32'd1) begin
            $display("FAIL active outputs"); $fatal;
        end

        // slot B content
        for (k = 0; k < cur_len; k = k + 1)
            if (mem[24'h640000 + k] !== cont[k]) begin
                $display("FAIL slot B byte %0d got %02x want %02x",
                         k, mem[24'h640000 + k], cont[k]); $fatal;
            end
        for (k = cur_len; k < cur_len + 16; k = k + 1)
            if (mem[24'h640000 + k] !== 8'hFF) begin
                $display("FAIL slot B padding %0d", k); $fatal;
            end

        // journal record
        if (mem[24'h670000] !== 8'h50 || mem[24'h670001] !== 8'h35 ||
            mem[24'h670002] !== 8'h30 || mem[24'h670003] !== 8'h53 ||
            mem[24'h670004] !== 8'h45 || mem[24'h670005] !== 8'h4C ||
            mem[24'h670006] !== 8'h30 || mem[24'h670007] !== 8'h31) begin
            $display("FAIL journal magic"); $fatal;
        end
        if (mem[24'h670008] !== 8'h01 || mem[24'h670009] !== 8'h00) begin
            $display("FAIL journal version"); $fatal;
        end
        if (mem[24'h67000C] !== 8'h01 || mem[24'h67000D] !== 8'h00 ||
            mem[24'h67000E] !== 8'h00 || mem[24'h67000F] !== 8'h00) begin
            $display("FAIL journal generation"); $fatal;
        end
        if (mem[24'h670010] !== 8'h01) begin $display("FAIL journal slot"); $fatal; end
        if (mem[24'h670014] !== (cur_len & 255) ||
            mem[24'h670015] !== ((cur_len >> 8) & 255) ||
            mem[24'h670016] !== ((cur_len >> 16) & 3)) begin
            $display("FAIL journal length"); $fatal;
        end
        for (k = 0; k < 32; k = k + 1)
            if (mem[24'h670018 + k] !== cur_sha[k]) begin
                $display("FAIL journal sha byte %0d", k); $fatal;
            end
        begin : body_crc_check
            reg [31:0] body_crc;
            body_crc = mem_crc(24'h670000, 56);
            if (mem[24'h670038] !== (body_crc & 255) ||
                mem[24'h670039] !== ((body_crc >> 8) & 255) ||
                mem[24'h67003A] !== ((body_crc >> 16) & 255) ||
                mem[24'h67003B] !== ((body_crc >> 24) & 255)) begin
                $display("FAIL journal body crc"); $fatal;
            end
        end
        if (mem[24'h67003C] !== 8'h43 || mem[24'h67003D] !== 8'h4D ||
            mem[24'h67003E] !== 8'h54 || mem[24'h67003F] !== 8'h31) begin
            $display("FAIL commit word"); $fatal;
        end

        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b1 || chk_gen !== 32'd1) begin
            $display("FAIL selector after gen1"); $fatal;
        end

        // -------- torn commit: clear the commit word --------
        for (k = 0; k < 4; k = k + 1) mem[24'h67003C + k] = 8'hFF;
        run_check_selector;
        if (chk_active_valid) begin $display("FAIL torn commit selected"); $fatal; end

        // -------- corrupted body CRC --------
        mem[24'h67003C] = 8'h43; mem[24'h67003D] = 8'h4D;
        mem[24'h67003E] = 8'h54; mem[24'h67003F] = 8'h31;
        mem[24'h670030] = mem[24'h670030] ^ 8'h01;
        run_check_selector;
        if (chk_active_valid) begin $display("FAIL corrupt body selected"); $fatal; end
        mem[24'h670030] = mem[24'h670030] ^ 8'h01;
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b1 || chk_gen !== 32'd1) begin
            $display("FAIL selector restore"); $fatal;
        end

        // -------- generation 2: target A --------
        cur_len = 121600;
        for (k = 0; k < 32; k = k + 1) cur_sha[k] = 8'h10 + k[7:0];
        for (k = 0; k < cur_len; k = k + 1) cont[k] = (k * 13 + 5) & 255;
        set_current_container_header(16'd3,8'd2,32'd384);
        send_header;
        expect_msg(8'h52);
        send_container;
        expect_msg(8'h43);
        host_recv(m); // slot
        if (m !== 8'h00) begin $display("FAIL gen2 slot"); $fatal; end
        host_recv(m); if (m !== 8'h02) begin $display("FAIL gen2 value"); $fatal; end
        for (k = 0; k < 3; k = k + 1) host_recv(m);
        if (active_slot !== 1'b0 || active_gen !== 32'd2) begin
            $display("FAIL gen2 active outputs"); $fatal;
        end
        for (k = 0; k < cur_len; k = k + 1)
            if (mem[24'h610000 + k] !== cont[k]) begin
                $display("FAIL slot A byte %0d", k); $fatal;
            end
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b0 || chk_gen !== 32'd2) begin
            $display("FAIL selector after gen2"); $fatal;
        end

        // -------- reject a committed but undersized selector entry --------
        // A short container could underflow the display asset base address.
        write_selector_record(2, 32'd3, 1'b1, 18'd1, 8'h70);
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b0 || chk_gen !== 32'd2 ||
            chk_invalid_count !== 8'd1) begin
            $display("FAIL undersized selector entry was not rejected"); $fatal;
        end

        // -------- refuse a valid-CRC container with incompatible map counts --------
        cur_len = 121600;
        for (k = 0; k < 32; k = k + 1) cur_sha[k] = 8'h30 + k[7:0];
        for (k = 0; k < cur_len; k = k + 1) cont[k] = (k * 17 + 9) & 255;
        set_current_container_header(16'd3,8'd1,32'd384);
        send_header;
        expect_msg(8'h52);
        send_container;
        expect_ok2(8'h45, 8'd1);
        if (active_slot !== 1'b0 || active_gen !== 32'd2) begin
            $display("FAIL incompatible map counts changed active selector"); $fatal;
        end
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b0 || chk_gen !== 32'd2) begin
            $display("FAIL incompatible map counts committed to selector"); $fatal;
        end

        // -------- refuse a v1 package even when its transport CRC is valid --------
        for (k = 0; k < 32; k = k + 1) cur_sha[k] = 8'h60 + k[7:0];
        for (k = 0; k < cur_len; k = k + 1) cont[k] = (k * 23 + 11) & 255;
        set_current_container_header(16'd1,8'd2,32'd384);
        send_header;
        expect_msg(8'h52);
        send_container;
        expect_ok2(8'h45,8'd1);
        if (active_slot !== 1'b0 || active_gen !== 32'd2) begin
            $display("FAIL incompatible container version changed active selector"); $fatal;
        end
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b0 || chk_gen !== 32'd2) begin
            $display("FAIL incompatible container version committed to selector"); $fatal;
        end

        // -------- newest valid entry in the final journal slot --------
        write_selector_record(127, 32'd3, 1'b1, 18'd121600, 8'h40);
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b1 || chk_gen !== 32'd3) begin
            $display("FAIL selector final record promotion"); $fatal;
        end

        // -------- conflicting highest generation ends at final slot --------
        write_selector_record(126, 32'd3, 1'b0, 18'd121600, 8'h50);
        run_check_selector;
        if (!chk_active_valid || chk_slot !== 1'b0 || chk_gen !== 32'd2 ||
            chk_conflicts == 0) begin
            $display("FAIL selector final conflict fallback"); $fatal;
        end

        // -------- journal full: no erased record --------
        for (k = 0; k < 8192; k = k + 1) mem[24'h670000 + k] = 8'h00;
        cur_len = 121600;
        send_header;
        expect_ok2(8'h45, 8'd4);            // 'E', journal full
        repeat (4) @(posedge clk);
        if (busy) begin $display("FAIL still busy after error"); $fatal; end

        // -------- exhausted uint32 generation rejects before erase --------
        for (k = 0; k < 8192; k = k + 1) mem[24'h670000 + k] = 8'hFF;
        write_selector_record(0, 32'hFFFFFFFF, 1'b0, 18'd121600, 8'hA0);
        send_header;
        expect_ok2(8'h45, 8'd6);
        repeat (4) @(posedge clk);
        if (busy) begin $display("FAIL busy after generation exhaustion"); $fatal; end

        $display("TEMPLATE_UPDATE_SIM_PASS slot_b_gen1=1 slot_a_gen2=1 page_ack=1 busy_header_drain=1 min_length_reject=1 short_selector_length_reject=1 v2_header_validation=1 map_count_mismatch_reject=1 bad_version_reject=1 torn_commit_ignored=1 crc_corrupt_ignored=1 final_record=1 final_conflict=1 journal_full_reject=1 generation_overflow_reject=1");
        $finish;
    end
endmodule
