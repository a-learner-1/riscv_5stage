`timescale 1ns/1ps
// Actual CPU, softmax, scheduler and post-CNN path. Accelerator arithmetic is
// represented by per-op completions; this test does not measure model accuracy.
module tb_rv32im_realtime_control;
    reg clk=0,rst_n=0;always #5 clk=~clk;
    reg [5:0] keys=6'h3f;
    wire [5:0] commands;
    reg ready=0,core_busy=0,core_done=0,logits_valid=0;
    reg [47:0] logits=0;
    wire listen,motor,work,panel,panel_busy,cs,sclk;
    wire grant,event_valid,probs_valid,job_done,start,accept;
    wire [3:0] event_class;
    wire [95:0] probs;
    wire [8:0] start_op,end_op;
    wire [31:0] signature,isa;
    reg template_valid=0;reg [1:0] template_class=0;
    reg [15:0] template_score=0;
    integer op_count=0,remaining=0,lastop=0,job_class=0,tft_edges=0;
    wire [3:0] display=control.backend.path.alerts.display_class_o;
    mn04_rv32im_control #(.CLOCK_HZ(100000)) cpu(
        .clk(clk),.rst_n(rst_n),.key_n_i(keys),.boot_ready_i(1'b1),.codec_ready_i(1'b1),
        .recognition_i(listen),.capture_busy_i(1'b0),.recording_i(1'b0),.alert_i(motor),
        .snapshot_ready_i(ready),.job_done_i(job_done),.cnn_valid_i(probs_valid),.cnn_probabilities_i(probs),
        .template_valid_i(template_valid),.template_class_i(template_class),.template_score_i(template_score),
        .capture_category_i(4'd5),.template_slot_mask_i(15'd0),.template_commit_i(1'b0),
        .command_key_n_o(commands),.job_authorized_o(grant),.template_slot_o(),
        .event_valid_o(event_valid),.event_class_o(event_class),.firmware_signature_o(signature),
        .command_count_o(),.irq_count_o(),.isa_selftest_o(isa));
    mn04_six_class_realtime_control #(.CURRENT_FIVE_CLASS_MODE(1),.CPU_TASK_CONTROL(1),
        .UNIFORM_120_WINDOW_MODE(1),.CLOCK_HZ(100000),.SPI_HZ(25000),
        .SOFTMAX_LUT_FILE("C:/Studying_file/pango50_sound_alert_v1/training/output/pc_five_class_fixed120_deployment_20261024/softmax_exp_q24_six_class.mem"),
        .BABY_THRESHOLD_Q16(59637),.KNOCK_THRESHOLD_Q16(47841),
        .EMERGENCY_VEHICLE_THRESHOLD_Q16(49152),.CAR_HORN_THRESHOLD_Q16(29491),
        .RESET_CYCLES(4),.PWR_DELAY_CYCLES(4),.DISPLAY_DELAY_CYCLES(4)) control(
        .clk(clk),.rst_n(rst_n),.short_snapshot_ready_i(ready),.short_snapshot_mode_i(2'd0),
        .core_busy_i(core_busy),.core_done_i(core_done),.core_logits_valid_i(logits_valid),.core_logits_i(logits),
        .window_quiet_i(1'b0),
        .template_result_valid_i(template_valid),.template_result_class_i(template_class),
        .cpu_job_authorized_i(grant),.cpu_event_valid_i(event_valid),.cpu_event_class_i(event_class),
        .cpu_probs_valid_o(probs_valid),.cpu_job_done_o(job_done),.cpu_probs_o(probs),
        .display_asset_we_i(1'b0),.display_asset_addr_i(15'd0),.display_asset_data_i(8'd0),
        .work_key_n_i(commands[0]),.confirm_key_n_i(commands[1]),.uart_rx_i(1'b1),
        .template_preview_i(1'b0),.template_preview_class_i(4'd0),.external_task_busy_i(1'b0),
        .set_time_i(1'b0),.set_hour_i(8'd0),.set_minute_i(8'd0),.set_second_i(8'd0),
        .core_start_o(start),.core_start_op_o(start_op),.core_end_op_o(end_op),
        .core_short_window_o(),.core_context_short_o(),.core_class_window_mode_o(),
        .short_snapshot_accept_o(accept),.short_result_valid_o(),.motor_o(motor),.recognition_enable_o(listen),
        .work_mode_o(work),.panel_ready_o(panel),.panel_busy_o(panel_busy),.tft_nrst_o(),.tft_backlight_o(),
        .tft_sclk_o(sclk),.tft_mosi_o(),.tft_dc_o(),.tft_cs_n_o(cs));
    always @(posedge sclk) if(!cs && motor) tft_edges=tft_edges+1;
    always @(posedge clk) if(rst_n) begin
        core_done<=0;logits_valid<=0;
        if(start) begin
            if(start_op==0 && !grant) $fatal(1,"accelerator bypassed CPU grant");
            if(start_op!=op_count%91) $fatal(1,"op sequence mismatch %0d %0d",start_op,op_count);
            core_busy<=1;remaining<=8;lastop<=start_op;op_count<=op_count+1;ready<=0;
        end
        if(remaining>0) remaining<=remaining-1;
        if(remaining==1) begin
            core_busy<=0;core_done<=1;
            if(lastop==90) begin
                logits<=48'h808080808080;
                logits[job_class*8+:8]<=8'd80;
                logits_valid<=1;
            end
        end
    end
    task press;input integer key;begin
        @(negedge clk);keys[key]=0;repeat(9000) @(negedge clk);
        keys[key]=1;repeat(9000) @(negedge clk);
    end endtask
    task start_listen;begin press(0);if(!listen) $fatal(1,"CPU start did not enable listener");end endtask
    task clear;begin press(1);if(motor || listen) $fatal(1,"CPU confirmation did not clear");end endtask
    task await_output;input integer expected;integer timeout;begin
        timeout=0;
        while(!motor && timeout<20000) begin @(negedge clk);timeout=timeout+1;end
        if(!motor || display!==expected) $fatal(1,"CPU routed event failed expected=%0d display=%0d motor=%b",expected,display,motor);
        repeat(10000) @(negedge clk);
        if(tft_edges==0) $fatal(1,"no TFT traffic for CPU-decided alert");
    end endtask
    integer i;
    initial begin
        repeat(8) @(negedge clk);rst_n=1;repeat(20000) @(negedge clk);
        if(signature!==32'h56584d32 || isa!==32'h4d554c44) $fatal(1,"CPU failed boot");
        wait(panel);repeat(2000) @(negedge clk);
        for(i=0;i<5;i=i+1) begin
            start_listen();job_class=i;@(negedge clk);ready=1;
            if(i==0) begin repeat(20000) @(negedge clk);if(motor) $fatal(1,"background alarm");end
            else await_output(i==4?5:i);
            clear();
        end
        for(i=1;i<=3;i=i+1) begin
            start_listen();@(negedge clk);template_class=i;template_score=30000;template_valid=1;
            @(negedge clk);template_valid=0;await_output(i+7);clear();
        end
        if(op_count!=455 || cpu.overrun_count!=0) $fatal(1,"job count or mailbox overrun %0d/%0d",op_count,cpu.overrun_count);
        $display("RV32IM_REALTIME_CONTROL_PASS classes=5 pure_templates=3 ops=455 CPU_admission_IRQ_softmax_decision=1 TFT_motor_ack=1 background_reject=1");
        $finish;
    end
    initial begin #100000000;$fatal(1,"CPU integration timeout");end
endmodule
