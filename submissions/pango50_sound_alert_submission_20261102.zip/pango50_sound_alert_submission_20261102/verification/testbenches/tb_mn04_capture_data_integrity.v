`timescale 1ns/1ps
// Two different takes, two different DDR slots, one class-batched UART export.
// Pre-filled DDR sentinels make stale/wrong-region reads fail byte by byte.
module tb_mn04_capture_data_integrity #(parameter integer DIAGNOSTICS=0);
    reg clk=0,rst_n=0,start=0,stop=0,advance=0;
    always #5 clk=~clk;
    reg [7:0] x0=0;
    reg xvalid=0;
    wire recording,busy,stream,freeze,uart_tx;
    wire [23:0] base;
    wire [3:0] category;
    wire [9:0] next_slot;
    wire frame_done,drained,overflow;
    wire [27:0] awaddr,araddr,da,dr;
    wire awvalid,awready,wvalid,wready,wlast,bvalid,bready;
    wire arvalid,arready,rvalid,rready;
    wire [255:0] wd,rd,hw,hr;
    wire [31:0] ws,hws;
    wire [1:0] br,rr;
    wire ha,hv,hwready,hra,hrv,hrvalid,hrlast;
    wire [3:0] halen,hrlen;
    integer take,frame,mel,n,cycles=0,received=0,write_count=0,read_count=0;
    reg [7:0] got [0:65535];
    function [7:0] value(input integer t,input integer f,input integer m);
        value=(t*71+f*5+m*3)&255;
    endfunction
    mn04_train_capture #(.CNN_CLASS_COUNT(5),.ENABLE_TEMPLATE_CAPTURE(1),
        .CLOCK_HZ(1152000),.BAUD(115200),.EXPORT_CAPTURE_TO_HOST(1),
        .CAPTURE_DIAGNOSTICS(DIAGNOSTICS)) cap(
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),.template_mode_i(1'b0),
        .category_advance_i(advance),.local_capture_start_i(start),.local_capture_stop_i(stop),
        .overflow_i({1'b0,overflow}),.uart_tx_o(uart_tx),.freeze_o(freeze),
        .live_feature_i(x0),.live_feature_valid_i(xvalid&&recording),
        .live_pcm_i({x0,8'h5a}),.live_pcm_valid_i(xvalid&&recording),
        .task_busy_o(busy),.stream_phase_o(stream),.recording_o(recording),
        .selected_category_o(category),.capture_ring_base_o(base),.selected_class_full_o(),
        .freeze_ack_i(freeze),.ring_drained_i(drained),.ring_frame_done_i(frame_done),
        .ring_next_slot_i(next_slot),.ddr_araddr_o(araddr),.ddr_arvalid_o(arvalid),
        .ddr_arready_i(arready),.ddr_rdata_i(rd),.ddr_rresp_i(rr),.ddr_rvalid_i(rvalid),.ddr_rready_o(rready));
    mn04_x0_writer #(.N_FRAMES(1000),.CONTINUOUS(1)) writer(
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),.overflow_clear_i(start),
        .x0_valid_i(xvalid&&recording),.x0_data_i(x0),.x0_ready_o(),.x0_base_byte_i(base),
        .done_o(),.frame_done_o(frame_done),.next_frame_slot_o(next_slot),.overflow_o(overflow),
        .ddr_awaddr_o(awaddr),.ddr_awvalid_o(awvalid),.ddr_awready_i(awready),
        .ddr_wdata_o(wd),.ddr_wstrb_o(ws),.ddr_wvalid_o(wvalid),.ddr_wlast_o(wlast),
        .ddr_wready_i(wready),.ddr_bresp_i(br),.ddr_bvalid_i(bvalid),.ddr_bready_o(bready),.drained_o(drained));
    mn04_axi4_ddr_bridge bridge(
        .clk(clk),.rst_n(rst_n),.s_awaddr(awaddr),.s_awlen(4'd0),.s_awvalid(awvalid),.s_awready(awready),
        .s_wdata(wd),.s_wstrb(ws),.s_wvalid(wvalid),.s_wlast(wlast),.s_wready(wready),
        .s_bresp(br),.s_bvalid(bvalid),.s_bready(bready),
        .s_araddr(araddr),.s_arlen(4'd0),.s_arvalid(arvalid),.s_arready(arready),
        .s_rdata(rd),.s_rresp(rr),.s_rlast(),.s_rvalid(rvalid),.s_rready(rready),
        .d_awaddr(da),.d_awlen(halen),.d_awvalid(hv),.d_awready(ha),
        .d_wdata(hw),.d_wstrb(hws),.d_wready(hwready),
        .d_araddr(dr),.d_arlen(hrlen),.d_arvalid(hrv),.d_arready(hra),
        .d_rdata(hr),.d_rlast(hrlast),.d_rvalid(hrvalid));
    mn04_ddr_behav #(.MEM_BYTES(6291456),.RD_LATENCY(9)) mem(
        .clk(clk),.rst_n(rst_n),.awaddr_i(da),.awlen_i(halen),.awvalid_i(hv),.awready_o(ha),
        .wdata_i(hw),.wstrb_i(hws),.wready_o(hwready),.araddr_i(dr),.arlen_i(hrlen),
        .arvalid_i(hrv),.arready_o(hra),.rdata_o(hr),.rlast_o(hrlast),.rvalid_o(hrvalid));
    wire [7:0] rxbyte;
    wire rxvalid;
    uart_rx_8n1 #(.CLOCK_HZ(1152000),.BAUD(115200)) rx(
        .clk(clk),.rst_n(rst_n),.rx_i(uart_tx),.data_o(rxbyte),.valid_o(rxvalid));
    always @(posedge clk) begin
        if(rxvalid) begin got[received]=rxbyte;received=received+1;end
        if(awvalid&&awready) write_count=write_count+1;
        if(arvalid&&arready) read_count=read_count+1;
        if(overflow) $fatal(1,"feature writer overflow");
        cycles=cycles+1;
        if(cycles>12000000) $fatal(1,"capture integrity timeout state=%0d received=%0d",cap.state,received);
    end
    integer offset,len,checksum,slot0,frames0,slots[0:1],lengths[0:1];
    initial begin
        #1;
        for(n='h540000;n<'h580000;n=n+1) mem.mem[n]=8'he7;
        repeat(5) @(negedge clk);rst_n=1;
        for(take=0;take<2;take=take+1) begin
            @(negedge clk);start=1;
            @(negedge clk);start=0;
            wait(recording);slots[take]=next_slot;lengths[take]=take==0?121:133;
            if(base!==('h540000+take*128000)) $fatal(1,"wrong write bank %h",base);
            for(frame=0;frame<lengths[take];frame=frame+1) begin
                if(frame==lengths[take]-1) begin
                    @(negedge clk);stop=1;@(negedge clk);stop=0;
                end
                for(mel=0;mel<128;mel=mel+1) begin
                    @(negedge clk);xvalid=1;x0=value(take,frame,mel);
                end
                @(negedge clk);xvalid=0;
                wait(frame_done);@(negedge clk);
            end
            wait(!busy);
            if(cap.record_frames[take]!==lengths[take] || cap.record_start_slot[take]!==slots[take])
                $fatal(1,"wrong record metadata take=%0d frames=%0d start=%0d",take,cap.record_frames[take],cap.record_start_slot[take]);
            for(mel=0;mel<128;mel=mel+1) for(frame=0;frame<lengths[take];frame=frame+1)
                if(mem.mem['h540000+take*128000+mel*1000+(slots[take]+frame)%1000]!==value(take,frame,mel))
                    $fatal(1,"DDR capture mismatch take=%0d mel=%0d frame=%0d",take,mel,frame);
            $display("CAPTURE_DDR_TAKE_PASS take=%0d frames=%0d start_slot=%0d base=%h",take,lengths[take],slots[take],base);
        end
        @(negedge clk);advance=1;@(negedge clk);advance=0;
        wait(!busy);repeat(200) @(negedge clk);
        offset=0;
        for(take=0;take<2;take=take+1) begin
            len=lengths[take]*128;
            if(got[offset]!==8'haa || got[offset+1]!==8'h55 || got[offset+2]!==0 ||
               {got[offset+5],got[offset+4],got[offset+3]}!==len)
                $fatal(1,"UART header mismatch take=%0d",take);
            checksum=0;
            for(mel=0;mel<128;mel=mel+1) for(frame=0;frame<lengths[take];frame=frame+1) begin
                n=offset+9+mel*lengths[take]+frame;
                if(got[n]!==value(take,frame,mel))
                    $fatal(1,"UART feature mismatch take=%0d mel=%0d frame=%0d got=%h expected=%h",take,mel,frame,got[n],value(take,frame,mel));
                checksum=checksum^got[n];
            end
            if(got[offset+9+len]!==checksum[7:0] || got[offset+10+len]!==8'h5a)
                $fatal(1,"UART trailer mismatch");
            offset=offset+len+11;
            if(DIAGNOSTICS) begin
                if(got[offset+2]!==8'hfd || got[offset+3]!==64 ||
                   {got[offset+12],got[offset+11],got[offset+10],got[offset+9]}!==32'h31304443)
                    $fatal(1,"diagnostic header/magic mismatch");
                checksum=0;
                for(n=0;n<64;n=n+1) checksum=checksum^got[offset+9+n];
                if(got[offset+73]!==checksum[7:0] || got[offset+74]!==8'h5a)
                    $fatal(1,"diagnostic trailer mismatch");
                offset=offset+75;
            end
        end
        if(got[offset+2]!==8'hfe || got[offset+8]!==2 || received!==offset+11)
            $fatal(1,"UART class batch marker mismatch bytes=%0d expected=%0d",received,offset+11);
        $display("CAPTURE_DATA_INTEGRITY_PASS takes=2 differing_features=1 feature_bytes=%0d UART_bytes=%0d writes=%0d reads=%0d no_stale_sentinel=1",254*128,received,write_count,read_count);
        $writememh("uart_bytes.hex",got,0,received-1);
        $finish;
    end
endmodule
