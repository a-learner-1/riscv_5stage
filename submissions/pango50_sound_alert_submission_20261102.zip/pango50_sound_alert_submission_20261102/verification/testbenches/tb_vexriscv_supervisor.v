`timescale 1ns/1ps
module tb_vexriscv_supervisor;
    reg clk=0,rst_n=0,boot=0,codec=0,listen=0,busy=0,recording=0,alert=0;
    reg [5:0] keys=6'h3f;
    wire [5:0] commands;
    wire [31:0] signature,count;
    always #5 clk=~clk;
    mn04_vexriscv_supervisor #(.CLOCK_HZ(10000)) dut(
        .clk(clk),.rst_n(rst_n),.key_n_i(keys),.boot_ready_i(boot),.codec_ready_i(codec),
        .recognition_i(listen),.capture_busy_i(busy),.recording_i(recording),.alert_i(alert),
        .command_key_n_o(commands),.firmware_signature_o(signature),.command_count_o(count));
    task press;
        input [5:0] mask;
        input [5:0] expected;
        integer i;
        reg [5:0] seen;
        begin
            seen=0;@(negedge clk);keys=~mask;
            for(i=0;i<400;i=i+1) begin @(negedge clk);seen=seen|~commands;end
            keys=6'h3f;
            for(i=0;i<700;i=i+1) begin @(negedge clk);seen=seen|~commands;end
            if(seen!==expected) $fatal(1,"firmware admission mismatch keys=%b expected=%b got=%b",mask,expected,seen);
        end
    endtask
    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        repeat(300) @(negedge clk);
        if(signature!==32'h56583531) $fatal(1,"CPU did not execute firmware");
        press(1,0);boot=1;codec=1;
        press(1,1);listen=1;
        press(8,0);press(32,0);
        listen=0;press(8,8);busy=1;recording=1;
        press(4,0);press(16,16);busy=0;recording=0;
        press(32,32);press(4,4);
        alert=1;press(1,0);press(2,2);alert=0;
        press(9,1);
        if(count!==7) $fatal(1,"unexpected command count %0d",count);
        $display("VEXRISCV_SUPERVISOR_PASS firmware_exec=1 boot_gate=1 admission=1 capture_stop=1 confirm=1 simultaneous_keys=1 commands=%0d",count);
        $finish;
    end
    initial begin #2000000;$fatal(1,"VexRiscv watchdog");end
endmodule
