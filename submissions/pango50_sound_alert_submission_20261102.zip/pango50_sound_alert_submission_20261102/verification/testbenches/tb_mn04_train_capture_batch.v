`timescale 1ns/1ps
module tb_mn04_train_capture_batch #(parameter integer CNN_CLASS_COUNT=6,
                                     parameter integer CPU_CONTROL=0);
    localparam integer CLOCK_HZ=1152000, BAUD=115200, KEY_CLOCK_HZ=10000;
    localparam integer MEL_BINS=2, RING_FRAMES=8;
    localparam integer MIN_FRAMES=2, MAX_FRAMES=8, MAX_RECORDS=2;
    localparam [23:0] BATCH_BASE=24'h540000;

    reg clk=0,rst_n=0,ddr_init_done=0;
    reg category_key_n=1,start_key_n=1,stop_key_n=1,mode_key_n=1;
    wire category_advance,start,stop,template_mode;
    reg [1:0] overflow=0;
    wire uart_tx,freeze,busy,stream_phase,recording,full;
    wire [3:0] selected_category;
    wire [23:0] capture_ring_base;
    reg freeze_ack=0,ring_drained=0,ring_frame_done=0;
    reg [9:0] ring_next_slot=0;
    wire [27:0] cap_araddr;
    wire cap_arvalid,cap_rready;
    reg cap_arready=0;
    reg [255:0] cap_rdata=0;
    reg [1:0] cap_rresp=0;
    reg cap_rvalid=0;
    integer category,takes=0;

    always #5 clk=~clk;
    wire [5:0] control_keys;
    generate if(CPU_CONTROL) begin:g_cpu
        mn04_vexriscv_supervisor #(.CLOCK_HZ(KEY_CLOCK_HZ)) supervisor(
            .clk(clk),.rst_n(rst_n),
            .key_n_i({mode_key_n,stop_key_n,start_key_n,category_key_n,2'b11}),
            .boot_ready_i(ddr_init_done),.codec_ready_i(1'b1),.recognition_i(1'b0),
            .capture_busy_i(busy),.recording_i(recording),.alert_i(1'b0),
            .command_key_n_o(control_keys),.firmware_signature_o(),.command_count_o());
    end else begin:g_direct
        assign control_keys={mode_key_n,stop_key_n,start_key_n,category_key_n,2'b11};
    end endgenerate
    mn04_board_capture_keys #(.CLOCK_HZ(KEY_CLOCK_HZ)) keys (
        .clk(clk),.rst_n(rst_n),
        .category_key_n_i(control_keys[2]),.start_key_n_i(control_keys[3]),
        .stop_key_n_i(control_keys[4]),.mode_key_n_i(control_keys[5]),
        .recognition_enable_i(1'b0),
        .capture_busy_i(busy),.capture_recording_i(recording),
        .category_advance_o(category_advance),.template_mode_o(template_mode),
        .preview_enable_o(),.capture_start_o(start),.capture_stop_o(stop));

    mn04_train_capture #(
        .BATCH_BASE_BYTE(BATCH_BASE),.MEL_BINS(MEL_BINS),
        .RING_FRAMES(RING_FRAMES),.MAX_CAPTURE_FRAMES(MAX_FRAMES),
        .MIN_CAPTURE_FRAMES(MIN_FRAMES),.MAX_RECORDS(MAX_RECORDS),
        .CNN_CLASS_COUNT(CNN_CLASS_COUNT),.ENABLE_TEMPLATE_CAPTURE(1),
        .CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD),.TX_FIFO_DEPTH(4),
        .EXPORT_CAPTURE_TO_HOST(0)
    ) dut (
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(ddr_init_done),
        .template_mode_i(template_mode),.category_advance_i(category_advance),
        .local_capture_start_i(start),.local_capture_stop_i(stop),
        .overflow_i(overflow),.uart_tx_o(uart_tx),.freeze_o(freeze),
        .task_busy_o(busy),.stream_phase_o(stream_phase),
        .recording_o(recording),.selected_category_o(selected_category),
        .capture_ring_base_o(capture_ring_base),.selected_class_full_o(full),
        .freeze_ack_i(freeze_ack),.ring_drained_i(ring_drained),
        .ring_frame_done_i(ring_frame_done),.ring_next_slot_i(ring_next_slot),
        .ddr_araddr_o(cap_araddr),.ddr_arvalid_o(cap_arvalid),
        .ddr_arready_i(cap_arready),.ddr_rdata_i(cap_rdata),
        .ddr_rresp_i(cap_rresp),.ddr_rvalid_i(cap_rvalid),
        .ddr_rready_o(cap_rready));

    task pulse_frame;
        begin
            @(negedge clk);ring_frame_done=1;
            @(negedge clk);ring_frame_done=0;
            repeat(2) @(negedge clk);
        end
    endtask
    task press_k4;
        begin
            @(negedge clk);category_key_n=0;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
            category_key_n=1;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
        end
    endtask
    task press_k5;
        begin
            @(negedge clk);start_key_n=0;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
            start_key_n=1;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
        end
    endtask
    task press_k6;
        begin
            @(negedge clk);stop_key_n=0;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
            stop_key_n=1;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
        end
    endtask
    task press_key7;
        begin
            @(negedge clk);mode_key_n=0;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
            mode_key_n=1;
            repeat(CPU_CONTROL ? 700 : 240) @(negedge clk);
        end
    endtask
    task capture_take(input [23:0] expected_base,input [9:0] next_slot);
        begin
            if(selected_category>=CNN_CLASS_COUNT+3 || full)
                $fatal(1,"invalid or full selected category %0d",selected_category);
            press_k5();
            repeat(2) @(negedge clk);
            if(!recording || capture_ring_base!==expected_base)
                $fatal(1,"record did not start in selected category %0d base=%h expected=%h",
                    selected_category,capture_ring_base,expected_base);
            pulse_frame();
            press_k6();
            pulse_frame();
            wait(freeze);
            ring_next_slot=next_slot;
            freeze_ack=1;ring_drained=1;
            wait(!busy);
            freeze_ack=0;ring_drained=0;
            repeat(2) @(negedge clk);
            if(dut.record_count[selected_category]<1 ||
               dut.record_frames[selected_category*MAX_RECORDS]!=2)
                $fatal(1,"local recording metadata not committed for category %0d",selected_category);
            takes=takes+1;
        end
    endtask

    initial begin
        repeat(5) @(negedge clk);rst_n=1;
        repeat(4) @(negedge clk);ddr_init_done=1;
        if(selected_category!==0 || full) $fatal(1,"CNN background must be the default");

        // Two same-class captures occupy adjacent DDR slots.
        capture_take(BATCH_BASE,10'd4);
        capture_take(BATCH_BASE+16,10'd6);
        press_k4();
        if(selected_category!==1 || busy) $fatal(1,"K4 must advance locally to CNN class 1");
        for(category=1;category<CNN_CLASS_COUNT;category=category+1) begin
            if(selected_category!==category)
                $fatal(1,"CNN category selection mismatch expected=%0d got=%0d",category,selected_category);
            capture_take(BATCH_BASE+category*MAX_RECORDS*MEL_BINS*RING_FRAMES,
                         (10'd4+category*2)%RING_FRAMES);
            press_k4();
            if(category<CNN_CLASS_COUNT-1 && selected_category!==category+1)
                $fatal(1,"K4 skipped CNN category %0d",category+1);
        end
        if(selected_category!==0) $fatal(1,"CNN category counter must wrap to background");

        // KEY7 selects the three pure-template classes; K4 cycles among them.
        press_key7();
        if(!template_mode || selected_category!==CNN_CLASS_COUNT)
            $fatal(1,"template family must begin at category 6, got %0d",selected_category);
        for(category=CNN_CLASS_COUNT;category<CNN_CLASS_COUNT+3;category=category+1) begin
            if(selected_category!==category)
                $fatal(1,"template category selection mismatch expected=%0d got=%0d",category,selected_category);
            capture_take(BATCH_BASE+category*MAX_RECORDS*MEL_BINS*RING_FRAMES,10'd4);
            press_k4();
        end
        if(selected_category!==CNN_CLASS_COUNT || !template_mode)
            $fatal(1,"template category counter must wrap to doorbell");

        repeat(2000) @(negedge clk);
        if(takes!=CNN_CLASS_COUNT+4 || busy || recording || cap_arvalid ||
           dut.tx_fifo_count!=0 || uart_tx!==1'b1)
            $fatal(1,"local capture did not settle with host export disabled");
        for(category=0;category<CNN_CLASS_COUNT+3;category=category+1) begin
            if(dut.record_count[category]!=(category==0 ? 2 : 1))
                $fatal(1,"category %0d local DDR take count mismatch",category);
        end
        if(CNN_CLASS_COUNT==6)
            $display("NINE_CATEGORY_LOCAL_CAPTURE_PASS ids=0..8 cnn=6 pure_templates=3 takes=%0d uart_export=disabled idle=1",takes);
        $display("LOCAL_CATEGORY_CAPTURE_PASS categories=%0d cnn=%0d pure_templates=3 takes=%0d uart_export=disabled idle=1",CNN_CLASS_COUNT+3,CNN_CLASS_COUNT,takes);
        $finish;
    end
    initial begin #3000000;$fatal(1,"NINE_CATEGORY_CAPTURE_WATCHDOG takes=%0d",takes);end
endmodule
