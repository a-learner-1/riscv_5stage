`timescale 1ns/1ps
module tb_mn04_uniform120_snapshot_manager;
    reg clk=0, rst_n=0, enable=0, frame_done=0, accept=0, dma_busy=0, dma_done=0, epoch_reset=0;
    reg [9:0] next_slot=0;
    wire dma_start,ready;
    wire [1:0] dma_mode,ready_mode;
    wire [9:0] dma_slot;
    integer i, watchdog;
    always #5 clk=~clk;

    mn04_class_window_snapshot_manager #(.UNIFORM_120_WINDOW(1)) dut(
        .clk(clk),.rst_n(rst_n),.epoch_reset_i(epoch_reset),
        .recognition_enable_i(enable),.frame_done_i(frame_done),
        .next_frame_slot_i(next_slot),.snapshot_accept_i(accept),
        .dma_busy_i(dma_busy),.dma_done_i(dma_done),
        .dma_start_o(dma_start),.dma_window_mode_o(dma_mode),
        .dma_next_frame_slot_o(dma_slot),.snapshot_ready_o(ready),
        .snapshot_window_mode_o(ready_mode));

    task frame_pulses(input integer count);
        begin
            for(i=0;i<count;i=i+1) begin
                @(negedge clk); frame_done=1; next_slot=(next_slot==999)?0:next_slot+1'b1;
                @(negedge clk); frame_done=0;
            end
        end
    endtask

    task expect_window(input integer gap,input [9:0] expected_end_slot);
        begin
            frame_pulses(gap);
            watchdog=0;
            while(!dma_start && watchdog<5) begin @(negedge clk); watchdog=watchdog+1; end
            if(!dma_start) $fatal(1,"uniform-120 snapshot request timeout gap=%0d",gap);
            if(dma_mode!==2'd1) $fatal(1,"mode=%0d expected=1 (120-frame)",dma_mode);
            if(dma_slot!==expected_end_slot)
                $fatal(1,"ring slot=%0d expected=%0d",dma_slot,expected_end_slot);
            @(negedge clk); accept=0;
            repeat(2) @(negedge clk);
            dma_done=1;
            @(negedge clk); dma_done=0;
            #1;
            if(!ready || ready_mode!==2'd1)
                $fatal(1,"snapshot-ready mode=%0d ready=%b expected mode 1",ready_mode,ready);
            @(negedge clk); accept=1;
        end
    endtask

    initial begin
        repeat(4) @(negedge clk); rst_n=1; enable=1; accept=1;
        frame_pulses(400);
        if (dma_start || dut.pending_r!=0) $fatal(1,"request during warmup");
        expect_window(120,10'd520);
        expect_window(60,10'd580);
        expect_window(60,10'd640);
        expect_window(60,10'd700);
        expect_window(60,10'd760);
        expect_window(60,10'd820);
        expect_window(60,10'd880);
        expect_window(60,10'd940);
        expect_window(60,10'd0);
        // Rearming must discard pending history and repeat the full warmup.
        @(negedge clk); epoch_reset=1;
        @(negedge clk); epoch_reset=0;
        frame_pulses(400);
        if (dma_start || dut.pending_r!=0) $fatal(1,"request during rearm warmup");
        expect_window(120,10'd520);
        expect_window(60,10'd580);
        $display("UNIFORM_120_SNAPSHOT_MANAGER_PASS classes=all-five window=120 hop=60 warmup=400 ring-wrap epoch-rearm");
        $finish;
    end
    initial begin #200000; $fatal(1,"uniform snapshot manager watchdog"); end
endmodule
