`timescale 1ns/1ps
module tb_probe;
reg clk=0,rst_n=0,start=0,valid=0,req=0;always #5 clk=~clk;
reg [7:0] data=0;reg[17:0] term=0;
wire loaded,rv;wire[7:0] a,b,c,d;wire[1:0] lane;
mn04_weight_block_cache dut(.clk(clk),.rst_n(rst_n),.load_start_i(start),.flash_base_i(24'd0),.loaded_o(loaded),.qspi_start_o(),.qspi_addr_o(),.qspi_count_o(),.qspi_byte_i(data),.qspi_byte_valid_i(valid),.qspi_byte_ready_o(),.weight_offset_i(12'd0),.req_valid_i(req),.req_ready_o(),.term_index_i(term),.rsp_valid_o(rv),.byte_lane_o(lane),.w0_o(a),.w1_o(b),.w2_o(c),.w3_o(d));
integer i;
initial begin
  repeat(4) @(negedge clk); rst_n=1;
  start=1; @(negedge clk); start=0;
  // first word = 11 22 33 44 at addresses 0..3
  for(i=0;i<4096;i=i+1) begin
    valid=1; data = (i==0)?8'h11:(i==1)?8'h22:(i==2)?8'h33:(i==3)?8'h44:8'h00;
    @(negedge clk);
  end
  valid=0; wait(loaded);
  term=0; req=1; @(negedge clk); req=0; @(negedge clk);
  $display("PROBE w0=%02h w1=%02h w2=%02h w3=%02h lane=%0d",a,b,c,d,lane);
  $finish;
end
endmodule