`timescale 1ns/1ps
// MN04 write-backpressure verification testbench (GATE6/DDR bridge).
//
// Exercises mn04_core + mn04_wmerge_bridge against a BOUNDED-backpressure DDR
// write model: the core's byte writes go through the write-merge FIFO, and the
// DDR write port (mn04_act_mem) accepts writes only in windows then stalls for
// BP_STALL cycles.  The core's requant starts are gated on the bridge
// wr_ready, so it must stall safely instead of dropping writes.
//
// Correctness gate: run the FIRST conv op (op0), which reads only the
// preloaded x0 and writes a fresh output region (no intra-op read-after-write),
// drain the bridge fully, then dump the f0_out region and compare byte-exact
// to the golden bin.  A match proves no write is lost / reordered / corrupted
// under bounded DDR write backpressure.  The tb also reports the overhead
// (cycle delta vs an unstalled run) and the bridge fill / stall statistics.
module tb_mn04_bp #(
    parameter CLIP_TAG     = "baby_cry_baby_cry_001.wav",
    parameter OP_FILE      = "op_desc.mem",
    parameter IMAGE_HEX    = "image.hex",
    parameter X0_HEX       = "x0_baby_cry_baby_cry_001.wav.hex",
    parameter LUTS_BASE    = 24'h0,
    parameter N_OPS        = 91,
    parameter MAX_CYCLES   = 20000000,
    parameter OUT_DIR      = "out",
    parameter DUMP_GEOM    = "dump_geom.mem",
    parameter BRIDGE_DEPTH = 16,
    parameter STALL_THRESHOLD = 8,
    // DDR write-port bounded backpressure: accept BP_ACCEPT consecutive bytes,
    // then stall for BP_STALL cycles, repeat.
    parameter BP_ACCEPT    = 1,
    parameter BP_STALL     = 7
)();
    reg clk = 0, rst_n = 0;
    reg start_i = 0;
    wire busy_o, done_o;
    wire [23:0] flash_rd_addr_o;
    wire [7:0]  flash_rd_data_i;
    wire qspi_cs, qspi_sck, qspi_mosi;

    wire        wr_en_o; wire [23:0] wr_addr_o; wire [7:0] wr_data_o;
    wire        wr_ready_o;
    wire        rd_req_valid_o; wire [23:0] rd_byte_addr_o;
    wire        rd_rsp_valid_i; wire [31:0] rd_data_i; wire [1:0] rd_lane_i;
    wire        dump_valid_o; wire [7:0] dump_id_o; wire [15:0] dump_op_index_o;
    wire [31:0] cycle_count_o;
    wire conv_req_ready = 1'b1;   // read-side stall is verified separately;
                                 // this tb isolates write-backpressure
    wire        mem_wr_en_o; wire [23:0] mem_wr_addr_o; wire [7:0] mem_wr_data_o;
    wire        mem_wr_ready_i;

    // ---- flash model (behavioral SPI-NOR) ----
    reg [7:0] flash_mem [0:24'h100000-1];
    reg [31:0] flash_len_r;
    integer fi;
    initial begin
        $readmemh(IMAGE_HEX, flash_mem);
        fi = 0;
        while (fi < 24'h100000 && flash_mem[fi] !== 8'hx) fi = fi + 1;
        flash_len_r = fi;
        $display("TB: flash loaded %0d bytes", flash_len_r);
    end
    assign flash_rd_data_i = flash_mem[flash_rd_addr_o];

    // ---- DDR write-port backpressure injector ----
    // mem_ready goes high only inside accept windows (1 per BP_ACCEPT drain
    // cycles), low during BP_STALL cycles.  force_drain overrides to drain the
    // bridge before the final dump.
    reg force_drain = 0;
    integer acc_r = 0, stall_r = 0;
    reg mem_ready_r = 1;
    integer drain_events = 0;
    always @(posedge clk) begin
        if (force_drain) mem_ready_r <= 1'b1;
        else if (BP_STALL == 0) mem_ready_r <= 1'b1;   // unstalled reference
        else if (acc_r > 0) begin
            mem_ready_r <= 1'b1; acc_r <= acc_r - 1;
            if (acc_r == 1) stall_r <= BP_STALL;
        end else if (stall_r > 0) begin
            mem_ready_r <= 1'b0; stall_r <= stall_r - 1;
            if (stall_r == 1) acc_r <= BP_ACCEPT;
        end else begin
            mem_ready_r <= 1'b0; acc_r <= BP_ACCEPT;
        end
    end
    initial begin
        acc_r = BP_ACCEPT;
        stall_r = 0;
        mem_ready_r = 1;
    end
    assign mem_wr_ready_i = mem_ready_r;
    // count actual DDR drain cycles (mem_wr_en fired)
    always @(posedge clk) if (mem_wr_en_o) drain_events <= drain_events + 1;

    // ---- DUT ----
    mn04_act_mem #(.DEPTH_BYTES(24'h190000)) u_act (
        .clk(clk), .rst_n(rst_n),
        .wr_en_i(mem_wr_en_o), .wr_addr_i(mem_wr_addr_o), .wr_data_i(mem_wr_data_o),
        .rd_req_valid_i(rd_req_valid_o), .rd_byte_addr_i(rd_byte_addr_o),
        .rd_rsp_valid_o(rd_rsp_valid_i), .rd_data_o(rd_data_i), .rd_lane_o(rd_lane_i)
    );

    mn04_wmerge_bridge #(
        .DEPTH(BRIDGE_DEPTH), .STALL_THRESHOLD(STALL_THRESHOLD)
    ) u_br (
        .clk(clk), .rst_n(rst_n),
        .wr_en_i(wr_en_o), .wr_addr_i(wr_addr_o), .wr_data_i(wr_data_o),
        .wr_ready_o(wr_ready_o),
        .mem_wr_en_o(mem_wr_en_o), .mem_wr_addr_o(mem_wr_addr_o),
        .mem_wr_data_o(mem_wr_data_o), .mem_wr_ready_i(mem_wr_ready_i)
    );

    mn04_core #(
        .OP_FILE(OP_FILE), .N_OPS(N_OPS), .LUTS_BASE(LUTS_BASE),
        .FAST_BYTES(1), .START_OP(0)
    ) u_core (
        .clk(clk), .rst_n(rst_n), .start_i(start_i),
        .segment_start_op_i(9'd0), .segment_end_op_i(N_OPS-1),
        .short_window_i(1'b0),
        .busy_o(busy_o), .done_o(done_o),
        .flash_rd_addr_o(flash_rd_addr_o), .flash_rd_data_i(flash_rd_data_i),
        .qspi_cs_o(qspi_cs), .qspi_sck_o(qspi_sck),
        .qspi_mosi_o(qspi_mosi), .qspi_miso_i(1'b1),
        .conv_req_ready_i(conv_req_ready),
        .scalar_req_ready_i(1'b1),
        .scalar_candidate_valid_o(),.scalar_candidate_addr_o(),
        .wr_en_o(wr_en_o), .wr_addr_o(wr_addr_o), .wr_data_o(wr_data_o),
        .wr_ready_i(wr_ready_o),
        .rd_req_valid_o(rd_req_valid_o), .rd_byte_addr_o(rd_byte_addr_o),
        .rd_rsp_valid_i(rd_rsp_valid_i), .rd_data_i(rd_data_i), .rd_lane_i(rd_lane_i),
        .conv_rd_data_i(rd_data_i), .conv_rd_lane_i(rd_lane_i),
        .dump_valid_o(dump_valid_o), .dump_id_o(dump_id_o),
        .dump_op_index_o(dump_op_index_o), .cycle_count_o(cycle_count_o),
        .logits_valid_o(), .logits_o()
    );

    // ---- x0 pump into REG_A (same layout as tb_mn04_core) ----
    reg [7:0] x0_mem [0:127999];
    integer x0_i, x0_n;
    initial begin
        $readmemh(X0_HEX, x0_mem);
        x0_n = 128000;
        $display("TB: x0 loaded %0d bytes", x0_n);
    end

    // ---- dump geometry (di0: f0_out) ----
    reg [31:0] geom [0:19*5-1];
    initial $readmemh(DUMP_GEOM, geom);

    reg x0_done_r;
    integer k;
    initial begin
        #20 rst_n = 1;
        for (k = 0; k < x0_n; k = k + 1) begin
            @(posedge clk);
            u_act.mem[k] = x0_mem[k];
        end
        x0_done_r = 1;
        $display("TB: x0 pumped into REG_A");
        @(posedge clk);
        start_i = 1;
        @(posedge clk);
        start_i = 0;
    end

    // ---- statistics: core write count, bridge max fill, stall cycles ----
    integer core_writes = 0;
    integer max_fill = 0;
    integer stalled_cycles = 0;
    always @(posedge clk) begin
        if (wr_en_o) core_writes <= core_writes + 1;
        if (u_br.fill_r > max_fill) max_fill <= u_br.fill_r;
        if (!mem_ready_r) stalled_cycles <= stalled_cycles + 1;
    end

    // ---- drain bridge, dump f0_out, compare ----
    reg dump_seen = 0;
    integer fd2, c2, h2, w2;
    reg [31:0] base2, C2, H2, W2;
    initial begin
        base2 = geom[0]; C2 = geom[1]; H2 = geom[2]; W2 = geom[3];
    end
    always @(posedge clk) begin
        if (dump_valid_o && !dump_seen) dump_seen <= 1;
    end
    initial begin
        wait(dump_seen);
        force_drain = 1;
        while (u_br.fill_r != 0) @(posedge clk);   // drain bridge into DDR
        @(posedge clk); @(posedge clk);
        fd2 = $fopen({OUT_DIR, "/rtl_", CLIP_TAG, "_0_0.bin"}, "wb");
        for (c2 = 0; c2 < C2; c2 = c2 + 1)
            for (h2 = 0; h2 < H2; h2 = h2 + 1)
                for (w2 = 0; w2 < W2; w2 = w2 + 1)
                    $fwrite(fd2, "%c", u_act.mem[base2 + ((h2*W2 + w2)*C2) + c2]);
        $fclose(fd2);
        $display("BP: DONE cycle=%0d core_writes=%0d ddr_drains=%0d max_bridge_fill=%0d stalled_cycles=%0d",
                 cycle_count_o, core_writes, drain_events, max_fill, stalled_cycles);
        $finish;
    end

    // ---- clock ----
    always #5 clk = ~clk;

    // ---- watchdog ----
    initial begin
        #(MAX_CYCLES * 64'd10);
        $display("BP: WATCHDOG TIMEOUT after %0d cycles", MAX_CYCLES);
        $finish;
    end
endmodule
