`timescale 1ns/1ps
module tb_mn04_ddr_write_chain;
    reg clk=0, rst_n=0;
    always #5 clk=~clk;
    localparam N=1024;
    reg [15:0] produced=0;
    wire producer_valid, bridge_ready;
    wire [23:0] producer_addr;
    wire [7:0] producer_data;
    wire bridge_valid, writer_ready, writer_drained;
    wire [23:0] bridge_addr;
    wire [7:0] bridge_data;
    wire [27:0] awaddr;
    wire awvalid, awready, wready;
    wire [255:0] wdata;
    wire [31:0] wstrb;
    integer committed=0, i, timeout=0;
    assign producer_valid = produced<N && bridge_ready;
    assign producer_addr = 24'h040000 + ((produced*16'd257) & 16'h7fff);
    assign producer_data = (produced*16'd37 + 16'd11) & 8'hff;
    always @(posedge clk) if (rst_n && producer_valid) produced<=produced+1'b1;
    always @(posedge clk) if (rst_n && awvalid && awready) committed=committed+1;

    mn04_wmerge_bridge bridge(
        .clk(clk),.rst_n(rst_n),
        .wr_en_i(producer_valid),.wr_addr_i(producer_addr),
        .wr_data_i(producer_data),.wr_ready_o(bridge_ready),
        .mem_wr_en_o(bridge_valid),.mem_wr_addr_o(bridge_addr),
        .mem_wr_data_o(bridge_data),.mem_wr_ready_i(writer_ready));
    mn04_ddr_act_byte_writer writer(
        .clk(clk),.rst_n(rst_n),.ddr_init_done_i(1'b1),
        .byte_valid_i(bridge_valid),.byte_addr_i(bridge_addr),
        .byte_data_i(bridge_data),.byte_ready_o(writer_ready),
        .ddr_awaddr_o(awaddr),.ddr_awvalid_o(awvalid),
        .ddr_awready_i(awready),.ddr_wdata_o(wdata),
        .ddr_wstrb_o(wstrb),.ddr_wready_i(wready),
        .drained_o(writer_drained));
    mn04_ddr_behav #(.MEM_BYTES(24'h080000),.RD_LATENCY(4)) ddr(
        .clk(clk),.rst_n(rst_n),
        .awaddr_i(awaddr),.awlen_i(4'd0),.awvalid_i(awvalid),
        .awready_o(awready),.wdata_i(wdata),.wstrb_i(wstrb),
        .wready_o(wready),
        .araddr_i(28'd0),.arlen_i(4'd0),.arvalid_i(1'b0),
        .arready_o(),.rdata_o(),.rlast_o(),.rvalid_o());
    initial begin
        repeat(4) @(negedge clk);
        rst_n=1;
        while ((committed<N || !writer_drained) && timeout<20000) begin
            @(negedge clk); timeout=timeout+1;
        end
        repeat(3) @(negedge clk);
        if (produced!=N || committed!=N) $fatal(1,"write count %0d/%0d",produced,committed);
        for (i=0;i<N;i=i+1)
            if (ddr.mem[24'h040000 + ((i*257) & 16'h7fff)] !== ((i*37+11) & 8'hff))
                $fatal(1,"DDR write mismatch at item %0d",i);
        $display("ACT_WRITE_CHAIN_PASS bytes=%0d cycles=%0d",N,timeout);
        $finish;
    end
    initial begin #300000; $fatal(1,"watchdog"); end
endmodule
