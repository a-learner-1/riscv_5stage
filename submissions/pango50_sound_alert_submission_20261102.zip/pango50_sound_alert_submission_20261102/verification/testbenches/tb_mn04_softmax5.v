`timescale 1ns/1ps
module tb_mn04_softmax5;
    reg clk = 0;
    always #10 clk = ~clk;
    reg rst_n = 0, logits_valid = 0;
    reg [39:0] logits = 0;
    wire probs_valid, busy;
    wire [79:0] probs;
    integer i, total;
    mn04_softmax_q16 #(
        .N_CLASSES(5),
        .LUT_FILE("C:/Studying_file/pango50_sound_alert_v1/firmware/v1_image/softmax_exp_q24.mem")
    ) dut (
        .clk(clk), .rst_n(rst_n), .logits_valid_i(logits_valid),
        .logits_i(logits), .probs_valid_o(probs_valid),
        .probs_q16_o(probs), .busy_o(busy));
    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1;
        logits_valid = 1;
        @(negedge clk);
        logits_valid = 0;
        wait (probs_valid);
        total = 0;
        for (i=0; i<5; i=i+1) begin
            if (probs[i*16 +:16] < 16'd13106 || probs[i*16 +:16] > 16'd13108)
                $fatal(1, "equal-logit class probability mismatch: %0d", probs[i*16 +:16]);
            total = total + probs[i*16 +:16];
        end
        if (total < 65530 || total > 65540) $fatal(1, "probability sum %0d", total);
        $display("SOFTMAX5_PASS total=%0d", total);
        $finish;
    end
    initial begin
        #100000;
        $fatal(1, "softmax5 timeout");
    end
endmodule
