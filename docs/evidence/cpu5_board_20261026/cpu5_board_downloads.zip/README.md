# CPU5 MES50HP 板测下载文件

源码提交：18c8e61fd5d024d41e96792f222c2de8f28fdc95。目标 PGL50H/-6/FBG484，50MHz，UART 115200/8N1。
本包为真实五级 CPU，RV32IM、D0、I/D Cache 各 2KiB、BTB64。两种子各 2000 迭代。
已完成布局布线、位流生成流程的最终 STA 和板级配置功能仿真。尚未下载，尚无 CPU5 正式成绩。

1. 连接并供电 MES50HP；接好 JTAG 和板载 USB-UART。
2. 串口先开始保存完整文本，使用实际 COM 口，115200/8N1/无流控。
3. PDS 下载器选择 CPU5_performance.sbit 作 JTAG SRAM 下载；KEY1 重启运行。
4. 必须收到 COREMARK RESULT: FORMAL PASS、platform=cpu5、run=performance、正确 CRC，raw_ticks >= 500000000。
5. 换 CPU5_validation.sbit 重复，确认 run=validation 和对应 CRC。
6. 保留本包 release_manifest.json、完整 UART 和下载记录；双种子结果齐全后再形成正式成绩。

performance CRC: e9f5/e714/1fd7/8e3a。
validation CRC: 18f2/e3c1/0747/8d84。
SBIT 用于 PDS SRAM 下载。BIN 仅作为同一次生成的配套产物；本步骤不写入板载 Flash。
SHA-256、路由及最终时序见 release_manifest.json。此前的三级 Mperformance/Mvalidation 文件不属于本包。
