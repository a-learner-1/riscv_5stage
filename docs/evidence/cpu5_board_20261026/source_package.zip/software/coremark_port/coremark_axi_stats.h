#ifndef COREMARK_AXI_STATS_H
#define COREMARK_AXI_STATS_H

/* Generated metadata must describe the actual dedicated AXI hardware. */
#if !defined(COREMARK_PLATFORM_NAME) || !defined(COREMARK_ENABLE_ICACHE) || \
    !defined(COREMARK_ENABLE_D0_BRAM) || !defined(COREMARK_DATA_BACKEND_ID) || \
    !defined(COREMARK_ENABLE_DCACHE) || !defined(COREMARK_AXI_STATS_BASE) || \
    !defined(COREMARK_AXI_STATS_ID) || !defined(COREMARK_AXI_CACHE_GEOMETRY) || \
    !defined(COREMARK_ENABLE_BRANCH_PRED) || !defined(COREMARK_BTB_ENTRIES) || \
    !defined(COREMARK_AXI_BP_CONFIG) || !defined(COREMARK_AXI_STATS_SCHEMA) || \
    !defined(COREMARK_AXI_CYCLE_PROFILE_SCHEMA) || \
    !defined(COREMARK_AXI_CYCLE_PROFILE_FIELDS) || \
    !defined(COREMARK_AXI_CYCLE_PROFILE_BITS) || \
    !defined(COREMARK_AXI_CYCLE_PROFILE_START_BANK) || \
    !defined(COREMARK_AXI_CYCLE_PROFILE_STOP_BANK) || \
    !defined(COREMARK_AXI_STATS_WINDOW_BYTES)
#error "Use build_coremark_axi.bat for the dedicated AXI CoreMark port"
#endif
#if (COREMARK_ENABLE_ICACHE != 0 && COREMARK_ENABLE_ICACHE != 1) || \
    (COREMARK_ENABLE_DCACHE != 0 && COREMARK_ENABLE_DCACHE != 1)
#error "Cache switches must be zero or one"
#endif
#if (COREMARK_ENABLE_D0_BRAM != 0 && COREMARK_ENABLE_D0_BRAM != 1) || \
    COREMARK_DATA_BACKEND_ID != COREMARK_ENABLE_D0_BRAM
#error "D0 backend identity must match the selected RAM path"
#endif
#if (COREMARK_ENABLE_BRANCH_PRED != 0 && COREMARK_ENABLE_BRANCH_PRED != 1) || \
    COREMARK_BTB_ENTRIES < 1 || COREMARK_BTB_ENTRIES > 1024 || \
    (COREMARK_BTB_ENTRIES & (COREMARK_BTB_ENTRIES - 1)) != 0
#error "Invalid branch predictor configuration"
#endif
#if COREMARK_AXI_STATS_SCHEMA != 3 || \
    COREMARK_AXI_BP_CONFIG != ((COREMARK_BTB_ENTRIES << 16) | COREMARK_ENABLE_BRANCH_PRED)
#error "CoreMark requires statistics schema 3 and matching BTB configuration"
#endif
#if COREMARK_AXI_CYCLE_PROFILE_SCHEMA != 1 || \
    COREMARK_AXI_CYCLE_PROFILE_FIELDS != 6 || \
    COREMARK_AXI_CYCLE_PROFILE_BITS != 64 || \
    COREMARK_AXI_CYCLE_PROFILE_START_BANK != 0x100 || \
    COREMARK_AXI_CYCLE_PROFILE_STOP_BANK != 0x140 || \
    COREMARK_AXI_STATS_WINDOW_BYTES != 0x200
#error "CoreMark requires the six-field 64-bit cycle profile and a 0x200-byte window"
#endif

#define COREMARK_AXI_EXPECTED_FLAGS \
    (COREMARK_ENABLE_ICACHE | (COREMARK_ENABLE_DCACHE << 1))
#define COREMARK_AXI_START_BANK 0x40u
#define COREMARK_AXI_STOP_BANK  0x80u
#define COREMARK_AXI_BANK_WORDS 16u
#define COREMARK_AXI_BP_START_BANK 0xc0u
#define COREMARK_AXI_BP_STOP_BANK  0xe0u
#define COREMARK_AXI_BP_BANK_WORDS 7u

static ee_u32 coremark_axi_read(ee_u32 offset)
{
    return *(volatile ee_u32 *)(ee_ptr_int)(COREMARK_AXI_STATS_BASE + offset);
}

static ee_u64 coremark_axi_join(ee_u32 low, ee_u32 high)
{
    return ((ee_u64)high << 32) | low;
}
#endif
